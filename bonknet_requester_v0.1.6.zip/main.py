"""
the main for the bonknet requester
"""
import sys
import time
import shlex
import argparse
import pika
from minirpcrequester import MiniRpcRequester
from commands import (
    connect_ssh, connect_vnc, use_scp,
    send_close, send_restart, request_clientlist,
    sshcommand, interactive,
)


def parse_args_tmp():
    """
    parse arguments
    """
    additional_info = """Wildcards:
    REMOTE:       user@remote_id
    REMOTE_IP:    remote_id
    USER:         user
    PORT:         port

Examples:
    $ bonk demotest
        connect to remote "demotest" via ssh
    $ bonk ssh demotest
        the same as the previous
    $ bonk vnc Polnareffland
        connect to remote "Polnareffland" via vnc
    $ bonk scp demotest file_to_copy.txt REMOTE:~/
        copy "file_to_copy.txt" from your computer to the demotest's desktop
    $ bonk scp Polnareffland REMOTE:Downloads/taralli.jpg ~/Pictures
        copy "Downloads/taralli.jpg" from Polnareffland to the local Pictures folder
    $ bonk sshcommand demotest nc REMOTE_IP PORT
        connect to demotest using netcat"""

    global_parser = argparse.ArgumentParser(
        formatter_class=argparse.RawTextHelpFormatter,
        epilog=additional_info
    )
    subparsers = global_parser.add_subparsers(title="subcommands", dest="mode")

    # ssh
    ssh = subparsers.add_parser("ssh", help="connect via ssh to the given remote_id (default)")
    ssh.add_argument("remote_id", help="the name of the remote id")

    # vnc
    vnc = subparsers.add_parser("vnc", help="connect via vnc to the given remote_id")
    vnc.add_argument("remote_id", help="the name of the remote id")
    vnc.add_argument(
        "--no-viewer",
        default=False, action='store_true',
        help="disable the viewer, retrieve only ip and port",
    )

    # scp
    scp = subparsers.add_parser(
        "scp",
        help="send a file from source to remote. This command uses scp syntax and must\n"
        "contain wildcards to work (see examples)."
    )
    scp.add_argument("remote_id", help="the name of the remote id")
    scp.add_argument("source", help="the source to copy from")
    scp.add_argument("target", help="where to copy")

    # sshcommand
    command = subparsers.add_parser(
        "sshcommand",
        help="connect to the remote using the custom command passed ad argument.\n"
        "You must use wildcards to make the command work."
    )
    command.add_argument("remote_id", help="the name of the remote id")
    command.add_argument(
        "command", nargs='+', help="the command you want to use for connecting"
    )

    # request
    request = subparsers.add_parser(
        "request", help="request to the server to open a port for the given remote_id"
    )
    request.add_argument("remote_id", help="the name of the remote id")

    # close
    close = subparsers.add_parser(
        "close", help="request to the server to close the open port for the given remote_id"
    )
    close.add_argument("remote_id", help="the name of the remote id")
    close.add_argument("port", help="the port on the remote you want to close", type=int)

    # restart
    restart = subparsers.add_parser(
        "restart", help="request a restart of the bonk service on remote_id"
    )
    restart.add_argument("remote_id", help="the name of the remote id")

    # clientlist
    subparsers.add_parser(
        "clientlist",
        help="retrieve the list with the clients in use and their ports"
    )

    # interactive
    subparsers.add_parser(
        "interactive",
        help="open the interactive terminal to directly communicate with the relay server"
    )

    # help
    subparsers.add_parser("help", help="show this message")

    argv = sys.argv
    argv.pop(0)
    subcommands = [
        "ssh", "vnc", "scp", "sshcommand",
        "request", "close", "restart", "clientlist",
        "interactive", "help"
    ]
    if len(argv) == 0:
        argv.append("--help")
    elif len(argv) > 0 and argv[0] not in subcommands:
        if "-h" in argv or "--help" in argv:
            argv = ["help"]
        else:
            argv.insert(0, "ssh")
    args = global_parser.parse_args(argv)

    if args.mode == "help":
        global_parser.print_help()
        sys.exit(0)

    return args


def main():
    args = parse_args_tmp()
    mode = args.mode
    rpc = MiniRpcRequester()
    remote_id = f"'{args.remote_id}'" if hasattr(args, 'remote_id') else None

    if mode == "interactive":
        interactive(rpc)
        sys.exit(0)
    if mode == "close":
        sys.exit(send_close(rpc, remote_id, args.port))
    if mode == "restart":
        sys.exit(send_restart(rpc, remote_id))
    if mode == "clientlist":
        sys.exit(request_clientlist(rpc))

    reply = rpc.send(f"REQUEST {remote_id}")
    tokens = shlex.split(reply)

    if tokens[0] != "DONE":
        error = " ".join(tokens[2:])
        print("Error: operation not done: ", error)
        sys.exit(1)

    try:
        if len(tokens) > 3:
            port = tokens[2]
            status_code = None
            for _ in range(15):
                time.sleep(1)
                if mode == "ssh":
                    status_code = connect_ssh(port)
                    if status_code == 255:
                        status_code = None
                elif mode == "vnc":
                    use_viewer = not args.no_viewer
                    status_code = connect_vnc(port, use_viewer)
                elif mode == "scp":
                    status_code = use_scp(port, args.source, args.target)
                elif mode == "sshcommand":
                    status_code = sshcommand(port, args.command)
                elif mode == "request":
                    print(port)
                    port = None
                    status_code = 0
                elif mode != "close":
                    print(f"Unknown mode {mode}")
                    status_code = 1
                if status_code is not None:
                    break
            else:
                print("Cannot connect with the requested client")
        else:
            print("Requested remote id is not available")
    except Exception as exc:
        print(f"got exception: {exc}")
    finally:
        if port is not None:
            try:
                reply = rpc.send(f"CLOSE {remote_id} {port}")
            except pika.exceptions.StreamLostError:
                # Sometimes pika lose the connection during a ssh session. If that happens,
                #  the close request will fail; to prevent this, we need to restore the connection
                #  and send the close
                rpc = MiniRpcRequester()
                reply = rpc.send(f"CLOSE {remote_id} {port}")


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        pass
