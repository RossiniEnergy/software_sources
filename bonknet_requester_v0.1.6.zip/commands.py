"""
Implementation of various commands for the bonknet client
"""
import re
import time
import shlex
import subprocess
from config import BONKNET_SERVER, BONKNET_USER
from minirpcrequester import MiniRpcRequester


def substitute_wildcards(cmd: str, port: int) -> str:
    """
    Take a command as argument and formats it with
    """
    return cmd \
        .replace("REMOTE_IP", f"{BONKNET_SERVER}") \
        .replace("REMOTE", f"{BONKNET_USER}@{BONKNET_SERVER}") \
        .replace("USER", f"{BONKNET_USER}")                     \
        .replace("PORT", f"{port}")


def connect_ssh(port: int):
    """
    Connect via ssh to the requested port
    """
    proc = subprocess.Popen([
        "ssh", "-o StrictHostKeychecking=no", "-o LogLevel=quiet",
        "-p", f"{port}", f"{BONKNET_USER}@{BONKNET_SERVER}"
    ])
    return proc.wait()


def connect_vnc(port: int, start_viewer: bool):
    """
    Connect via vnc to the requested port
    """
    time.sleep(2)
    bridge_cmd = (
        f"ssh -L 5900:localhost:5900 {BONKNET_USER}@{BONKNET_SERVER} -p {port} -N -f " +
        "-o StrictHostKeychecking=no -o LogLevel=quiet"
    )
    ssh_res = subprocess.run(shlex.split(bridge_cmd), check=False).returncode
    no_viewer = False

    print("Attempting to connect..", end='', flush=True)
    failure_counter = 0
    while failure_counter < 10 and ssh_res == 255:
        if failure_counter % 3 == 0:
            print(".", end='', flush=True)
        ssh_res = subprocess.run(shlex.split(bridge_cmd), check=False).returncode
        failure_counter = failure_counter + 1
        time.sleep(0.5)
    print("")

    if ssh_res != 0:
        print(f"Error - cannot create a connection with remote (error code {ssh_res})")
    else:
        try:
            if start_viewer:
                try:
                    vnc_res = subprocess.run(
                        ["vncviewer", "localhost::5900"], check=True
                    ).returncode
                except FileNotFoundError:
                    print("vncviewer executable not found")
                    no_viewer = True
            if not start_viewer or no_viewer:
                print("Bridge to the remote opened\n"
                      "ip:   localhost\n"
                      "port: 5900\n"
                      "Example: vncviewer localhost::5900")
                print("Press Ctrl-C to close the bridge")
                while True:
                    try:
                        time.sleep(120)
                    except KeyboardInterrupt:
                        break
        except Exception as exc:
            print(f"Got exception while opening vnc subprocess: {exc}")

    pgrep = subprocess.Popen(
        ("pgrep", "-f", bridge_cmd), stdout=subprocess.PIPE, stderr=subprocess.STDOUT
    )
    head = subprocess.Popen(
        ("head", "-1"), stdin=pgrep.stdout, stdout=subprocess.PIPE, stderr=subprocess.STDOUT
    )
    try:
        pid = int(subprocess.check_output(('awk', '"{print $2}"'), stdin=head.stdout,))
        pgrep.stdout.close()
    except ValueError:
        return -1

    try:
        print("killin'")
        subprocess.run(('kill', f'{pid}'), check=True)
    except subprocess.CalledProcessError:
        subprocess.run(('kill', '-9', f'{pid}'), check=False)
    return vnc_res


def use_scp(port: int, source: str, target: str):
    """
    Copy a file from/to the remote
    """
    source = substitute_wildcards(source, port)
    target = substitute_wildcards(target, port)
    return subprocess.run([
        "scp", "-o StrictHostKeychecking=no", "-o LogLevel=quiet", f'-P {port}', source, target
    ], check=False).returncode


def send_close(rpc: MiniRpcRequester, remote_id: str, port: int):
    """
    Send a CLOSE message to the server
    """
    reply = rpc.send(f"CLOSE {remote_id} {port}")
    tokens = shlex.split(reply)
    if tokens[0] != "DONE":
        error = " ".join(tokens[2:])
        print(f"Error: {error}")
        return -1
    return 0


def send_restart(rpc: MiniRpcRequester, remote_id: str):
    """
    Ask a remote to restart
    """
    reply = rpc.send(f"RESTART {remote_id}")
    tokens = shlex.split(reply)
    if tokens[0] != "DONE":
        error = " ".join(tokens[3:])
        print(f"Error: {error}")
        return -1
    if len(tokens) == 3:
        print(
            "Warning - the remote did not respond to the message. It could require a couple of "
            "minutes for the restart to be effective"
        )
    return 0


def request_clientlist(rpc: MiniRpcRequester):
    """
    Request the clientlist to the server
    """
    reply = rpc.send("CLIENTLIST")
    tokens = shlex.split(reply)
    if tokens[0] != "DONE":
        error = " ".join(tokens[2:])
        print(f"Error: {error}")
        return -1
    ipsum_regex = re.compile("^IP(\d+)")

    def clean_str(str):
        return str.strip(",").strip("[").strip("]")

    to_ignore = ['SERVER', 'name']
    parks = [clean_str(token) for token in tokens[2:] if ("amq." not in token and clean_str(token) not in to_ignore)]
    parks.sort(key=str.casefold)
    ipsums = [ipsum_regex.match(park)[0] for park in parks if ipsum_regex.match(park)]
    parks = [park for park in parks if not ipsum_regex.match(park)]
    border = '#' * 30
    parks_string = "\n# {:^26} #\n".format("Park list")
    ipsums_string = "\n# {:^26} #\n".format("Ipsum list")
    print(border+parks_string+border)
    for park in parks:
        print(park)

    print('\n'+border+ipsums_string+border)
    for ipsum in ipsums:
        print(ipsum)
    return 0


def interactive(rpc: MiniRpcRequester):
    """
    Run the interactive console
    """
    print("Starting interactive console - press Ctrl-D or Ctrl-C to exit")
    while True:
        try:
            query = input('command: ')
            reply = rpc.send(query)
            print(f"response: {reply}")
        except EOFError:
            break


def sshcommand(port: int, commands: list):
    """
    Connects to the remote using a custom command
    """
    full_command = substitute_wildcards(" ".join(commands), port)

    return subprocess.run(shlex.split(full_command), check=False).returncode
