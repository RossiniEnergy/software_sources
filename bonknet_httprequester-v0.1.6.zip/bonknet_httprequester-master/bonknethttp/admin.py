from django.contrib import admin
from .models import BonkHTTPSession

admin.site.register(BonkHTTPSession)
