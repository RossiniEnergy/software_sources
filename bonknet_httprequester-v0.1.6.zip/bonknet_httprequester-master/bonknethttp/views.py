import uuid
import logging
import pika
import json
import shlex
import datetime
import pytz
from pika.exceptions import AMQPError
from dateutil.parser import isoparse
from django.conf import settings
from django.http import HttpResponse
from django.db.models import DurationField, F, ExpressionWrapper

from base64 import b64decode
# noinspection PyPackageRequirements
from Crypto.Cipher import ChaCha20
# noinspection PyPackageRequirements
from Crypto.Hash import HMAC, SHA256

from .models import BonkHTTPSession

logger = logging.getLogger('api.views')


class MiniRpcRequester(object):
    def __init__(self):
        logger.info("Starting connection")
        self.connection = pika.BlockingConnection(
            pika.URLParameters(
                f'AMQP_URL'
                '?blocked_connection_timeout=15'))
        logger.info("Connected")
        self.response = None
        self.corr_id = None
        self.channel = self.connection.channel()
        logger.info("Channel Created")

        result = self.channel.queue_declare(queue='', exclusive=True)
        logger.info("Queue created")
        self.callback_queue = result.method.queue

        self.channel.basic_consume(
            queue=self.callback_queue,
            on_message_callback=self.on_response,
            auto_ack=True)
        logger.info("Callback set")

    def on_response(self, ch, _method, props, body):
        logger.info("Reply receieved")
        if self.corr_id == props.correlation_id:
            self.response = body

    def send(self, msg):
        self.response = None
        self.corr_id = str(uuid.uuid4())
        logger.info("Publishing...")
        self.channel.basic_publish(
            exchange='requester-board',
            routing_key='SERVER',
            properties=pika.BasicProperties(
                reply_to=self.callback_queue,
                correlation_id=self.corr_id,
            ),
            body=bytes(msg, 'ascii'))
        logger.info("Published")
        while self.response is None:
            self.connection.process_data_events()
        logger.info("Response while completed")
        # noinspection PyUnresolvedReferences
        return self.response.decode('utf8')


def open_bonk(request):
    """
    { 'encoded': 'stringa codificata in base64',
    'nonce': 'nounce usato per ChaCha20 in base64',
    'mac': 'HMAC generato SHA256' }

    { 'isodatetime': 'classica datetime in ISO8601 con timezone', 'parkname': 'nomeparco' }
    """
    encoded_data = json.loads(request.body)
    # Extract data to decode
    logger.info("Extracting and decoding")
    try:
        encoded = b64decode(encoded_data['encoded'])
        nonce = b64decode(encoded_data['nonce'])
        mac = encoded_data['mac']
        # Decode with ChaCha20
        cipher = ChaCha20.new(key=settings.CHACHA20_KEY, nonce=nonce)
        decoded = cipher.decrypt(encoded)
    except (ValueError, KeyError):
        msg = "Error during decrypting"
        logger.warning(msg)
        return HttpResponse(msg, status=403)
    # Do HMAC check on decoded data
    logger.info("HMAC Check")
    h = HMAC.new(settings.HMAC_SECRET, digestmod=SHA256)
    h.update(decoded)
    try:
        h.hexverify(mac)
    except ValueError:
        msg = "Error checking the HMAC"
        logger.warning(msg)
        return HttpResponse(msg, status=403)
    # Continue with the validated data
    logger.info("Use validated data")
    data = json.loads(decoded)
    now = datetime.datetime.now(pytz.UTC)
    isodatetime = data['isodatetime']
    parkname = data['parkname']
    # Check timestamp
    timestamp = isoparse(isodatetime)
    delay = max(now, timestamp) - min(now, timestamp)
    if delay >= datetime.timedelta(minutes=10):
        msg = f"Datetime used for verification: {now} - max delay 10 minutes"
        return HttpResponse(msg, status=403)
    # Send Command
    try:
        logger.info("Opening connection with Bonk")
        rpc = MiniRpcRequester()
        logger.info(f"Sending message to Bonk for parkname {parkname}")
        reply = rpc.send(f"REQUEST {parkname}")
        logger.info("Reply received!")
    except AMQPError:
        msg = "Error during AMPQ-RPC connection"
        logger.error(msg)
        return HttpResponse(msg, status=500)
    tokens = shlex.split(reply)
    if len(tokens) <= 3:
        # "Requested remote id is not available"
        msg = "Requested remote id is not available"
        logger.info(msg)
        return HttpResponse(msg, status=403)
    port = tokens[2]
    logger.info("Writing session on the database")
    BonkHTTPSession.objects.create(
        parkname=parkname,
        port=port,
    )
    msg = f"Occupied port {port} for remote id {parkname}"
    logger.info(msg)
    return HttpResponse(port)


def check_and_close_session():
    now = datetime.datetime.now(pytz.UTC)
    query = BonkHTTPSession.objects\
        .annotate(elapsed=ExpressionWrapper(now - F('last_heartbeat'), output_field=DurationField()))\
        .filter(elapsed__gt=settings.AUTO_CLOSE_DELAY)
    rpc = MiniRpcRequester()
    for session in query:
        # Manually check with the server if the connection is still open
        try:
            reply = rpc.send(f"ISCONNECTEDON {session.parkname} {session.port}")
        except AMQPError:
            msg = f"Error during AMPQ-RPC isavailable, skipping {session.parkname}:{session.port}"
            logger.error(msg)
            continue
        tokens = shlex.split(reply)
        # reply => f'DONE ISCONNECTEDON {avail}
        if len(tokens) >= 3 and tokens[0] == 'DONE' and tokens[1] == 'ISCONNECTEDON':
            if tokens[2] == "FALSE":
                # The connection was already closed. Just dump the line on the db
                query.delete()
            elif tokens[2] == "TRUE":
                # RUN CLOSE
                try:
                    close_reply = rpc.send(f"CLOSE {session.parkname} {session.port}")
                except AMQPError:
                    msg = f"Error during AMPQ-RPC, skipping {session.parkname}:{session.port}"
                    logger.warning(msg)
                    continue
                tokens = shlex.split(close_reply)
                if len(tokens) >= 2 and tokens[0] == 'DONE' and tokens[1] == 'CLOSE':
                    logger.info(f"SCHEDULER: Closed for {session.parkname}:{session.port}")
                    query.delete()
                else:
                    msg = f"SCHEDULER: Unexpected reply from a CLOSE: {reply}"
                    logger.info(msg)
            else:
                msg = f"SCHEDULER: unexpected error during ISCONNECTEDON: {reply}"
                logger.error(msg)
        else:
            msg = f"SCHEDULER: unexpected error during ISCONNECTEDON: {reply}"
            logger.error(msg)


def isonline_bonk(request):
    data = json.loads(request.body)
    parkname = data['parkname']
    try:
        rpc = MiniRpcRequester()
        reply = rpc.send(f"ISONLINE {parkname}")
    except AMQPError:
        msg = f"Error during AMPQ-RPC connection for {parkname}"
        logger.error(msg)
        return HttpResponse(msg, status=500)
    tokens = shlex.split(reply)
    if len(tokens) >= 2 and tokens[0] == 'DONE' and tokens[1] == 'ISONLINE':
        return HttpResponse(tokens[2])


def close_bonk(request):
    data = json.loads(request.body)
    parkname = data['parkname']
    port = data['port']
    query = BonkHTTPSession.objects.filter(parkname=parkname, port=port)
    count = query.count()
    if count == 1:
        try:
            rpc = MiniRpcRequester()
            reply = rpc.send(f"CLOSE {parkname} {port}")
        except AMQPError:
            msg = f"Error during AMPQ-RPC connection for {parkname}:{port}"
            logger.error(msg)
            return HttpResponse(msg, status=500)
        tokens = shlex.split(reply)
        if len(tokens) >= 2 and tokens[0] == 'DONE' and tokens[1] == 'CLOSE':
            query.delete()
            return HttpResponse()
        else:
            msg = f"Unexpected reply from a CLOSE: {reply}"
            logger.error(msg)
            return HttpResponse(msg, status=403)
    elif count == 0:
        msg = f"Received close for an invalid parkname-port combination ({parkname}-{port})"
        logger.info(msg)
        return HttpResponse(msg, status=403)
    else:
        msg = f"Internal conflict, more non-unique combination of {parkname}-{port}. Check DB integrity"
        logger.critical(msg)
        return HttpResponse(msg, status=500)


def heartbeat(request):
    data = json.loads(request.body)
    now = datetime.datetime.now(pytz.UTC)
    parkname = data['parkname']
    port = data['port']
    query = BonkHTTPSession.objects.filter(parkname=parkname, port=port)
    count = query.count()
    if count == 1:
        query.update(last_heartbeat=now)
        return HttpResponse()
    elif count == 0:
        msg = f"Received heartbeat for an invalid parkname-port combination ({parkname}-{port})"
        logger.info(msg)
        return HttpResponse(msg, status=403)
    else:
        msg = f"Internal conflict, more non-unique combination of {parkname}-{port}. Check DB integrity"
        logger.critical(msg)
        return HttpResponse(msg, status=500)


def dumpdb(_request):
    data = BonkHTTPSession.objects.order_by('id').values()
    return HttpResponse(str(data))
