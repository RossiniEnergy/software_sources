from django.urls import path

from .views import open_bonk, close_bonk, heartbeat, dumpdb, isonline_bonk

urlpatterns = [
    path('bonknet/open/', open_bonk),
    path('bonknet/close/', close_bonk),
    path('bonknet/heartbeat/', heartbeat),
    path('bonknet/isonline/', isonline_bonk),
    path('dumpdb/', dumpdb),
]
