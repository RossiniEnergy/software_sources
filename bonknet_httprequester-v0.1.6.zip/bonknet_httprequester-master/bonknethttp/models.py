from django.db import models


class BonkHTTPSession(models.Model):
    parkname = models.CharField(max_length=100)
    port = models.IntegerField(null=True)
    last_heartbeat = models.DateTimeField(auto_now_add=True)
