import logging
import argparse
from time import sleep
import os

import pika

from clientrpccontroller import ClientRpcController
from clientsmanager import ClientsManager
from portrangemanager import PortRangeManager
from requesterconsumer import ReconnectingRequesterConsumer

from config import PIKA_URL

# REMEMBER TO DO ON THE MACHINE:
# /etc/ssh/sshd_config
# GatewayPorts yes


clients_manager = ClientsManager(PortRangeManager(7220, 8000))

# LOG_FORMAT = ('%(levelname) -10s %(asctime)s %(name) -30s %(funcName) '
#               '-35s %(lineno) -5d: %(message)s')
LOG_FORMAT = '[%(asctime)s|%(levelname)s]: %(message)s'
LOGGER = logging.getLogger(__name__)


def channels_list():
    cmd = "rabbitmqctl list_queues -p bonknet"
    LOGGER.info(f"asking rabbitmq for the client list")
    output = os.popen(cmd).read().split('\n')
    lst = [x.split('\t')[0] for x in output[2:]]
    LOGGER.info(f"got list of {len(lst)} items")
    # proc = subprocess.Popen(shlex.split(cmd), shell=True, stdout=subprocess.PIPE)
    # lst = proc.stdout.read()
    return [item for item in lst if (item is not None and len(item) > 0)]


def message_elaboration(args, channel, properties):
    header = args[0]
    if header == 'REQUEST':  # parkname
        parkname = args[1]
        LOGGER.info(f"got a REQUEST for park {parkname}")
        # try connection
        conn = ClientRpcController(parkname)
        try:
            port = clients_manager.new_client(parkname)
            # send order to client
            LOGGER.info(f"requested connection to {parkname}:{port}")
            client_response = conn.send(f"CONNECT {port}")
            # check and reply to requester
            if len(client_response) == 0:
                response = f"NOTDONE CONNECT 'request for {parkname}:{port} timed out'" 
                LOGGER.info(f"request for {parkname}:{port} timed out")
                clients_manager.remove_client(parkname, port)
            else:
                response = f"DONE CONNECT {port} '{client_response}'"
                LOGGER.info(f"park {parkname}, port {port} responded '{client_response}'")
        except Exception as exc:
            response = f'NOTDONE CONNECT {exc}'
            LOGGER.warning(
                f"error during the request of connection with park {parkname}, port {port}"
            )
    elif header == 'CLOSE':  # parkname
        parkname = args[1]
        try:
            port = int(args[2])
            LOGGER.info(f"got a CLOSE for park {parkname}, port {port}")
            # send command
            conn = ClientRpcController(parkname)
            client_response = conn.send(f"DISCONNECT {port}")
            clients_manager.remove_client(parkname, port)
            response = f'DONE CLOSE {client_response}'
        except ValueError:
            LOGGER.error(f"Error - {args[2]} is not an integer")
            response = f'NOTDONE CLOSE Expected an integer, got {args[2]}'
        except Exception as exc:
            LOGGER.error(f"Error - got exception: {exc}")
            response = 'NOTDONE CLOSE Generic error'
    elif header == 'RESTART':
        parkname = args[1]
        LOGGER.info(f"got a RESTART for park {parkname}")
        conn = ClientRpcController(parkname)
        client_response = conn.send("RESTART")
        LOGGER.info(f"restart request sent, response is {client_response}")
        sleep(3)
        response = f'DONE RESTART {parkname} {client_response}'
    elif header == 'CLIENTLIST':
        LOGGER.info("got CLIENTLIST")
        clients = channels_list()
        LOGGER.info("got client list, sending...")
        response = f"DONE CLIENTLIST {clients}"
    elif header == 'PORTLIST':
        LOGGER.info("got PORTLIST")
        clientlist = clients_manager.get_connected_dict()
        LOGGER.info("clientlist retrieved, sending...")
        response = f'DONE PORTLIST {clientlist}'
    elif header == 'ISAVAILABLE':  # TODO: change to retrieve a list of ports open for a parkname
        parkname = args[1]
        LOGGER.info(f"got ISAVAILABLE for park {parkname}")
        avail = str(parkname not in clients_manager).upper()
        LOGGER.info(f"park {parkname} is available: {avail}")
        response = f'DONE ISAVAILABLE {avail}'
    else:
        LOGGER.error(f"got unknown command \"{header}\"")
        response = 'UNKNOWKN COMMAND'
    channel.basic_publish(exchange='',
                          routing_key=properties.reply_to,
                          properties=pika.BasicProperties(correlation_id=properties.correlation_id),
                          body=bytes(response, 'ascii'))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--verbose', '-v', action="count", default=0,
        help="Increase verbosity; repeat max 5 times to set to maximum verbosity"
    )
    parser.add_argument(
        '--pika-logs', '-p', action="store_true", default=False, help="Enable pika logs"
    )
    args = parser.parse_args()

    verbosity = 5 - min(max(args.verbose, 0), 5)
    log_level = {
        0: logging.NOTSET,
        1: logging.DEBUG,
        2: logging.INFO,
        3: logging.WARNING,
        4: logging.ERROR,
        5: logging.CRITICAL
    }[verbosity]

    logging.basicConfig(level=log_level, format=LOG_FORMAT)

    if not args.pika_logs:
        logging.getLogger("requesterconsumer").setLevel(logging.ERROR)
        logging.getLogger("pika").setLevel(logging.ERROR)


    consumer = ReconnectingRequesterConsumer(PIKA_URL, message_elaboration)
    print(" [x] Awaiting RPC requests")
    consumer.run()
