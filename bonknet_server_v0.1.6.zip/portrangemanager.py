import threading


# THREAD-SAFE
class PortRangeManager:
    def __init__(self, port_min, port_max):
        assert port_min < port_max
        self.port_min = port_min
        self.port_max = port_max
        self.port_occupied = set()
        self.lock = threading.Lock()

    def request_port(self):
        from random import choice
        with self.lock:
            port = choice([i for i in range(self.port_min, self.port_max) if i not in self.port_occupied])
            self.port_occupied.add(port)
        print(f"[PORT MANAGER] {port} occupied.")
        return port

    def free_port(self, port):
        with self.lock:
            if port in self.port_occupied:
                self.port_occupied.remove(port)
        print(f"[PORT MANAGER] {port} released.")
