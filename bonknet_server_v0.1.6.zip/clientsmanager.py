import logging
import threading
from copy import deepcopy

LOGGER = logging.getLogger(__name__ + ".CLIENT")

class ClientsManager:
    def __init__(self, port_manager):
        self.clients = {}
        self.lock = threading.Lock()
        self.port_manager = port_manager

    def new_client(self, parkname):
        with self.lock:
            port = self.port_manager.request_port()
            if parkname in self.clients.keys():
                self.clients[parkname].append(port)
            else:
                self.clients[parkname] = [port]
        LOGGER.info(f"Parkname {parkname} SSH assigned to port {port}")
        return port

    def remove_client(self, parkname, port):
        with self.lock:
            self.port_manager.free_port(port)
            self.clients[parkname].remove(port)
        LOGGER.info(f"Parkname {parkname}, port {port} released")

    def __getitem__(self, item) -> list:
        with self.lock:
            return self.clients[item]

    def get_connected_dict(self) -> {str: list}:
        with self.lock:
            resultlist = {}
            for park, ports in self.clients.items():
                if len(ports) != 0:
                    resultlist[park] = deepcopy(ports)
            return resultlist

    def __contains__(self, item: str):
        with self.lock:
            return item in self.clients.keys()
