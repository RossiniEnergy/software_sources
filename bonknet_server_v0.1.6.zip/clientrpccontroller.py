import datetime
import threading
import time
import uuid

import pika

from config import PIKA_URL


# CAN MANAGE A SINGLE RESPONSE
class ClientRpcController:
    # TODO: Remake with Error management
    def __init__(self, parkname):
        self.connection = pika.BlockingConnection(
            pika.URLParameters(PIKA_URL))
        self.parkname = str(parkname)
        self.response = None
        self.corr_id = None
        self.channel = self.connection.channel()
        self.lock = threading.Lock()

        result = self.channel.queue_declare(queue='', exclusive=True)
        self.callback_queue = result.method.queue

        self.channel.basic_consume(
            queue=self.callback_queue,
            on_message_callback=self.on_response,
            auto_ack=True)

    def on_response(self, _ch, _method, props, body):
        if self.corr_id == props.correlation_id:
            self.response = body

    def send(self, msg):
        with self.lock:
            self.response = None
            self.corr_id = str(uuid.uuid4())
            self.channel.basic_publish(
                exchange='client-board',
                routing_key=self.parkname,
                properties=pika.BasicProperties(
                    reply_to=self.callback_queue,
                    correlation_id=self.corr_id,
                ),
                body=bytes(msg, 'ascii'))
            timeout = datetime.datetime.now() + datetime.timedelta(seconds=30)
            while self.response is None:
                time.sleep(1)
                self.connection.process_data_events(time_limit=10)
                if datetime.datetime.now() > timeout:
                    break
            if self.response:
                return str(self.response)
            else:
                return ""
