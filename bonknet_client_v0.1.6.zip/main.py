import pika
import shlex
import subprocess
import threading
from time import sleep
import logging
import re
import os

from config import SERVER_IP, SERVER_USER, PIKA_URL

LOGGER = logging.getLogger(__name__)
LOG_FORMAT = ('[%(asctime)s|%(levelname)s]: %(message)s')

# RUN BY ROOT BY SERVICE

# REMEMBER TO INCLUDE THE PRIVATE KEY BY COMMANDLINE (-i identityfile)


def formatted_ssh_command(port):
    path_id = "/etc/bonknet-client/relay-node-key"
    full_command = f"ssh -o StrictHostKeychecking=no -R 0.0.0.0:{port}:localhost:22 {SERVER_USER}@{SERVER_IP} -N -i {path_id}"
    return shlex.split(full_command)


class SshHandler:
    # TODO: Various error handling
    def __init__(self):
        self.proc = {}
        self.lock = threading.Lock()

    def new_ssh(self, port):
        with self.lock:
            self.proc[port] = subprocess.Popen(formatted_ssh_command(port))

    def disconnect(self, port):
        with self.lock:
            if len(self.proc) == 0:
                raise Exception
            self.proc[port].terminate()
            del self.proc[port]


handler = SshHandler()


class RestartException(Exception):
    pass


def on_request(ch, method, props, body):
    data = body.decode()
    LOGGER.debug(f"Received message: {data}")
    arguments = data.split(' ')
    header = arguments[0]
    if header == 'CONNECT':
        port = int(arguments[1])
        LOGGER.info(f"Connecting forward SSH bridge on port {port}")
        try:
            handler.new_ssh(port)
            LOGGER.info(f"Connection on port {port} done")
            response = f"DONE CONNECT {port}"
        except Exception:  # FIXME: BETTER PLZ
            response = "NOTDONE CONNECT"
            LOGGER.error(f"Connection on {port} FAILED")
    elif header == 'DISCONNECT':
        port = int(arguments[1])
        try:
            handler.disconnect(port)
            LOGGER.info(f"Disconnection of port {port} succeded")
            response = f"DONE DISCONNECT {port}"
        except Exception:  # FIXME: BETTER PLZ
            LOGGER.error(f"Disconnection of port {port} FAILED")
            response = "NOTDONE DISCONNECT ALREADYDISCONNECTED"
    elif header == 'RESTART':
        # Logging done on a lower level
        LOGGER.info("Requested restart")
        response = "DONE RESTART"
    else:
        LOGGER.warning(f"Got unknown command: {header}")
        response = 'UNKNOWN COMMAND'

    ch.basic_publish(exchange='',
                     routing_key=props.reply_to,
                     properties=pika.BasicProperties(correlation_id=props.correlation_id),
                     body=bytes(response, 'ascii'))
    ch.basic_ack(delivery_tag=method.delivery_tag)

    if header == 'RESTART':
        raise RestartException


def retrieve_parkname():
    if os.path.exists("/etc/standard-raspberry/conf.toml"):
        with open("/etc/standard-raspberry/conf.toml") as conf:
            for line in conf:
                parkname_entry = re.compile("^\s*park_name\s*=\s*\"([A-Za-z0-9_\- ]+)\"\s*")
                match = parkname_entry.match(line)
                if match:
                    return match[1]
    else:
        with open("/etc/ipsum/conf.toml") as conf:
            for line in conf:
                parkname_entry = re.compile("^\s*ipsum_id\s*=\s*(\"|')IP(\d+)\\1.*")
                match = parkname_entry.match(line)
                if match:
                    return "IP" + match[2]
    return "CONFFILEERRORPARK"


# TODO: PLEASE USE LOGGER
# noinspection PyUnresolvedReferences
def main():
    logging.basicConfig(level=logging.DEBUG, format=LOG_FORMAT)
    logging.getLogger("pika").setLevel(logging.WARNING)
    while True:
        parkname = retrieve_parkname()
        LOGGER.info(f"PARKNAME: {parkname}")
        try:
            connection = pika.BlockingConnection(
                pika.URLParameters(PIKA_URL))
            channel = connection.channel()
            channel.queue_declare(queue=parkname, auto_delete=True)
            channel.queue_bind(queue=parkname, exchange='client-board', routing_key=parkname)

            channel.basic_qos(prefetch_count=1)
            channel.basic_consume(queue=parkname, on_message_callback=on_request)
            channel.start_consuming()
        except RestartException:
            LOGGER.warning("Received RESTART command. Reloading parkname and connection.")
            sleep(3)
            LOGGER.warning("Restarting...")
        except pika.exceptions.ConnectionClosedByBroker:
            LOGGER.warning("Connection closed by Broker. Restarting...")
            sleep(3)
            LOGGER.warning("Restarting...")
        except pika.exceptions.AMQPChannelError as err:
            LOGGER.error(f"Channel Error! Aborting for 10 seconds. Error: {err}")
            sleep(10)
            LOGGER.error("Restarting...")
        except pika.exceptions.AMQPConnectionError:
            LOGGER.critical("Connection Error!")
            sleep(3)
            LOGGER.critical("Restarting...")
        finally:
            channel.close()
            connection.close()


if __name__ == '__main__':
    main()
