import setuptools

setuptools.setup(name='ipsum',
                 version='1.0.2',
                 description='ipsum software',
                 author='Rossini energy',
                 author_email='federico@rossinienergy.com',
                 packages=['ipsum', 'ipsum.core', 'ipsum.utils'],
                 package_dir={"": "."},
                 # package_data={"": ["conf.toml", "debug_options.toml"]},
                 # include_package_data=True,
                 entry_points={
                     'console_scripts': [
                         'ipsum = ipsum.__main__:main',
                     ]
                 },
                 install_requires=['pika', 'toml', 'pyserial']
                 )