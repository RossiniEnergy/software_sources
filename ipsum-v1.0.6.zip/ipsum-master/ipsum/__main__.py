from datetime import datetime, timedelta
import time
import logging
import pytz
import paho.mqtt.client as mqtt

from ipsum.core.web import init_mqtt, upload, connection_info
from ipsum.core.measure import measure
from ipsum.utils.conf import CONF, __version__


def setup_logger():
    """
    creates and configures the main logger
    """
    local_logger = logging.getLogger("ipsum")
    local_logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    fmt = logging.Formatter('\033[1m[%(asctime)sZ|%(levelname)s]\033[0m: %(name)s: %(message)s')
    fmt.converter = time.gmtime
    handler.setFormatter(fmt)
    local_logger.addHandler(handler)
    return local_logger


def main():
    logger = setup_logger()
    logger.info(f"starting ipsum v{__version__}")
    update_timer = timedelta(seconds=CONF.get("update_timer"))
    broker_url = CONF.get("broker_url")
    client = mqtt.Client()
    while True:
        try:
            init_mqtt(client, broker_url)
            start = datetime.now(pytz.utc)
            while True:
                now = datetime.now(pytz.utc)
                measure_dict = measure()
                logger.info(f"parsed: {measure_dict}")
                if measure_dict is not None and now >= start + update_timer:
                    upload(client, measure_dict)
                    start = now
                if not connection_info.all_ok():
                    logger.warning(f"bad connection flag: {connection_info.bad_connection}")
                    logger.warning(f"connected flag: {connection_info.connected}")
                    logger.warning(f"active flag: {connection_info.active}")
                    break
        except Exception as exc:
            logger.exception(f"Got exception: {exc}")
            if connection_info.bad_connection:
                client.loop_stop()
                # client.reinitialise()


if __name__ == "__main__":
    main()
