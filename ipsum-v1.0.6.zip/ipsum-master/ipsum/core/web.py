import time
import logging
import binascii
import copy
import datetime
from threading import Lock
from contextlib import contextmanager
import paho.mqtt.client as mqtt
from typing import Optional

from ipsum.utils.conf import CONF, __version__
from .measure import Measure


class ConnectionInfo:
    _connected = False
    _last_message: Optional[datetime.datetime] = None
    _bad_connection = False
    _lock = Lock()

    def all_ok(self) -> bool:
        with self._lock:
            return self.active and not self._bad_connection

    @property
    def connected(self) -> bool:
        return copy.copy(self._connected)

    @property
    def bad_connection(self) -> bool:
        return copy.copy(self._bad_connection)

    @property
    def active(self) -> bool:
        if not self.connected:
            return False
        date = self._last_message or datetime.datetime(day=1, month=1, year=1990)
        diff = date - datetime.datetime.now()
        update_timer = datetime.timedelta(seconds=CONF["update_timer"])
        return diff < update_timer * 4 + datetime.timedelta(seconds=1)

    class LockedConnectionInfo:
        def __init__(self, origin):
            self._instance = origin

        @property
        def connected(self) -> bool:
            return copy.copy(self._instance._connected)

        @connected.setter
        def connected(self, new_value: bool):
            self._instance._connected = copy.copy(new_value)
            self._instance._last_message = datetime.datetime.now() if new_value else None

        @property
        def bad_connection(self) -> bool:
            return copy.copy(self._instance._bad_connection)

        @bad_connection.setter
        def bad_connection(self, new_value: bool):
            self._instance._bad_connection = copy.copy(new_value)

        @property
        def active(self) -> bool:
            return self._instance.active

        def all_ok(self) -> bool:
            return self.active and not self.bad_connection

        def update_last_message_sent(self):
            self._instance._last_message = datetime.datetime.now()

    @contextmanager
    def locked(self):
        with self._lock:
            try:
                yield self.LockedConnectionInfo(self)
            finally:
                pass


connection_info = ConnectionInfo()


def encode(metrics: Measure) -> bytes:
    """
    PROTOCOL VERSION 1:
    data are bytestring with this structure: bytenumberx content (type)
    firstbytenumber-lastbytenumberinclusive
        1x bytecode version (unsigned integer) 0
        3x software version (major.minor.rev) 1-3
        8x timestamp UTC (unsigned integer 64 bit) 4-11
        1x number P of power values in this metric (unsigned integer) 12
        3xP power values (unsigned integer) 13-15
        [ Nx NaN signaling bytes (uint) with N = 1 + P//8 and binary encoding with p1 = LSB]

    total bytesyze: 15 (1P) - 777 (255P CP)
    Every number is encoded as BIG ENDIAN.
    Note that in this list the interval is INCLUSIVE, in the list operator in Python the last number
    is EXCLUSIVE: software version is bytes from 1 to 3 (1,2,3) but the list retrieve is
    data[1:4]=>(1,2,3)
    The Encoding used is: the n-byte contain the number as ASCII characters corresponding to the
    number that we wanted to send for example if we want to send 94 the byte will be \x61 so the
    bytestring will contain the corresponding char 'a'. For example the unsigned 12000 coded for 3
    byte will be the bytestring b'\x00.\xe0' obtained with the function
    `numbervariable.to_bytes(nbytes, 'big', signed=False)`
    """
    measures = [m if m is None or m >= 0 else None for m in metrics.measure]

    bytecode_version = int(1).to_bytes(1, 'big', signed=False)
    major, minor, rev = [int(x).to_bytes(1, 'big', signed=False) for x in __version__.split('.')]

    timestamp = int(metrics.timestamp).to_bytes(8, 'big', signed=False)
    how_many = int(len(measures)).to_bytes(1, 'big', signed=False)
    values = b''.join([int(m or 0).to_bytes(3, 'big', signed=False) for m in measures])
    msg = bytecode_version + \
        major + minor + rev + \
        timestamp + how_many + values

    if None in measures:
        nan_pos = 0
        packet_len = 1 + (len(measures) - 1) // 8
        for i, elem in enumerate(measures):
            if elem is None:
                nan_pos += 2**i
        nan_pos_enc = nan_pos.to_bytes(packet_len, 'big', signed=False)
        msg += nan_pos_enc

    return msg


def upload(client: mqtt.Client, measure_dict: Measure):
    """ Uploads the encoded measure to the rabbitmq broker """
    logger = logging.getLogger("ipsum.upload")
    ipsum_id = CONF.get("ipsum_id")
    if measure_dict is None:
        logger.error("tried to send a None measure")
        return
    data = encode(measure_dict)
    payload = binascii.b2a_base64(data).decode()
    routing_key = CONF.get('routing_key')
    try:
        logger.info(f"sending measure {measure_dict}")
        packet = f"{ipsum_id} {payload}"
        res = client.publish(topic=routing_key, payload=bytes(packet, 'ascii'))
        if res.rc == mqtt.MQTT_ERR_NO_CONN:
            logger.error(f"Can't publish data to topic {routing_key}: no connection")
            with connection_info.locked() as connection:
                connection.bad_connection = True
                client.disconnect()
            return
        if res.rc == mqtt.MQTT_ERR_QUEUE_SIZE:
            logger.error(f"Can't publish data to topic {routing_key}: full queue")
            with connection_info.locked() as connection:
                connection.bad_connection = True
            return

        logger.info(f"measure sent: {packet}")
        with connection_info.locked() as connection:
            connection.update_last_message_sent()
    except Exception:
        logger.error(f"Can't publish data to topic {routing_key}")
        raise


def on_connect(client, _userdata, _flags, errc):
    logger = logging.getLogger("ipsum.on_connect")
    with connection_info.locked() as connection:
        if errc == 0:
            client.spurious = connection.all_ok()
            if client.spurious:
                logger.info("already connected and active - preventing a new connection")
                client.disconnect()
            else:
                logger.info("connection established")
                connection.connected = True
                connection.bad_connection = False
            return
        if not connection.all_ok():
            if errc in (4, 5):
                logger.error("invalid username or password, or unauthorized")
            else:
                logger.error(f"returned errc {errc}")
            connection.connected = True
            connection.bad_connection = False


def on_disconnect(client, _userdata, errc):
    if not client.spurious:
        logging.getLogger("ipsum.on_disconnect").info(f"disconnecting: {errc}")
        with connection_info.locked() as connection:
            connection.connected = False


def init_mqtt(client, broker_url):
    logger = logging.getLogger("ipsum.init_mqtt")
    with connection_info.locked() as connection:
        if connection.all_ok():
            logger.info("an instance of the mqtt thread is already running - not reinitializing")
            return
    logger.info("initializing mqtt")
    client.reinitialise()
    client.spurious = False
    client.on_connect = on_connect
    client.on_disconnect = on_disconnect
    username = CONF["mqtt_username"] + ":" + CONF["mqtt_username"]
    client.username_pw_set(username=username, password=CONF["mqtt_password"])
    logger.info(f"trying to connect to {broker_url}, port {CONF['mqtt_port']}")
    try:
        client.loop_start()
        client.connect_async(broker_url, CONF["mqtt_port"], keepalive=CONF["mqtt_keepalive"])
        logger.info("connection launched")
        while not connection_info.active:
            time.sleep(1)
    except TimeoutError:
        logger.error("can't connect to the MQTT server")
        with connection_info.locked() as connection:
            connection.bad_connection = True
