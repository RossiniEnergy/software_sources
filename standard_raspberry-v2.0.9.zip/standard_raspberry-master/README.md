# Configuration options

You can change the configuration of the device editing `/etc/standard-raspberry/conf.toml` as super
user.
Keep in mind that
- all numbers are integers
- all boolean are lowercase strings (`true`, `false`)
- lists are enclosed between square brackets.

# Basic Configuration
This is the part of the conf file you generally want to modify to configure the software.
- [User and Power Configuration](#user-and-power-configuration)
- [Clamps enumeration](#clamps-enumeration)
- [Scatolino configuration](#scatolino)

### User and Power Configuration
- **cp** - the number of charge points connected to this device
- **park_name** - globally unique name of the device. This is used for database, metric, remote
    connection and order retrieve purposes, and it's important that two raspberry do not share the
    same park_name
- **production_counting** - if `true`, the energy produced (e.g. via solar panels) will be counted for
    the available power calculation
- **building_counting** - if `true`, the energy from the hosting building will be counted for the
    available power calculation
- **receive_orders** - if `true`, this device will receive orders from servers; set to `false` for
    public erogation (solar mode)
- **building_include_chargepoint** - `true` if the measures from the building clamps includes include
    the chargepoint consumption. For example: if I see the building consumption increasing after
    connecting a car, this parameter should be `true`. If connecting the car does not increase the
    consumption, this should be `false`. Default: `true`
- **max_order_power** - *(unimplemented)*
- **fixed_power_from_grid** - a fixed amount of always available power from the grid (in Watt)
- **guaranteed_min_power** - the guaranteed amount of always available power (grid and production) for
    this device (in Watt). If accepting orders, see later for how to configure this parameter.
- **lowest_power_level_default** - minimum possible erogable power level. Generally you want level
    `2` or level `3`: level `2` requires a lot less power, but the correspondent power is too low
    to charge some old cars (very old ZOEs), for which a minimum power level of `3` is requred.
- **hardware_pilotage_version** - *(unimplemented)* the pilotage version: 0 for the 7-levels model, 1 for the potentiometer
- **nan_buffer_length** - maximum number of consecutive times for which a `nan` from the measurement
    card will be replaced with the last buffered valid power before raising an error. Default: 0.

##### Value of `guaranteed_min_power` in enterprise mode
In enterprise mode, since we can't "pause" a car charge without auto-closing the order for inactivity,
there must always be a minimum amount of current flowing into the cars. That means, in the worst case
we need to be able to charge every chargepoint in the charging station at least at `lowest_power_level_default`.
To make it possible, we require the customer to guarantee a minimum amount of power, which can be
calculated as follow:
- Let `n_mono` be the number of chargepoints configured to be only monophase (1 clamp)
- Let `n_three` be the number of chargepoints configured to possibly be threephase (2 or 3 clamps)
- Let `min_power_mono` and `min_power_three` be the minimum power required from a mono/threephase chargepoint.
  This quantity depends on `lowest_power_level_default` in the following way:
  | `lowest_power_level_default` | `min_power_mono` | `min_power_three` |
  | :--------------------------: | :--------------: | :---------------: |
  | 2                            | 1404             | 4212              |
  | 3                            | 3042             | 9126              |
- Then the _minimum_ value for `minimum_guaranteed_power` is
    `n_mono * min_power_mono + n_three * min_power_three`
This rule is enforced by the software: the program will not start unless this variable is set to an
acceptable value, and will print in the journal log informations about the minimum required power.

An example:
```toml
receive_orders = true
lowest_power_level_default = 3
cs_1 = [1]
cs_2 = [2,3]
cs_3 = [4,5,6]
cs_4 = []
cs_5 = []
cs_6 = []
```
In this configuration, `min_power_mono` is 3042, `min_power_three` is 9126, `n_mono` is 1 and `n_three`
is 2, so the minimum guaranteed power must be greater or equal than `1 * 3042 + 2 * 9126 = 21294`.

### Clamps enumeration
- **cs_N** - the list of clamps for chargepoint N. Use only lists from cs_1 to cs_X, where X is the
    value of the "cp" option, will be used by the program. Unsupported N > 6. A chargepoint with
    a single clamp will always be considered monophase.
- **disable_pilotage_on_cs** - the list of the chargepoints for which the pilotage must be disabled.
    Default: `[]` (empty list)
- **building** - a list of clamps grouped by phase. Power lines of the hosting building
- **production** - a list of clamps grouped by phase. Power lines of the production systems like solar panels

You can flag the various entry as "Monophase" (1 clamp) or "Threephase" (1,2,3 clamps) for building and
production.
This two lists are composed by comma-separated entries structured like:
  `{ phase = "mono",  clamps = [7]}` or `{ phase = "three", clamps = [8, 9] }`
where first we have if mono or three-phased entry, and next the list of clamps assigned to that entry.
Every entry is an independent energy line.
  
### Scatolino
- **with_scatolino** - if `true`, energy from Scatolino will be used for the available power calculation
    __instead of__ production and building
- **scatolino** - the id of Scatolino on the remote database
- **scatolino_calculation** - the formula to calculate the available power from Scatolino.

  
  
# Advanced configuration
Do not modify these values unless you are absolutely sure about what you are doing.
All of these parameters have a default value inside the program: if you are not sure about what value
to use, just delete the line and let the program use its defaults.

### Timers and system configurations
- **metrics_url** - the address to send the metrics to
- **get_cs_state_url** - the address from which to retrieve the status of the charging station
- **get_cs_list_url** - the address from which to retrieve the list of the charging station's ids
- **rabbitmq_url** - the address to communicate via rabbitmq
- **supply_loop_timing** - time between the refresh of the energy supply state (generally short is better, but it can't be less than 8 seconds)
- **low_activity_metrics_timer** - time between two submissions of power metrics to the server if no charge point is erogating (in seconds)
- **high_activity_metrics_timer** - time between two submissions of power metrics to the server if at least a charge point is erogating (in seconds)
- **shuffle_timer** - time between two reshuffle of the priority list used when the power is not enough, and to distribute the surplus power
- **power_attenuation_check_timer** - time for which a chargepoint must deliver less power than assigned, to reduce its power level to exactly that required by the car
- **bootstrap_cp_time** - time of pause after the first supply loop at the startup with `receive_orders=false`. One minute is a good value
- **smart_debug** - enables the smart debug thread (see after). Default: `true`
- **debug_config_file** - where the debug file is located. Default: `/etc/standard-raspberry/debug_options.toml`

## Debug options
If the `smart_debug` option is enabled, at the launch of the program a special debug thread will be started.
This thread will read the `/etc/standard-raspberry/debug_options.toml` file and will log on systemd journal various information.
You can change values in `debug_options.toml` while the program is running to enable/disable
logs at runtime with a max time between updates of 5 secs; keep in mind that all the values are lowercase booleans.

- **new_orders** - whenever a new order is received, it will be dumped in the journal
- **sendmetrics_timers** - print in the journal the activity metrics timer (in seconds) every time a measure is sent to the server
- **last_measure_update** - whenever a measurement is about to be sent to the server, it will also be printed on the screen
- **energy_balance_in_out** - print the power balance (available power, power consumed by each charge point, residual power, etc...) at the end of every supply cycle
- **chargepoint_list_general_status** - print state information for each charge point (is charging, power level, low priority endtime, mono/three-phase, etc...) at the end of every supply cycle
