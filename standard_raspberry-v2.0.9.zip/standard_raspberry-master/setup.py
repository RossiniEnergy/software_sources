import setuptools

setuptools.setup(name='standard_raspberry',
                 version='2.0.9',
                 description='Unified Raspberry Firmware with Enterprise and Solar functions',
                 author='Rossini energy',
                 author_email='federico@rossinienergy.com',
                 packages=setuptools.find_packages(
                     where='.',
                     include=[
                         'standard_raspberry*',
                         'standard_raspberry/core*',
                         'standard_raspberry/utils*',
                         'standard_raspberry/utils/configuration*'
                     ]
                 ),
                 package_dir={"": "."},
                 # package_data={"": ["conf.toml", "debug_options.toml"]},
                 # include_package_data=True,
                 entry_points={
                     'console_scripts': [
                         'standard-raspberry = standard_raspberry.__main__:main',
                         'set_level = standard_raspberry.set_level:set_level'
                     ]
                 },
                 install_requires=[
                     'RPi.GPIO',
                     'toml',
                     'pyserial',
                     'pymysql',
                     'requests',
                     'dynaconf',
                     'spidev',
                     'pytz',
                     'python-dateutil',
                     'paho-mqtt'
                 ])
