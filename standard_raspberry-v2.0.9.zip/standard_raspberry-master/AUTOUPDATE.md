# AutoUpdate Documentation
Una repository Debian è composta ad un semplice percorso web con una specifica 
struttura di file e cartelle che il packet manager APT può leggere e utilizzare. 
Il nostro si trova sul server Web su dominio http://DEBIANREPO.com/

Si può suddividere il sistema dell'autoaggiornamento in tre componenti:
- Pacchettizzazione del software: procedura svolta su un Raspberry dedicato per la creazione e la firma digitale
 del pacchetto software da caricare sulla repository.
  
- Web Repository: URL a cui trovare la struttura di cartelle e file che APT può leggere e interpretare.
- APT Configuration: APT (e crontab) vanno configurati in modo che il sistema aggiorni solo la repository
 di interesse e non tutto il sistema in modo automatico ogni sera.

## Software Packaging
Debian fornisce un set di programmi e script fatti apposta per semplificare il processo
di pacchettizzazione. Abbiamo provveduto ad unire questi strumenti in un unico script che
consenta di pacchettizzare e inviare il prodotto alla repository in automatico.

Andiamo ora a spiegare cosa abbiamo utilizzato per questa fase ed il loro funzionamento:
- GPG: per la firma del pacchetto e della repository è obbligatorio l'utilizzo di una chiave GPG
  che abbiamo provveduto a creare.
  Quella che al momento è in uso in ogni immagine distribuita è la `RossiniEnergy_dpkg1` depositata
  nei portachiavi della BuildStation e del server Repo per la controfirma. La chiave è inoltre backuppata
  nella cartella omonima nella home directory di root.
  
- pip3 module `pip-tools`: Questo modulo installabile via pip contiene gli strumenti `pip-compile` utilizzato
  per rigenerare il `requirements.txt` impiegato per creare l'ambiente virtuale all'interno del pacchetto.
  
- `devscripts`: Pacchetto Debian contenente gli script d'utilità impiegati per la pacchettizzazione, tra cui il 
  fondamentale DebHelper (dh).
- `dh-virtualenv`: Plugin per DebHelper che ci consente di creare un pacchetto python monolitico, contenente un 
  ambiente virtuale con tutte le librerie impiegate, senza dover pensare ad eventuali cross-dipendenze con la 
  repository Debian ufficiale.
- `dpkg-sig`: Programma utilizzato per firmare un pacchetto con una chiave GPG.

Come spiegato in testa allo script `uplaodrepo.sh` affinchè esso possa funzionare, si richiedono tutti i componenti
sopracitati installati, con i comandi
```shell
pip3 install pip-tools
apt install dh-virtualenv devscripts dpkg-sig
```
Importante notare che l'installazione di pip-tools richiede l'aggiunta in PATH di una cartella comunicata 
dall'installazione stessa.
Altra considerazione importante. Viene richiesto almeno Python 3.7 per il corretto funzionamento del programma.
Questo è importante perché nelle versioni di Debian precedenti alla 10 nelle repository ufficiali 
ci si ferma a Python 3.6.

Le fasi della creazione di un nuovo pacchetto sono le seguenti:
- Caricare le chiavi SSH della macchina da build come autorizzata sul server SSH.
  
- Caricare nel portachiavi GPG la chiave privata `RossiniEnergy_dpkg1` utilizzata per la firma digitale del pacchetto.
  
- Assicurarti di essere sulla branch di interesse e con l'ultima versione della stessa. Normalmente noi usiamo `devel`:
  ```shell
  git checkout devel
  git pull
  ```

- _(Opzionale)_ Rigenerare il `requirements.txt` dal `requirements.in` e dai pacchetti installati sulla macchina locale:
  utilizzando i comandi 
  ```shell
  pip3 install -r requirements.in
  pip-compile requirements.in > requirements.txt
  ```
  aggiorniamo i pacchetti localmente, per poi caricare la nuova versione nel `requirements.txt` utilizzato 
  dalla pacchettizzazione.
  
- Scegliere un numero di versione `MAJOR.MINOR.REV` (es. `1.9.2`) maggiore o uguale all'ultimo utilizzato 
  (puoi visualizzare quelli già utilizzati con il comando `git tag` dato che a ogni release corrispopnde un tag remoto)
  
- Aggiorna il contenuto di `setup.py` e `debian/changelog` con le informazioni sulla nuova versione:
  ```shell
  VERSION="1.9.2"
  sed -i -E "s/version='([0-9]+\.){2}[0-9]+'/version='$VERSION'/" setup.py
  dch -v "$VERSION" "In breve la modifica di questa versione."
  dch -r --distribution stable ignored
  ```
  Cosi abbiamo generato con `dch`, un helper per la gestione del `debian/changelog`, una nuova entry nel changelog
  da cui Debian prenderà la versione del pacchetto `.deb` e con la modifica a setup.py ora abbiamo la giusta versione
  nel modulo python all'interno del pacchetto.
  
- Genera e pusha in remoto la nuova tag relativa alla nuova release con le modifiche del punto precedente:
  ```shell
  git add debian/changelog requirements.txt setup.py
  git commit -m "Deploying Release v$VERSION"
  git tag -a "v$VERSION" -m "Release v$VERSION"
  git push
  git push origin "v$VERSION"
  ```
  Utilizziamo questo sistema per tenere traccia su Git le nuove release a che commit corrispondono con precisione.

- _(Opzionale)_ Genera un pacchetto da installare dove stai impacchettando che richiami l'installazione delle 
  `Build-Depends` del pacchetto come scritte sul `debian/control`:
  ```shell
  sudo mk-build-deps --install debian/control
  sudo apt install "./standard-raspberry-build-deps_${VERSION}_all.deb"
  rm -f "standard-raspberry-build-deps_${VERSION}_all.deb"
  ```
  Normalmente questa operazione può essere eseguita solo una volta e rifatta solo in caso vi sia una modifica 
  delle `Build-Depends` in `debian/control`. Il file d'installazione del metapacchetto è cancellabile senza problemi,
  anzi è consigliato farlo per non intasare la cartella del sorgente.
  
- Avvia la procedura d'impacchettamento. Questo comando genererà nella cartella superiore a quella del sorgente
  (ovvero la root directory della repository git) vari file tra cui un `standard-raspberry_1.9.2_armhf.deb`):
  ```shell
  dpkg-buildpackage -uc -us
  ```
  
- Firmare il pacchetto con la chiave segreta scelta:
  ```shell
  PKGFILENAME="standard-raspberry_${VERSION}_armhf.deb"
  dpkg-sig -k "RossiniEnergy_dpkg1" --sign repo "$PKGFILENAME"
  ```
  L'uso del comando `dpkg-sig` qui è diverso da quello in `uploadrepo.sh` perché li il programma vuole chiedere
  all'utente una sola volta la passphrease della chiave per automatizzrne l'inserimento nelle conseguenti 3 operazioni
  che la richiedono. Il comando come qui mostrato invece chiede direttamente all'utente la Passphrase 
  della chiave se presente. Il file verrà firmato e sovrascritto.
  
- Upload del file nella cartella corrispondente alla giusta architettura sul server della repository Debian:
  ```shell
  SSHADDR="root@167.99.209.185"
  scp "$PKGFILENAME" ${SSHADDR}:/www/repo/armhf/
  ```
  Attualmente sul nostro server la cartella della repository è `/www/repo/` e il Raspberry Pi è un 
  architettura ARMv7 con supporto hardware alla virgola mobile. Debian classifica l'architettura col nome `armhf`.
  
- Procedere a rigenerare la repository:
  Questo procedimento è identico (letteralmente stessi comandi) alla creazione di una nuova repo, 
  infatti la creazione di una nuova repo richiede la presenza di almeno un pacchetto.
  
## Online Repository Structure
Una repository Debian è composta semplicimente da file esposti sul Web tramite sistemi quali HTTP, FTP o SSH.
Essa deve essere composta dai seguenti file:
- Cartelle specifiche per le varie architetture: nel nostro caso l'unica architettura è `armhf` e quindi
  questa sarà l'unica cartella presente nella repository.
  
- Release Files: File contenenti l'informazioni sui file specifici della repository, in particolare quali sono
  e il loro hash. Questi sono i primi file scaricati da APT, e possono essere tre:
  - `Release`: il file tradizionale contenente solo gli hash degli altri file repository specifici
  - `Release.gpg`: file contenente la firma GPG di `Release`
  - `InRelease`: come `Release` solo che la firma è fatta inline, quindi in cima al file e non in un file separato
    come con `Release.gpg`
    
  Normalmente ne basta uno solo di questi, ma è comune e consigliato averli tutti e tre.
  
- Packages Files: File contenenti l'informazione su quali pacchetti sono disponibili nella repository e le loro
  informazioni specifiche, quali hash, versioni, descrizioni. Fungono da indice, e anche qui ne abbiamo
  molteplici versioni equivalenti:
  - `Packages`: versione tradizionale contenente l'indice così com'è. Principale problema di questo file è
    che tende a lievitare molto di dimensione nel tempo, e deve venir scaricato ad ogni ricerca di aggiornamento,
    comportando un aumento di banda consumata con ogni nuova release.
  
  - `Packages.gz`: per risolvere il problema sopra citato, APT supporta la compressione gzip sul Packages
    consentendo di scaricarne, se disponibile, solo la versione compressa riducendo di molto il consumo
    di banda per la ricerca di aggiornamenti. Sempre meglio avere disponibili entrambi per quei
    sistemi incapaci di decomprimere gzip.
    
Una repository Debian non è un servizio complicato o specifico, ma semplicemente dei file disposti in un modo 
particolare, che APT sa riconoscere. La struttura della nostra repo per esempio può essere:
```text
armhf/                                             11-Jan-2021 16:46                   -
armhf/standard-raspberry_0.1.6_armhf.deb           11-Jan-2021 16:12             4489578
armhf/standard-raspberry_0.1.7_armhf.deb           11-Jan-2021 16:46             4489038
InRelease                                          11-Jan-2021 16:46                1952
Packages                                           11-Jan-2021 16:46                6200
Packages.gz                                        11-Jan-2021 16:46                1848
Release                                            11-Jan-2021 16:46                1204
Release.gpg                                        11-Jan-2021 16:46                 699
```
Una cosa importante è che se per lo stesso pacchetto esistono molteplici versioni, vengono registrate tutte nella
repository, e sono tutte utilizzabili. 
In automatico però se non specificato verrà richiesta l'ultima verisone disponibile.

## Regenerate Repository Procedure
Ogni volta che viene aggiunto, modificato o rimosso un file `.deb`, la repository va rigenerata interamente
da zero. Questa cosa porta la procedura di creazione e quella di aggiornamento a coincidere completamente.

Sono richiesti dei pacchetti specfici lato server per fare le seguenti operazioni, in particolare:
- GPG: come per il packaging, è essenziale per la firma della repository.
- Pacchetti per sviluppatori di `dpkg`: in particolare si parla di `dpkg-dev` e `dpkg-sig` che forniscono strumenti di
  sviluppo specifici per la firma dei pacchetti e dei file di una repository.
  
- `gzip`: utilizzato per comprimere il file `Packages`
- Strumenti APT per la creazione e la gestione di una repository: il pacchetto `apt-utils` ci fornisce tra le tante
  cose il comodissimo strumenti `apt-ftparchive` che andremo a utilizzare per creare i file specifici della repository.

Si possono installare tutti questi strumenti e assicurarsi siano aggiornati con il comando:
```shell
apt install dpkg-dev dpkg-sig gzip apt-utils
```
Stiamo dando per scontati la presenza di GPG già configurato. Generalmente non si vuole aggiornare GPG senza motivo.

La fasi per l'effettiva generazione della repository sono le seguenti:
- Assicurarsi che la chiave privata GPG utilizzata per firmare i pacchetti sia presente nel portachiavi del server ospitante 
  la repository. Rimane possibile effettuare le operazioni di firma dei file della repository a distanza per ragioni 
  di sicurezza, ma al momento nei nostri script ci aspettiamo la presenza sul server della chiave GPG.
  
- Caricare il nuovo pacchetto o modificare comunque il contenuto di una cartella architettura-specifica.
- Spostarsi all'interno della cartella ospitante la repository (nel nostro caso `/www/repo/`)
- Rigenerare il `Packages` per una specifica architettura, ovvero `armhf`:
  ```shell
  apt-ftparchive --arch armhf packages armhf > Packages
  ```
  Il primo `armhf` rappresenta l'architettura scelta, mentre il secondo `armhf` indica la cartella utilizzata per 
  ospitare i pacchetti per quella specifica architettura. Generalmente vengono fatti coincidere.
  
- Comprimo `Packages` per generare `Packages.gz`:
  ```shell
  gzip -k -f Packages
  ```
  Questo comando non cancella il file originale.

- Rigenero il `Release`: 
  ```shell
  apt-ftparchive release . > Release
  ```
  questo deve venir fatto dopo la generazione di tutti i file specifici per la repository dato
  che la funzione di questo file è proprio dire ad APT quali file di sistema sono disponibili su questa specifica
  repository (ad esempio, se disponibile un `Packages.gz` o solo la versione non compressa).

- Procedere alla firma di `Release` sia inline che in file dedicato:
  ```shell
  rm -fr Release.gpg; gpg --default-key "RossiniEnergy_dpkg1" -abs -o Release.gpg Release
  rm -fr InRelease;  gpg --default-key "RossiniEnergy_dpkg1" --clearsign -o InRelease Release
  ```
  GPG normalmente genera un errore se il file di output di un comando è già esistente, quindi prima di rigenerarlo va
  obbligatoriamente eliminato manualmente. Anche in questo caso il comando nello script è diverso. Questo è dovuto alla
  volontà nello script di automatizzare l'inserimento della passphrase tramite script e non manualmente ogni volta da 
  parte dell'utente, inoltre le operazioni remote vengono eseguite passando a SSH una lista di comandi da eseguire.
  

### GPG specific configurations (VERY IMPORTANT)
L'ultima operazione è prona a ritornare un errore molto strano su molte macchine perché GPG si aspetta uno specifico
terminale virtuale quasi mai utilizzato. Il nostro script in particolare è in grado di causare questo errore su 
qualunque macchina a causa delle funzionalità aggiuntive che richiede a GPG
Quando appare un errore simile a:
```text
Error: gpg: using "D5673F3E" as default secret key for signing 
Error: gpg: signing failed: Inappropriate ioctl for device 
Error: gpg: [stdin]: sign+encrypt failed: Inappropriate ioctl for device
```
la soluzione consiste nel modificare per l'utente in uso alcune impostazioni di GPG. Queste modifiche sono sicure
anche quando effettuate sull'utente root.

Bisogna aggiungere al file `~/.gnupg/gpg.conf` le seguenti righe:
```text
use-agent 
pinentry-mode loopback
```
E aggiungere al file `~/.gnupg/gpg-agent.conf` la seguente:
```text
allow-loopback-pinentry
```
Dopo queste modifiche si deve riavviare l'agent GPG con questo comando:
```shell
echo RELOADAGENT | gpg-connect-agent
```

Questa procedura consente di automatizzare l'inserimento della Passphrase oltre che sistemare molti bug
nel caso di firma tramite SSH dove il terminale virtuale a volte non è correttamente configurato.

### NGINX's configuration for repository
La repository essendo esposta tramite un server web NGINX richiede una specifica configurazione in esso, così
come ogni altro sito presente sul server.

Siamo consapevoli che esistono metodi migliori, come sfruttare la cartella `/etc/nginx/conf.d/`, ma al momento abbiamo
optato per l'aggiunta di alcune righe nel `/etc/nginx/nginx.conf` globale.

In particolare si parla delle seguenti righe (va bene anche in fondo al file):
```text
server {
        listen 80;
        listen [::]:80;
        server_name DEBIANREPO.com;
        location / {
                root /www/repo/;
                autoindex on;
        }
}
```
Come possiamo vedere sono indicate la porta del server web utilizzato, il dominio corrispondente e soprattuto
la posizione della repository come root del server web.
La funzionalità `autoindex on;` non è necessaria, ma è buono averla attiva come debug iniziale per vedere se i file
sono effettivamente visibili. APT non utilizza l'index della repository per orientarsi conoscendo già il nome dei file 
facenti da indice per tutti gli altri, quindi richiede direttamente quelli.

Per dire a NGINX di ricaricare il file di configurazione si può usare il comando:
```shell
nginx -s reload
```

## Client-side APT configuration
Ora l'ultimo passaggio è dire ad APT dove andare a cercare la repository.
Quello che ci serve è creare un nuovo file di configurazione dedicato alla nostra repository con un nome specifico che 
andremo a utilizzare per scopi successivi.

Il file in questione è `/etc/apt/sources.list.d/rossinienergy.list` che deve contenere:
```text
deb http://DEBIANREPO.com/ /
```

Qui stiamo dicendo ad APT di caricare una nuova repository contrassegnata dal nome `rossinienergy` con le 
caratteristiche:
- Repository di Binari: `deb` in testa sta a indicare che la repository contiene dei binari e non dei sorgenti. Nel 
  caso si voglia un repository di sorgent si utilizza `deb-src` in testa e vengono usate tramite il comando
  `apt-get sources`, non di nostro interesse.
  
- Percorso HTTP della repository: `http://DEBIANREPO.com/` indica il server da utilizzare come repository,
  oltre che la necessità di utilizzare il protocollo HTTP per la comunicazione con esso. Si possono usare anche 
  protocolli SSH e FTP, oltre che indicare porte differenti.
  
- Percorso remoto della repository: `/` serve a dire che la root directory del server web contiene subito la repository.
  Questo è utilizzato nel caso il server scelto contenga più repository. Ad esempio la repo ufficiale di Debian
  contiene varie sottorepository una per ogni versione di Debian, ed è qua che viene indicata quale sottorepo scegliere.

A questo punto `apt update` e `apt upgrade` aggiornano correttamente gli indici della repository e i pacchetti 
installati. Normalmente questi comandi effettuano un update e un upgrade _globale_, mentre nel nosotro specifico 
caso d'applicazione desideriamo un update e un upgrade _parziale_ sulla sola nostra repository.

L'update parziale consiste nell'aggiornare l'indice dei pacchetti solo da una specifica repository e viene fatto
forzando delle configurazioni da linea di comando su APT con il comando:
```shell
apt-get update -y -o Dir::Etc::sourcelist="sources.list.d/${name}.list" -o Dir::Etc::sourceparts="-" -o APT::Get::List-Cleanup="0"
```
Con questo comando stiao dicendo ad APT di prendere solo la nostra repo come fonte, ignorando le altre, più qualche
opzione specifica per evitare che l'update parziale possa rompere il database locale. Inoltre è fatto apposta per 
non richiedere input dall'utente per l'applicazione dell'update.

Per l'aggiornamento parziale il procedimento è simile e il comando è:
```shell
apt-get -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" upgrade
```
Con questo comando stiamo aggiornando i pacchetti di cui conosciamo l'esistenza di un aggiornamento, con delle 
specifiche opzioni di conservazione dei file di configurazione che ci consentono di automatizzare l'aggiornamento
senza input dell'utente.

Questi due comandi sono utilizzati negli script del nostro software per automatizzare il processo di aggiornamento 
parziale sulla nostra repository aziendale.

## External Links

- https://opensource.com/article/20/4/package-python-applications-linux
- https://pi3g.com/2019/04/19/packaging-python-projects-for-debian-raspbian-with-dh-virtualenv/
- https://medium.com/sqooba/create-your-own-custom-and-authenticated-apt-repository-1e4a4cf0b864
- https://d.sb/2016/11/gpg-inappropriate-ioctl-for-device-errors