import logging
import multiprocessing
import queue
import requests
from standard_raspberry.core import smart_debug
from standard_raspberry.utils.conf import CONF, __version__
from threading import Thread
from standard_raspberry.utils.sync import AtomicResource, ThreadStatus

logger = logging.getLogger("rpi.sendmetrics")


def encode(metrics):
    """
    data are bytestring with this structure:
    bytenumberx content (type) firstbytenumber-lastbytenumberinclusive
        1x bytecode version (unsigned integer) 0
        3x software version (major.minor.rev) 1-3
        3x available power (signed integer) 4-6
        3x production (signed integer) 7-9
        3x consumption (signed integer) 10-12
        8x timestamp UTC (unsigned integer 64 bit) 13-20
        1x number N of CP in this metric (unsigned integer) 21
        3xN power consumed from CP (unsigned integer) 22-24

    total bytesize: 25 (1CP) - 46 (8 CP)
    Every number is encoded as BIG ENDIAN.
    Note that in this list the interval is INCLUSIVE, in the list operator in Python the last number
    is EXCLUSIVE:
        software version is bytes from 1 to 3 (1,2,3) but the list retrieve is data[1:4]=>(1,2,3)
    Unencoded = the byte contain the number as it is without needing of extra processing
    Encoded = the n-byte contain the number as ASCII characters corresponding to the number that we
        wanted to send
    for example if we want to send 94 the byte will be \x61 so the bytestring will contain the
    corresponding char 'a'. For example the number 12000 coded for 3 byte will be the bytestring
    b'\x00.\xe0' obtained with the function `numbervariable.to_bytes(nbytes, 'big')`
    """

    # TODO: The bytecode version is hardcoded or must be in the CONF?
    bytecode_version = int(1).to_bytes(1, 'big', signed=False)
    major, minor, revision = [int(x).to_bytes(1, 'big', signed=False) for x in __version__.split('.')]

    available_power = int(sum(metrics._available_power)).to_bytes(3, 'big', signed=True)
    production = int(sum(metrics._production)).to_bytes(3, 'big', signed=True)
    consumption = int(sum(metrics._consumption)).to_bytes(3, 'big', signed=True)
    timestamp = int(metrics._timestamp.timestamp()).to_bytes(8, 'big', signed=False)
    number_of_cp = len(metrics._cp_metrics).to_bytes(1, 'big', signed=False)
    cp_metrics = b''.join([int(sum(m)).to_bytes(3, 'big', signed=False) for m in metrics._cp_metrics])
    return bytecode_version + \
        major + minor + revision + \
        available_power + production + consumption + timestamp + number_of_cp + cp_metrics


class SendMetrics(Thread):
    def __init__(self, shared_last_measure: AtomicResource, new_timer_queue: multiprocessing.Queue,
                 thread_status: ThreadStatus):
        super().__init__(daemon=True)
        self._shared_last_measure = shared_last_measure
        self._new_timer_queue = new_timer_queue
        self._seconds_for_update = CONF.time.get("low_activity_metrics_timer")
        self._thread_status = thread_status
        self._post_power_link = CONF.web["metrics_url"] + CONF.park["park_name"]

    def run(self):
        while True:
            # I use the timer as timeout for a blocking queue.get, so if i receive a new
            #  timer i set it and proceed with the update. Otherwise we wait the exception
            #  raised by the timeout of a queue (queue.Empty) to skip the "set new timer" part.
            try:
                new_timer = self._new_timer_queue.get(True, self._seconds_for_update)
                self._seconds_for_update = new_timer
                # Smart debug hooks
                smart_debug.timers(new_timer, self._new_timer_queue.qsize())
            except queue.Empty:
                pass
            finally:
                try:
                    err_code = self._thread_status.status_code_measurements()
                    data = self._shared_last_measure.read()
                    if data is None:
                        self._thread_status.sendmetrics_err(1)
                        logger.error("Last Measure is None, sendmetrics cycle skipped")
                    elif err_code != 0:
                        self._thread_status.sendmetrics_ok()
                        logger.error(f"Metrics not sent because of Measurements error {err_code}")
                    else:
                        encoded_data = encode(data)
                        response = requests.post(self._post_power_link, data=encoded_data)
                        response_code: int = response.status_code
                        if response_code == requests.codes.ok:
                            self._thread_status.sendmetrics_ok()
                            logger.info("Metrics sent to the remote db")
                        else:
                            self._thread_status.sendmetrics_err(response_code)
                            logger.error(f"Metrics POST request returned HTTP code {response_code}")
                except requests.RequestException as exc:
                    self._thread_status.sendmetrics_err(1)
                    logger.error("Unexpected error while sending metrics to the remote db", exc_info=exc)
