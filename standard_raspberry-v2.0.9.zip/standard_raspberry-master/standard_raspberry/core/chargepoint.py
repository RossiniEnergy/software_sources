import datetime
import pytz
import logging
from enum import Enum
from dataclasses import dataclass
from typing import Optional
from copy import deepcopy

from standard_raspberry.utils.pilotageinterface import hardware_class
from standard_raspberry.utils.conf import CONF
from standard_raspberry.utils.vector import Vector

logger = logging.getLogger("rpi.chargepoint")

DEFAULT_PWRLV: int = CONF.park["probing_power_level"]
PWRATT_CUTOFF = CONF.park.get("min_mono_charging_power")
GHOST_POWER_HOTFIX: bool = CONF.internal.get("enable_ghost_power", False)

"""
Variables:
- supplying: the chargepoint is trying to supply some power
- car_present: a car is plugged in the chargepoint
- charge_started: the car plugged has received some power

States:
- inactive:   000,001 => the chargepoint is completely off
- probing:    100     => the chargepoint is waiting for a car to plug in
- starting:   110     => a car is plugged but it has not started to charge yet (off-balance)
- charging:   111     => a car is accepting some power
- suspended:  011     => a car is plugged but the chargepoint has not enough power to start a charge

Meaningless states:
- 010 => it is currently not possible to know if a car plugs without supplying energy, and when we
         know there is a car we always want it to be in charge or suspended
- 101 => transition phase between charging and probing, does not happen because when car_present
         goes to 0 charge_started is also reset to 0
"""


class CPStatus(Enum):
    inactive = 0b001
    probing = 0b100
    starting = 0b110
    charging = 0b111
    suspended = 0b011
    BUG_1 = 0b010
    BUG_2 = 0b101

    @classmethod
    def build(cls, supplying, car_present, charge_started):
        val = ((supplying << 2) | (car_present << 1) | charge_started) or 0b001
        return cls(val)

    @classmethod
    def destructure(cls, status):
        val = status.value
        return (val & 0b100) == 0b100, (val & 0b010) == 0b010, (val & 0b001) == 0b001


@dataclass
class ChargePointSettings:
    def __init__(self, mono: bool, phase_mask: Vector, pilotage: str, max_power_level: int):
        self.mono = mono
        self._phase_mask = phase_mask
        self.pilotated = pilotage != "no"
        self.has_qrcode = pilotage == "qrlb"
        self._max_power_level = max_power_level
        self.power_attenuation_cutoff = PWRATT_CUTOFF

    @property
    def phase_mask(self):
        return Vector(self._phase_mask)

    @property
    def max_power_level(self):
        return deepcopy(self._max_power_level)

    def serialize_for_debug(self, prefix) -> str:
        return (
            f"{prefix}Phase mask: {self._phase_mask}\n"
            f"{prefix}Pilotated: {self.pilotated}\n"
            f"{prefix}Max power level: {self.max_power_level}\n"
            f"{prefix}Power attenuation cutoff: {self.power_attenuation_cutoff}\n"
        )


class InternalState:
    def __init__(self, default_phase_mask: Vector, max_power_level: int):
        # Charge macro-state
        self._supplying: bool = False
        self._car_present: bool = False
        self._charge_started = None

        # Power level related state
        self._power_level: int = 0
        self._power_budget: Vector = Vector.zeros(3)

        self._power_attenuation: int = max_power_level
        self._power_attenuation_timer: Optional[datetime.datetime] = None
        self._phase_mask: Vector = Vector(default_phase_mask)

    @property
    def _is_mono(self) -> bool:
        return Vector.count_nonzero(self._phase_mask) == 1

    def serialize_for_debug(self, prefix) -> str:
        status = CPStatus.build(self._supplying, self._car_present, self.charge_started)
        return (
            f"{prefix}Power level: {self._power_level}\n"
            f"{prefix}Power budget: {self._power_budget}\n"
            f"{prefix}Current mask: {[x for x in self._phase_mask]}\n"
            f"{prefix}Supplying:      {self._supplying}\n"  # probe active
            f"{prefix}Car present:    {self._car_present}\n"  # charging
            f"{prefix}Charge started: {bool(self._charge_started)} {self._charge_started}\n"
            f"{prefix}Status:         {status.name}\n"
            f"{prefix}Power attenuation: {self._power_attenuation}\n"
            f"{prefix}Power att timer: {self._power_attenuation_timer}\n"
        )

    def status(self):
        """ Returns the current status of the chargepoint """
        return CPStatus.build(self._supplying, self._car_present, self.charge_started)

    def set_status(self, status: CPStatus):
        """ Set a status """
        self._supplying, self._car_present, self.charge_started = CPStatus.destructure(status)

    # Zero Level Methods
    def override_power_level(self, power_level: int):
        self._power_level = power_level
        if CONF.park["scalar"]:
            power = hardware_class().get_power_given_level(self._is_mono, power_level)
            self._power_budget = Vector([power, 0, 0])
        else:
            power = hardware_class().get_power_given_level(True, power_level)
            self._power_budget = self._phase_mask * power

    @property
    def charge_started(self) -> bool:
        return self._charge_started is not None

    @charge_started.setter
    def charge_started(self, x: bool):
        if x:
            if not self.charge_started:
                self._charge_started = datetime.datetime.now(pytz.UTC)
        else:
            self._charge_started = None

    def charge_start_time(self):
        return self._charge_started

    @property
    def power_level(self) -> int:
        return self._power_level

    @property
    def power_budget(self) -> Vector:
        return Vector(self._power_budget)

    @property
    def mono(self) -> bool:
        return self._is_mono

    @property
    def supplying(self) -> bool:
        return self._supplying

    @supplying.setter
    def supplying(self, x: bool):
        self._supplying = x

    @property
    def power_attenuation_timer(self):
        return self._power_attenuation_timer

    def new_power_attenuation_timer(self, duration: Optional[datetime.timedelta] = None):
        if duration is None:
            duration = datetime.timedelta(seconds=CONF.time["power_attenuation_check_timer"])
        self._power_attenuation_timer = datetime.datetime.now(datetime.timezone.utc) + duration

    def reset_power_attenuation_timer(self):
        self._power_attenuation_timer = None

    def is_power_attenuation_timer_expired(self) -> bool:
        timer = self._power_attenuation_timer
        if timer is None:
            return False
        return datetime.datetime.now(datetime.timezone.utc) > timer


class OrderInfo:
    def __init__(self, num: int, kind: str):
        self.num: int = num
        self.kind: str = kind  # "suspend", "resume"
        self.sent: datetime.datetime = datetime.datetime.now(pytz.utc)
        self.attempt: int = 1

    def expired(self) -> bool:
        assert self.sent is not None, "OrderInfo 'sent' member should not be None"
        delta = datetime.timedelta(seconds=CONF.time["order_response"])
        return datetime.datetime.now(pytz.utc) > self.sent + delta

    def can_retry(self):
        return self.attempt < CONF.web["max_retry_attempt"]

    def retry(self):
        self.sent = datetime.datetime.now(pytz.utc)
        self.attempt += 1


class ChargePoint:
    def __init__(self, num: int):
        assert num >= 1
        chargepoint = CONF.cp[num - 1]
        self._cpnum = num

        def find_phase(ph):
            clamps = chargepoint["clamps"]
            return 1 if next(filter(lambda x: x["phase"] == ph, clamps), None) is not None else 0

        mono = len(chargepoint["clamps"]) == 1
        if CONF.park["scalar"]:
            mask = Vector([1, not mono, not mono])
        else:
            mask = Vector([find_phase(ph) for ph in "abc"])
        max_power_level = chargepoint["max_power_level"]
        pilotage = chargepoint["pilotage"]
        self.defaults = ChargePointSettings(mono, mask, pilotage, max_power_level)
        self._internal_state = InternalState(mask, max_power_level)
        score = CONF.park["charge_priority_score"]
        self._priority = {"no": 99999, "qrlb": score["user"], "lb": score["lb"]}[pilotage]
        self._last_order: Optional[OrderInfo] = None

    def serialize_for_debug(self, prefix) -> str:
        return f"{prefix}CHARGEPOINT {self._cpnum}\n" + \
                self.defaults.serialize_for_debug(prefix+"  ") + \
                self.state.serialize_for_debug(prefix+"  ")

    def register_order(self, num: int, kind: str):
        assert kind in ("suspend", "resume"), "the 'kind' parameter must be 'suspend' or 'resume'"
        self._last_order = OrderInfo(num, kind)

    def unregister_order(self):
        self._last_order = None

    def last_order_expired(self) -> bool:
        return self._last_order is not None and self._last_order.expired()

    @property
    def cpnum(self):
        return self._cpnum

    @property
    def state(self):
        return self._internal_state

    @property
    def status(self):
        return self._internal_state.status()

    @status.setter
    def status(self, status: CPStatus):
        self.state.set_status(status)

    @property
    def power_level(self) -> int:
        return self._internal_state._power_level

    def need_energy(self):
        """ The cp wants energy and is not suspended """
        return self.status in (CPStatus.starting, CPStatus.charging) and \
            self.defaults.pilotated

    def pilotated(self):
        return self.defaults.pilotated

    def has_qrcode(self):
        return self.defaults.has_qrcode

    def supplying(self):
        return self.state.supplying

    def suspended(self):
        return self.status == CPStatus.suspended

    def priority(self):
        """ Returns the priority score for the current charge """
        return self._priority

    @property
    def car_present(self) -> bool:
        return self.state._car_present

    @car_present.setter
    def car_present(self, present: bool):
        if not present:
            self.state._power_attenuation = self.defaults.max_power_level
            self.state._power_attenuation_timer = None
        self.state._car_present = present

    @property
    def current_phase_mask(self) -> Vector:
        return Vector(self._internal_state._phase_mask)

    @current_phase_mask.setter
    def current_phase_mask(self, new_mask):
        self._internal_state._phase_mask = new_mask

    def reset_phase_mask(self):
        self._internal_state._phase_mask = self.defaults.phase_mask

    def n_clamps(self):
        return Vector.count_nonzero(self.current_phase_mask)

    def set_priority(self, priority_score):
        self._priority = priority_score

    def reset_budget(self):
        self.state._power_level = 0
        self.state._power_budget = Vector.zeros(3)

    def flag_charging(self, is_charging: bool, charge_type: str, start: Optional[datetime.datetime]):
        score = CONF.park["charge_priority_score"]
        charge_priority_score = score.get(charge_type.lower(), score["user"])
        self.car_present = is_charging
        self.state.supplying = is_charging
        if start is not None:
            self.state._charge_started = start
        else:
            self.state.charge_started = False
        self.reset_budget()
        self.set_priority(charge_priority_score)

    def can_accept_more_power(self):
        return self.power_attenuation_level != 0 and \
                self.power_level < self.defaults.max_power_level and \
                self.power_level < self.power_attenuation_level

    def request_total_power_for_level(self, level: int) -> Vector:
        if not self.defaults.pilotated:
            return Vector.zeros(3)
        if self.power_level >= self.state._power_attenuation:
            return Vector.zeros(3)
        if self.power_level >= level:
            return Vector.zeros(3)

        power = hardware_class().get_power_given_level(True, level)
        # vectorial pilotage requires each clamp to have a monophase power
        if not CONF.park["scalar"]:
            return self.state._phase_mask * power
        # ghost power requires to allocate an amount of power as if 3 clamps were occupied
        if GHOST_POWER_HOTFIX:
            return Vector([power * 3, 0, 0])
        # scalar mode requires the clamps to allocate power as if 1 or 3 clamps were occupied
        return power * Vector([3 - 2 * self.state._is_mono, 0, 0])

    def request_next_level_total_power(self) -> Vector:
        """
        request and get the amount of power needed by the next power_level
        """
        return self.request_total_power_for_level(self.state._power_level + 1) - \
            self.state._power_budget

    def request_minimal_power(self) -> Vector:
        """
        returns the minimum amount of power required to activate the chargepoint
        """
        return self.request_total_power_for_level(DEFAULT_PWRLV)

    def give_minimum_power(self, power: Vector, dry_run=False) -> Vector:
        """
        increase the power budget, starting from zero, until there is enough power to supply
        the minimum power level for this park.
        :param power: the available power
        :param dry_run: perform only the calculation, without increasing the power budget
        :returns: the new amount of available power after the distribution
        """
        if not self.defaults.pilotated:
            return power
        if self.state._power_attenuation < DEFAULT_PWRLV:
            if not dry_run:
                self.state._power_level = 0
            return power

        power_level = DEFAULT_PWRLV

        monophase_power = hardware_class().get_power_given_level(True, power_level)

        if not CONF.park["scalar"]:
            effective_power = monophase_power * self.current_phase_mask
        else:
            n_phases = 3 - 2 * (self.state._is_mono and not GHOST_POWER_HOTFIX)
            effective_power = monophase_power * Vector([n_phases, 0, 0])

        if dry_run:
            return power - effective_power
        self.state._power_level = power_level
        self.state._power_budget = Vector(effective_power)
        return power - self.state._power_budget  # Residue

    def give_next_level_power(self, power: Vector) -> Vector:
        """
        give the min quantity of power to the power budget, possibly enough to increase the level
        of 1, and return the residue
        """
        if not self.defaults.pilotated:
            return power
        if (self.state._power_level >= self.state._power_attenuation or
           self.state._power_level >= self.defaults.max_power_level):
            return power
        next_level_power_delta = self.request_next_level_total_power()
        if all(power >= next_level_power_delta):
            self.state._power_level += 1
            self.state._power_budget += next_level_power_delta
            return power - next_level_power_delta
        else:
            return power

    @property
    def power_attenuation_level(self):
        return self.state._power_attenuation

    @power_attenuation_level.setter
    def power_attenuation_level(self, x: int):
        assert 0 <= x <= self.defaults.max_power_level, \
                f"setting power attenuation for cp {self._cpnum} to level {x}"
        self.state._power_attenuation = x
        self.state._power_attenuation_timer = None

    def reset_power_attenuation_level(self):
        self.power_attenuation_level = self.defaults.max_power_level

    @property
    def power_budget(self):
        return self.state.power_budget

    def apply_power_budget(self, hardware_interface):
        if self.defaults.pilotated:
            hardware_interface.apply_power_level(self._cpnum, self.state.power_level)
        else:
            unpilotated_power_level = self.defaults.max_power_level
            self.state.override_power_level(unpilotated_power_level)
            hardware_interface.apply_power_level(self._cpnum, unpilotated_power_level)
