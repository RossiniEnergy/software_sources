import json
import logging

import pytz
from typing import List, Dict, Tuple, Any, Union, Optional

from standard_raspberry.core import smart_debug
from standard_raspberry.secrets import secrets
from datetime import datetime, timedelta
from threading import Thread

import pymysql
import serial

from standard_raspberry.utils.conf import CONF
from standard_raspberry.utils.sync import AtomicResource, ThreadStatus
from standard_raspberry.utils.vector import Vector, minimum, maximum

SCALAR = CONF.park["scalar"]
PWRATT_CUTOFF = CONF.park["min_mono_charging_power"]
CLAMP_CUTOFF = CONF.park["clamp_power_cutoff"]

logger = logging.getLogger("rpi.measurements")

# 20 is a first buffer dimension
buffer = [[0, 0] for _ in range(20)]  # [ [value, nan appeared before a real measure] , ... ]


class Metrics:
    def __init__(self, measure: dict, phase_masks_list: list):
        """
        measure: dict = {"power_available": power, 1: power, 2, ..., n}
        power is int
        """
        self._available_power = measure["available_power"]
        self._production = measure["production"]  # TODO: property?
        self._consumption = measure["consumption"]  # TODO: property?
        self._cp_metrics = [measure[i + 1] for i in range(len(CONF.cp))]
        self._timestamp = datetime.now()
        # If system is only mono, then ALL is only mono
        self._phase_masks_list = phase_masks_list

    @property
    def available_power(self):
        return self._available_power

    @property
    def timestamp(self):
        return self._timestamp

    def phase_mask(self, n: int):
        return self._phase_masks_list[n - 1]

    def is_mono(self, n: int):
        return Vector.count_nonzero(self.phase_mask(n)) == 1

    def get_cp_power(self, n: int):
        return self._cp_metrics[n - 1]

    def to_dict(self):
        dic: Dict[Union[str, int], Any] = {
            "available_power": int(sum(self.available_power)),
            "production": int(sum(self._production)),
            "consumption": int(sum(self._consumption)),
            "timestamp": str(self.timestamp)
        }
        for i, cs in enumerate(self._cp_metrics):
            dic[i + 1] = int(sum(cs))
        return dic

    def jsonize(self):
        return json.dumps(self.to_dict())

    def __repr__(self):
        return self.jsonize()


class Measurements(Thread):
    def __init__(self,
                 shared_last_measure: AtomicResource,
                 thread_status: ThreadStatus,
                 ipsum_buffer: AtomicResource):
        super().__init__(daemon=True)
        self._shared_last_measure = shared_last_measure
        self._thread_status = thread_status
        self._ipsum_buffer = ipsum_buffer
        self._ser = serial.Serial("/dev/ttyAMA0", 38400, timeout=10)
        logger.info("Serial port initialized")

    def reset_ser(self):
        self._ser = serial.Serial("/dev/ttyAMA0", 38400, timeout=10)
        logger.warning("Serial port resetted")

    def run(self):
        while True:
            try:
                line = self._ser.readline()
                if line != "":
                    smart_debug.raw_serial(line)
                    # CS in Metrics_Dict are with numbers as keys
                    metrics_dict, phase_masks_list = parse(line, self._ipsum_buffer)
                    if metrics_dict == {}:
                        continue
                    for i in range(1, len(CONF.cp) + 1):
                        for idx, metric in enumerate(metrics_dict[i]):
                            if metric < PWRATT_CUTOFF:
                                metrics_dict[i][idx] = 0
                    self._thread_status.measurements_ok()
                    metrics = Metrics(metrics_dict, phase_masks_list)
                    self._shared_last_measure.write(metrics)

                    # Smart debug hooks
                    smart_debug.last_measure(metrics)
                else:
                    self.reset_ser()
            except serial.SerialException as exc:
                self._thread_status.measurements_err(1)  # TODO: errcode
                logger.error("Serial port exception handled", exc_info=exc)
                self.reset_ser()
            except Exception as exc:
                self._thread_status.measurements_err(1)  # TODO: errcode
                logger.error("Unable to complete the Measurement parsing cycle", exc_info=exc)
                self.reset_ser()


def parse(measurements_string: bytes, ipsum_buffer: AtomicResource) -> (dict, list):
    """
    return metrics dict and mono list with for every charge points defined in conf
    """
    # power used
    try:
        # Clear some \0 that can appear in the leading 11
        measurements_string = measurements_string.replace(b"1\x001", b"11").strip()
        default_factor = CONF.park.get("default_calibration_factor", 1.)
        power_measures = []
        specific_calibration = False

        def get_calibration_factor(clamp_list, i) -> float:
            for entry_info in clamp_list:
                for clamp_info in entry_info["clamps"]:
                    if i == clamp_info["clamp"]:
                        return clamp_info.get("calibration", default_factor)
            return default_factor

        for i, x in enumerate(measurements_string.split(b" ")):
            if i == 0:
                if int(float(x)) == 11:
                    # All the code after this expected the 0-pos to contain a unused value
                    power_measures.append(11)
                    continue
                else:
                    logger.warning("String from serial without leading 11")
            if i > len(buffer):
                buffer.append([0, 0])

            def check_clamp(lst):
                for item in lst:
                    c_list = item['clamps']
                    if any(c["clamp"] == i for c in c_list):
                        return True
                return False

            if x.lower() == b'nan':
                can_ignore = check_clamp([*CONF.cp, *CONF.building, *CONF.production])
                if can_ignore:
                    continue
                value = buffer[i - 1][0]
                if buffer[i - 1][1] >= CONF.park["nan_buffer_length"]:
                    raise ValueError("Not A Number found outside the buffer configuration")
                buffer[i - 1][1] += 1
            else:

                calibration_factor: float = get_calibration_factor(
                        [*CONF.cp, *CONF.building, *CONF.production], i
                )
                value = int(float(x) * calibration_factor)
                buffer[i - 1][0] = value
                buffer[i - 1][1] = 0
            power_measures.append(value)

        if specific_calibration or default_factor != 1.0:
            smart_debug.raw_serial_after_calibration([elem[0] for elem in buffer])

        chargepoint_power = {}
        phase_masks = []

        # TODO: check if this comment is valid
        # here we are measuring each clamp and checking what type of car is charging at each CP
        # in case we have a single clamp we have to assume the car is mono-phase, and that's it
        # in case we have more than one clamp, we check if, in each of the clamps, we have power
        # above CLAMP_CUTOFF, the power level we consider zero. this is because if for example we
        # have three clamps but only on one of them is flowing current, we understand that actually
        # we are charging a mono-phase car. idem for two clamps
        for cp in CONF.cp:
            bnum = cp["id"]
            clamps = cp['clamps']

            clamps_dict = {}
            for clamp in clamps:
                if clamp['phase'] not in clamps_dict.keys():
                    clamps_dict[clamp['phase']] = 0
                clamps_dict[clamp['phase']] += power_measures[clamp['clamp']]

            cp_power = Vector.zeros(3)
            for phase, power in clamps_dict.items():
                if power > CLAMP_CUTOFF:
                    mask = Vector([phase == 'a', phase == 'b', phase == 'c'])
                    cp_power += mask * power

            if SCALAR:
                if len(clamps) == 2 and cp_power.count_nonzero() >= 2:
                    phase_masks.append(Vector.ones(3))
                    effective_power = sum(cp_power) * 3 / 2
                else:
                    ln = cp_power.count_nonzero()
                    mask = Vector([ln >= 1, ln >= 2, ln >= 3]) * 1
                    phase_masks.append(mask)
                    effective_power = sum(cp_power)
                chargepoint_power[bnum] = Vector([effective_power, 0, 0])
            else:
                phase_masks.append((cp_power != 0) * 1)
                chargepoint_power[bnum] = cp_power

    except Exception as exc:
        logger.error("Impossible to determinate power in use", exc_info=exc)
        raise RuntimeError
    # power_available
    final_dict = add_power_balance(power_measures, chargepoint_power, ipsum_buffer)
    return final_dict, phase_masks


def add_power_balance(split: List[int], chargepoint_dict: Dict[int, Vector], ipsum_buffer: AtomicResource) -> dict:
    """
    return the dictionary with the measurements "production", "consumption" (building),
    "available_power"
    """
    try:
        production = Vector.zeros(3)
        consumption = Vector.zeros(3)
        available_power = Vector.zeros(3)
        if CONF.legacy.get("with_scatolino"):
            # TODO: How to populate dict production and consumption if we are using Scatolino?
            available_power += get_power_scatolino()
            if CONF.legacy.get("scatolino_include_chargepoint"):
                for i in range(len(CONF.cp)):
                    available_power += chargepoint_dict[i + 1]
        else:
            def parse_mph_tph_list(mph_tph_list: list) -> Vector:
                """parser for Mph and Tph lists"""
                result = Vector.zeros(3)
                for entry in mph_tph_list:
                    n_phases = entry.get("phases")
                    clamps = [clamp['clamp'] for clamp in entry["clamps"]]
                    phases = [clamp['phase'] for clamp in entry["clamps"]]
                    if n_phases.lower().startswith("mono"):
                        # Monophased
                        power = split[clamps[0]]
                        phase = phases[0]
                        result += Vector([phase == 'a', phase == 'b', phase == 'c']) * power
                    elif n_phases.lower().startswith("three"):
                        # Three-phased
                        if len(clamps) == 1:
                            power = split[clamps[0]]
                            result += Vector.ones(3) * power
                        elif len(clamps) == 2:
                            # Use the average to accurately estimate the third clamp value
                            avg_clamp = (split[clamps[0]] + split[clamps[1]]) / 2
                            power = avg_clamp
                            result += Vector.ones(3) * power
                        elif len(clamps) == 3:
                            result += Vector([split[clamps[x]] for x in range(3)])
                if SCALAR:
                    return Vector([sum(result), 0, 0])
                return result

            total_cp_consumption = sum(
                    (chargepoint_dict[i + 1] for i in range(len(CONF.cp))), Vector.zeros(3)
            )
            if SCALAR:
                assert total_cp_consumption.count_nonzero() <= 1, \
                    "non-scalar result in scalar computation for the total cp consumption"

            # production counting
            if CONF.internal.get("production_counting"):
                production = parse_mph_tph_list(CONF.production)
                if SCALAR:
                    assert production.count_nonzero() <= 1, \
                        "non-scalar result in scalar computation for the production counting"
            # building consumption
            if CONF.internal.get("building_counting"):
                consumption = parse_mph_tph_list(CONF.building)
                if SCALAR:
                    assert consumption.count_nonzero() <= 1, \
                        "non-scalar result in scalar computation for the consumption counting"
                building = consumption.astype(int) * 1.0
                if CONF.park.get("building_include_chargepoint"):
                    building -= total_cp_consumption
                else:
                    consumption += total_cp_consumption
            else:
                consumption = total_cp_consumption
                building = Vector.zeros(3)
            # retrieve Ipsum available power
            if CONF.park.get("with_ipsum"):
                max_inactivity = timedelta(seconds=CONF.time["ipsum_timeout"])
                ipsum_data = ipsum_buffer.read()
                ipsum_avalpower = Vector.zeros(3)
                time_delta = datetime.now(pytz.UTC) - ipsum_data.timestamp
                if time_delta > max_inactivity:
                    msg = f"# Ipsum data are out-of-date by {time_delta.total_seconds()} s #"
                    border = "#" * len(msg)
                    raise RuntimeError(f"\n{border}\n{msg}\n{border}")
                # if building_include_chargepoint, we want to remove cp power from building or ipsum
                if CONF.park["ipsum_include_chargepoint"]:
                    ipsum_avalpower += total_cp_consumption
                ipsum_avalpower += ipsum_data.available_power
            else:
                ipsum_avalpower = Vector.zeros(3)
            # base available power
            available_power = ipsum_avalpower + production - building
        # Subtract unpilotated cs from available_power (they have building-like priority)
        for cp in CONF.cp:
            if cp['pilotage'] == "no":
                available_power -= chargepoint_dict[cp['id']]

        # fixed power from grid always available
        for clamp in CONF.park["fixed_power_from_grid"]:
            phase = clamp['phase']
            power = clamp['power']
            available_power += Vector([phase == 'a', phase == 'b', phase == 'c']) * power
        if SCALAR:
            available_power = Vector([sum(available_power), 0, 0])
        # check if respect the guaranteed minimum power level
        min_power = Vector.zeros(3)
        for clamp in CONF.park["guaranteed_min_power"]:
            phase = clamp['phase']
            power = clamp['power']
            min_power += Vector([phase == 'a', phase == 'b', phase == 'c']) * power
        if SCALAR:
            min_power = Vector([sum(min_power), 0, 0])
        available_power = maximum(available_power, min_power)
        # check if you're overcapping max_available_power
        max_available_power = CONF.park.get("max_available_power", None)
        if max_available_power is not None:
            tmp_dict = {ph["phase"]: ph["power"] for ph in max_available_power}
            max_available_power_v = Vector([
                    tmp_dict.get("a", 0), tmp_dict.get("b", 0), tmp_dict.get("c", 0)
            ])
            available_power = minimum(available_power, max_available_power_v)
        final_dict = {**chargepoint_dict,
                      "available_power": available_power,
                      "production": production,
                      "consumption": consumption}
        return final_dict
    except Exception as exc:
        logger.error("Impossible to determinate available power", exc_info=exc)
        raise RuntimeError


def get_power_scatolino() -> Vector:
    """
    get scatolino's informations
    """
    result = 0
    db = None
    # TODO: Think if some 30sec cache is needed to reduce db load
    try:
        db = pymysql.connect(
            host=secrets['scatolino_host'],
            user=secrets['scatolino_user'],
            password=secrets['scatolino_password'],
            db=secrets['scatolino_db']
        )
        # TODO: We can delegate Mono/Three-phased calculation to the SQL Query?
        with db.cursor() as cursor:
            query = secrets['scatolino_query'].format(
                CONF.legacy["scatolino_calculation"], "TimeHuman", CONF.legacy["scatolino"]
            )
            cursor.execute(query)
            fetch_res: Optional[Tuple[Any, ...]] = cursor.fetchone()
            assert fetch_res is not None
            result = int(fetch_res[0])
            last_time = fetch_res[1]
            smart_debug.scatolino_power(result, last_time)
            max_inactivity = timedelta(seconds=CONF.legacy["scatolino_timeout"])
            time_delta = datetime.now() - last_time
            if time_delta > max_inactivity:
                raise RuntimeError(f"Scatolino did not sent new data in {time_delta.total_seconds()}")
    except Exception as exc:
        logger.error("Connection error with scatolino", exc_info=exc)
        raise RuntimeError("Connection error with scatolino")
    finally:
        if db is not None:
            db.close()
    if not SCALAR:
        raise RuntimeError("Using scatolino in vectorial mode")
    return Vector([result, 0, 0])
