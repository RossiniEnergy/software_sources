import json
import binascii
import datetime
import pytz
import logging
import requests

from standard_raspberry.utils.conf import CONF
from standard_raspberry.utils.sync import AtomicResource
from standard_raspberry.utils.vector import Vector


logger = logging.getLogger("rpi.ipsum")


class IpsumMetrics:
    def __init__(self, timestamp: datetime.datetime, available_power):
        self.timestamp = timestamp
        self.available_power = available_power

    def as_tuple(self):
        return self.timestamp, self.available_power

    def as_dict(self):
        return {'timestamp': self.timestamp, 'available_power': self.available_power}

    @staticmethod
    def from_encoded_msg(encoded_msg: bytes):
        return decode_bytecode_ipsumlastpower(encoded_msg)


def decode_bytecode_ipsumlastpower(encoded_data: bytes) -> IpsumMetrics:
    """
    PROTOCOL VERSION 1:
        data are bytestring with this structure:
            bytenumberx content (type) firstbytenumber-lastbytenumberinclusive

            1x bytecode version = 1 (unsigned integer) 0
            8x timestamp UTC (unsigned integer 64 bit) 1-8
            4x available power (signed integer) 9-12

        total bytesyze: 13

    PROTOCOL VERSION 2:
        data are bytestring with this structure:
            bytenumberx content (type) firstbytenumber-lastbytenumberinclusive

            1x bytecode version = 2 (unsigned integer) 0
            8x timestamp UTC (unsigned integer 64 bit) 1-8
            4x available power phase A (signed integer) 9-12
            4x available power phase B (signed integer) 13-16
            4x available power phase C (signed integer) 17-20

        total bytesyze: 21


        Every number is encoded as BIG ENDIAN.
        Note that in this list the interval is INCLUSIVE, in the list operator in Python the last
        number is EXCLUSIVE:
            software version is bytes from 1 to 3 (1,2,3) but the list retrieve is data[1:4]→(1,2,3)
        The Encoding used is: the n-byte contain the number as ASCII characters corresponding to the
            number that we wanted to send, for example if we want to send 94 the byte will be \x61
            so the bytestring will contain the corresponding char 'a', and the unsigned 12000 coded
            in 3 byte will be the bytestring b'\x00.\xe0' obtained with the function
            `numbervariable.to_bytes(nbytes, 'big', signed=False)`
    """
    bytestring = binascii.a2b_base64(encoded_data)
    protocol_version = bytestring[0]
    if protocol_version == 1:
        if not CONF.park["scalar"]:
            text = "USING A SCALAR IPSUM TO FEED A VECTORIAL PILOTAGE"
            line_len = len(text) + 4
            border = '#' * line_len
            message = f"\n{border}\n# {text} #\n{border}"
            logger.error(message)
            raise ValueError(message)
        # Timestamp UTC
        timestamp_raw = int.from_bytes(bytestring[1:9], 'big')
        timestamp = datetime.datetime.fromtimestamp(timestamp_raw, pytz.UTC)
        # Available Power
        scalar_available_power = int.from_bytes(bytestring[9:13], 'big', signed=True)
        available_power = Vector([scalar_available_power, 0, 0])
        return IpsumMetrics(timestamp, available_power)
    elif protocol_version == 2:
        if CONF.park["scalar"]:
            text = "USING A VECTORIAL IPSUM TO FEED A SCALAR PILOTAGE"
            line_len = len(text) + 4
            border = '#' * line_len
            message = f"\n{border}\n# {text} #\n{border}"
            logger.error(message)
            raise ValueError(message)
        # Timestamp UTC
        timestamp_raw = int.from_bytes(bytestring[1:9], 'big')
        timestamp = datetime.datetime.fromtimestamp(timestamp_raw, pytz.UTC)
        available_power = [
            int.from_bytes(bytestring[9+i*4:13+i*4], 'big', signed=True) for i in range(0, 3)
        ]
        return IpsumMetrics(timestamp, Vector(available_power))
    else:
        logger.error(f"Received Ipsum data with unrecognized protocol_version {protocol_version}")
        raise ValueError("Invalid protocol version")


def recover_ipsum(ipsum_buffer: AtomicResource):
    park_name = CONF.park['park_name']
    res = requests.get(f"{CONF.web['ipsum_recovery_api']}{park_name}")
    if res.status_code != 200:
        logger.info(f"ipsum recovery API returned status code {res.status_code}")
        return
    try:
        encoded_data = res.json()["available_power"]
    except json.decoder.JSONDecodeError:
        logger.info("Ipsum data received as invalid JSON")
        raise ValueError("Ipsum data received as invalid JSON")
    if encoded_data is None:
        raise ValueError("Ipsum without last power data")
    ipsum_buffer.write(IpsumMetrics.from_encoded_msg(encoded_data))
