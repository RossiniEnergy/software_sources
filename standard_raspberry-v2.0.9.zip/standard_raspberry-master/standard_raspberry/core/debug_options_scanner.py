import logging
from standard_raspberry.core import smart_debug
from threading import Thread
from time import sleep

import toml

from standard_raspberry.utils.sync import AtomicResource
from standard_raspberry.utils.conf import CONF

logger = logging.getLogger("rpi.smart_debug")


class Debug(Thread):
    def __init__(self):
        super().__init__(daemon=True)

        with open(CONF.debug.get('config_file')) as conf_file:
            user_options = toml.load(conf_file)

        available_options = {
                "new_orders": True,
                "raw_serial": True,
                "scatolino_power": True,
                "sendmetrics_timers": True,
                "last_measure_update": True,
                "energy_balance_in_out": True,
                "chargepoint_list_general_status": True,

                "global_status": False
        }

        for expected_key, default in available_options.items():
            if expected_key not in user_options.keys():
                logger.debug(f"Warning: missing debug option '{expected_key}' - defaulting to '{default}'")
                smart_debug.debug_options[expected_key] = AtomicResource(default)
            else:
                val = user_options[expected_key]
                if not isinstance(val, bool):
                    logger.debug(f"Warning: wrong type for debug option '{expected_key}' - defaulting to '{default}'")
                    smart_debug.debug_options[expected_key] = AtomicResource(default)
                else:
                    smart_debug.debug_options[expected_key] = AtomicResource(val)

        self._sleep_timeout = 5  # TODO: Movein debug_options.toml?

    def run(self):
        while True:
            sleep(self._sleep_timeout)
            try:
                with open(CONF.debug.get('config_file')) as conf_file:
                    user_options = toml.load(conf_file)
                # FIXME: check if this code can be done better with a logic similar to that used in init
                for key, val in user_options.items():
                    if not isinstance(val, bool):
                        logger.debug('Non-boolean value "%s" for key "%s" ignored', val, key)
                    elif key in smart_debug.debug_options.keys():
                        if smart_debug.debug_options.get(key).read() != val:
                            smart_debug.debug_options.get(key).write(val)
                            logger.debug(f"Debug Options Update: Key {key} changed to new value {val}")
                    else:
                        logger.debug('New key "%s" ignored', key)
            except NameError as error:
                logger.debug(
                    'Error encountered while loading debug_options.toml: "%s"', error)
                logger.debug("Some options could be unmodified")
            except Exception as error:
                logger.debug('Exception raised while loading debug_options.toml: "%s"', error)
