import logging
import multiprocessing
from standard_raspberry.utils.conf import CONF
from standard_raspberry.core.ipsum import recover_ipsum
from threading import Thread
import paho.mqtt.publish as publish
from standard_raspberry.utils.sync import AtomicResource, ThreadStatus

logger = logging.getLogger("rpi.sendcommands")


class SendCommands(Thread):
    def __init__(self, thread_status: ThreadStatus, command_queue: multiprocessing.Queue):
        super().__init__(daemon=True)
        self._thread_status = thread_status
        self._mqtt_hostname = CONF.web["mqtt_hostname"]
        self._mqtt_port = CONF.web["mqtt_port"]
        self._username = f"{CONF.web['mqtt_vhost']}:{CONF.web['mqtt_username']}"
        self._password = CONF.web["mqtt_password"]
        self._command_queue = command_queue

    def run(self):
        while True:
            command = self._command_queue.get()  # Blocking without Timeout
            try:
                publish.single(
                    topic='SERVER',
                    payload=command,
                    hostname=self._mqtt_hostname,
                    port=self._mqtt_port,
                    auth={'username': self._username, 'password': self._password},
                    keepalive=14,  # seconds, timeout
                )
                self._thread_status.sendcommands_ok()
            except Exception:
                self._thread_status.sendcommands_err(1)


class WebInterface:
    """
    Interface to push commands to the SendCommands thread
    """
    def __init__(self, command_queue: multiprocessing.Queue, ipsum_buffer: AtomicResource):
        """
        Creates a new instance of WebInterface, which can be used to receive messages from and to
        send messages to the server
        """
        self._command_queue = command_queue
        self._ipsum_buffer = ipsum_buffer

    def recover_states(self):
        """ Ask the server for the chargepoints' last known states """
        logger.info("Restoring charging station status from remote db")
        self.send_message(f"askcpstatus {CONF.park['park_name']}")

    def recover_ipsum(self):
        """ Ask the server for the last metrics sent by ipsum """
        recover_ipsum(self._ipsum_buffer)

    def send_message(self, payload: str):
        self._command_queue.put(payload)
