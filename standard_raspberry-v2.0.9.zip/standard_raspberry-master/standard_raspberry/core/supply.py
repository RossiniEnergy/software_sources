import logging
from threading import Thread
from time import sleep

from standard_raspberry.utils.conf import CONF
from standard_raspberry.core.cpmanager import CPManager
from standard_raspberry.utils.sync import ThreadStatus
from standard_raspberry.core import smart_debug

logger = logging.getLogger("rpi.supply")


class Supply(Thread):
    def __init__(self, cp_manager: CPManager, thread_status: ThreadStatus):
        super().__init__(daemon=True)
        self._cp_manager = cp_manager
        self._thread_status = thread_status

    def run(self):
        # Reset to 0 every chargepoint at the beginning
        # for i in range(len(CONF.cp)):
        #     self._cp_manager.reset_cp(i + 1)
        # TODO: I want this everytime we exit from fallback in no order mode
        # If Solar i want the first wait to be longer than normal
        first_loop_flag = not CONF.internal["receive_orders"]
        if CONF.internal.get("receive_orders"):
            sleep(16)  # Give time to the other threads to start correctly
        # Main Loop
        supply_loop_timing = CONF.time["supply_loop_timing"]
        while True:
            try:
                # Check other thread status
                measuremenets_code = self._thread_status.status_code_measurements()
                orders_code = self._thread_status.status_code_orders()
                sendmetrics_code = self._thread_status.status_code_sendmetrics()
                sendcommands_code = self._thread_status.status_code_sendcommands()
                if measuremenets_code != 0:
                    logger.error(f"Power supply cycle in Fallback for Measurements error {measuremenets_code}")
                    self._cp_manager.erogate_fallback()
                elif orders_code != 0:
                    logger.error(f"Power supply cycle in Fallback for Orders error {orders_code}")
                    self._cp_manager.erogate_fallback()
                    logger.error("Requesting resync...")
                    self._cp_manager.request_resync()
                elif sendcommands_code != 0:
                    logger.error(f"Power supply cycle in Fallback for SendCommands error {orders_code}")
                    self._cp_manager.erogate_fallback()
                    logger.error("Requesting resync...")
                    self._cp_manager.request_resync()
                elif sendmetrics_code != 0 and CONF.internal.get("receive_orders"):
                    logger.error(
                        f"Power supply cycle (QRcode enabled) in Fallback Mode for SendMetric error {sendmetrics_code}")
                    self._cp_manager.erogate_fallback()
                else:
                    self._cp_manager.erogate(first_run=first_loop_flag)
                    if first_loop_flag:
                        first_loop_flag = False
            except Exception as exc:
                logger.critical("Unable to complete the Supply cycle, going Fallback", exc_info=exc)
                self._cp_manager.erogate_fallback()

            smart_debug.global_status(self._cp_manager, self._thread_status)
            # Sleep between cycles
            sleep(supply_loop_timing)
