import pytz
import datetime
import logging
import random
from standard_raspberry.core import smart_debug
from copy import copy
from time import sleep
from threading import Lock
from contextlib import contextmanager
from typing import List, Optional

from standard_raspberry.utils.conf import CONF
from standard_raspberry.core.chargepoint import ChargePoint, CPStatus, OrderInfo
from standard_raspberry.core.measurements import Metrics
from standard_raspberry.utils.pilotageinterface import hardware_class
from standard_raspberry.utils.sync import AtomicResource, ThreadStatus
from standard_raspberry.core.send_commands import WebInterface
from standard_raspberry.utils.vector import Vector

logger = logging.getLogger("rpi.cpmanager")

DEFAULT_PWRLV = CONF.park["probing_power_level"]
PWRATT_CUTOFF = CONF.park["min_mono_charging_power"]


def generate_seed_every_tot_time(tot_time_in_seconds):
    """
    generates a new seed every `tot_time_in_seconds` seconds, and notifies if the seed
    changed
    :param int tot_time_in_seconds: the time interval between two reseeds
    :returns: a pair (seed: int, reshuffled: bool)
    """
    def now():
        return datetime.datetime.now(pytz.UTC)
    delta = datetime.timedelta(seconds=tot_time_in_seconds)
    next_shuffle_seed_time = now() + delta  # Change shuffle seed every n sec
    while True:
        shuffle = now() > next_shuffle_seed_time
        if shuffle:
            logger.info("Reshuffle seed changed")
            next_shuffle_seed_time = now() + delta
        yield next_shuffle_seed_time.timestamp(), shuffle


class LockedCPList:
    def __init__(self, number_of_cp: int):
        self._cp_list = [ChargePoint(i + 1) for i in range(number_of_cp)]
        self._resource_lock = Lock()

    @contextmanager
    def locked(self):
        """ This method is designed to be used via the `with` statement. """
        try:
            self._resource_lock.acquire()
            yield self._cp_list
        finally:
            self._resource_lock.release()

    def is_locked(self):
        return self._resource_lock.locked()


class CPManager:
    def __init__(self,
                 number_of_cp: int,
                 shared_last_measure: AtomicResource,
                 thread_status: ThreadStatus):
        self._hardware_interface = hardware_class()(number_of_cp)  # Init the returned class type
        self._cp_list = LockedCPList(number_of_cp)
        self._shared_last_measure = shared_last_measure
        self._order_system_enabled = CONF.internal.get('receive_orders')
        self._shuffle_seed_generator = generate_seed_every_tot_time(CONF.time.get("shuffle_timer"))
        self._web: Optional[WebInterface] = None
        self._order_counter = 0
        self._thread_status = thread_status

    def register_web_interface(self, web_interface):
        self._web = web_interface

    def serialize_for_debug(self, prefix) -> str:
        cp_serialized = ""
        with self._cp_list.locked() as list:
            for cp in list:
                cp_serialized += f"{cp.serialize_for_debug(prefix=prefix+'  ')}"

        return (
            f"{prefix}CP MANAGER\n"
            f"{prefix}  Hardware interface: {type(self._hardware_interface)}\n"
            f"{prefix}  Shared last measure: {self._shared_last_measure.read()}\n"
            f"{prefix}  QR codes: {'enabled' if self._order_system_enabled else 'disabled'}\n"
            f"{prefix}CP LIST:\n{cp_serialized}"
        )

    def get_power_given_level(self, mono: bool, level: int) -> int:
        return self._hardware_interface.get_power_given_level(mono, level)

    def get_higher_level_given_power(self, mono: bool, power: int) -> int:
        return self._hardware_interface.get_higher_level_given_power(mono, power)

    # External Interface Functions (ORDERS)
    def flag_charging(self,
                      num: int, is_charging: bool, charge_type: str,
                      start: Optional[datetime.datetime] = None):
        # num is cp number from 1 to n, so the index is num - 1
        with self._cp_list.locked() as cp_list:
            cp_list[num - 1].flag_charging(is_charging, charge_type, start)

    def start_charge_session_on_cp(self,
                                   num: int, charge_type: str,
                                   start: Optional[datetime.datetime] = None):
        self.flag_charging(num, True, charge_type, start)

    def stop_charge_session_on_cp(self, num: int):
        self.flag_charging(num, False, "user")

    def suspend_charge_session_on_cp(self, num: int):
        with self._cp_list.locked() as cp_list:
            cp = cp_list[num - 1]
            if cp.pilotated() and cp.supplying():
                logger.info(f"cp {num} suspension set to True")
                cp.status = CPStatus.suspended
                cp.unregister_order()  # TODO: check the order id

    def resume_charge_session_on_cp(self, num: int):
        with self._cp_list.locked() as cp_list:
            cp = cp_list[num - 1]
            if cp.pilotated() and cp.status == CPStatus.suspended:
                logger.info(f"cp {num} suspension set to False")
                cp.status = CPStatus.charging
                cp.unregister_order()  # TODO: check the order id

    def request_suspension(self, cp: int):
        """
        Request the server to suspend a charge.
        :param cp int: the park bnum in range [1..len(cp)]
        """
        if not CONF.park["disable_suspension"]:
            self._request_impl(cp, "suspend")

    def request_resumption(self, cp: int):
        """
        Request the server to suspend a charge.
        :param cp int: the park bnum in range [1..len(cp)]
        """
        self._request_impl(cp, "resume")

    def _request_impl(self, cp: int, order: str):
        assert self._cp_list.is_locked(), "accessing the cpmanager._cp_list without a lock"
        cp_list = self._cp_list._cp_list
        last_order: Optional[OrderInfo] = cp_list[cp - 1]._last_order
        if last_order is not None and last_order.kind == order:
            if last_order.can_retry():
                last_order.retry()
        else:
            assert self._web is not None, "cpmanager's web interface is None, can't make requests!"
            cp_list[cp - 1].register_order(self._order_counter, order)
            self._order_counter += 1
            self._web.send_message(f"ask{order} {CONF.park['park_name']} {cp}")

    def request_resync(self):
        assert self._web is not None, "cpmanager's web interface is None, can't resync!"
        self._web.recover_states()

    def clear_orders(self):
        logger.info("resetting orders")
        with self._cp_list.locked() as cs_list:
            for cp in cs_list:
                cp.unregister_order()

    # FIXME: make sense to move order first init (states recovery) here?
    def no_order_first_initialization(self, cp_list):
        if not self._order_system_enabled:
            logger.info("Start no order first initialization...")
            for i, cp in enumerate(cp_list):
                if not cp.pilotated():
                    continue
                self._hardware_interface.apply_power_level(cp.cpnum, DEFAULT_PWRLV)
                sleep(CONF.time["bootstrap_cp_time"])
                last_metrics: Metrics = self._shared_last_measure.read()
                # FIXME: check if 01/10 is a good choice for first init (alt. 10/11)
                if sum(last_metrics.get_cp_power(i + 1)) > 0:
                    cp.status = CPStatus.starting
                    logger.info(f"CP {i + 1} status set to 'charging'")
                else:
                    cp.status = CPStatus.probing
                    logger.info(f"CP {i + 1} status set to 'probing'")
                self._hardware_interface.apply_power_level(cp.cpnum, 0)
            logger.info("Finished no order first initialization.")

    # Subroutines
    def __prepare_states(self, cp_list: List[ChargePoint], last_metrics: Metrics):
        # Clear old timeout and power budgets from cp_list
        SCALAR = CONF.park["scalar"]
        for i, cp in enumerate(cp_list, 1):
            if not cp.pilotated():
                continue
            if cp.status in (CPStatus.BUG_1, CPStatus.BUG_2):
                logger.warn(f"cp {i} is in state {cp.status}, resetting to 'probing'")
                cp.status = CPStatus.probing

            # Check for orders timed out
            last_order = cp._last_order
            if last_order is not None and last_order.expired() and not last_order.can_retry():
                # TODO: HERE
                self._thread_status.orders_err(255)  # error code 255: order timer expired
                self.request_resync()
                raise RuntimeError("didn't receive response from the server to an order")

            metrics_power = last_metrics.get_cp_power(i)
            # If the C = 0 we need to reset to default the mono because we don't have a car in place
            if not cp.car_present:
                cp.reset_phase_mask()
            # Write down mono/three-phased flags if the cp in the state PC = 11
            elif cp.supplying() and Vector.count_nonzero(last_metrics.phase_mask(i)) != 0:
                cp.current_phase_mask = last_metrics.phase_mask(i)

            # use a single-phase value if we are working in monophase, or in vector mode
            current_mask = cp.current_phase_mask
            # Read, Assign, Reset power_attenuation
            #  cap power is a lower bound
            #  If we have power assigned 4 and effective to 3.5 we have a cap at 3. If our effective
            #  go under 3 (2.9) we flag the power_attenuation at 3, so we can free the power 3to4
            #  for another charge point

            # we now have our max power, and I compare it with the one measured. If this last one is
            # the smaller, we stop charging

            pwratt_cap_power = Vector(current_mask) if not SCALAR else Vector((1, 0, 0))
            multiplier = 3 if SCALAR and cp.n_clamps() in (2, 3) else 1
            if cp.power_level == DEFAULT_PWRLV:
                pwratt_cap_power *= PWRATT_CUTOFF * multiplier
            else:
                pwratt_cap_power *= self.get_power_given_level(True, cp.power_level - 1) \
                    * multiplier

            # here our charging point is "suspended", meaning there is an active order but not
            # enough available power to start the charge
            if not cp.supplying() and cp.car_present:
                # so we can reset the pwratt timer
                cp.state.reset_power_attenuation_timer()

            # if instead we are actually charging, we need to check for how much power the
            # chargepoint is using
            elif cp.state.power_attenuation_timer is not None:
                # Check timer lift (level power 2)

                # if we measure more power than the max power we set earlier we can unlock the
                # power attenuation timer
                if all(metrics_power >= pwratt_cap_power):
                    # all this is to check if we need to lower the power to our charging station or
                    # not, here we see that clearly the car is able to pull more power than we
                    # calculated earlier, so we unlock the timer
                    cp.state.reset_power_attenuation_timer()

                # now we check if we can update power_attenuation:
                # first we check if its timer is expired
                elif cp.state.is_power_attenuation_timer_expired():
                    # is so, we set the new power level

                    # if our cap power is equal to the cutoff we cut the power
                    if cp.power_level == DEFAULT_PWRLV:
                        new_level = 0
                    else:
                        lowest_power = min([pow for pow in metrics_power if pow != 0] or [0])
                        mono = not SCALAR or cp.n_clamps() == 1
                        new_level = self.get_higher_level_given_power(mono, lowest_power)
                        if new_level <= DEFAULT_PWRLV:
                            new_level = DEFAULT_PWRLV

                    cp.power_attenuation_level = new_level

            # Check if we can generate a new Power Attenuation Timer
            elif cp.supplying() and cp.car_present and any(metrics_power < pwratt_cap_power):
                # if we are measure less than our cap power we generate a new timer
                if cp.state.charge_started:
                    cp.state.new_power_attenuation_timer()

            # if we are not charging we reset the pwratt level
            elif not cp.car_present:
                cp.reset_power_attenuation_level()  # Reset when not charging
            # Reset Power Budgets
            cp.reset_budget()
        # (NO ORDER) Flag the charging stations  # TODO: adapt for hybrid parks
        if not self._order_system_enabled:
            for i, cp in enumerate(cp_list):
                if not cp.pilotated():
                    continue
                if cp.supplying():
                    cp.state._car_present = any(last_metrics.get_cp_power(i + 1) > 0)
                    cp.state.charge_started = cp.state._car_present
                # Reset eventually unreachable PC = 00 status  ( fix unreachable 00 )
                if not cp.supplying() and not cp.car_present:
                    cp.status = CPStatus.probing
                    logger.error(f"Chargepoint {i} in unreachable state PC=00, reset to probing")
        # (ORDER) Flag the charge started
        else:
            for i, cp in enumerate(cp_list):
                if cp.state._car_present:
                    if not cp.state.charge_started:
                        power_flowing = any(last_metrics.get_cp_power(i + 1) > 0)
                        cp.state.charge_started = power_flowing
                else:
                    cp.state.charge_started = False

    def __distribute_min_power(self, cp_list: List[ChargePoint], power_available: Vector) \
            -> Vector:
        # Regenerate seed
        seed_shuffle, reshuffled = next(self._shuffle_seed_generator)
        # Shurima Shuffle!
        need_energy = [i for i, cp in enumerate(cp_list) if cp.need_energy() or cp.suspended()]
        random.seed(seed_shuffle)
        random.shuffle(need_energy)
        if len(need_energy) == 0:
            logger.info("no chargepoint needs energy")
        elif not reshuffled:
            logger.info(f"minimum power distribution order is {[i + 1 for i in need_energy]}")
        else:
            logger.info(f"minimum power distribution order changed {[i + 1 for i in need_energy]}")

        def cp_priority_score(x):
            """ Lower score means higher priority """
            cp = cp_list[x]
            score = CONF.park["charge_priority_score"]
            now = datetime.datetime.now(pytz.UTC)
            start_time = cp.state.charge_start_time()
            charge_duration = (start_time - now).total_seconds() if start_time is not None else 0
            charge_is_starting = charge_duration > CONF.time["charge_startup_priority"]
            # Default order:
            # - charges in progress for less than CONF.time["charge_startup_priority"] (0)
            # - stable charges (1)
            # --> VIP users (10)
            #  -> guest users paying with card (20)
            #  -> load-balanced charges and registered users (30)
            # - suspended charges (100)
            # - charges disabled by attenuation (1000)
            # Note that the first "round" after reshuffling must ignore the suspension to be able to
            # determinate who must be resumed and who must be suspended
            flags = {
                    'charge_startup_priority': charge_is_starting,
                    'charge_normal_priority': not charge_is_starting,  # charge is already started
                    'suspended_charge': cp.status == CPStatus.suspended and not reshuffled,
                    'charge_disabled_by_attenuation': cp.power_attenuation_level == 0,
            }
            total_score = sum((score[key] for key, enabled in flags.items() if enabled), cp.priority())
            return total_score

        need_energy.sort(key=cp_priority_score)  # Low Priority at the end
        for i in need_energy:
            cp = cp_list[i]
            if all(cp.request_minimal_power() <= power_available):
                if cp.suspended():
                    logger.info(f"asking to resume cp {i + 1}")
                    self.request_resumption(i + 1)
                    power_available = cp.give_minimum_power(power_available, dry_run=True)
                else:
                    cp.state.supplying = True
                    power_available = cp.give_minimum_power(power_available)
            else:
                if cp.has_qrcode() and not cp.suspended():
                    logger.info(f"requesting suspension for cp {i + 1}")
                    self.request_suspension(i + 1)
                    power_available = cp.give_minimum_power(power_available)
                else:
                    logger.info(f"deactivating cp {i + 1}")
                    cp.state.supplying = False
                    cp.state.override_power_level(0)
        # FIXME: write a better code
        # TODO: hybrid parks
        for cp in cp_list:
            if not cp.car_present:
                if self._order_system_enabled:
                    cp.state.supplying = False
                    cp.state.override_power_level(0)
                else:
                    cp.status = CPStatus.probing
                    cp.state.override_power_level(DEFAULT_PWRLV)  # Off-budget energy
        return power_available

    def __distribute_surplus_power(self, cp_list: List[ChargePoint], power_available: Vector) \
            -> Vector:
        # Regenerate seed
        seed_shuffle, _ = next(self._shuffle_seed_generator)
        # Need_energy erogation
        need_energy = [i for i, cp in enumerate(cp_list) if cp.need_energy()]
        random.shuffle(need_energy)
        logger.info(f"surplus power distribution order is {[i + 1 for i in need_energy]}")

        if len(need_energy) == 0:
            return power_available

        def need_energy_sort_key(j: int) -> float:
            chargepoint = cp_list[j]
            if not chargepoint.can_accept_more_power():
                # I want the "Full chargepoint" as the ABSOLUTE LATEST in need energy priority
                import math
                return math.inf
            return sum(chargepoint.request_next_level_total_power()) / chargepoint.n_clamps()

        need_energy.sort(key=need_energy_sort_key)  # First have high priority, last have low
        while len(need_energy):
            last_power_available = copy(power_available)
            erogate_index = need_energy[0]
            # Assign Energy!
            cp = cp_list[erogate_index]
            power_available = cp.give_next_level_power(power_available)
            if not cp.can_accept_more_power() or all(power_available == last_power_available):
                need_energy = need_energy[1:]
            else:
                # Only need to sort if the first car has received power
                # First have high priority, last have low
                need_energy.sort(key=need_energy_sort_key)
        return power_available

    def erogate(self, first_run=False):
        # Retrieve the last metrics available
        with self._cp_list.locked() as cp_list:
            # Start Erogation subroutines
            if first_run:
                self.no_order_first_initialization(cp_list)
                sleep(15)  # Wait some time to let the charge start correctly

            last_metrics: Metrics = self._shared_last_measure.read()
            available_power = last_metrics.available_power
            residual_power = Vector(available_power)
            if not first_run:
                self.__prepare_states(cp_list, last_metrics)
            residual_power = self.__distribute_min_power(cp_list, residual_power)
            residual_power = self.__distribute_surplus_power(cp_list, residual_power)
            # Charge: Apply the Effective Charge Level
            for cp in cp_list:
                cp.apply_power_budget(self._hardware_interface)

        # Smart debug hooks
        smart_debug.energy_balance(self._cp_list, available_power, residual_power, False)
        smart_debug.cp_list_general_status(self._cp_list)

    def erogate_fallback(self):
        # Bypass Metrics Thread for fallback
        available_power = Vector.zeros(3)
        for clamp in CONF.park.get("guaranteed_min_power", {}):
            phase = clamp['phase']
            power = clamp['power']
            available_power += Vector([phase == 'a', phase == 'b', phase == 'c']) * power
        if CONF.park["scalar"]:
            available_power = Vector([sum(available_power), 0, 0])
        with self._cp_list.locked() as cp_list:
            for cp in cp_list:
                cp.reset_budget()
            # In fallback we give priority to CP numerically first (1>2>3>...)
            for cp in cp_list:
                needed_power = cp.request_minimal_power()
                if all(needed_power < available_power):
                    available_power = cp.give_minimum_power(available_power)
                else:
                    break
            for cp in cp_list:
                cp.apply_power_budget(self._hardware_interface)
        # Smart debug hooks
        smart_debug.energy_balance(self._cp_list, None, available_power, True)
        smart_debug.cp_list_general_status(self._cp_list)
