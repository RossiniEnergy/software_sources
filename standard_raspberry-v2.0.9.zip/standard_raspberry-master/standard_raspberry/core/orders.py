from __future__ import annotations
import json
import logging
from multiprocessing import Queue
from dateutil.parser import isoparse
import paho.mqtt.client as mqtt
import time
from standard_raspberry.core import smart_debug
from standard_raspberry.utils.conf import CONF
from standard_raspberry.core.ipsum import IpsumMetrics
from standard_raspberry.utils.sync import AtomicCounter, AtomicResource, ThreadStatus
from standard_raspberry.core.send_commands import WebInterface

logger = logging.getLogger("rpi.orders")


def pilotated_only(f):
    """
    Decorator which logs and cancel an order directed to a non-qr chargepoint
    """
    def wrapper(*args, **kwargs):
        num = kwargs.get("num") or args[0]
        if CONF.cp[num - 1]["pilotage"] != "qrlb":
            try:
                logger.warning(f"attempt to trigger {f.__name__} for non-qr chargepoint {num}")
            except AttributeError:
                logger.warning(f"attempt to trigger <something> for non-qr chargepoint {num}")
            return
        f(*args, **kwargs)
    return wrapper


class MQTTOrderClient:
    def __init__(
            self,
            cs_list,  # CPManager
            timer_queue: Queue,
            thread_status: ThreadStatus,
            ipsum_buffer: AtomicResource,
            web_interface: WebInterface,
    ):
        # Attributes
        self._cs_list = cs_list
        self._timer_queue = timer_queue
        self._thread_status = thread_status
        self._ipsum_buffer = ipsum_buffer
        self._nb_charging = AtomicCounter(0)
        # Initialization Client and flags
        self._client = mqtt.Client()
        self._web = web_interface
        self._init_mqtt()

    def _on_connect(self, client, _userdata, _flags, errc):
        if errc == 0:
            logger.info("connection established")
            client.subscribe(f"CS_{CONF.park['park_name']}")
            self._thread_status.orders_ok()
            if CONF.internal["can_comunicate"]:
                self._web.recover_states()  # reload every order state in case of reboot
            if CONF.park["with_ipsum"] and self._thread_status.status_code_orders() > 0:
                self._web.recover_ipsum()  # recover ipsum
        elif errc in (4, 5):
            logger.error("invalid username or password, or unauthorized")
        else:
            logger.error(f"returned errc {errc}")

    def _on_connect_fail(self, _client, _userdata):
        self._thread_status.orders_err(1)
        logger.error("connection failed, retrying in 5 seconds...")
        time.sleep(5)

    def _on_message(self, _client, _userdata, msg):
        @pilotated_only
        def start_charge(num: int, charge_type="user", start_time=None):
            with self._nb_charging.incremented() as _:
                self._timer_queue.put(CONF.time["high_activity_metrics_timer"])
                self._cs_list.start_charge_session_on_cp(num, charge_type, start_time)

        @pilotated_only
        def stop_charge(num: int):
            with self._nb_charging.decremented() as ctr:
                if ctr == 0:
                    self._timer_queue.put(CONF.time["low_activity_metrics_timer"])
                self._cs_list.stop_charge_session_on_cp(num)

        def ipsum_receive(payl: bytes):
            ipsum_data = IpsumMetrics.from_encoded_msg(payl)
            self._ipsum_buffer.write(ipsum_data)

        @pilotated_only
        def suspend_charge(num: int):
            self._cs_list.suspend_charge_session_on_cp(num)

        @pilotated_only
        def resume_charge(num: int):
            self._cs_list.resume_charge_session_on_cp(num)

        body = msg.payload.decode()

        # smart debug
        smart_debug.notify_new_order(body)

        command, data = body.split(" ", maxsplit=1)
        # orders
        if command == "charge":
            args = data.split(" ")
            start_charge(int(args[0]), args[1] if len(args) > 1 else "user")
        elif command == "stop_charge":
            stop_charge(int(data))
        elif command == "suspend":
            suspend_charge(int(data))
        elif command == "resume":
            resume_charge(int(data))
        # other stuff
        elif command == "is":
            if CONF.park["with_ipsum"]:
                ipsum_receive(data.encode())
            else:
                logger.warning("Received ipsum message, but it is disabled")
        elif command == "recoverystatus":
            self._cs_list.clear_orders()
            self._thread_status.orders_ok()  # remove error code 255 and others
            self._nb_charging = AtomicCounter(0)
            self._timer_queue.put(CONF.time["low_activity_metrics_timer"])
            try:
                payload = json.loads(data)
                for cs_info in payload["chargingstations"]:
                    bnum = cs_info["park_bnum"]
                    if bnum > len(CONF.cp):
                        continue
                    charge = cs_info.get("active_charge")
                    if charge is None:
                        self._cs_list.stop_charge_session_on_cp(bnum)
                        continue
                    try:
                        lnpt = charge["last_nonzero_power_time"]
                        last_power_time = isoparse(lnpt) if lnpt is not None else None
                    except KeyError:
                        last_power_time = None
                    start_charge(bnum, "guest" if charge["guest"] else "user", last_power_time)
                    if cs_info["suspended"]:
                        suspend_charge(bnum)
            except Exception as exc:
                logger.error("received bad recoverystatus message. Exception: ", exc_info=exc)
        else:
            logger.warning("Received invalid command \"%s\"", body)

    def _on_disconnect(self, _client, _userdata, errc):
        self._thread_status.orders_err(1)
        logger.warning(f"disconnecting: {errc}")

    def _init_mqtt(self):
        logger.info("initializing mqtt")
        self._client.reinitialise()
        self._client.on_connect = self._on_connect
        self._client.on_connect_fail = self._on_connect_fail
        self._client.on_message = self._on_message
        self._client.on_disconnect = self._on_disconnect
        username = f"{CONF.web['mqtt_vhost']}:{CONF.web['mqtt_username']}"
        self._client.username_pw_set(username=username, password=CONF.web["mqtt_password"])
        logger.info(f"connecting to {CONF.web['mqtt_hostname']}, port {CONF.web['mqtt_port']}")
        self._client.connect_async(CONF.web["mqtt_hostname"],
                                   CONF.web["mqtt_port"], keepalive=CONF.web["mqtt_sub_keepalive"])

    def loop_forever(self):
        self._client.loop_forever(retry_first_connection=True)
        logger.warning("Exiting from the Orders Loop...")
