import logging
from standard_raspberry.utils.pilotageinterface import hardware_class
from standard_raspberry.utils.conf import CONF
from standard_raspberry.utils.vector import Vector

debug_options = {}


def energy_balance(cp_list, power_available, last_residue, is_fallback: bool):
    SCALAR = CONF.park["scalar"]
    if SCALAR:
        last_residue = sum(last_residue)

    width = 6
    def fmt(x): return f"{int(x):>{width}}"
    debug_energy_balance_flag = debug_options.get("energy_balance_in_out")
    if debug_energy_balance_flag is not None and debug_energy_balance_flag.read():
        if not is_fallback:
            total = int(sum(power_available))
            if SCALAR:
                out_string = f"Power supply\nPower available: {total:>{width}} W"
            else:
                out_string = \
                        f"Power supply\nPower available: {total:>{width}} W  {power_available} W"
        else:
            out_string = "Power supply in fallback mode"

        cp_balance = ""
        with cp_list.locked() as cp_list:
            total = 0 if SCALAR else Vector.zeros(3)
            for i, cp in enumerate(cp_list):
                on_balance = cp.car_present and cp.supplying
                status = f"{'on' if on_balance else 'off'}-balance"
                if CONF.cp[i]["pilotage"] == 'no':
                    status += ' (pilotage disabled)'
                if cp.state.charge_started is not None and cp.car_present and not cp.supplying:
                    cp_balance += " (suspended)"
                if SCALAR:
                    mono = cp.state.mono
                    power_consume = \
                        hardware_class().get_power_given_level(mono, cp.power_level)
                    cp_balance += f"\n  Chargepoint {i+1}: {power_consume:>{width}} W {status}"
                    if mono and cp.supplying and CONF.internal.get("enable_ghost_power"):
                        cp_balance += f" x3 [ghost power]: {power_consume * 3:>{width}} W"
                else:
                    power_consume_per_ph = \
                        hardware_class().get_power_given_level(True, cp.power_level)
                    power_consume = power_consume_per_ph * cp.current_phase_mask
                    cp_total = sum(power_consume)
                    cp_balance += \
                        f"\n  Chargepoint {i+1}: {cp_total:>{width}} W  {power_consume} W {status}"
                if on_balance:
                    total += power_consume

        if SCALAR:
            out_string += f"\nOn-balance:      {int(total):>{width}} W"
            out_string += cp_balance
            out_string += f"\nResidue:         {int(last_residue):>{width}} W"
        else:
            assert isinstance(total, Vector), "what"
            total_s = int(sum(total))
            residue_s = int(sum(last_residue))
            out_string += f"\nOn-balance:      {total_s:>{width}} W  {total} W"
            out_string += cp_balance
            out_string += f"\nResidue:         {residue_s:>{width}} W  {last_residue} W"
        logging.getLogger("rpi.debug.energy_balance").debug(out_string)


def scatolino_power(power_available, last_time):
    debug_scatolino_power = debug_options.get("scatolino_power")
    if debug_scatolino_power:
        logger = logging.getLogger("rpi.debug.scatolino")
        logger.debug(f"retrieved power from scatolino: {power_available} W ({last_time})")


def cp_list_general_status(cp_list):
    debug_cp_list_general_status = debug_options.get("chargepoint_list_general_status")
    if debug_cp_list_general_status is not None and debug_cp_list_general_status.read():
        out_string = "Current chargepoint status:"
        with cp_list.locked() as cp_list:
            for cp in cp_list:
                i = cp.cpnum
                if CONF.cp[i - 1]["pilotage"] == 'no':
                    out_string += f"\n  Chargepoint {i:<3}pilotage disabled"
                else:
                    state = cp.status.name

                    if CONF.park["scalar"]:
                        # phase = f"{'monophase' if cp.state.mono else 'threephase':<12}"
                        phase = "monophase" if cp.state.mono else "threephase"
                    else:
                        A = 'A' if cp.current_phase_mask[0] != 0 else '_'
                        B = 'B' if cp.current_phase_mask[1] != 0 else '_'
                        C = 'C' if cp.current_phase_mask[2] != 0 else '_'
                        phase = f"phase {A}{B}{C}"
                    if cp.state.power_attenuation_timer is not None:
                        pwratt_timer = cp.state.power_attenuation_timer.isoformat(' ', 'seconds')
                    else:
                        pwratt_timer = "None"
                    out_string += \
                        f"\n  Chargepoint {i:<3}" + \
                        f"state: {state:<12}" + \
                        f"power level: {cp.power_level:<3}" + \
                        f"{phase:<12}" + \
                        f"pwratt: {str(cp.power_attenuation_level):<7}" + \
                        f"pwratt timer: {pwratt_timer}"  # :<34
        logging.getLogger("rpi.debug.general_status").debug(out_string)


def raw_serial(data):
    debug_raw_serial = debug_options.get("raw_serial")
    if debug_raw_serial is not None and debug_raw_serial.read():
        logging.getLogger("rpi.debug.raw_serial").debug(f"Latest serial data:\n\t'{data}'")


def raw_serial_after_calibration(values):
    debug_raw_serial = debug_options.get("raw_serial")
    if debug_raw_serial is not None and debug_raw_serial.read():
        vs = ' '.join(f"{v}" for v in values)
        logging.getLogger("rpi.debug.raw_serial") \
               .debug(f"Latest serial data (recalibrated):\n\t'{vs}'")


def last_measure(metrics):
    debug_last_measure = debug_options.get("last_measure_update")
    if debug_last_measure is not None and debug_last_measure.read():
        logging.getLogger("rpi.debug.last_measure").debug(f"Latest metrics:\n\t{metrics}")


def timers(new_timer, queue_size):
    debug_timers_flag = debug_options.get("sendmetrics_timers")
    if debug_timers_flag is not None and debug_timers_flag.read():
        logging.getLogger("rpi.debug.timers")\
                .debug("SendMetrics's timer set to %s (%s events in queue)", new_timer, queue_size)


def notify_new_order(order):
    debug_orders_flag = debug_options.get("new_orders")
    if debug_orders_flag is not None and debug_orders_flag.read():
        logging.getLogger("rpi.debug.new_order").debug('New order: %s', repr(order))


def global_status(cp_manager, thread_status):
    flag = debug_options.get("global_status", None)
    if flag is not None and flag.read():
        logging.getLogger("rpi.debug.global_status") \
               .debug(f"\n{cp_manager.serialize_for_debug('')}\n{thread_status.serialize_for_debug('')}")
