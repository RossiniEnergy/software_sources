from standard_raspberry.utils.conf import CONF
from standard_raspberry.utils.pilotageinterface import hardware_class
import sys
import argparse
from time import sleep


def set_level():
    if len(sys.argv) < 3:
        # TODO Can argparse auto-generate the Usage?
        print(f"Usage: {sys.argv[0]} <cp_number: int> <level: int> [-f|--force]")
        print(f"\t<cp_number>: the chargepoint index, must be between 1 and {len(CONF.cp)}")
        print("\t<level>:     the power level you want to assign to the chargepoint")
        print("\t--force:     force the chargepoint to remain at the choosen power level even")
        print("\t             if the main program is running")
        exit(0)

    parser = argparse.ArgumentParser()
    parser.add_argument("cp_number", help=f"the chargepoint index, must be between 1 and {len(CONF.cp)}", type=int)
    parser.add_argument("level", help="the power level you want to assign to the chargepoint", type=int)
    parser.add_argument("-f", "--force", help="force the chargepoint to remain at the choosen power level even if the main program is running", action="store_true")

    args = parser.parse_args()

    if not (0 < args.cp_number <= len(CONF.cp)):
        print(f"This device only accepts chargepoints from 1 to {len(CONF.cp)}")
        exit(1)

    # try:
    #     power_level = int(args[1])
    # except ValueError:
    #     print("Second argument must be a number")
    #     exit(1)

    # force_loop = False
    # if len(opts) != 0 and (opts[0][0] == "-f" or opts[0][0] == "--force"):
    #     force_loop = True
    # print(f"loop: {force_loop}")
    # print(f"len(opts): {len(opts)}")

    print(f"Forcing: {args.force}")

    hardware_interface = hardware_class()(len(CONF.cp))

    max_power_level = hardware_interface.get_max_power_level()
    print(f"Max power level allowed by the interface is {max_power_level}")
    power_level = max(0, min(args.level, max_power_level))

    hardware_interface.apply_power_level(args.cp_number, power_level)
    while args.force:
        hardware_interface.apply_power_level(args.cp_number, power_level)
        sleep(1)


if __name__ == "__main__":
    set_level()
