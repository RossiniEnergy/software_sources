from dynaconf import Validator
from standard_raspberry.secrets import secrets

CONF_VER = [
    # Conf version
    Validator("CONF.version", default=1.0)
]

VALIDATORS_V1 = [
    # Conf version
    Validator("CONF.version", default=1.0),
    # User and Power Configuration
    Validator("CONF.cp", must_exist=True, gte=1),
    Validator("CONF.metrics_url", default=secrets['metrics_url']),
    Validator("CONF.get_cs_state_url", default=secrets['get_cs_state_url']),
    Validator("CONF.get_cs_list_url", default=secrets['get_cs_list_url']),
    Validator("CONF.rabbitmq_url", default=secrets['rabbitmq_url']),
    Validator("CONF.park_name", must_exist=True),
    Validator("CONF.production_counting", "CONF.building_counting", "CONF.receive_orders",
              must_exist=True),
    Validator("CONF.building_include_chargepoint", default=True),
    Validator("CONF.fixed_power_from_grid", must_exist=True),
    Validator("CONF.guaranteed_min_power", must_exist=True, gte=0),
    Validator("park.disable_suspension", default=True),
    Validator("CONF.max_available_power", default=None),
    Validator("CONF.lowest_power_level_default", must_exist=True),
    Validator("CONF.min_mono_charging_power", default=400),
    Validator("CONF.clamp_power_cutoff", default=300),
    Validator("CONF.smart_debug", default=True),
    Validator("CONF.debug_config_file", default="/etc/standard-raspberry/debug_options.toml"),
    Validator("CONF.max_retry_attempt", default=3),
    # Clamps enumeration
    Validator(*(f"CONF.cs_{i}" for i in range(1, 17)), default=[], len_max=3),
    Validator("CONF.disable_pilotage_on_cs", default=[]),
    Validator("CONF.unpilotated_default_power_level", default=7),
    Validator("CONF.building", "CONF.production", must_exist=True),
    Validator("CONF.default_calibration_factor", default=1.0, gte=0.0),
    Validator("CONF.specific_calibration_factors", default=[]),
    # Timers and system configurations
    Validator("CONF.hardware_pilotage_version", default=0, gte=0),
    Validator("CONF.supply_loop_timing", default=10, gte=2),
    Validator("CONF.low_activity_metrics_timer", default=120, gte=8),
    Validator("CONF.high_activity_metrics_timer", default=30, gte=8),
    Validator("CONF.shuffle_timer", default=900, gte=8),
    Validator("CONF.power_attenuation_check_timer", default=300, gte=8),
    Validator("CONF.charge_startup_priority_timer", default=60),
    Validator("CONF.bootstrap_cp_time", default=60, gte=8),
    Validator("CONF.nan_buffer_length", default=0, gte=0),
    Validator("CONF.ghost_power_hotfix", default=False),
    Validator("CONF.order_response_timer", default=30),
    # Scatolino - remote power probing
    Validator("CONF.with_scatolino", must_exist=True),
    Validator("CONF.scatolino", default="MISSINGSCATOLINOID"),
    Validator("CONF.scatolino_calculation", default="MISSINGCALCULATION"),
    Validator("CONF.scatolino_include_chargepoint", default=False),
    Validator("CONF.scatolino_timeout", default=50),
    # IPSUM - the new scatolino
    Validator("CONF.with_ipsum", default=False),
    Validator("CONF.ipsum_recovery_api", default=secrets["ipsum_recovery_api"]),
    Validator("CONF.ipsum_timeout", default=50),
    # MQTT
    Validator("CONF.mqtt_vhost", default="chargingstation"),
    Validator("CONF.mqtt_username", default="csremote"),
    Validator("CONF.mqtt_password", default="Tar3ll1PiccAnTi992"),
    Validator("CONF.mqtt_hostname", default="api.charge.re"),
    Validator("CONF.mqtt_port", default="1883"),
    Validator("CONF.mqtt_sub_keepalive", default="30"),
]

VALIDATORS_V2 = [
    # conf
    Validator("CONF.version", default=2.0),
    # park
    Validator("park.park_name", must_exist=True),
    Validator("park.default_calibration_factor", default=1.0),
    Validator("park.with_ipsum", default=False),
    Validator("park.building_include_chargepoint", default=True),
    Validator("park.ipsum_include_chargepoint", default=True),
    Validator("park.fixed_power_from_grid", must_exist=True),
    Validator("park.guaranteed_min_power"),
    Validator("park.disable_suspension", default=False),
    Validator("park.max_power_level", default=None),
    Validator("park.probing_power_level", must_exist=True),
    Validator("park.hardware_pilotage_version", default=0, gte=0),
    Validator("park.default_pilotage", must_exist=True),
    Validator("park.nan_buffer_length", default=0, gte=0),
    Validator("park.min_mono_charging_power", default=400),
    Validator("park.clamp_power_cutoff", default=300),
    Validator("park.production_counting", must_exist=True),
    Validator("park.building_counting", must_exist=True),
    Validator("park.max_available_power", default=None),
    # debug
    Validator("debug.smart_debug", default=True),
    Validator("debug.config_file", default="/etc/standard-raspberry/debug_options.toml"),
    # web
    Validator("web.metrics_url", default="http://api.charge.re/post_power/v1/"),
    Validator("web.mqtt_vhost", default="chargingstation"),
    Validator("web.mqtt_username", default="csremote"),
    Validator("web.mqtt_password", default="Tar3ll1PiccAnTi992"),
    Validator("web.mqtt_hostname", default="api.charge.re"),
    Validator("web.mqtt_port", default="1883"),
    Validator("web.mqtt_sub_keepalive", default="30"),
    # TODO: check if those are used
    Validator("web.get_cs_state_url", default="https://api.charge.re/ischarging/"),
    Validator("web.get_cs_list_url", default="https://api.charge.re/csidlist/"),
    Validator("web.ipsum_recovery_api", default="https://api.charge.re/retrieve_ipsum/"),
    Validator("web.max_retry_attempt", default=3),
    # timings and stuff
    Validator("time.supply_loop_timing", default=10, gte=2),
    Validator("time.low_activity_metrics_timer", default=120, gte=8),
    Validator("time.high_activity_metrics_timer", default=30, gte=8),
    Validator("time.shuffle_timer", default=900, gte=8),
    Validator("time.power_attenuation_check_timer", default=300, gte=8),
    Validator("time.bootstrap_cp_time", default=60, gte=8),
    Validator("time.ipsum_timeout", default=50),
    Validator("time.charge_startup_priority", default=60),
    Validator("time.order_response", default=30),
    # cp
    Validator("cp", must_exist=True),
    # building
    Validator("building", must_exist=True),
    # production
    Validator("production", must_exist=True)
]
