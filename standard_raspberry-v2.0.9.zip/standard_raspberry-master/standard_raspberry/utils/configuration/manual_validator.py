import logging
from dynaconf import Dynaconf
from standard_raspberry.utils.configuration.dynaconf_validator import VALIDATORS_V1, VALIDATORS_V2, CONF_VER
from standard_raspberry.utils.pilotageinterface import hardware_class_impl


logger = logging.getLogger("rpi.conf_validator")


# Check the config v1
def check_conf(conf):
    """
    check the consistency of the information of a v1 CONF file
    """
    def hardware_class():
        """
        drop-in replacement for pilotageinterface.hardware_class which uses the temporary
        conf instead of the validated one
        """
        return hardware_class_impl(conf)
    lowest_power_level_default = conf.get("lowest_power_level_default")
    min_mono_charging_power = conf.get("min_mono_charging_power")
    assert lowest_power_level_default < hardware_class().MAX_POWER_LEVEL
    assert min_mono_charging_power < hardware_class().get_power_given_level(True, lowest_power_level_default)
    already_used_clamps = []
    # Check Production
    production_counting = conf.get("production_counting")
    if production_counting:
        production = conf.get("production")
        for elem in production:
            assert isinstance(elem, dict)
            assert elem.get("phase") in ("mono", "three")
            assert isinstance(elem.get("clamps"), list)
            for clamp in elem.get("clamps"):
                assert isinstance(clamp, int)
                already_used_clamps.append(clamp)
    # Check Building
    building_counting = conf.get("building_counting")
    if building_counting:
        building = conf.get("building")
        for elem in building:
            assert elem.get("phase") in ("mono", "three")
            assert isinstance(elem.get("clamps"), list)
            for clamp in elem.get("clamps"):
                assert isinstance(clamp, int)
                already_used_clamps.append(clamp)
    # Check if we are Enterprise, if we have enough guaranteed_min_power
    if conf.get("receive_orders"):
        guaranteed_min_power = conf.get("guaranteed_min_power")
        lowest_power_level_default = conf.get("lowest_power_level_default")
        disable_pilotage_on_cs = conf.get("disable_pilotage_on_cs")
        min_needed = 0
        for k in range(conf.get("cp")):
            if k + 1 in disable_pilotage_on_cs:
                continue
            clamps = conf.get(f"cs_{k + 1}")
            already_used_clamps += clamps
            if len(clamps) == 1:
                # Support only Mono
                min_needed += hardware_class().get_power_given_level(True, lowest_power_level_default)
            elif len(clamps) > 1:
                # Support Mono and Three, use Three
                min_needed += hardware_class().get_power_given_level(False, lowest_power_level_default)
        if not guaranteed_min_power >= min_needed:
            error_border = "#" * 71 + "\n"
            error_body = "# {:^67} #\n".format(f"Required guaranteed_min_power: {min_needed} W")
            error_hint = "# {:^67} #\n".format("If you have enough power available increase it in the conf file")
            raise AssertionError(
                "\n\n" +
                error_border +
                error_body +
                error_hint +
                error_border +
                "\n"
            )
    # Check if some clamps are repeated
    clamps_repeated = [el for el in already_used_clamps if already_used_clamps.count(el) > 1]
    if len(clamps_repeated) > 0:
        raise AssertionError(
            f"Repeated clamps {clamps_repeated} in the configuration file. Every clamp must be used a single time")
    # Scatolino
    with_scatolino = conf.get("with_scatolino")
    if with_scatolino:
        assert conf.get("scatolino") != "MISSINGSCATOLINOID"
        assert conf.get("scatolino_calculation") != "MISSINGCALCULATION"


# Check the conf v2
# TODO: some validations are present in v1 but not in v2
def check_conf_v2(conf):
    """
    check the consistency of a v2 CONF file
    """
    if conf.get("park.default_pilotage").lower() not in ["qrlb", "lb", "no"]:
        raise ValueError("default_pilotage must be one of 'qrlb', 'lb', 'no'")
    total_clamp_list = []
    # cp consistency
    tmp_cp = []
    for chargepoint in conf.cp:
        if chargepoint is None or chargepoint == {}:
            continue
        if "id" not in chargepoint:
            raise ValueError("missing 'id' in cp item")
        if "clamps" not in chargepoint:
            raise ValueError("missing 'clamps' in cp item")
        for clamp_info in chargepoint.get("clamps"):
            if "clamp" not in clamp_info:
                raise ValueError("missing 'clamp' field in clamp list of cp item")
            if clamp_info["clamp"] in total_clamp_list:
                raise ValueError("clamp in cp item already in use")
            total_clamp_list.append(clamp_info["clamp"])
            if "phase" not in clamp_info:
                raise ValueError("missing 'phase' field in clamp list of cp item")
            if clamp_info["phase"] not in "aAbBcC":
                raise ValueError("wrong phase setting, please use 'a', 'b' or 'c'")
        if "pilotage" in chargepoint:
            if chargepoint["pilotage"].lower() not in ["qrlb", "no", "lb", "default"]:
                raise ValueError("wrong 'pilotage' setting for cp item")
        if 'max_power_level' in chargepoint:
            assert isinstance(chargepoint["max_power_level"], int)
        tmp_cp.append(chargepoint)
    conf.cp = tmp_cp
    # building consistency
    tmp_building = []
    for building in conf.get("building"):
        if building is None or building == {}:
            continue
        if "phases" not in building:
            raise ValueError("missing 'phases' in building item")
        if building["phases"].lower() not in ["three", "mono"]:
            raise ValueError("'phases' in building item must be 'three' or 'mono'")
        if "clamps" not in building:
            raise ValueError("missing 'clamps' in building item")
        for clamp_info in building.get("clamps"):
            if "clamp" not in clamp_info:
                raise ValueError("missing 'clamp' field in clamp list of building item")
            if clamp_info["clamp"] in total_clamp_list:
                raise ValueError("clamp in building item already in use")
            total_clamp_list.append(clamp_info["clamp"])
            if "phase" not in clamp_info:
                raise ValueError("missing 'phase' field in clamp list of building item")
            if clamp_info["phase"] not in "aAbBcC":
                raise ValueError("wrong phase setting, please use 'a', 'b' or 'c'")
        tmp_building.append(building)
    conf["building"] = tmp_building
    # production consistency
    tmp_production = []
    for production in conf.get("production"):
        if production is None or production == {}:
            continue
        if "phases" not in production:
            raise ValueError("missing 'phases' in production item")
        if production.get("phases").lower() not in ["three", "mono"]:
            raise ValueError("'phases' in production item must be 'three' or 'mono'")
        if "clamps" not in production:
            raise ValueError("missing 'clamps' in production item")
        for clamp_info in production.get("clamps"):
            if "clamp" not in clamp_info:
                raise ValueError("missing 'clamp' field in clamp list of production item")
            if clamp_info["clamp"] in total_clamp_list:
                raise ValueError("clamp in production item already in use")
            total_clamp_list.append(clamp_info["clamp"])
            if "phase" not in clamp_info:
                raise ValueError("missing 'phase' field in clamp list of production item")
            if clamp_info["phase"] not in "aAbBcC":
                raise ValueError("wrong phase setting, please use 'a', 'b' or 'c'")
        tmp_production.append(production)
    conf["production"] = tmp_production

    if 'charge_priority' in conf.park:
        for key, item in conf.park["charge_priority"]:
            assert key in ["lb", "user", "guest"], "charge_priority key must be 'lb', 'user' or 'guest'"
            assert isinstance(item, int) or isinstance(item, float), "charge_priority values must be numbers"


def parse_config_file(filename: str):
    """
    parse the file passed as argument, validates the input and returns the result
    """
    settings = Dynaconf(settings_files=[filename], validators=CONF_VER)
    conf = settings.get("CONF")
    conf_version = conf.get("version")

    try:
        if conf_version < 2:
            settings = Dynaconf(settings_files=[filename], validators=VALIDATORS_V1)
            conf = settings.get("CONF")
            check_conf(conf)
        else:
            settings = Dynaconf(settings_files=[filename], validators=VALIDATORS_V2)
            conf = settings
            check_conf_v2(conf)
    except (ValueError, AssertionError, KeyError) as exc:
        logger.critical("Config File Error. Abort.", exc_info=exc)
        import sys
        sys.exit(1)
    conf["conf_version"] = conf_version
    return conf
