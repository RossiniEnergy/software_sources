# pylint: disable=consider-using-ternary
from standard_raspberry.utils.pilotageinterface import hardware_class_impl


class Config:
    version = 0.0
    park = {}
    time = {}
    web = {}
    debug = {}
    legacy = {}
    cp = []
    production = []
    building = []
    internal = {}

    def __init__(self, conf_file):
        # TODO: integrate advanced stuff
        self.version = conf_file["conf_version"]
        if self.version >= 2:
            self.park = conf_file["park"]
            self.web = conf_file["web"]
            self.time = conf_file["time"]
            self.cp = conf_file["cp"]

            self.legacy["building_counting"] = self.park.pop("building_counting", False)
            if self.legacy["building_counting"]:
                self.building = conf_file["building"]
            self.legacy["production_counting"] = self.park.pop("production_counting", False)
            if self.legacy["production_counting"]:
                self.production = conf_file["production"]
            self.debug = conf_file["debug"]

            self.cp.sort(key=lambda cp: cp.id)
        else:
            self.translate_conf(conf_file)
        self.set_defaults()

        # Set the internal, pre-cached variables
        # TODO: it is a good idea to have a production_counting in internal and one in park?
        receive_orders = any(cp["pilotage"] == "qrlb" for cp in self.cp)
        can_comunicate = receive_orders or not self.park["disable_suspension"],
        ghost_power = self.legacy.get("ghost_power_hotfix", False) and self.park.get("scalar", False)
        self.internal = {'receive_orders': receive_orders,
                         'can_comunicate': can_comunicate,
                         'web_enabled': can_comunicate or self.park["with_ipsum"],
                         'enable_ghost_power': ghost_power,
                         'production_counting': self.legacy["production_counting"] and len(self.production),
                         'building_counting': self.legacy["building_counting"] and len(self.building),
                         }
        ipsum_include_cp = self.park['building_include_chargepoint'] and not self.internal['building_counting'],
        if self.version < 2:
            self.park["ipsum_include_chargepoint"] = ipsum_include_cp

    def translate_conf(self, conf_file):
        hw_version = conf_file['hardware_pilotage_version']
        park_keys = (
                'park_name', 'with_ipsum', 'building_include_chargepoint', 'clamp_power_cutoff',
                'hardware_pilotage_version', 'min_mono_charging_power', 'nan_buffer_length',
                'default_calibration_factor', 'max_available_power'
                )
        park_special_keys = {
            'scalar': True,
            'fixed_power_from_grid': [{'phase': 'a', 'power': conf_file['fixed_power_from_grid']}],
            'guaranteed_min_power': [{'phase': 'a', 'power': conf_file['guaranteed_min_power']}],
            'probing_power_level': conf_file['lowest_power_level_default'],
            'default_pilotage': "qrlb" if conf_file['receive_orders'] else "lb",
            'unpilotated_power_level': conf_file['unpilotated_default_power_level'],
            'disable_suspension': True,
            'max_power_level': self.hardware_class(hw_version).get_max_power_level()
        }
        self.park = {
            **park_special_keys,
            **{key: conf_file[key] for key in park_keys}
        }

        legacy_keys = (
                'ghost_power_hotfix', 'with_scatolino', 'scatolino', 'scatolino_calculation',
                'scatolino_include_chargepoint', 'scatolino_timeout',
                'production_counting', 'building_counting'
                )
        self.legacy = {key: conf_file[key] for key in legacy_keys}

        web_keys = (
                'metrics_url', 'get_cs_state_url', 'get_cs_list_url', 'rabbitmq_url',
                'ipsum_recovery_api', 'max_retry_attempt',
                'mqtt_vhost', 'mqtt_username', 'mqtt_password',
                'mqtt_hostname', 'mqtt_port', 'mqtt_sub_keepalive')
        self.web = {key: conf_file[key] for key in web_keys}

        time_keys = (
                'supply_loop_timing', 'low_activity_metrics_timer', 'high_activity_metrics_timer',
                'shuffle_timer', 'power_attenuation_check_timer', 'bootstrap_cp_time',
                'ipsum_timeout'
                )
        self.time = {
            'charge_startup_priority': conf_file['charge_startup_priority_timer'],
            'order_response': conf_file['order_response_timer'],
            **{key: conf_file[key] for key in time_keys}
        }

        self.debug['smart_debug'] = conf_file['smart_debug']
        self.debug['config_file'] = conf_file['debug_config_file']

        default_factor = self.park["default_calibration_factor"]
        calibration = {}
        scf = conf_file.get("specific_calibration_factors")
        if scf is not None:
            calibration = {int(pair["clamp"]): float(pair["factor"]) for pair in scf}
        disabled_cs = conf_file['disable_pilotage_on_cs']
        cp_list = []
        next_phase = {'a': 'b', 'b': 'c', 'c': 'a'}
        ph = 'a'
        for i in range(1, 17):
            cs = conf_file.get(f'cs_{i}')
            if cs is None or len(cs) == 0:
                for j in range(i, 17):
                    cs_ = conf_file.get(f'cs_{j}')
                    if cs_ is not None and len(cs_) != 0:
                        raise AssertionError("cs must be sequentials")
                break
            cp_item = {'id': i, 'clamps': []}
            for clamp in cs:
                cp_item['clamps'].append({
                    'clamp': clamp,
                    'phase': ph,
                    'calibration': calibration.get(clamp, default_factor)
                })
                ph = next_phase[ph]
            if i in disabled_cs:
                cp_item['pilotage'] = "no"
            cp_list.append(cp_item)
        self.cp = cp_list

        building_list = []
        if conf_file["building_counting"]:
            for building in conf_file['building']:
                b = {'phases': building['phase'], 'clamps': []}
                for c in building['clamps']:
                    b['clamps'].append({'phase': "a", 'clamp': c})
                building_list.append(b)
        self.building = building_list

        production_list = []
        if conf_file["production_counting"]:
            for production in conf_file['production']:
                p = {'phases': production['phase'], 'clamps': []}
                for c in production['clamps']:
                    p['clamps'].append({'phase': "a", 'clamp': c})
                production_list.append(p)
        self.production = production_list

    def set_defaults(self):
        def gen_phase(phase, where):
            default = {"phase": phase, "power": 0}
            return next(filter(lambda x: x["phase"] == phase, where), default)

        for item in ("guaranteed_min_power", "fixed_power_from_grid"):
            self.park[item] = [gen_phase(ph, self.park.get(item, {})) for ph in "abc"]

        if 'max_power_level' not in self.park or self.park["max_power_level"] is None:
            self.park['max_power_level'] = self.hardware_class().get_max_power_level()

        # set the cp pilotage to the default one and lowercase the clamps
        max_power_lvl = self.park["max_power_level"]
        for cp in self.cp:
            if 'pilotage' not in cp:
                cp['pilotage'] = self.park["default_pilotage"]
            for clamp in cp["clamps"]:
                clamp["phase"] = clamp["phase"].lower()
            if 'max_power_level' not in cp or cp['max_power_level'] is None:
                if cp['pilotage'] == 'no':
                    cp["max_power_level"] = self.park.get("unpilotated_power_level", max_power_lvl)
                else:
                    cp["max_power_level"] = max_power_lvl

        # normalize the clamps to lowercase
        for item in [*self.production, *self.building]:
            for clamp in item["clamps"]:
                clamp["phase"] = clamp["phase"].lower()
        for clamp in self.park["fixed_power_from_grid"]:
            clamp["phase"] = clamp["phase"].lower()

        # set default priority score. Lower score means higher priority
        default_priority_scores = {
                # low values so the difference can be perceived within the same user category.
                # use values < 10, so it does not interfere with the user category differentiation
                'charge_startup_priority': 0,  # before the `time.charge_startup_priority` expires
                'charge_normal_priority': 1,  # after the `time.charge_startup_priority` expires

                # user category differentiation.
                # use multiples of 10 in order not to interfer with the previous category
                'vip': 10,
                'guest': 20,
                'user': 30,
                'lb': 30,

                # high values so the effect will be greater than that of user category.
                # use multiples of 100 in order not to interfer with the previous categories
                'suspended_charge': 100,
                'charge_disabled_by_attenuation': 1000,
        }
        if 'charge_priority_score' not in self.park:
            self.park["charge_priority_score"] = default_priority_scores
        else:
            tmp = {}
            for key, val in self.park["charge_priority_score"]:
                tmp[key.lower()] = val
            for key, val in default_priority_scores:
                if key not in tmp:
                    tmp[key] = val
            self.park["charge_priority_score"] = tmp

        max_available_power = self.park.get("max_available_power")
        if max_available_power is not None:
            if isinstance(max_available_power, list):
                if self.park["scalar"]:
                    self.park["max_available_power"] = [
                            {'phase': 'a', 'power': sum(ph["power"] for ph in max_available_power)}
                    ]
                else:
                    self.park["max_available_power"] = [
                        {'phase': ph["phase"].lower(), 'power': ph["power"]}
                        for ph in max_available_power
                    ]
            elif isinstance(max_available_power, (int, float)):
                assert self.park["scalar"], "max_available_power can be a number only in scalar mode"
                self.park["max_available_power"] = [{'phase': 'a', 'power': max_available_power}]

    def hardware_class(self, hw_version=None):
        """
        drop-in replacement for pilotageinterface.hardware_class which uses the temporary
        conf instead of the validated one
        """
        if hw_version is None:
            return hardware_class_impl(self)
        return hardware_class_impl(pilotage_version=hw_version)
