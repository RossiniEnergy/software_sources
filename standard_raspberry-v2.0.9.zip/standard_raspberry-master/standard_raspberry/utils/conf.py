from standard_raspberry.utils.configuration.manual_validator import parse_config_file
from standard_raspberry.utils.configuration.config import Config


parsed_conf = parse_config_file('/etc/standard-raspberry/conf.toml')
CONF = Config(parsed_conf)

# DON'T EDIT THIS LINE. THIS IS DONE BY THE AUTOBUILDER
__version__ = '0.0.1'
