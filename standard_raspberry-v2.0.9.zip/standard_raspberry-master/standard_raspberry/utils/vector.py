from collections.abc import Sequence
from numbers import Real, Integral
from typing import Union, Type


def same_length(f):
    def same_length_checker(a, b):
        if isinstance(a, Sequence) and isinstance(b, Sequence) and len(a) != len(b):
            raise ValueError("You can do only vector with the same length")
        return f(a, b)
    return same_length_checker


class Vector(Sequence):
    def __init__(self, obj: Sequence):
        self._data = list(obj)

    # Class Methods
    @classmethod
    def ones(cls, size: Integral):
        return cls([1] * size)

    @classmethod
    def zeros(cls, size: Integral):
        return cls([0] * size)

    def astype(self, newtype: Type):
        return Vector((newtype(val) for val in self))

    # Implement Sequence abs
    @same_length
    def __getitem__(self, item: Union[Sequence, Integral]):
        if isinstance(item, Sequence):
            return self.__class__([val for i, val in enumerate(self._data) if item[i]])
        elif isinstance(item, Integral):
            return self._data[item]
        else:
            raise TypeError("Square braket get can be done with a Sequence or a integer")

    def __contains__(self, item):
        return item in self._data

    def __iter__(self):
        return iter(self._data)

    def __len__(self):
        return len(self._data)

    # Extra methods
    def __setitem__(self, key: Integral, value: Real):
        self._data[key] = value

    def __str__(self):
        return f"[{', '.join(f'{int(s):>6}' for s in self)}]"

    def __repr__(self):
        return repr(self._data)

    def count_nonzero(self):
        return sum(1 for x in self._data if x)

    # Implement math operators
    @same_length
    def __add__(self, other: Sequence):
        return self.__class__([i + j for i, j in zip(self, other)])

    @same_length
    def __sub__(self, other: Sequence):
        return self.__class__([i - j for i, j in zip(self, other)])

    def __mul__(self, other: Real):
        if not isinstance(other, Real):
            raise TypeError("Scalar multiplication requires a scalar. For element-wise use @")
        return self.__class__([i * other for i in self._data])

    @same_length
    def __matmul__(self, other: Sequence):
        """Element-wise multiplication"""
        return self.__class__([i * j for i, j in zip(self, other)])

    def __truediv__(self, other: Real):
        if not isinstance(other, Real):
            raise TypeError("Scalar division requires a scalar. For element-wise use @ with a reciprocal")
        return self.__class__([i / other for i in self._data])

    # Implement reverse math operators
    __radd__ = __add__
    __rsub__ = __sub__
    __rmul__ = __mul__
    __rmatmul__ = __matmul__
    __rtruediv__ = __truediv__

    # Unary operators
    def __neg__(self):
        return self.__class__([-i for i in self._data])

    # Comparison operators
    @same_length
    def __lt__(self, other: Union[Sequence, Real]):
        if isinstance(other, Sequence):
            return self.__class__([i < j for i, j in zip(self, other)])
        elif isinstance(other, Real):
            return self.__class__([i < other for i in self._data])

    @same_length
    def __le__(self, other: Union[Sequence, Real]):
        if isinstance(other, Sequence):
            return self.__class__([i <= j for i, j in zip(self, other)])
        elif isinstance(other, Real):
            return self.__class__([i <= other for i in self._data])

    @same_length
    def __eq__(self, other: Union[Sequence, Real]):
        if isinstance(other, Sequence):
            return self.__class__([i == j for i, j in zip(self, other)])
        elif isinstance(other, Real):
            return self.__class__([i == other for i in self._data])

    @same_length
    def __ne__(self, other: Union[Sequence, Real]):
        if isinstance(other, Sequence):
            return self.__class__([i != j for i, j in zip(self, other)])
        elif isinstance(other, Real):
            return self.__class__([i != other for i in self._data])

    @same_length
    def __gt__(self, other: Union[Sequence, Real]):
        if isinstance(other, Sequence):
            return self.__class__([i > j for i, j in zip(self, other)])
        elif isinstance(other, Real):
            return self.__class__([i > other for i in self._data])

    @same_length
    def __ge__(self, other: Union[Sequence, Real]):
        if isinstance(other, Sequence):
            return self.__class__([i >= j for i, j in zip(self, other)])
        elif isinstance(other, Real):
            return self.__class__([i >= other for i in self._data])


@same_length
def maximum(a: Vector, b: Vector) -> Vector:
    return Vector([max(x, y) for x, y in zip(a, b)])


@same_length
def minimum(a: Vector, b: Vector) -> Vector:
    return Vector([min(x, y) for x, y in zip(a, b)])
