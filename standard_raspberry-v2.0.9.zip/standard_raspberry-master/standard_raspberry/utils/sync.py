from contextlib import contextmanager
from copy import deepcopy
from threading import Lock


class RWLock(object):
    """ RWLock class; this is meant to allow an object to be read from by
        multiple threads, but only written to by a single thread at a time.
        See: https://en.wikipedia.org/wiki/Readers%E2%80%93writer_lock
        Usage:
            from rwlock import RWLock
            my_obj_rwlock = RWLock()
            # When reading from my_obj:
            with my_obj_rwlock.r_locked():
                do_read_only_things_with(my_obj)
            # When writing to my_obj:
            with my_obj_rwlock.w_locked():
                mutate(my_obj)
    """

    def __init__(self):

        self.w_lock = Lock()
        self.num_r_lock = Lock()
        self.num_r = 0

    # ___________________________________________________________________
    # Reading methods.

    def r_acquire(self):
        self.num_r_lock.acquire()
        self.num_r += 1
        if self.num_r == 1:
            self.w_lock.acquire()
        self.num_r_lock.release()

    def r_release(self):
        assert self.num_r > 0
        self.num_r_lock.acquire()
        self.num_r -= 1
        if self.num_r == 0:
            self.w_lock.release()
        self.num_r_lock.release()

    @contextmanager
    def r_locked(self):
        """ This method is designed to be used via the `with` statement. """
        try:
            self.r_acquire()
            yield
        finally:
            self.r_release()

    # ___________________________________________________________________
    # Writing methods.

    def w_acquire(self):
        self.w_lock.acquire()

    def w_release(self):
        self.w_lock.release()

    @contextmanager
    def w_locked(self):
        """ This method is designed to be used via the `with` statement. """
        try:
            self.w_acquire()
            yield
        finally:
            self.w_release()


class AtomicResource:
    def __init__(self, obj):
        self.data = obj
        self.rwlock = RWLock()

    def read(self):
        with self.rwlock.r_locked():
            return deepcopy(self.data)

    def write(self, new_obj):
        with self.rwlock.w_locked():
            self.data = deepcopy(new_obj)


class AtomicCounter:
    def __init__(self, start=0):
        self.data = deepcopy(start)
        self.rwlock = RWLock()

    def read(self):
        with self.rwlock.r_locked():
            return deepcopy(self.data)

    @contextmanager
    def incremented(self):
        try:
            self.rwlock.w_acquire()
            self.data += 1
            yield self.data
        finally:
            self.rwlock.w_release()

    @contextmanager
    def decremented(self):
        try:
            self.rwlock.w_acquire()
            self.data -= 1
            yield self.data
        finally:
            self.rwlock.w_release()

    def increment(self):
        with self.rwlock.w_locked():
            self.data += 1
            return deepcopy(self.data)

    def decrement(self):
        with self.rwlock.w_locked():
            self.data -= 1
            return deepcopy(self.data)


class ThreadStatus:
    def __init__(self):
        self._measurements = AtomicResource(0)
        self._orders = AtomicResource(0)
        self._sendcommands = AtomicResource(0)
        self._sendmetrics = AtomicResource(0)

    def serialize_for_debug(self, prefix) -> str:
        return (
            f"{prefix}THREAD STATUS\n"
            f"{prefix}  measurements: {self.status_code_measurements()}\n"
            f"{prefix}  orders:       {self.status_code_orders()}\n"
            f"{prefix}  sendcommands: {self.status_code_sendcommands()}\n"
            f"{prefix}  sendmetrics:  {self.status_code_sendmetrics()}\n"
        )

    def measurements_ok(self):
        self._measurements.write(0)

    def orders_ok(self):
        self._orders.write(0)

    def sendcommands_ok(self):
        self._sendcommands.write(0)

    def sendmetrics_ok(self):
        self._sendmetrics.write(0)

    def measurements_err(self, errcode: int):
        self._measurements.write(errcode)

    def orders_err(self, errcode: int):
        self._orders.write(errcode)

    def sendcommands_err(self, errcode: int):
        self._sendcommands.write(errcode)

    def sendmetrics_err(self, errcode: int):
        self._sendmetrics.write(errcode)

    def status_code_measurements(self) -> int:
        return self._measurements.read()

    def status_code_orders(self) -> int:
        return self._orders.read()

    def status_code_sendcommands(self) -> int:
        return self._sendcommands.read()

    def status_code_sendmetrics(self) -> int:
        return self._sendmetrics.read()
