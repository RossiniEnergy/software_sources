import logging
import time
from multiprocessing import Queue


def setup_logger():
    """
    creates and configures the main logger
    """
    local_logger = logging.getLogger("rpi")
    local_logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    formatter = logging.Formatter('\033[1m[%(asctime)sZ|%(levelname)s]\033[0m: %(name)s: %(message)s')
    formatter.converter = time.gmtime
    handler.setFormatter(formatter)
    local_logger.addHandler(handler)
    return local_logger


logger = setup_logger()


from standard_raspberry.utils.conf import CONF
from standard_raspberry.utils.sync import AtomicResource, ThreadStatus
from standard_raspberry.core.cpmanager import CPManager
from standard_raspberry.core.measurements import Measurements
from standard_raspberry.core.orders import MQTTOrderClient
from standard_raspberry.core.send_commands import SendCommands, WebInterface
from standard_raspberry.core.send_metrics import SendMetrics
from standard_raspberry.core.supply import Supply
from standard_raspberry.core.ipsum import recover_ipsum


def main():
    # <----- SMART DEBUG BEGIN ----->
    try:
        if CONF.debug["smart_debug"]:
            from standard_raspberry.core.debug_options_scanner import Debug

            debug = Debug()
            debug.start()
    except (AssertionError, KeyError) as exc:
        logger.critical("Debug Config File Error. Abort.", exc_info=exc)
        import sys
        sys.exit(1)
    # <----- SMART DEBUG END ----->

    shared_last_measure = AtomicResource(None)
    thread_status = ThreadStatus()
    ipsum_buffer = AtomicResource(None)
    timer_queue = Queue()
    cpmanager = CPManager(len(CONF.cp), shared_last_measure, thread_status)
    command_queue = Queue()
    web = WebInterface(command_queue, ipsum_buffer)
    cpmanager.register_web_interface(web)

    # recover ipsum
    if CONF.park.get("with_ipsum"):
        logger.info("Retrieving ipsum data...")
        try:
            recover_ipsum(ipsum_buffer)
            logger.info("Ipsum data retrieved")
        except Exception:
            logger.info("Failed to retrieve ipsum data - starting in fallback mode")
            thread_status.orders_err(3)

    # Create and launch threads
    measurements = Measurements(shared_last_measure, thread_status, ipsum_buffer)
    send_metrics = SendMetrics(shared_last_measure, timer_queue, thread_status)
    supply = Supply(cpmanager, thread_status)
    send_commands = SendCommands(thread_status, command_queue)

    measurements.start()
    send_metrics.start()
    supply.start()
    send_commands.start()

    if CONF.internal.get("web_enabled"):
        orderclient = MQTTOrderClient(cpmanager, timer_queue, thread_status, ipsum_buffer, web)
        orderclient.loop_forever()
    else:
        from time import sleep

        while True:
            sleep(5)


if __name__ == '__main__':
    main()
