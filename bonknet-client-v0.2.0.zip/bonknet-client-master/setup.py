import setuptools

setuptools.setup(name='bonknet_client',
                 version='0.2.0',
                 description='Bonknet client for remote connection and control',
                 author='Rossini energy',
                 author_email='federico@rossinienergy.com',
                 packages=setuptools.find_packages(
                     where='.',
                     include=['bonknet_client*']
                 ),
                 package_dir={"": "."},
                 # package_data={"": ["conf.toml", "debug_options.toml"]},
                 # include_package_data=True,
                 entry_points={
                     'console_scripts': [
                         'bonknet-client = bonknet_client.__main__:main',
                     ]
                 },
                 install_requires=['pika', 'toml']
                 )
