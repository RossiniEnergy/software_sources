# Backend Rossini Energy
This is the software that manage the full backend stack of the Rossini Energy
main system, from the talking with the charging stations to the scheduling and processing
of the requests.

Right now the project require a set of config files you need to create:
- An environment file `.env` with the format present in `.env.example`
- A `docker-compose.yml` with the format of one of the various compose example files
- A `rabbitmq_definitions.json` with the format of `rabbitmq_definitions.example.json`
- A `nginx.conf` with the format of `nginx.example.conf` used only in Staging Configuration
- An optional `.env-migration` with the format of `.env-migration.example`

The `SECRET_KEY` is used only to generate and sign the cookie's session_id token.\
The reason why it's not included is to prevent the reuse of the same key in more critical place.
Changing the key cause only all the opened session to became invalid, that's not a problem.

To start the software you just need to have Docker installed and configued with
[Buildkit](https://docs.docker.com/develop/develop-images/build_enhancements/#to-enable-buildkit-builds) enabled for 
the launched commands or directly from daemon configuration.\
If your Docker has been installed after October 2020 or recently reset to factory settings is very
probable that you have it already enabled correctly.

Before everything you need to copy the example files and create your local version of the config files.\
You have available 3 docker compose example files:
- `docker-compose.local.yml` is with Backend, RabbitMQ, Redis, PostgreSQL that expect to run with the default
urls present in `.env.example` and a pre-existent Docker Network called `local_network`
- `docker-compose.staging.yml` is with Backend, RabbitMQ, Redis, PostgreSQL, Nginx that expect to run over a 
pre-existent Docker Network called `staging_network`
- `docker-compose.migratefromold.yml` is a override file used to enable the reading of the host environment variable
`SSHTUNNEL_HOSTPKEY` and allow the migration of the Docker database from a pre-existent one


First of all you need to create the Docker Network, for Local configuration you need to do:
```shell
docker network create local_network
```
or for Staging:
```shell
docker network create staging_network
```

After you created and **configured** everything you can then launch the Full Stack from Docker Compose:
```shell
docker compose up -d
```
where the `-d` is the daemon option to not block the shell with the operation.

The opened port for the local config are:
| Service             | Host Port |
|---------------------|-----------|
| Backend             | 8000      |
| Database            | 5432      |
| RabbitMQ/MQTT       | 1883      |
| RabbitMQ/AMQP       | 5672      |
| RabbitMQ/Management | 15672     |

The opened port for local are:
| Service             | Host Port |
|---------------------|-----------|
| Web Server HTTP     | 80        |
| Web Server HTTPS    | 443       |
| Database            | 5432      |
| RabbitMQ/MQTT       | 1883      |
| RabbitMQ/AMQP       | 5672      |
| RabbitMQ/Management | 15672     |

The staging configuration is created with in mind integrability with other Docker Compose projects like charge.re or 
admin and superadmin panels using `staging_network`.

Generally you don't need to rebuild the image until you don't edit a Dockerfile.\
You need to rebuild a container if you change the .env file becuase they are
staticized by Docker inside the container instance.\
Generally in this situation you can run:
```shell
docker compose down
docker compose up -d --build
```
and add `--scale celey_worker=3` if you want.\
If you need to restart the software after you changed the source code you can simply restart the container.
Docker will reload the volume with the source code automatically.

This operation DON'T DELETE THE INFORMATION OF THE DATABASE because they are stored in a volume
that you need to address separately.\
To reset the local information of all downed container you just need to run
```shell
docker volume prune
```
or use the option `-v` when you put down your compose:
```shell
docker compose down -v
```

If you want to have more than one Celery Worker (generally 3 is a good number to have even in devel)
you can use this command (usable even if the docker is already started):
```shell
docker compose up -d --scale celery_worker=3
```

## Migration from Production Database
You now have the full infrastructure running but the database is empty.\
If you instead want to do test on the production dataset, you need to create a second environment file
called `.env-migration` to hold a new set of informations required for the migration.\
The template is called `.env-migration.example`.

There is a special override file called `docker-compose.migratefromold.yml` that modify the web (Django) container 
adding a SSH Key as OS enviroment variable with this command for Linux (insert the right private key path):
```shell
export SSHTUNNEL_HOSTPKEY=/home/user/.ssh/id_ed25519
```
and this for Windows:
```powershell
$env:SSHTUNNEL_HOSTPKEY="C://Users/name/.ssh/id_ed25519"
```

After you created and configured this special env file, you need to launch this compose command:
```shell
docker compose -f docker-compose.yml -f docker-compose.migratefromold.yml run --rm django python manage.py migratefromold
```

After this command is completed, your local docker database is populated with the production data (if you configured 
everything correctly).

The command is extremely conservative on the production database, but can sometime return error because a table has been
modified during the queries and the data retrieved are desynced. I'm fixing this.
