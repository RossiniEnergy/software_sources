import logging
import shlex

from django.conf import settings
from django.core.management.base import BaseCommand

from pika.exchange_type import ExchangeType

from re_restapi.libs.ipsum import task_post_ipsum_bytecode
from re_restapi.libs.rmqconsumer import ReconnectingRMQConsumer

logger = logging.getLogger('re.command.runipsumrouter')


def message_elaboration(body, _properties):
    """
    :param bytes body: Body of the message to elaborate
    :param dict _properties: Properties of the message, like app_id and headers
    """
    data = body.decode()
    args = shlex.split(data)
    sid = args[0]
    basecoded = args[1]
    task_post_ipsum_bytecode.delay(basecoded, sid)


class Command(BaseCommand):
    help = "Run the RabbitMQ Router/Consumer for IPSUM"

    def handle(self, *args, **options):
        # TODO Make the queue as DURABLE
        consumer = ReconnectingRMQConsumer(
            amqp_url=settings.IPSUM_BROKER_URL,
            exchange='amq.topic',
            exchange_type=ExchangeType.topic,
            queue='SERVER',
            routing_key='SERVER',
            callback=message_elaboration,
            prefetch_count=10
        )
        print(" [x] Awaiting RPC requests")
        consumer.run()
