from django.core.serializers.json import DjangoJSONEncoder
from rest_framework import serializers
from re_restapi.models import Charge


class ChargeNoUserSerializer(serializers.ModelSerializer):
    qrcodeid = serializers.IntegerField(source='chargingstation.qrcodeid')
    park_id = serializers.IntegerField(source='chargingstation.park_id')

    class Meta:
        model = Charge
        fields = ['id', 'chargingstation', 'qrcodeid', 'start', 'stop', 'last_nonzero_power_time', 'energy_wh',
                  'park_id']


# noinspection PyAbstractClass
class CreatePMSSubUserSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=50)
    password = serializers.CharField(max_length=50)
    expire_datetime = serializers.DateTimeField(allow_null=True, default=None)
    price = serializers.IntegerField(default=0)
    memory = serializers.JSONField(encoder=DjangoJSONEncoder, default=dict())

    # noinspection PyMethodMayBeStatic
    def validate_username(self, value):
        if '$' in value:
            raise serializers.ValidationError("'$' is an illegal character for a username")
        elif '#' in value:
            raise serializers.ValidationError("'#' is an illegar character for a username")
        return value


# noinspection PyAbstractClass
class PMSSubUserSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    username = serializers.CharField(max_length=50)
    expire_datetime = serializers.DateTimeField(allow_null=True, default=None)
    expired = serializers.BooleanField(read_only=True)
    price = serializers.IntegerField(default=0)
    memory = serializers.JSONField(encoder=DjangoJSONEncoder)
    charges = serializers.ListField(child=ChargeNoUserSerializer(read_only=True, allow_null=True))


# noinspection PyAbstractClass
class PMSTotalEnergyUser(serializers.Serializer):
    energy_wh = serializers.IntegerField()
    price_cents = serializers.IntegerField()
    total_price_cents = serializers.IntegerField()
