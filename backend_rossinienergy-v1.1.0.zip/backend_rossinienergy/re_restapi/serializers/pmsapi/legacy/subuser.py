from rest_framework import serializers


# noinspection PyAbstractClass
class CreatePMSLegacySubUserSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=50)
    password = serializers.CharField(max_length=50)
    expire_datetime = serializers.DateTimeField(allow_null=True, default=None)

    # noinspection PyMethodMayBeStatic
    def validate_username(self, value):
        if '$' in value:
            raise serializers.ValidationError("'$' is an illegal character for a username")
        elif '#' in value:
            raise serializers.ValidationError("'#' is an illegar character for a username")
        return value


# noinspection PyAbstractClass
class PMSLegacySubUserSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    username = serializers.CharField(max_length=50)
    expire_datetime = serializers.DateTimeField(allow_null=True, default=None)
    expired = serializers.BooleanField(read_only=True)
