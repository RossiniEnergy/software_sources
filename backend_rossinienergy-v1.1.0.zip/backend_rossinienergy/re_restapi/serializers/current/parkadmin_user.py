import datetime
import logging
import random

import pytz
from django.db import transaction
from rest_framework import serializers
from rest_framework.utils import model_meta

from re_restapi.models import User, ChargingStation, ChargeFeature
from re_restapi.serializers.current.user_utils import serializer_validate_username

logger = logging.getLogger('re.serializers.current.parkadmin_user')


class ParkadminUserDefaultUsername:
    """
    May be applied as a `default=...` value on a serializer field.
    """
    requires_context = True

    def __call__(self, serializer_field):
        # Retrieve parent user from the request
        parent_user = serializer_field.context['request'].user
        # Find unused random_username with a sequential available suffix number
        i = 1
        while i < 1_000_000:
            random_username = "{}_{}".format(parent_user.username, i)
            if not User.objects.filter(username=random_username).exists():
                break
            i += 1
        else:
            msg = "Trying to create a temp user with id over 1'000'000. This is a sign of database saturation."
            raise ValueError(msg)
        return random_username


class ParkadminUserDefaultAuthorizedCs:
    """
    May be applied as a `default=...` value on a serializer field.
    """
    requires_context = True

    def __call__(self, serializer_field):
        # Retrieve parent user from the request
        parent_user = serializer_field.context['request'].user
        # Retrieve the managed parks
        if not parent_user.has_parkadmin_feat:
            msg = "Impossible to generate a default authorization set for a user without the parkadmin feature"
            raise ValueError(msg)
        managed_parks = parent_user.parkadminfeature.managed_parks.all()
        # Generate the authorized_cs list
        authorized_cs = []
        for park in managed_parks:
            authorized_cs.extend(list(park.chargingstation_set.all().values_list('bnum', flat=True)))
        return authorized_cs


class ParkadminUserSerializer(serializers.ModelSerializer):
    new_password = serializers.CharField(
        required=False,
        write_only=True
    )
    password = serializers.SerializerMethodField(allow_null=True)
    authorized_cs = serializers.PrimaryKeyRelatedField(
        many=True,
        source='chargefeature.authorized_cs',
        queryset=ChargingStation.objects,
        allow_empty=True,
    )
    scheduled_expire_time = serializers.DateTimeField(
        allow_null=True,
        default=None,
    )

    # noinspection PyMethodMayBeStatic
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.temp_password = None

    def to_representation(self, instance):
        result = super().to_representation(instance)
        # Make the field password disappear if None
        if result.get('password') is None:
            result.pop('password')
        return result

    def get_password(self, obj) -> str:
        return self.temp_password

    # noinspection PyMethodMayBeStatic
    def validate_authorized_cs(self, value):
        # We do manual validation for security and compatibility reasons
        # Check duplicates
        value_len = len(value)
        if value_len != len(set(value)):
            raise serializers.ValidationError(
                "authorized_cs contains duplicate elements."
            )
        # Check if bnum exists
        query_len = ChargingStation.objects.filter(bnum__in=value).count()
        if value_len != query_len:
            raise serializers.ValidationError(
                "authorized_cs contains non-existent charging stations bnum"
            )
        # Valid
        return value

    # noinspection PyMethodMayBeStatic
    def validate_scheduled_expire_time(self, value):
        if value is not None and value < datetime.datetime.now(pytz.UTC):
            raise serializers.ValidationError(
                "Trying to create a user with expire_datetime in the past."
            )
        return value

    # noinspection PyMethodMayBeStatic
    def validate_username(self, value):
        return serializer_validate_username(value)

    class Meta:
        model = User
        fields = ['id', 'username', 'password', 'new_password', 'email', 'is_active', 'is_staff', 'is_superuser',
                  'is_readonly', 'authorized_cs', 'scheduled_expire_time']
        read_only_fields = ['is_active', 'is_staff', 'is_superuser', 'is_readonly']
        extra_kwargs = {
            'username': {'default': ParkadminUserDefaultUsername()},
        }

    def create(self, validated_data):
        parent_user: User = self.context['request'].user
        assert parent_user.has_parkadmin_feat
        if 'new_password' in validated_data:
            self.temp_password = validated_data.pop('new_password')
        else:
            self.temp_password = str(random.randint(1_000_000, 9_999_999))
        authorized_cs = validated_data.pop('chargefeature').pop('authorized_cs')
        with transaction.atomic():
            # New user
            tmp_user = User.objects.create_user(
                password=self.temp_password,
                email="",
                on_expire_readonly=True,
                on_expire_disable=True,
                on_expire_appendtimestamp=False,
                **validated_data
            )
            # Enable charge
            charge_feat = ChargeFeature(user=tmp_user)
            charge_feat.authorized_cs.add(*authorized_cs)  # This can accept list of pk so it works
            charge_feat.save()
            # Register the user as managed by parent_user
            parent_user.parkadminfeature.child_users.add(tmp_user)
            parent_user.save()
        tmp_user.refresh_features_from_db()
        logger.info(f"Created tmp user with username \"{tmp_user.username}\" for the user \"{tmp_user.username}\".")
        return tmp_user

    def update(self, instance: User, validated_data):
        parent_user: User = self.context['request'].user
        assert parent_user.has_parkadmin_feat
        assert instance.has_charge_feat
        if 'chargefeature' in validated_data:
            authorized_cs = validated_data.pop('chargefeature').pop('authorized_cs')
        else:
            authorized_cs = None
        with transaction.atomic():
            # Change Password
            if 'new_password' in validated_data:
                self.temp_password = validated_data.pop('new_password')
                instance.set_password(self.temp_password)
            # Manually set authorized_cs
            if authorized_cs is not None:
                instance.chargefeature.authorized_cs.clear()
                instance.chargefeature.authorized_cs.add(*authorized_cs)  # This can accept list of pk so it works
            # Standard Update procedure and end
            info = model_meta.get_field_info(instance)

            # Simply set each attribute on the instance, and then save it.
            # Note that unlike `.create()` we don't need to treat many-to-many
            # relationships as being a special case. During updates we already
            # have an instance pk for the relationships to be associated with.
            m2m_fields = []
            for attr, value in validated_data.items():
                if attr in info.relations and info.relations[attr].to_many:
                    m2m_fields.append((attr, value))
                else:
                    setattr(instance, attr, value)

            instance.save()

            # Note that many-to-many fields are set after updating instance.
            # Setting m2m fields triggers signals which could potentially change
            # updated instance and we do not want it to collide with .update()
            for attr, value in m2m_fields:
                field = getattr(instance, attr)
                field.set(value)

            return instance
