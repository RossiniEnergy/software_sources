import random
import string

from rest_framework import serializers

from re_restapi.models import PMSPendingRequest, Park


def default_registration_token():
    return ''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(24))


class PMSPendingRequestSerializer(serializers.ModelSerializer):
    """
    Used in internal panels and not in PMS API
    """

    class Meta:
        model = PMSPendingRequest
        fields = ['id', 'label', 'authorized_parks', 'registration_token', 'pms']
        extra_kwargs = {
            'registration_token': {'default': default_registration_token},
        }

    # noinspection PyMethodMayBeStatic
    def validate_authorized_parks(self, value):
        # TODO: Check if there's another Pending Request for these parks - In theory is done via Many to Many DB
        # Check if every park requested is in fact adminless
        if any([i.admin_users.exists() for i in value]):
            raise serializers.ValidationError(
                "One of the parks is already managed by a user."
            )
        return value

    # noinspection PyMethodMayBeStatic
    def validate(self, data):
        # Retrieve the pms
        if 'pms' in data:
            pms_id = data['pms']
        elif self.partial:
            pms_id = self.instance.pms.id
        else:
            raise serializers.ValidationError("Unable to parse pms: missing value")
        return data
