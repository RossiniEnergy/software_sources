import re

from rest_framework import serializers


def serializer_validate_username(value):
    regex = r"^[A-zÀ-ù][^$#@\s]*$"  # start with letter, follow zero or more char that are not $, #, @ or space.
    match = re.compile(regex).match(value)
    if match is None:
        return serializers.ValidationError(
            "Username need to respsect start with letter, follow zero or more char that are not $, #, @ or space."
        )
    elif match[0] != value:
        return serializers.ValidationError(
            "The validator match on username returned an uncomplete value, report to administrator."
        )
    return value
