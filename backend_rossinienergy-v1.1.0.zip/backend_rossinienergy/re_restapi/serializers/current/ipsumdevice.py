from rest_framework import serializers

from re_restapi.models import IPSUMDevice


class IPSUMDeviceSerializer(serializers.ModelSerializer):
    class Meta:
        model = IPSUMDevice
        fields = ['id', 'token', 'alias', 'save_data', 'linked_parks', 'autosave_min_interval', 'autodrop_max_interval',
                  'expected_clamps', 'software_version', 'note']
        extra_kwargs = {
            'linked_parks': {'read_only': True},
            'software_version': {'read_only': True},
        }

    # noinspection PyMethodMayBeStatic
    def validate_expected_clamps(self, value):
        if value < 1:
            raise serializers.ValidationError("Unable to parse expected_clamps: need to be greater than 1")
        return value
