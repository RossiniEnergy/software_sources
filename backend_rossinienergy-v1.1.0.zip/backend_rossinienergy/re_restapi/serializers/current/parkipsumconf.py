from py_expression_eval import Parser
from rest_framework import serializers

from re_restapi.models import ParkIpsumConf, IPSUMDevice


class ParkIpsumConfSerializer(serializers.ModelSerializer):
    class Meta:
        model = ParkIpsumConf
        fields = ['park', 'linked_ipsums', 'avalpower_formula_1', 'avalpower_formula_2', 'avalpower_formula_3',
                  'postponed_send_timing', 'last_send_timestamp']
        extra_kwargs = {
            'last_send_timestamp': {'read_only': True},
        }

    # noinspection PyMethodMayBeStatic
    def validate(self, data):
        # Retrieve the list of linked ipsums
        if 'linked_ipsums' in data:
            linked_ipsums = [obj.id for obj in data['linked_ipsums']]
        elif self.partial:
            linked_ipsums = self.instance.linked_ipsums.values_list('id', flat=True)
        else:
            linked_ipsums = []
            # raise serializers.ValidationError("Unable to parse ipsum_avalpower_formula: missing linked_ipsums")
        for number in (1, 2, 3):
            try:
                parser = Parser()
                # Retrieve the ipsum_avalpower_formula
                if f'avalpower_formula_{number}' in data:
                    avalpower_formula = data[f'avalpower_formula_{number}']
                elif self.partial:
                    avalpower_formula = getattr(self.instance, f'avalpower_formula_{number}')
                else:
                    if number > 1:
                        return data
                    else:
                        raise serializers.ValidationError(f"Unable to parse avalpower_formula_{number}: missing value")
                if number > 1 and avalpower_formula == "":
                    return data
                # Execute and verify the parse
                parsed = parser.parse(avalpower_formula)
                for var in parsed.variables():
                    # Verify that variables are in the format and pattern D21P3
                    if var[0] == 'D':
                        splitted = var[1:].split('P')
                        if len(splitted) != 2:
                            raise serializers.ValidationError(f"Invalid variable name {var}")
                        ipsum_id, power_id = (int(x) for x in splitted)
                        # Check if ipsum_id is valid
                        try:
                            ipdevice = IPSUMDevice.objects.get(pk=ipsum_id)
                        except IPSUMDevice.DoesNotExist:
                            raise serializers.ValidationError(f"Ipsum with id {ipsum_id} doesn't exist")
                        if ipsum_id not in linked_ipsums:  # IPSUMDevice in linked_ipsums
                            raise serializers.ValidationError(f"Ipsum with id {ipsum_id} is not linked")
                        # Check if power_id is valid
                        expected_clamps = ipdevice.expected_clamps
                        if power_id < 0 or power_id > expected_clamps:
                            raise serializers.ValidationError(
                                f"Variable D{ipsum_id}P number need to be between 1 and expected_clamps {expected_clamps}")
            except KeyError:
                raise serializers.ValidationError(f"Unable to parse avalpower_formula_{number}: Variable Format Error")
            except serializers.ValidationError:
                raise
            except Exception:
                raise serializers.ValidationError(f"Unable to parse avalpower_formula_{number}")
        return data
