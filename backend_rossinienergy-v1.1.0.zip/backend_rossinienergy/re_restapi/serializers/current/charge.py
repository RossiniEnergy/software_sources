from rest_framework import serializers

from re_restapi.models import Charge
from re_restapi.serializers.current.featured_user import FeaturedUserSerializer
from re_restapi.serializers.v1.cspower import CSLastPowerSerializer


class InternalChargeSerializer(serializers.ModelSerializer):
    last_power = CSLastPowerSerializer(source='chargingstation.last_power', required=False)

    class Meta:
        model = Charge
        fields = ['id', 'start', 'stop', 'user', 'last_nonzero_power_time', 'energy_wh', 'last_power']


class InternalStandaloneChargeSerializer(serializers.ModelSerializer):
    qrcodeid = serializers.IntegerField(source='chargingstation.qrcodeid')
    park_id = serializers.IntegerField(source='chargingstation.park_id')

    class Meta:
        model = Charge
        fields = ['id', 'chargingstation', 'qrcodeid', 'start', 'stop', 'last_nonzero_power_time', 'energy_wh',
                  'park_id', 'user']


class ParkadminChargeSerializer(serializers.ModelSerializer):
    qrcodeid = serializers.IntegerField(source='chargingstation.qrcodeid')
    park_id = serializers.IntegerField(source='chargingstation.park_id')
    user = FeaturedUserSerializer()

    class Meta:
        model = Charge
        fields = ['id', 'chargingstation', 'qrcodeid', 'start', 'stop', 'user', 'last_nonzero_power_time', 'energy_wh',
                  'park_id']
