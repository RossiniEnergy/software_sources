from rest_framework import serializers

from re_restapi.models import BuildingInfosPowerTable


class BuildingInfosPowerTableSerializer(serializers.ModelSerializer):
    class Meta:
        model = BuildingInfosPowerTable
        fields = '__all__'
