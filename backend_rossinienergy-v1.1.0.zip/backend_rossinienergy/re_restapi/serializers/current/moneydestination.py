from rest_framework import serializers

from re_restapi.models import MoneyDestination

__all__ = ['MoneyDestinationSerializer']


class MoneyDestinationSerializer(serializers.ModelSerializer):
    class Meta:
        model = MoneyDestination
        fields = ['id', 'society_name', 'email', 'stripe_id', 'address_1', 'address_2', 'postal_code', 'city',
                  'country_alpha2', 'vat_country_alpha2', 'phone_number', 'receipt_language']
