from rest_framework import serializers


# noinspection PyAbstractClass
class PaymentApiPaymentMethodEmailSerializer(serializers.Serializer):
    paymentmethod_id = serializers.CharField(allow_blank=False, default="")  # defaulted for compatibility
    skip_fingerprint = serializers.BooleanField(default=False)
    email = serializers.EmailField(default="receipts@rossinienergy.com")


# noinspection PyAbstractClass
class PaymentApiEmailSerializer(serializers.Serializer):
    email = serializers.EmailField(default="receipts@rossinienergy.com")
