from rest_framework import serializers

from re_restapi.models import ChargingStation
from re_restapi.serializers.v1.cspower import CSLastPowerSerializer


class PublicChargingStationSerializer(serializers.ModelSerializer):
    last_power = CSLastPowerSerializer(required=False)

    class Meta:
        model = ChargingStation
        fields = ['evse_id', 'qrcodeid', 'payment_enabled', 'price', 'last_power']
        read_only_fields = fields
