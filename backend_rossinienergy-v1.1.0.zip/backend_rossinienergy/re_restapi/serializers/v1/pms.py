from rest_framework import serializers

from re_restapi.models import PMS


class PMSSerializer(serializers.ModelSerializer):
    class Meta:
        model = PMS
        fields = ['id', 'name', 'abbrev']
