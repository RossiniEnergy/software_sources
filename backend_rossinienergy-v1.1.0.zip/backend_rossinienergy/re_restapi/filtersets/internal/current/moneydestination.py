from django_filters import rest_framework as filters

from re_restapi.models import MoneyDestination


class MoneyDestinationFilterSet(filters.FilterSet):
    city = filters.CharFilter(field_name='city', lookup_expr='iexact')
    country_alpha2 = filters.CharFilter(field_name='country_alpha2', lookup_expr='iexact')
    vat_country_alpha2 = filters.CharFilter(field_name='vat_country_alpha2', lookup_expr='iexact')
    receipt_language = filters.CharFilter(field_name='receipt_language', lookup_expr='iexact')

    class Meta:
        model = MoneyDestination
        fields = [
            'society_name',
            'email',
            'postal_code',
            'city',
            'country_alpha2',
            'vat_country_alpha2',
            'phone_number',
            'receipt_language',
        ]
