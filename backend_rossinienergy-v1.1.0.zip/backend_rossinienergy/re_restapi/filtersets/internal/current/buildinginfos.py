from django_filters import rest_framework as filters
from django.db.models import DateTimeField

from re_restapi.models import BuildingInfosPowerTable


class BuildingInfosPowerTableFilterSet(filters.FilterSet):
    park_id = filters.NumberFilter(field_name='park')
    park_name = filters.CharFilter(field_name='park__name')

    class Meta:
        model = BuildingInfosPowerTable
        fields = {
            'id': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'production': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'consumption': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'available_power': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'timestamp': ['lt', 'lte', 'gt', 'gte'],
        }
        filter_overrides = {
            DateTimeField: {
                'filter_class': filters.IsoDateTimeFilter
            }
        }
