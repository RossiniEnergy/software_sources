from django_filters import rest_framework as filters
from django.db.models import DateTimeField

from re_restapi.models import ChargingStationPowerTable


class CSPowerTableFilterSet(filters.FilterSet):
    park_id = filters.NumberFilter(field_name='chargingstation__park_id')
    park_name = filters.CharFilter(field_name='chargingstation__park__name')
    park_bnum = filters.NumberFilter(field_name='chargingstation__park_bnum')
    chargingstation = filters.NumberFilter(field_name='chargingstation__bnum')

    class Meta:
        model = ChargingStationPowerTable
        fields = {
            'id': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'power': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'timestamp': ['lt', 'lte', 'gt', 'gte'],
        }
        filter_overrides = {
            DateTimeField: {
                'filter_class': filters.IsoDateTimeFilter
            }
        }
