from django_filters import rest_framework as filters

from re_restapi.models import ChargingStation


class InternalChargingStationFilterSet(filters.FilterSet):
    latitude = filters.NumericRangeFilter()
    longitude = filters.NumericRangeFilter()

    class Meta:
        model = ChargingStation
        fields = {
            'park': ['exact'],
            'park_bnum': ['exact'],
            'bnum': ['exact'],
            'accept_guests': ['exact'],
            'money_receiver': ['exact', 'isnull'],
            'price': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'qrcodeid': ['exact', 'isnull', 'in'],
        }
