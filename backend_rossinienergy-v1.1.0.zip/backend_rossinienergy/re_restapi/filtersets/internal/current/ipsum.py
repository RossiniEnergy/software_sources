from django_filters import rest_framework as filters

from re_restapi.models import IPSUMDevice


class IPSUMDeviceFilterSet(filters.FilterSet):
    class Meta:
        model = IPSUMDevice
        fields = {
            'id': ['exact'],
            'token': ['exact'],
            'alias': ['exact'],
            'save_data': ['exact'],
            'linked_parks': ['exact'],
            'autosave_min_interval': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'autodrop_max_interval': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'expected_clamps': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'software_version': ['exact'],
        }
