from django_filters import rest_framework as filters

from re_restapi.models import Park


class PublicParkFilterSet(filters.FilterSet):
    city = filters.CharFilter(field_name='city', lookup_expr='iexact')
    country_alpha2 = filters.CharFilter(field_name='country_alpha2', lookup_expr='iexact')

    class Meta:
        model = Park
        # For reorder in fields dict, the overload in the attribute is equal to the exact lookup
        fields = {
            # Public
            'id': ['exact'],
            'name': ['exact', 'contains', 'icontains'],
            'latitude': ['lt', 'lte', 'gt', 'gte'],
            'longitude': ['lt', 'lte', 'gt', 'gte'],
            'postal_code': ['exact'],
            'city': ['exact', 'contains', 'icontains'],
            'country_alpha2': ['exact'],
            'accept_gireve': ['exact'],
            'installed': ['exact'],
        }
