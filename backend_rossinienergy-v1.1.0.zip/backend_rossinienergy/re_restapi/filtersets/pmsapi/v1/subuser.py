from django_filters import rest_framework as filters

from re_restapi.models import User


class PMSSubUserFilterSet(filters.FilterSet):
    username = filters.CharFilter(method='pms_username_filter')
    expired = filters.BooleanFilter(field_name='is_readonly')
    expire_datetime__lt = filters.IsoDateTimeFilter(field_name='scheduled_expire_time', lookup_expr='lt')
    expire_datetime__lte = filters.IsoDateTimeFilter(field_name='scheduled_expire_time', lookup_expr='lte')
    expire_datetime__gt = filters.IsoDateTimeFilter(field_name='scheduled_expire_time', lookup_expr='gt')
    expire_datetime__gte = filters.IsoDateTimeFilter(field_name='scheduled_expire_time', lookup_expr='gte')

    class Meta:
        model = User
        fields = []
        # QUESTION: Why i'm not using IsoDateTimeFilter as filter_class for DateTimeField?

    def pms_username_filter(self, queryset, name, value):
        logged_user = getattr(self.request, 'user', None)
        if logged_user is None or not logged_user.is_authenticated:
            return queryset
        username_for_filter = f"{logged_user.id}${value}"
        return queryset.filter(username=username_for_filter)
