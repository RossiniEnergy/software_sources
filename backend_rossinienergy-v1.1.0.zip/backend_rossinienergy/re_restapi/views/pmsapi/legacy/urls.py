from django.urls import path, include
from rest_framework import routers
from rest_framework_nested import routers as nested_routers  # https://github.com/alanjds/drf-nested-routers

from .common import PMSLegacyAPIView, PMSLegacySubUserView, pms_legacy_initialize_token_api

router = routers.DefaultRouter()
router.register(r'pms', PMSLegacyAPIView, basename='pmsapi_legacy_pms')
nested_pms_router = nested_routers.NestedDefaultRouter(router, r"pms", lookup="pms")
nested_pms_router.register(f'users', PMSLegacySubUserView, basename='pmsapi_legacy_pms_n_subuser')

urlpatterns = [
    path("", include(router.urls)),
    path("", include(nested_pms_router.urls)),
    path("pms/<str:pms_abbrev>/initialize_token/<str:tmp_token>", pms_legacy_initialize_token_api,
         name='pmsapi_legacy_inittoken'),
]
