from dateutil.parser import isoparse

from rest_framework import status, serializers, mixins
from rest_framework.decorators import action, api_view, authentication_classes
from rest_framework.response import Response
from django_filters import rest_framework as filters
from drf_spectacular.utils import extend_schema, inline_serializer
from drf_spectacular.types import OpenApiTypes
from django.db.models import Sum
from django.db import transaction

from re_restapi.libs.charge import close_all_user_charges
from re_restapi.libs.exceptions import HTTPResponseWrapperError
from re_restapi.libs.pms.authtoken import initialize_token, NestedIsAuthenticatedAndPMSAdmin
from re_restapi.libs.authentication import TokenAuthentication
from re_restapi.libs.pms.usermanagement import PMSSubUser
from re_restapi.libs.permissionviewset import *
from re_restapi.libs.user.expire import expire_user
from re_restapi.serializers.pmsapi.legacy.subuser import CreatePMSLegacySubUserSerializer, PMSLegacySubUserSerializer
from re_restapi.serializers.v1.pms import PMSSerializer
from re_restapi.filtersets.pmsapi.v1.subuser import PMSSubUserFilterSet
from re_restapi.models import User, Charge, PMS, PMSChildFeature, ChargeFeature

"""
Remember, all this code use TokenAuthentication as DRF authenticator, implying that the field
    request.user in particular is not a User but a PMSAdminUser !!!
"""


class PMSLegacyAPIView(
    PermissionGenericViewSet,
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
):
    serializer_class = PMSSerializer
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAuthenticated]
    lookup_field = 'abbrev'
    queryset = PMS.objects.order_by('id')


@extend_schema(
    request=OpenApiTypes.NONE,
    responses=inline_serializer(name='PmsInitialization', fields={'authorization_token': serializers.CharField()}),
)
@api_view(['GET'])
@authentication_classes([TokenAuthentication])
def pms_legacy_initialize_token_api(request, pms_abbrev: str, tmp_token: str):
    """Not stonks to use GET in a function with side effects, but this time is better to not have random CORS errors"""
    try:
        pms = PMS.objects.get(abbrev=pms_abbrev)
    except PMS.DoesNotExist:
        return Response("Unknown PMS", status=status.HTTP_400_BAD_REQUEST)
    try:
        user = initialize_token(tmp_token, pms)
    except HTTPResponseWrapperError as exc:
        return exc.httpresponse
    output = {'authorization_token': user.authorization_token}
    return Response(output)


class PMSLegacySubUserView(PermissionGenericViewSet):
    serializer_class = PMSLegacySubUserSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = PMSSubUserFilterSet
    authentication_classes = [TokenAuthentication]
    permission_classes = [NestedIsAuthenticatedAndPMSAdmin]

    def get_queryset(self):
        if not IsAuthenticatedNotExpired().has_permission(self.request, self):
            return User.objects.none()
        else:
            # Show the user in the list only if at least one of this condition is True:
            # - The user contains the requester user in his belonging_to
            user = self.request.user
            # Check if requester is correlated to the requested PMS
            try:
                if not user.has_pmsadmin_feat or user.pmsadminfeature.pms.abbrev != self.kwargs['pms_abbrev']:
                    return User.objects.none()
            except KeyError:
                return User.objects.none()
            return User.objects.distinct().filter(pmschildfeature__pms_admin=user.pmsadminfeature)

    def list(self, request, *args, **kwargs):
        users = self.filter_queryset(self.get_queryset())
        pms_users = PMSSubUser.init_list(users)
        serializer = self.get_serializer(pms_users, many=True)
        return Response(serializer.data)

    def retrieve(self, request, pk=None, *args, **kwargs):
        instance = self.get_object()
        pms_user = PMSSubUser(instance)
        serializer = self.get_serializer(pms_user)
        return Response(serializer.data)

    def create(self, request, *args, **kwargs):
        serializer = CreatePMSLegacySubUserSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        username = serializer.validated_data.get('username')
        password = serializer.validated_data.get('password')
        scheduled_expire_time = serializer.validated_data.get('expire_datetime')
        if not request.user.has_pmsadmin_feat:
            return Response("Only users with the PMSAdmin Feature can create new PMSChild user",
                            status=status.HTTP_403_FORBIDDEN)
        assert request.user.has_pmsadmin_feat
        child_username = f"{request.user.pk}${username}"
        with transaction.atomic():
            new_user = User.objects.create_user(
                username=child_username,
                password=password,
                scheduled_expire_time=scheduled_expire_time,
                on_expire_disable=True,
                on_expire_appendtimestamp=True,
            )
            _new_pmschild_feat = PMSChildFeature.objects.create(
                user=new_user,
                pms_admin=request.user.pmsadminfeature,
            )
            new_charge_feat = ChargeFeature.objects.create(
                user=new_user,
            )
            authorized_bnum = []
            for park in request.user.pmsadminfeature.pms_managed_parks.all():
                authorized_bnum.extend(list(park.chargingstation_set.all().values_list('bnum', flat=True)))
            new_charge_feat.authorized_cs.add(*authorized_bnum)
            new_user.refresh_features_from_db()
        pmssubuser = PMSSubUser(new_user)
        output_serializer = self.get_serializer(pmssubuser)
        return Response(output_serializer.data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=['post'])
    def force_expire(self, request, pk=None, *args, **kwargs):
        user = self.get_object()
        if user.is_readonly:
            return Response("The user is already expired", status=status.HTTP_400_BAD_REQUEST)
        expire_user(user)
        close_all_user_charges(user)
        serializer = self.get_serializer(PMSSubUser(user))
        return Response(serializer.data)

    @action(detail=True, methods=['post'])
    def change_expire_date(self, request, pk=None, *args, **kwargs):
        user = self.get_object()
        if user.is_readonly:
            return Response("The user is already expired", status=status.HTTP_400_BAD_REQUEST)
        expire_datetime_str = request.data.get('expire_datetime')
        if expire_datetime_str is not None:
            try:
                expire_datetime = isoparse(expire_datetime_str)
            except ValueError:
                return Response("Error during the datetime parsing with ISO-8601.", status=status.HTTP_400_BAD_REQUEST)
        else:
            expire_datetime = None
        user.scheduled_expire_time = expire_datetime
        user.save()
        serializer = self.get_serializer(PMSSubUser(user))
        return Response(serializer.data)

    @action(detail=True, methods=['get'])
    def total_energy_used(self, request, pk=None, *args, **kwargs):
        user = self.get_object()
        user_energy = Charge.objects.filter(user=user).aggregate(Sum('energy_wh'))['energy_wh__sum']
        if user_energy is None:
            user_energy = 0
        return Response({'energy_wh': int(user_energy)})
