from django.urls import path, include
from rest_framework import routers

from .auth import login, logout, myself
from .chargecontroller import ChargeControllerViewSet
from .park import PublicParkViewSet

router = routers.DefaultRouter()
router.register(r"chargecontroller", ChargeControllerViewSet, basename="public_v1_chargecontroller")
router.register(r"parks", PublicParkViewSet, basename="public_v1_park")
urlpatterns = [
    # AUTH API
    path("auth/login/", login, name='public_v1_auth_login'),
    path("auth/logout/", logout, name='public_v1_auth_logout'),
    path("auth/myself/", myself, name='public_v1_auth_myself'),
    # Routers
    path("", include(router.urls)),
]
