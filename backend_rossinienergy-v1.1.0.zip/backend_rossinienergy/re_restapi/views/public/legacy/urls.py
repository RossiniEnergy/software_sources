from django.urls import path, include
from rest_framework import routers

from .auth import login, logout, myself
from .legacy import retrieve_user_charge_permissions
from re_restapi.views.public.v1.chargecontroller import ChargeControllerViewSet
from re_restapi.views.public.v1.park import PublicParkViewSet

router = routers.DefaultRouter()
router.register(r"chargecontroller", ChargeControllerViewSet, basename="public_legacy_chargecontroller")
router.register(r"parks", PublicParkViewSet, basename="public_legacy_park")
urlpatterns = [
    # AUTH API
    path("v3/users/login/", login, name='public_legacy_auth_login'),
    path("v3/users/logout/", logout, name='public_legacy_auth_logout'),
    path("v3/users/myself/", myself, name='public_legacy_auth_myself'),
    path("v3/users/<int:user_id>/charge_permissions/", retrieve_user_charge_permissions,
         name='public_legacy_chargepermissions'),
    # Routers
    path("v2/", include(router.urls)),
]
