import logging

from rest_framework import serializers, status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from drf_spectacular.utils import extend_schema, extend_schema_view, inline_serializer
from drf_spectacular.types import OpenApiTypes

from django.conf import settings
from django.contrib import auth

from re_restapi.serializers.legacy.user import LegacyUserSerializer
from re_restapi.libs.permissionviewset import *
from re_restapi.models import ChargingStation, User

logger = logging.getLogger('re.views.public.auth')


@extend_schema(request=inline_serializer(name='Login', fields={
    'username': serializers.CharField(),
    'password': serializers.CharField(),
    'qrcodeid': serializers.IntegerField(required=False)
}), responses=LegacyUserSerializer)
@api_view(['POST'])
def login(request):
    try:
        username = request.data['username']
        password = request.data['password']
        qrcodeid = request.data.get('qrcodeid')
    except KeyError:
        msg = "Bad Request. Expecting `username` and `password` in POST Request body (POSTForm or JSON)"
        return Response(msg, status=status.HTTP_400_BAD_REQUEST)
    if '#' in username or '$' in username:
        return Response("Invalid use of special characters # or $ in username",
                        status=status.HTTP_403_FORBIDDEN)
    # Check if a prefix is needed for the username
    if qrcodeid:
        try:
            cs = ChargingStation.objects.get(qrcodeid=qrcodeid)
            park = cs.park
            pmsuser = User.objects.filter(pmsadminfeature__pms_managed_parks=park).distinct().first()
            if pmsuser:
                username = f"{pmsuser.pk}${username}"
        except ChargingStation.DoesNotExist:
            pass
    # Authenticate
    user = auth.authenticate(request, username=username, password=password)
    if user is not None:
        # QUESTION: in theory the role for this condition was active on the paper, what to do now?
        if user.is_readonly:
            return Response("User requested is expired", status=status.HTTP_401_UNAUTHORIZED)
        auth.login(request, user)
        serialized_user = LegacyUserSerializer(user)
        return Response(serialized_user.data)
    else:
        return Response("Invalid User/Password combination", status=status.HTTP_401_UNAUTHORIZED)


# For multiple method, drf suggest separate annotation with extend_schema_view:
# https://drf-spectacular.readthedocs.io/en/latest/faq.html#how-to-correctly-annotate-function-based-views-that-use-api-view
@extend_schema_view(
    get=extend_schema(request=OpenApiTypes.NONE, responses=OpenApiTypes.NONE),
    post=extend_schema(request=OpenApiTypes.NONE, responses=OpenApiTypes.NONE),
)
@api_view(['GET', 'POST'])
def logout(request):
    csrf_domain = settings.CSRF_COOKIE_DOMAIN
    auth.logout(request)
    response = Response()
    response.delete_cookie("sessionid", samesite='Lax')  # Delete old sessionid from before the domain change
    response.delete_cookie("csrftoken", domain=csrf_domain, samesite='Lax')  # Delete csrftoken at logout
    return response


@extend_schema(request=OpenApiTypes.NONE, responses=LegacyUserSerializer)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def myself(request):
    serialized_user = LegacyUserSerializer(request.user)
    return Response(serialized_user.data)
