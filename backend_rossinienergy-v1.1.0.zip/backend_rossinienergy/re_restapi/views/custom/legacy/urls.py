from django.urls import path, include
from rest_framework import routers

from .common import get_custom_permissiontable
from . import kiloutou, franceparebrise

router = routers.DefaultRouter()
# France Pare-Brise
router.register(r"franceparebrise/charges", franceparebrise.FranceparebriseChargeViewSet, basename='franceparebrise-charge')
# Kiloutou
router.register(r"kiloutou/charges", kiloutou.KiloutouChargeViewSet, basename='kiloutou-charge')

urlpatterns = [
    path("", include(router.urls)),
    path('permissiontable/', get_custom_permissiontable),
    # France Pare-Brise
    path('franceparebrise/caniusethis/', franceparebrise.api_check_user_permission),
    path('franceparebrise/region_list/', franceparebrise.get_region_list),
    path('franceparebrise/chargingstation_table/', franceparebrise.get_chargingstation_table),
    path('franceparebrise/summary/', franceparebrise.get_summary_by_date),
    path('franceparebrise/consumption_kwh_histogram/', franceparebrise.get_consumption_kwh_histogram),
    path('franceparebrise/globalsummary/', franceparebrise.get_globalsummary_by_date),
    path('franceparebrise/summary/export', franceparebrise.export_get_summary_by_date),
    path('franceparebrise/globalsummary/export', franceparebrise.globalexport_get_summary_by_date),
    # Kiloutou
    path('kiloutou/caniusethis/', kiloutou.api_check_user_permission),
    path('kiloutou/region_list/', kiloutou.get_region_list),
    path('kiloutou/chargingstation_table/', kiloutou.get_chargingstation_table),
    path('kiloutou/summary/', kiloutou.get_summary_by_date),
    path('kiloutou/consumption_kwh_histogram/', kiloutou.get_consumption_kwh_histogram),
    path('kiloutou/globalsummary/', kiloutou.get_globalsummary_by_date),
    path('kiloutou/summary/export', kiloutou.export_get_summary_by_date),
    path('kiloutou/globalsummary/export', kiloutou.globalexport_get_summary_by_date),
]
