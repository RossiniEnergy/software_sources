from django.conf import settings
from django.http import FileResponse, HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt

import os


@csrf_exempt
def get_receipts(request):
    if not request.user.is_authenticated:
        return HttpResponse(status=401)
    if not request.user.is_staff:
        return HttpResponse(status=401)
    files = os.listdir(settings.ADMIN_REPORT_PATH)
    ret_val = {"receipts": files}
    return JsonResponse(ret_val)


@csrf_exempt
def download_receipt(request, receipt_name):
    if not request.user.is_authenticated:
        return HttpResponse(status=401)
    if not request.user.is_staff:
        return HttpResponse(status=401)
    try:
        files = os.listdir(settings.ADMIN_REPORT_PATH)
        if receipt_name not in files:
            return HttpResponse(status=404)
        receipt = open(settings.ADMIN_REPORT_PATH + receipt_name, 'rb')
        return FileResponse(receipt, as_attachment=True)
    except FileNotFoundError:
        return HttpResponse(status=404)
