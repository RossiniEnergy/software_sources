from django.urls import path

from . import gireve, newcomer, raspberry, receipts, stripewebhook

urlpatterns = [
    # GIREVE API
    path("gireve/locations", gireve.get_gireve_location),
    path("gireve/locations/<str:location_id>/<str:evse_uid>/<str:connector_id>", gireve.get_gireve_location_params),
    path("gireve/locations/<str:location_id>/<str:evse_uid>", gireve.get_gireve_location_params),
    path("gireve/locations/<str:location_id>", gireve.get_gireve_location_params),
    path('gireve/<str:evse_uid>/start', gireve.start_evse),
    path('gireve/<str:evse_uid>/stop', gireve.stop_evse),
    # NEWCOMER API
    path("get_newcomers/", newcomer.get_newcomers),
    path("newcomer/", newcomer.newcomer),
    path("cancelnewcomer/", newcomer.cancelnewcomer),
    path("nowtimeutc/", newcomer.nowtimeutc),
    # RASPBERRY API
    path(r"ischarging/<int:bnum>", raspberry.get_is_charging),
    path(r"csidlist/<str:park_name>", raspberry.get_cs_id_list),
    path("post_power/v1/<str:park_name>", raspberry.post_power_bytecode),  # HTTP
    path("post_power/<str:park_name>", raspberry.post_power_bytecode),  # HTTPS/Old config
    path("post_power/", raspberry.post_power_legacy),
    path("retrieve_ipsum/<str:park_name>", raspberry.manual_retrieve_ipsum),
    # RECEIPTS API
    path(r"get_receipts/", receipts.get_receipts),
    path(r"download_receipt/<str:receipt_name>", receipts.download_receipt),
    # STRIPE WEBHOOK API
    path(r"handlers/strwebhook/", stripewebhook.stripe_webhook),
]
