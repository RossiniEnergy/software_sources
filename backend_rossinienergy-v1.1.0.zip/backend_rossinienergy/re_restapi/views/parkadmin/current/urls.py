from django.urls import path, include
from rest_framework import routers
from rest_framework_nested import routers as nested_routers  # https://github.com/alanjds/drf-nested-routers

from .buildinginfos import ParkadminBuildingInfosViewSet
from .charge import ParkadminChargeViewSet
from .park import ParkadminParkViewset, NestedParkadminChargingStationViewset
from .power import ParkadminPowerTableViewSet
from .stripelink import generate_stripeconnect_link
from .user import ParkadminUserViewSet

router = routers.DefaultRouter()
router.register(r"buildinginfos", ParkadminBuildingInfosViewSet, basename="parkadmin_c_buildinginfospowertable")
router.register(r"charges", ParkadminChargeViewSet, basename="parkadmin_c_charge")
router.register(r"parks", ParkadminParkViewset, basename="parkadmin_c_park")
router.register(r"powers", ParkadminPowerTableViewSet, basename="parkadmin_c_power")
router.register(r"users", ParkadminUserViewSet, basename="parkadmin_c_user")
# Nested on Park
nested_park_router = nested_routers.NestedDefaultRouter(router, r"parks", lookup="park")
nested_park_router.register(
    r"chargingstations", NestedParkadminChargingStationViewset, basename="parkadmin_c_park_n_cs")
urlpatterns = [
    path("", include(router.urls)),
    path("", include(nested_park_router.urls)),
    path("generate_stripeconnect_link/", generate_stripeconnect_link, name="parkadmin_c_genstripelink"),
]
