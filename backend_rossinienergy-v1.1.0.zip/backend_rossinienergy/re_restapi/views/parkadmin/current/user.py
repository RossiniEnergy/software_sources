import logging

from rest_framework import mixins, status
from rest_framework.decorators import action
from rest_framework.response import Response
from drf_spectacular.utils import extend_schema
from drf_spectacular.types import OpenApiTypes
from django_filters import rest_framework as filters

from django.db.models import Q
from django.contrib.auth import login

from re_restapi.serializers.current.parkadmin_user import ParkadminUserSerializer
from re_restapi.filtersets.parkadmin.current.user import ParkadminUserFilterSet
from re_restapi.libs.charge import close_all_user_charges
from re_restapi.libs.permissionviewset import *
from re_restapi.libs.user.expire import expire_user
from re_restapi.models import User

logger = logging.getLogger('re.views.parkadmin.user')


class ParkadminUserViewSet(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    mixins.CreateModelMixin,
    PermissionGenericViewSet,
):
    serializer_class = ParkadminUserSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = ParkadminUserFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsParkAdmin, IsParkAdminForUser | IsHimselfUser]

    # TODO: Assicurarsi che l'ex check_pms_correlation sia verificato da validator in altre posizioni

    def get_queryset(self):
        if not IsAuthenticatedNotExpired().has_permission(self.request, self):
            return User.objects.none()
        elif IsAdminUser().has_permission(self.request, self):
            # If a user is Admin, show every user
            return User.objects.order_by("id")
        else:
            # Show the user in the list only if at least one of this condition is True:
            # - The user is himself
            # - The user contains the requester user in his belonging_to
            user = self.request.user
            return User.objects.filter(Q(pk=user.pk) | Q(admin_users=user.parkadminfeature)).distinct()

    @action(detail=False, methods=['get'], permission_classes=[IsAuthenticated])
    def myself(self, request):
        user = request.user
        serialized_user = self.get_serializer(user)
        return Response(serialized_user.data)

    @extend_schema(request=OpenApiTypes.NONE, responses=OpenApiTypes.NONE)
    @action(
        detail=True,
        methods=['post'],
    )
    def expire(self, request, pk=None):
        user = self.get_object()
        if user.is_readonly:
            msg = f"Trying to force expiration of the already expired user \"{user.username}\""
            logger.warning(msg)
            return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        else:
            expire_user(user)
            close_all_user_charges(user)
            return Response()

    @extend_schema(request=OpenApiTypes.NONE)
    @action(detail=True, methods=['get', 'post'])
    def sudo(self, request, pk=None):
        user = self.get_object()
        login(request, user)
        serialized_user = self.get_serializer(user)
        return Response(serialized_user.data)
