from rest_framework import mixins
from rest_framework.pagination import LimitOffsetPagination
from django_filters import rest_framework as filters
from django.db.models import Q

from re_restapi.models import Charge
from re_restapi.libs.permissionviewset import *
from re_restapi.serializers.current.charge import ParkadminChargeSerializer
from re_restapi.filtersets.parkadmin.current.charge import ChargeFilter


class ChargeSetPagination(LimitOffsetPagination):
    default_limit = 1000
    max_limit = 10000


class ParkadminChargeViewSet(mixins.ListModelMixin,
                             mixins.RetrieveModelMixin,
                             PermissionGenericViewSet):
    serializer_class = ParkadminChargeSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = ChargeFilter
    pagination_class = ChargeSetPagination
    permission_classes = [IsAuthenticatedNotExpired, IsParkAdmin]

    def get_queryset(self):
        user = self.request.user
        if user is None or not user.is_authenticated:
            # Not authenticated user see no charge
            queryset = Charge.objects.none()
        elif user.is_staff:
            # Staff user see all the charge
            queryset = Charge.objects.order_by("id")
        else:
            # Everyone else see self charge and managed_parks charges and belonging_user charges
            queryset = Charge.objects.distinct().order_by("id").filter(
                Q(user=user) |
                Q(chargingstation__park__admin_users=user.parkadminfeature) |
                Q(user__admin_users=user.parkadminfeature)
            )
        queryparam_reversed = bool(int(self.request.query_params.get('reversed', 0)))
        if queryparam_reversed:
            queryset = queryset.reverse()
        return queryset
