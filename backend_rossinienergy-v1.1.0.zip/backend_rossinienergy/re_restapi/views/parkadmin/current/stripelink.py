from rest_framework.decorators import permission_classes

from rest_framework import status, serializers
from rest_framework.decorators import api_view
from rest_framework.response import Response
from drf_spectacular.utils import extend_schema
from drf_spectacular.types import OpenApiTypes

from re_restapi.libs.payment import generate_stripeconnect_link as api_generate_stripeconnect_link
from re_restapi.libs.permissionviewset import *


# noinspection PyAbstractClass
class GenerateLinkSerializer(serializers.Serializer):
    """Serializer for the request of a Stripe Registration Link"""
    email = serializers.EmailField(default="")
    iban_nationality = serializers.CharField(default="FR")  # TODO: validate against PyCountry alpha2 list
    refresh_url = serializers.URLField()
    return_url = serializers.URLField()


@extend_schema(request=GenerateLinkSerializer, responses=OpenApiTypes.URI)
@api_view(['POST'])
@permission_classes([IsAuthenticatedNotExpired | IsParkAdmin])
def generate_stripeconnect_link(request):
    serialized = GenerateLinkSerializer(data=request.data)
    if not serialized.is_valid():
        msg = "Error validating request format."
        return Response(msg, status=status.HTTP_400_BAD_REQUEST)
    url = api_generate_stripeconnect_link(
        serialized.data['email'],
        serialized.data['iban_nationality'],
        serialized.data['refresh_url'],
        serialized.data['return_url']
    )
    return Response(url, status=status.HTTP_201_CREATED)
