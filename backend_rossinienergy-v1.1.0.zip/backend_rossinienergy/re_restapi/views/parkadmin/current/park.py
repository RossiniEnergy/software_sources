from rest_framework import mixins, status
from rest_framework.decorators import action
from rest_framework.response import Response
from drf_spectacular.utils import extend_schema
from drf_spectacular.types import OpenApiTypes
from django_filters import rest_framework as filters

from re_restapi.libs.charge import stop_opened_charge
from re_restapi.libs.permissionviewset import *
from re_restapi.serializers.current.chargingstation import ParkadminChargingStationSerializer
from re_restapi.serializers.current.charge import ParkadminChargeSerializer
from re_restapi.serializers.current.park import ParkadminParkSerializer, SimpleParkSerializer
from re_restapi.filtersets.parkadmin.current.chargingstation import ParkadminChargingStationFilterSet
from re_restapi.filtersets.parkadmin.current.park import ParkadminParkFilterSet

from re_restapi.models import Park, ChargingStation


class ParkadminParkViewset(
    PermissionGenericViewSet,
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
):
    """
    Used to give endpoint for public retrieve and parkadmin update
    """
    serializer_class = ParkadminParkSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = ParkadminParkFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsParkAdminForPark]

    def get_queryset(self):
        if not IsAuthenticatedNotExpired().has_permission(self.request, self):
            return Park.objects.none()
        user = self.request.user
        return Park.objects.filter(admin_users=user.parkadminfeature).distinct()

    @extend_schema(responses=SimpleParkSerializer)
    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())

        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = SimpleParkSerializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = SimpleParkSerializer(queryset, many=True)
        return Response(serializer.data)


class NestedParkadminChargingStationViewset(
    PermissionGenericViewSet,
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
):
    """
    Used to give endpoint for public retrieve and parkadmin update
    """
    lookup_field = "park_bnum"
    serializer_class = ParkadminChargingStationSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = ParkadminChargingStationFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsParkAdminForChargingStation]

    def get_queryset(self):
        try:
            return ChargingStation.objects.filter(park_id=self.kwargs['park_pk']).order_by('park_bnum')
        except KeyError:
            return ChargingStation.objects.none()

    @extend_schema(request=None, responses={200: ParkadminChargeSerializer, 400: OpenApiTypes.NONE})
    @action(detail=True, methods=['POST'])
    def force_close_charge(self, request, **kwargs):
        cs: ChargingStation = self.get_object()
        active_charge = cs.active_charge
        if active_charge is not None:
            stopped_charge = stop_opened_charge(active_charge)
            serializer = ParkadminChargeSerializer(stopped_charge)
            return Response(serializer.data)
        else:
            return Response(None, status=status.HTTP_400_BAD_REQUEST)
