from django.urls import path, include

from .current import urls as current_urls

urlpatterns = [
    path("current/", include(current_urls))
]
