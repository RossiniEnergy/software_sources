import logging

from rest_framework import mixins, status
from rest_framework.decorators import action
from rest_framework.response import Response
from drf_spectacular.utils import extend_schema
from drf_spectacular.types import OpenApiTypes
from django_filters import rest_framework as filters

from django.contrib.auth import login

from re_restapi.serializers.current.featured_user import FeaturedUserSerializer, SimpleUserSerializer
from re_restapi.filtersets.internal.current.user import InternalUserFilterSet
from re_restapi.libs.charge import close_all_user_charges
from re_restapi.libs.permissionviewset import *
from re_restapi.libs.user.expire import expire_user
from re_restapi.models import User

logger = logging.getLogger('re.views.internal.user')


class InternalUserViewSet(
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    mixins.CreateModelMixin,
    PermissionGenericViewSet,
):
    queryset = User.objects.order_by('id')
    serializer_class = FeaturedUserSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = InternalUserFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser]

    # TODO: Assicurarsi che l'ex check_pms_correlation sia verificato da validator in altre posizioni

    @extend_schema(responses=SimpleUserSerializer)
    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())

        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = SimpleUserSerializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = SimpleUserSerializer(queryset, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'], permission_classes=[IsAuthenticated])
    def myself(self, request):
        user = request.user
        serialized_user = self.get_serializer(user)
        return Response(serialized_user.data)

    @extend_schema(request=OpenApiTypes.NONE, responses=OpenApiTypes.NONE)
    @action(
        detail=True,
        methods=['post'],
    )
    def expire(self, request, pk=None):
        user = self.get_object()
        if user.userconfig.expired:
            msg = f"Trying to force expiration of the already expired user \"{user.username}\""
            logger.warning(msg)
            return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        else:
            expire_user(user)
            close_all_user_charges(user)
            return Response()

    @extend_schema(request=OpenApiTypes.NONE)
    @action(detail=True, methods=['get', 'post'])
    def sudo(self, request, pk=None):
        user = self.get_object()
        login(request, user)
        serialized_user = self.get_serializer(user)
        return Response(serialized_user.data)
