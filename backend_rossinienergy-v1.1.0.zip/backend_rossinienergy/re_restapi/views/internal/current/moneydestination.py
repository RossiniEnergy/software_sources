import logging

from rest_framework import mixins, serializers, status
from rest_framework.decorators import action
from rest_framework.response import Response
from drf_spectacular.utils import extend_schema
from drf_spectacular.types import OpenApiTypes
from django_filters import rest_framework as filters
from django.http import FileResponse
from django.db.models.deletion import ProtectedError

from re_restapi.models import MoneyDestination
from re_restapi.serializers.current.moneydestination import MoneyDestinationSerializer
from re_restapi.filtersets.internal.current.moneydestination import MoneyDestinationFilterSet
from re_restapi.libs.permissionviewset import *
from re_restapi.libs.reports.admin import make_admin_report

logger = logging.getLogger('re.views.internal.moneydestination')


# noinspection PyAbstractClass
class GeneratePaymentReportSerializer(serializers.Serializer):
    moneydestination = serializers.PrimaryKeyRelatedField(queryset=MoneyDestination.objects.all(), read_only=False)
    timestamp_from = serializers.DateTimeField()
    timestamp_to = serializers.DateTimeField()

    def validate(self, data):
        if not data['timestamp_from'] < data['timestamp_to']:
            raise serializers.ValidationError("'timestamp_to need to be after 'timestamp_from'")
        return data


class MoneyDestinationViewSet(mixins.ListModelMixin,
                              mixins.RetrieveModelMixin,
                              mixins.UpdateModelMixin,
                              mixins.CreateModelMixin,
                              mixins.DestroyModelMixin,
                              PermissionGenericViewSet):
    queryset = MoneyDestination.objects.order_by("id")
    serializer_class = MoneyDestinationSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = MoneyDestinationFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser]

    def destroy(self, request, *args, **kwargs):
        try:
            return super().destroy(request, *args, **kwargs)
        except ProtectedError:
            msg = "MoneyDestination protected by relation with other objects."
            logger.error(f"Error trying to delete {msg}")
            return Response(msg, status=status.HTTP_403_FORBIDDEN)

    @extend_schema(request=GeneratePaymentReportSerializer, responses=OpenApiTypes.BINARY)
    @action(detail=True, methods=['post'])
    def make_payment_report(self, request):
        serializer = GeneratePaymentReportSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        moneydestination = serializer.validated_data['moneydestination']
        timestamp_from = serializer.validated_data['timestamp_from']
        timestamp_to = serializer.validated_data['timestamp_to']
        filename = make_admin_report(moneydestination, timestamp_from, timestamp_to)
        return FileResponse(open(filename, 'rb'), as_attachment=True)
