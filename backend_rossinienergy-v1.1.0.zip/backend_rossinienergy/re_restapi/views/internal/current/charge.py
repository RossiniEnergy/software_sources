from rest_framework import mixins
from rest_framework.pagination import LimitOffsetPagination
from django_filters import rest_framework as filters

from re_restapi.models import Charge
from re_restapi.libs.permissionviewset import *
from re_restapi.serializers.current.charge import InternalStandaloneChargeSerializer
from re_restapi.filtersets.parkadmin.current.charge import ChargeFilter


class ChargeSetPagination(LimitOffsetPagination):
    default_limit = 1000
    max_limit = 10000


class InternalChargeViewSet(mixins.ListModelMixin,
                            mixins.RetrieveModelMixin,
                            PermissionGenericViewSet):
    queryset = Charge.objects.order_by('id')
    serializer_class = InternalStandaloneChargeSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = ChargeFilter
    pagination_class = ChargeSetPagination
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser]
