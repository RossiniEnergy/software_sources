from rest_framework import mixins
from django_filters import rest_framework as filters

from re_restapi.models import ChargingStation
from re_restapi.filtersets.internal.current.chargingstation import InternalChargingStationFilterSet
from re_restapi.serializers.current.chargingstation import InternalChargingStationSerializer
from re_restapi.libs.permissionviewset import *


class ChargingStationViewSet(mixins.ListModelMixin,
                             mixins.RetrieveModelMixin,
                             mixins.UpdateModelMixin,
                             PermissionGenericViewSet):
    queryset = ChargingStation.objects.order_by("bnum")
    serializer_class = InternalChargingStationSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = InternalChargingStationFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser]
