import logging

from rest_framework import mixins, serializers, status
from rest_framework.decorators import action
from rest_framework.response import Response
from drf_spectacular.utils import extend_schema
from drf_spectacular.types import OpenApiTypes
from django_filters import rest_framework as filters
from django.conf import settings
from django.db import transaction
from django.db.models.functions import Lower

from re_restapi.libs.advenir import advenir_send_test_charge
from re_restapi.libs.charge import stop_opened_charge
from re_restapi.libs.park import ResizetoOutputSerializer, shrink_park, dilate_park
from re_restapi.libs.permissionviewset import *
from re_restapi.serializers.current.chargingstation import InternalChargingStationSerializer
from re_restapi.serializers.current.charge import InternalChargeSerializer
from re_restapi.serializers.current.park import InternalParkSerializer, SimpleParkSerializer
from re_restapi.filtersets.internal.current.chargingstation import InternalChargingStationFilterSet
from re_restapi.filtersets.internal.current.park import InternalParkFilterSet

from re_restapi.models import Park, ChargingStation

logger = logging.getLogger('re.views.internal.park')


# noinspection PyAbstractClass
class SendAdvenirTestDataSerializer(serializers.Serializer):
    transaction_id = serializers.IntegerField(default=1)


# noinspection PyAbstractClass
class ResizePublicParkSerializer(serializers.Serializer):
    new_size = serializers.IntegerField()
    dry_run = serializers.BooleanField(default=True)


# noinspection PyAbstractClass
class PurgePublicParkSerializer(serializers.Serializer):
    dry_run = serializers.BooleanField(default=True)


class InternalParkViewSet(
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    mixins.CreateModelMixin,
    PermissionGenericViewSet
):
    serializer_class = InternalParkSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = InternalParkFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser]

    def get_queryset(self):
        queryparam_orderbyname = bool(int(self.request.query_params.get('orderbyname', 0)))
        if queryparam_orderbyname:
            queryset = Park.objects.order_by(Lower("name"))
        else:
            queryset = Park.objects.order_by("id")
        return queryset

    @extend_schema(responses=SimpleParkSerializer)
    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())

        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = SimpleParkSerializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = SimpleParkSerializer(queryset, many=True)
        return Response(serializer.data)

    @extend_schema(request=InternalChargingStationSerializer, responses=InternalChargingStationSerializer)
    @action(detail=True, methods=['POST'])
    def add_chargingstation(self, request, pk=None):
        serializer = InternalChargingStationSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        park = self.get_object()
        new_cs = ChargingStation.objects.create(
            park=park,
            park_bnum=park.chargingstation_set.count() + 1,
            **serializer.validated_data
        )
        reply_serializer = InternalChargingStationSerializer(new_cs)
        return Response(reply_serializer.data, status=status.HTTP_201_CREATED)

    @extend_schema(request=ResizePublicParkSerializer, responses=ResizetoOutputSerializer)
    @action(detail=True, methods=['POST'], permission_classes=[IsAuthenticatedNotExpired, IsAdminUser])
    def resize_to(self, request, pk=None):
        serializer = ResizePublicParkSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        new_size = serializer.data['new_size']
        dry_run = serializer.data['dry_run']
        park = self.get_object()
        old_size = park.chargingstation_set.count()
        if old_size > new_size:
            # Shrink
            resizeserializer = shrink_park(park, new_size, dry_run)
        elif old_size < new_size:
            # Dilate
            # TODO: Default for creation of CS in dilate-type resizes?
            resizeserializer = dilate_park(park, new_size, dry_run)
        else:
            return Response("new size equal to old size", status=status.HTTP_400_BAD_REQUEST)
        return Response(resizeserializer.data, status=status.HTTP_200_OK)

    @extend_schema(request=PurgePublicParkSerializer, responses=ResizetoOutputSerializer)
    @action(detail=True, methods=['POST'])
    def purge(self, request, pk=None):
        serializer = PurgePublicParkSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        dry_run = serializer.data['dry_run']
        park = self.get_object()
        with transaction.atomic():
            resizeserializer = shrink_park(park, 0, dry_run)
            if not dry_run:
                park.buildinginfospowertable_set.all().delete()
                park.delete()
        return Response(resizeserializer.data, status=status.HTTP_200_OK)

    @extend_schema(request=SendAdvenirTestDataSerializer, responses=OpenApiTypes.NONE)
    @action(detail=True, methods=['POST'])
    def send_advenir_test_data(self, request, pk=None):
        serializer = SendAdvenirTestDataSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        transaction_id = serializer.data['transaction_id']
        park = self.get_object()
        for ch in park.chargingstation_set.all():
            if not settings.ENABLE_ADVENIR:
                logger.info(f"[STAGING] Launched advenir_test_charge with params {ch.bnum}, {transaction_id}")
            else:
                advenir_send_test_charge.delay(ch.bnum, transaction_id)
        return Response()


class NestedInternalChargingStationViewSet(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    PermissionGenericViewSet
):
    lookup_field = "park_bnum"
    serializer_class = InternalChargingStationSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = InternalChargingStationFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser]

    def get_queryset(self):
        try:
            return ChargingStation.objects.filter(park_id=self.kwargs['park_pk']).order_by('park_bnum')
        except KeyError:
            return ChargingStation.objects.none()

    @extend_schema(request=None, responses={200: InternalChargeSerializer, 400: OpenApiTypes.NONE})
    @action(detail=True, methods=['POST'])
    def force_close_charge(self, request, **kwargs):
        cs: ChargingStation = self.get_object()
        active_charge = cs.active_charge
        if active_charge is not None:
            stopped_charge = stop_opened_charge(active_charge)
            serializer = InternalChargeSerializer(stopped_charge)
            return Response(serializer.data)
        else:
            return Response(None, status=status.HTTP_400_BAD_REQUEST)
