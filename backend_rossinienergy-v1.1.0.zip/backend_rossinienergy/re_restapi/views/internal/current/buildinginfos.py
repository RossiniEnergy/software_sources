from rest_framework import mixins
from rest_framework.pagination import LimitOffsetPagination
from django_filters import rest_framework as filters

from re_restapi.libs.permissionviewset import *
from re_restapi.filtersets.internal.current.buildinginfos import BuildingInfosPowerTableFilterSet
from re_restapi.serializers.current.buildinginfos import BuildingInfosPowerTableSerializer
from re_restapi.models import BuildingInfosPowerTable


class BuildingInfosPagination(LimitOffsetPagination):
    default_limit = 1000
    max_limit = 10000


class BuildingInfosViewSet(mixins.ListModelMixin,
                           mixins.RetrieveModelMixin,
                           PermissionGenericViewSet):
    serializer_class = BuildingInfosPowerTableSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = BuildingInfosPowerTableFilterSet
    pagination_class = BuildingInfosPagination
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser]

    def get_queryset(self):
        queryparam_reversed = bool(int(self.request.query_params.get('reversed', 0)))
        queryset = BuildingInfosPowerTable.objects.order_by("id")
        if queryparam_reversed:
            queryset = queryset.reverse()
        return queryset
