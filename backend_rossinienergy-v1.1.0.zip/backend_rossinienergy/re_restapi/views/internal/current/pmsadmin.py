from rest_framework import mixins
from django_filters import rest_framework as filters

from re_restapi.libs.permissionviewset import *
from re_restapi.models import PMSPendingRequest, PMS
from re_restapi.filtersets.internal.current.pms import PMSPendingRequestFilterSet, PMSFilterSet
from re_restapi.serializers.current.pmspendingrequest import PMSPendingRequestSerializer
from re_restapi.serializers.v1.pms import PMSSerializer


class InternalPMSViewSet(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    mixins.CreateModelMixin,
    mixins.DestroyModelMixin,
    PermissionGenericViewSet
):
    queryset = PMS.objects.order_by('id')
    serializer_class = PMSSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = PMSFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser]


class PMSPendingRequestViewSet(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    mixins.CreateModelMixin,
    mixins.DestroyModelMixin,
    PermissionGenericViewSet
):
    queryset = PMSPendingRequest.objects.order_by('id')
    serializer_class = PMSPendingRequestSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = PMSPendingRequestFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser]

    def get_queryset(self):
        try:
            return PMSPendingRequest.objects.filter(pms_id=self.kwargs['pms_pk']).order_by('id')
        except KeyError:
            return PMSPendingRequest.objects.none()

    def get_pms_object(self):
        try:
            pms = PMS.objects.get(pk=self.kwargs['pms_pk'])
        except PMS.DoesNotExist:
            raise
        return pms

    def create(self, request, *args, **kwargs):
        request.data['pms'] = self.kwargs['pms_pk']
        return super().create(request, *args, **kwargs)
