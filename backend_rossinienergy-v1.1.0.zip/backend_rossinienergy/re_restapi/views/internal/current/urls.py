from django.urls import path, include
from rest_framework import routers
from rest_framework_nested import routers as nested_routers  # https://github.com/alanjds/drf-nested-routers

from .access_status import access_status_raw
from .buildinginfos import BuildingInfosViewSet
from .charge import InternalChargeViewSet
from .chargingstation import ChargingStationViewSet
from .ipsum import IPSUMDeviceViewSet
from .moneydestination import MoneyDestinationViewSet
from .park import InternalParkViewSet, NestedInternalChargingStationViewSet
from .parkipsumconf import ParkIpsumConfView
from .pmsadmin import InternalPMSViewSet, PMSPendingRequestViewSet
from .power import PowerTableViewSet
from .user import InternalUserViewSet

router = routers.DefaultRouter()
router.register(r"buildinginfos", BuildingInfosViewSet, basename="internal_c_buildinginfospowertable")
router.register(r"charges", InternalChargeViewSet, basename='internal_c_charge')
router.register(r"chargingstations", ChargingStationViewSet, basename="internal_c_chargingstation")
router.register(r"ipsumdevices", IPSUMDeviceViewSet, basename="internal_c_ipsumdevice")
router.register(r"moneydestinations", MoneyDestinationViewSet, basename="internal_c_moneydestination")
router.register(r"parks", InternalParkViewSet, basename="internal_c_park")
router.register(r"parkipsumconfs", ParkIpsumConfView, basename="internal_c_parkipsumconf")
router.register(r"pms", InternalPMSViewSet, basename="internal_c_pms")
router.register(r"powers", PowerTableViewSet, basename="internal_c_power")
router.register(r"users", InternalUserViewSet, basename="internal_c_user")
# Nested on Park
nested_park_router = nested_routers.NestedDefaultRouter(router, r"parks", lookup="park")
nested_park_router.register(r"chargingstations", NestedInternalChargingStationViewSet, basename="internal_c_park_n_cs")
# Nested on PMS
nested_pms_router = nested_routers.NestedDefaultRouter(router, r"pms", lookup="pms")
nested_pms_router.register(r"pendingrequests", PMSPendingRequestViewSet, basename="internal_c_pms_n_pr")
urlpatterns = [
    path("", include(router.urls)),
    path("", include(nested_park_router.urls)),
    path("", include(nested_pms_router.urls)),
    path("access_status/", access_status_raw, name='internal_c_access_status'),
]
