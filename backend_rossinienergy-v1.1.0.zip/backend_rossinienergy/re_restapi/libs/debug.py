def debug_toolbar_callback(request):
    return request.user.is_authenticated and request.user.is_superuser

