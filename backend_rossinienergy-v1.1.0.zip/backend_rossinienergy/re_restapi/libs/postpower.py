import datetime
import json
import logging
import binascii

import pytz

from celery import shared_task

from django.core.exceptions import MultipleObjectsReturned, ObjectDoesNotExist
from django.db import transaction
from django.db.models import DurationField, F, ExpressionWrapper

from re_restapi.models import \
    Park, BuildingInfosPowerTable, BuildingInfosLastPower, \
    ChargingStation, ChargingStationPowerTable, ChargingStationLastPower
from re_restapi.libs.charge import closing_charge_logic

logger = logging.getLogger("re.libs.powertable")


@shared_task(ignore_result=True, store_errors_even_if_ignored=True)
def park_powertable_scansave():
    datetime_now = datetime.datetime.now(pytz.UTC)
    # Return the Park that we need to save. Skip the one without buildinginfoslastpower defined
    # Take the Park with a buildinginfoslastpower that results not already saved
    # This query require that BuildingInfosLastPower.timestamp defaults to datetime.now
    with transaction.atomic():
        park_tosave = Park.objects.select_related('buildinginfoslastpower').prefetch_related('chargingstation_set') \
            .filter(save_data=True, autosave_min_interval__isnull=False, buildinginfoslastpower__already_saved=False) \
            .annotate(elapsed=ExpressionWrapper(datetime_now - F('buildinginfoslastpower__last_save_timestamp'),
                                                output_field=DurationField())) \
            .filter(elapsed__gt=F('autosave_min_interval')).distinct()
        bipowertable_tosave = []
        cspowertable_tosave = []
        for park in park_tosave:
            newbipt = BuildingInfosPowerTable(
                park=park,
                timestamp=park.buildinginfoslastpower.timestamp,
                production=park.buildinginfoslastpower.production,
                consumption=park.buildinginfoslastpower.consumption,
                available_power=park.buildinginfoslastpower.available_power,
            )
            bipowertable_tosave.append(newbipt)
            for cs in park.chargingstation_set.all():
                newcspt = ChargingStationPowerTable(
                    chargingstation=cs,
                    power=cs.last_power.power,
                    timestamp=cs.last_power.timestamp,
                )
                cspowertable_tosave.append(newcspt)
        BuildingInfosPowerTable.objects.bulk_create(bipowertable_tosave)
        ChargingStationPowerTable.objects.bulk_create(cspowertable_tosave)
        BuildingInfosLastPower.objects.filter(park__in=park_tosave).update(
            already_saved=True,
            last_save_timestamp=datetime_now,
        )


@shared_task(ignore_result=True, store_errors_even_if_ignored=True)
def task_post_power_bytecode(coded_data, park_name):
    """
    PROTOCOL VERSION 1:
        data are bytestring with this structure: bytenumberx content (type) firstbytenumber-lastbytenumberinclusive
            1x bytecode version (unsigned integer) 0
            3x software version (major.minor.rev) 1-3
            3x available power (signed integer) 4-6
            3x production (signed integer) 7-9
            3x consumption (signed integer) 10-12
            8x timestamp UTC (unsigned integer 64 bit) 13-20
            1x number N of CP in this metric (unsigned integer) 21
            3xN power consumed from CP (unsigned integer) 22-24

        total bytesyze: 25 (1CP) - 46 (8 CP)
        Every number is encoded as BIG ENDIAN.
        Note that in this list the interval is INCLUSIVE, in the list operator in Python the last number is EXCLUSIVE:
            software version is bytes from 1 to 3 (1,2,3) but the list retrieve is data[1:4]=>(1,2,3)
        The Encoding used is: the n-byte contain the number as ASCII characters corresponding to the number that we
            wanted to send for example if we want to send 94 the byte will be \x61 so the bytestring will contain the
            corresponding char 'a'. For example the number 12000 coded for 3 byte will be the bytestring b'\x00.\xe0'
            obtained with the function `numbervariable.to_bytes(nbytes, 'big')`
    """
    # Check park existance
    query = Park.objects.filter(name=park_name).count()
    if query == 0:
        msg = f"Tried post_power on inexistent park {park_name}"
        logger.debug(msg)
        raise ValueError(msg)
    elif query > 1:
        msg = f"Tried post_power on duplicated park {park_name}"
        logger.critical(msg)
        raise ValueError(msg)
    bytestring = binascii.a2b_base64(coded_data.encode())
    # Retrieve protocol version
    protocol_version = bytestring[0]
    if protocol_version == 1:
        # Retrieve software version
        major, minor, revision = bytestring[1:4]
        software_version = f"{major}.{minor}.{revision}"
        # Available Power
        available_power = int.from_bytes(bytestring[4:7], 'big')
        # Production
        production = int.from_bytes(bytestring[7:10], 'big')
        # Consumption
        consumption = int.from_bytes(bytestring[10:13], 'big')
        # Timestamp UTC
        timestamp_raw = int.from_bytes(bytestring[13:21], 'big')
        _timestamp = datetime.datetime.fromtimestamp(timestamp_raw, pytz.UTC)
        # Number of CP
        cp_quantity = bytestring[21]
        # CP Power Consumption
        cp_powers = []
        for i in range(cp_quantity):
            cp = int.from_bytes(bytestring[22 + i * 3:25 + i * 3], 'big')
            cp_powers.append(cp)
        # return
        post_power_elaboration(park_name,
                               software_version,
                               available_power,
                               production, consumption,
                               datetime.datetime.now(pytz.UTC),
                               cp_powers)
    else:
        msg = f"Received post_power_bytecode with unrecognized protocol_version {protocol_version}"
        logger.warning(msg)
        raise ValueError(msg)


def post_power_elaboration(park_name, software_version, available_power,
                           production, consumption, timestamp, cp_powers):
    try:
        park = Park.objects.get(name=park_name)
    except (ObjectDoesNotExist, MultipleObjectsReturned):
        logger.error(f"UNREACHABLE in post_power on park {park_name}")
        return  # HttpResponse(status=500)
    realtime_park_save = park.save_data and park.autosave_min_interval is None
    with transaction.atomic():
        # Software Version update
        park.software_version = software_version
        park.save()
        # BuildingInfos
        bi_lastpower, _created = BuildingInfosLastPower.objects.update_or_create(
            park=park,
            defaults={
                'timestamp': timestamp,
                'production': production,
                'consumption': consumption,
                'available_power': available_power,
                # False if it will be saved later (T and not None = F), True if will be saved now (T and None = T)
                # In case you don't need to save the data, use False (F and any = F)
                'already_saved': realtime_park_save,
            }
        )
        if realtime_park_save:
            bi = BuildingInfosPowerTable(
                park=bi_lastpower.park,
                timestamp=timestamp,
                production=bi_lastpower.production,
                consumption=bi_lastpower.consumption,
                available_power=bi_lastpower.available_power,
            )
            bi.save()
        # TODO: to use the REAL timestamp from the raspberry we need a dynamic integration for energy calculation
        # Prepare Power Objects
        cs_with_error = []
        power_objects = []
        for k, power in enumerate(cp_powers, start=1):
            try:
                cs = ChargingStation.objects.get(park=park, park_bnum=k)
                csp_lp, _created = ChargingStationLastPower.objects.update_or_create(
                    chargingstation=cs,
                    defaults={
                        'timestamp': timestamp,
                        'power': power,
                        'already_saved': realtime_park_save,
                    }
                )
                if realtime_park_save:
                    csp = ChargingStationPowerTable(
                        chargingstation=csp_lp.chargingstation,
                        timestamp=csp_lp.timestamp,
                        power=csp_lp.power,
                    )
                    power_objects.append(csp)
            except ChargingStation.DoesNotExist:
                cs_with_error.append(k)
                continue
            # old version: Charge.objects.filter(stop=None, chargingstation=cs).order_by("-id").first()
            # BEGIN CLOSING CHARGE LOGIC
            if cs.suspended:
                continue
            active_charge = cs.active_charge
            if active_charge is not None:
                closing_charge_logic(active_charge)
        # Bulk create Power Objects
        #    This automatically append pk because our backend is PostgreSQL
        #    https://docs.djangoproject.com/en/4.0/ref/models/querysets/#bulk-create
        ChargingStationPowerTable.objects.bulk_create(power_objects)
    # END TRANSACTION
    # Error report
    if len(cs_with_error) != 0:
        formatted_list = list(map(int, cs_with_error))
        logger.debug(f"Tried post_power on chargingstations {park_name}:{formatted_list} but they don't exist.")


@shared_task(ignore_result=True, store_errors_even_if_ignored=True)
def task_post_power_legacy(data):
    """
    data = {
            "park_name": park_name,
            "timestamp":timestamp,
            1:value,
            2:value,
            x:value}
    Remember to modify this function the least possible. Only small changes for compat reasons.
    """
    # When you need to edit post_power_elaboration make sure to unify this function with that
    if isinstance(data, str):
        data = json.loads(data)
        park_name = data.get("park_name")
    else:
        logger.warning("Bad post_power request")
        return  # HttpResponse(status=400)
    try:
        _park = Park.objects.get(name=park_name)
    except ObjectDoesNotExist:
        logger.debug(f"Tried post_power on inexistent park {park_name}")
        return  # HttpResponse(status=400)
    except MultipleObjectsReturned:
        logger.critical(f"Tried post_power on duplicated park {park_name}")
        return  # HttpResponse(status=400)
    # New decode logic for old legacy parks
    cp_powers = []
    for k in range(1, 9):
        try:
            cp_powers.append(data[k])
        except KeyError:
            break
    post_power_elaboration(
        park_name,
        data.get("version", ""),
        data.get("available_power", 0),
        data.get("production", 0),
        data.get("consumption", 0),
        datetime.datetime.now(pytz.utc),
        cp_powers
    )
    return  # HttpResponse(status=200)
