import json

from rest_framework import serializers

from re_restapi.models import Charge, ChargingStation, Park


class RecoveryChargeSerializer(serializers.ModelSerializer):
    guest = serializers.BooleanField(source='user.has_guest_feat')

    class Meta:
        model = Charge
        fields = ['last_nonzero_power_time', 'guest']


class RecoveryChargingStationSerializer(serializers.ModelSerializer):
    active_charge = RecoveryChargeSerializer(required=False)

    class Meta:
        model = ChargingStation
        fields = ['active_charge', 'park_bnum', 'suspended']


class RecoveryStatusSerializer(serializers.ModelSerializer):
    chargingstations = RecoveryChargingStationSerializer(source='chargingstation_set', many=True, read_only=True)

    class Meta:
        model = Park
        fields = ['chargingstations']
        read_only_fields = fields


def format_recovery_status(park_name):
    try:
        park = Park.objects.get(name=park_name)
    except Park.DoesNotExist:
        raise
    serializer = RecoveryStatusSerializer(park)
    return json.dumps(serializer.data)
