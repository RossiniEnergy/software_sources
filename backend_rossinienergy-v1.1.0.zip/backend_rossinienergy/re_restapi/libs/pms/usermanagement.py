from re_restapi.models import User, Charge


class PMSSubUser:
    def __init__(self, user: User):
        if not user.has_pmschild_feat:
            raise ValueError("User is without PMSChild Feature")
        if '$' not in user.username:
            raise ValueError("Username without $, sure it's a PMSSubUser?")
        self.username = '$'.join(user.username.split('$')[1:])
        self.id = user.id
        self.expire_datetime = user.scheduled_expire_time
        self.expired = user.is_readonly
        self.price = user.pmschildfeature.price
        self.memory = user.pmschildfeature.memory
        self.charges = list(Charge.objects.filter(user=user).order_by('id'))
        self.model_instance = user

    @classmethod
    def init_list(cls, users):
        output = []
        for user in users:
            output.append(cls(user))
        return output
