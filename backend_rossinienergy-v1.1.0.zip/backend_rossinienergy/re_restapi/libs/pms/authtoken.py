from hashlib import blake2b
import datetime
from uuid import uuid4

import pytz
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import BasePermission

from django.db import transaction

from re_restapi.libs.exceptions import HTTPResponseWrapperError

from re_restapi.models import PMSPendingRequest, User, PMSAdminFeature


def initialize_token(tmp_token, pms):
    try:
        pending_request = PMSPendingRequest.objects.get(registration_token=tmp_token, pms=pms)
    except PMSPendingRequest.DoesNotExist:
        raise HTTPResponseWrapperError(
            Response(f"No pending request corresponding to token {tmp_token}",
                     status=status.HTTP_404_NOT_FOUND)
        )
    # Generate internal_username for the parkadmin and auth token for the PMS client
    timestamp_now = int(datetime.datetime.now(pytz.UTC).timestamp())
    internal_token = f"{pending_request.pms.pk}#{pending_request.label}#{timestamp_now}"
    hasher = blake2b(digest_size=16)
    hasher.update(internal_token.encode())  # This way if the username is unique, probably the token is unique too
    token = hasher.hexdigest()
    # Check if every requested park is in fact adminless
    # OPTIMIZE: It's possible to move this to a trigger?
    if any(map(lambda x: x.admin_users.exists(), pending_request.authorized_parks.distinct().all())):
        raise HTTPResponseWrapperError(
            Response(f"One of the park is already managed by a user. Contact system administrator.",
                     status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        )
    # Execute initialization
    with transaction.atomic():
        user = User.objects.create_user(
            username=str(uuid4()),
            email="",
            password="temp_password",
            authorization_token=token,
        )
        user.set_unusable_password()
        user.save()
        pmsadmin_feat = PMSAdminFeature.objects.create(
            user=user,
            label=pending_request.label,
            pms=pms,
        )
        pmsadmin_feat.pms_managed_parks.add(*pending_request.authorized_parks.distinct().all())
        pending_request.delete()
        user.refresh_features_from_db()
    return user


class NestedIsAuthenticatedAndPMSAdmin(BasePermission):
    # Retrevo PMS da view utilizzando il self keys definito dal router! Se mancante, droppo False.
    def has_permission(self, request, view):
        try:
            pms_abbrev = view.kwargs['pms_abbrev']
        except KeyError:
            return False  # Not found the nested key in the view kwargs
        if request.user is None:
            return False
        elif not request.user.is_authenticated:
            return False
        elif not request.user.has_pmsadmin_feat:
            return False
        elif request.user.pmsadminfeature.pms.abbrev != pms_abbrev:
            return False
        else:
            return True
