import stripe
import logging

from celery import shared_task

from django.conf import settings

stripe.api_key = settings.STRIPE_PRIVATE_KEY

logger = logging.getLogger('re.libs.stripewebhook')


@shared_task(ignore_result=True, store_errors_even_if_ignored=True)
def handle_stripe_webhook(event_json):
    pass
