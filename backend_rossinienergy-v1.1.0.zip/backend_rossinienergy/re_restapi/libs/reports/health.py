import datetime

import pytz
import stripe
import logging

from django.conf import settings

from collections import namedtuple
from collections.abc import Iterable

from re_restapi.models import MoneyDestination, Park

logger = logging.getLogger("re.libs.reports.health")

stripe.api_key = settings.STRIPE_PRIVATE_KEY

StripeReport = namedtuple('StripeReport',
                          ['id', 'transfers', 'payout',
                           'capab_transfers', 'capab_cardpayments',
                           'enabled_cp', 'total_cp'])

ParkReport = namedtuple('ParkReport',
                        ['id', 'has_orders', 'last_contact'])


def stripe_health_retrieve(moneydestionation: MoneyDestination or Iterable[MoneyDestination], many=False):
    output = []
    if not many:
        moneydestionation = [moneydestionation]
    for md in moneydestionation:
        try:
            account = stripe.Account.retrieve(md.stripe_id)
            transfers = account['charges_enabled']
            payout = account['payouts_enabled']
            total_cp = md.chargingstation_set.count()
            enabled_cp = md.chargingstation_set.filter(accept_guests=True).count()
            transf = account['capabilities'].get("transfers")
            card_pay = account['capabilities'].get("card_payments")
            capab_transfers = (transf == "active")
            capab_cardpayments = (card_pay == "active")
            output.append(
                StripeReport(md.id, transfers, payout, capab_transfers, capab_cardpayments, enabled_cp, total_cp))
            # This was the old condition to exclude the healty MoneyDestination
            # if not (transfers and payout) or enabled_cp != total_cp or not (capab_transfers and capab_cardpayments):
        except Exception:
            output.append(StripeReport(md.id, *[None] * 6))
            logger.warning(f"MD {md.id} named {md.society_name} with stripe_id {md.stripe_id} is invalid")
    if not many:
        return output[0]
    else:
        return output


def park_health_retrieve(park: Park or [Park], many=False):
    output = []
    if not many:
        park = [park]
    for pk in park:
        # FIXME: verificare se funziona correttamente anche per colonnine senza last_power
        last_contact_timestamp = pk.chargingstation_set.all().values_list('last_power__timestamp', flat=True).first()
        orders_enabled = pk.chargingstation_set.filter(qrcodeid__isnull=False).exists()
        if last_contact_timestamp is None:
            output.append(ParkReport(pk.id, orders_enabled, None))
        else:
            output.append(ParkReport(pk.id, orders_enabled, last_contact_timestamp))
    if not many:
        return output[0]
    else:
        return output


def produce_park_health_html_table():
    now = datetime.datetime.now(pytz.UTC)

    def park_not_good(park_report):
        last_c = park_report.last_contact
        return last_c is None or now - last_c > datetime.timedelta(hours=1)

    park_reports_mixed = [
        p for p in park_health_retrieve(Park.objects.filter(installed=True), many=True) if park_not_good(p)
    ]
    # Sorting to have park in decreased contacttime order, with None at the end of the table
    park_reports = [p for p in park_reports_mixed if p.last_contact is not None]
    park_reports.sort(key=lambda x: x.last_contact, reverse=True)
    park_reports_withnone = [p for p in park_reports_mixed if p.last_contact is None]
    park_reports.extend(park_reports_withnone)

    park_table = "<h2>Offline parks</h2>"
    park_table += (
        "<div>Every park's last contact has been reset during an update the December 16 2021.<br/>"
        "Only the data after December 01 2021 are showed in this report.</div>"
        "<br/><table>"
        "<tr><th>Park name (id)</th><th>Orders</th>"
        "<th>Last contact</th><th>Days offline</th></tr>")
    style = 'style="border: 1px solid black; text-align:center; padding: 3px"'
    for pid, orders_enabled, last_contact in park_reports:
        if last_contact is None:
            last_contact = "<font color='red'>None</font>"
            delta = "<font color='red'>???</font>"
        else:
            short = last_contact.strftime('%d/%m/%Y %H:%M:%S')
            delta = now - last_contact
            delta_days = int(delta.total_seconds()) // (60 * 60 * 24)
            if delta > datetime.timedelta(days=14):
                last_contact = f"<font color='orange'>{short}</font>"
                delta = f"<font color='orange'>{delta_days}</font>"
            elif delta > datetime.timedelta(days=30):
                last_contact = f"<font color='red'>{short}</font>"
                delta = f"<font color='red'>{delta_days}</font>"
            else:
                last_contact = short
                delta = f"{delta_days}"
        pname = Park.objects.get(id=pid).name
        orders = 'enabled' if orders_enabled else 'disabled'
        park_table += (
            f'<tr><td {style}>{pname} ({pid})</td>'
            f'<td {style}>{orders}</td>'
            f'<td {style}>{last_contact}</td>'
            f'<td {style}>{delta}</td></tr>\n'
        )
    park_table += "</table>\n"

    return park_table


def produce_stripe_health_html_table():
    def stripe_not_good(stripe_report):
        # noinspection PyShadowingNames
        _, transfers, payout, capab_transfer, capab_cardpayment, enabled_cp, tot_cp = stripe_report
        return not (transfers and payout) or enabled_cp != tot_cp or not (capab_transfer and capab_cardpayment)

    stripe_reports = stripe_health_retrieve(MoneyDestination.objects.all(), many=True)
    bad_stripe_status = [report for report in stripe_reports if stripe_not_good(report)]
    table_header = [
        "Society (moneyreceiver id)", "Can transfer", "Can payout",
        "CP enabled", "Capability: transfer", "Capability: card payment"
    ]
    valid_receivers = [table_header]
    invalid_receivers = [table_header[0]]
    for report in bad_stripe_status:
        name = MoneyDestination.objects.get(id=report.id).society_name
        scname = f"{name} ({report.id})"
        if None in report:
            invalid_receivers.append(scname)
            continue
        transf = report.transfers
        payout = report.payout
        bornes = f"{report.enabled_cp}/{report.total_cp}"
        cap_tr = report.capab_transfers
        cap_cp = report.capab_cardpayments
        valid_receivers.append([scname, transf, payout, bornes, cap_tr, cap_cp])

    if len(valid_receivers) > 1:
        valid_receivers_table = "<h2>Money receivers with errors</h2><br/>\n<table>\n"
        header = True
        for line in valid_receivers:
            html_line = "<tr>"
            for field in line:
                tag = "th" if header else "td"
                style = 'style="border: 1px solid black; text-align:center; padding: 3px"'
                header = False
                if not isinstance(field, str):
                    if field:
                        field = "<font color='green'>OK</font>"
                    else:
                        field = "<font color='red'><b>NO!</b></font>"
                html_line += f'<{tag} {style}>{field}</{tag}>'
            html_line += "</tr>\n"
            valid_receivers_table += html_line
        valid_receivers_table += "</table>\n"
    else:
        valid_receivers_table = ""

    if len(invalid_receivers) > 1:
        invalid_receivers_table = "<h2>Invalid money receivers</h2><br/>\n<table>\n"
        header = True
        for receiver in invalid_receivers:
            tag = "th" if header else "td"
            style = 'style="border: 1px solid black; text-align:center; padding: 3px"'
            header = False
            invalid_receivers_table += f'<tr><{tag} {style}>{receiver}</{tag}></tr>\n'
        invalid_receivers_table += "</table>\n"
    else:
        invalid_receivers_table = ""

    return valid_receivers_table + "<br/>\n" + invalid_receivers_table
