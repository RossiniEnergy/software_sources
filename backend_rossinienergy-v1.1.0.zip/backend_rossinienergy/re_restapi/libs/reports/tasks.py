import pycountry
import datetime

from celery import shared_task

from django.conf import settings
from django.conf.global_settings import EMAIL_HOST_USER
from django.core.mail import EmailMessage, EmailMultiAlternatives

from re_restapi.models import MoneyDestination, Park
from re_restapi.libs.reports.admin import make_admin_report
from re_restapi.libs.reports.park import make_park_report
from re_restapi.libs.reports.utils import get_month_range
from re_restapi.libs.reports.health import produce_park_health_html_table, produce_stripe_health_html_table


@shared_task(autoretry_for=(Exception,), retry_backoff=10, max_retries=20, retry_jitter=True)
def sendmail_moneydestination_report(filepath, moneydest_id, month):
    def month_name_dictionary(num):
        month_name_dict = {
            'en': [
                'January', 'February', 'March', 'April', 'May', 'June',
                'July', 'August', 'September', 'October', 'November', 'December'
            ],
            'it': [
                'Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno',
                'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'
            ],
            'fr': [
                'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
                'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
            ],
            'nl': [
                'Januari', 'Februari', 'Maart', 'April', 'Mei', 'Juni',
                'Juli', 'Augustus', 'September', 'Oktober', 'November', 'December'
            ]
        }

        def _month_name_impl(lang):
            return month_name_dict[lang][num - 1]

        return _month_name_impl

    month_name = month_name_dictionary(month)

    subjects = {
        'en': f'RossiniEnergy report month of {month_name("en")}',
        'it': f'Report mensile per il mese di {month_name("it")} da RossiniEnergy',
        'fr': f'RossiniEnergy rapport mois de {month_name("fr")}',
        'nl': f'RossiniEnergy rapport maand {month_name("nl")}'
    }
    messages = {
        'en': f'Dear Customer,\n\n'
              f'Please find attached the summary of the charge sessions paid out by credit card '
              f'at your chargepoints for the month of {month_name("en")}.\n\n'
              f'Happy charging,\nRossiniEnergy s.a.s.\n\n'
              f'+33 (0)3 74 09 01 05\ninfo@rossinienergy.com',
        'it': f'Gentile Cliente,\n\n'
              f'In allegato troverà un riepilogo delle ricariche a pagamento effettuate sul '
              f'vostro parco di colonnine nel mese di {month_name("it")}.\n\n'
              f'Cordialmente,\nRossiniEnergy s.a.s.\n\n'
              f'+33 (0)3 74 09 01 05\ninfo@rossinienergy.com',
        'fr': f'Cher Client,\n\n'
              f'Ci joint le récapitulatif des sessions de recharge payantes sur votre parc de '
              f'bornes de recharge pour le mois de {month_name("fr")}.\n\n'
              f'Bonnes recharges,\nRossiniEnergy s.a.s.\n\n'
              f'+33 (0)3 74 09 01 05\ninfo@rossinienergy.com',
        'nl': f'Beste klant,\n\n'
              f'Hierbij vindt u het overzicht van de betaalde oplaadbeurten voor uw wagenpark '
              f'voor de maand {month_name("fr")}.\n\n'
              f'Goede opladingen,\nRossiniEnergy s.a.s.\n\n'
              f'+33 (0)3 74 09 01 05\ninfo@rossinienergy.com',
    }
    moneydest = MoneyDestination.objects.get(pk=moneydest_id)
    if moneydest.email == "":
        raise ValueError("Missing email in Moneydestination")
    subject = subjects[moneydest.receipt_language]
    message = messages[moneydest.receipt_language]
    recepient = moneydest.email
    # QUESTION: Changed to BCC. Better to use the old CC?
    email = EmailMessage(subject, message, EMAIL_HOST_USER, [recepient], bcc=settings.EMAIL_MONTH_REPORT_BCC)
    email.attach_file(filepath)
    result = email.send(fail_silently=False)
    return result


@shared_task(autoretry_for=(Exception,), retry_backoff=10, max_retries=20, retry_jitter=True)
def sendmail_park_report(filepath, park_id, month, year):
    subjects = {
        'en': 'RossiniEnergy report for park "{}"',
        'it': 'Report mensile per il parco "{}" da RossiniEnergy',
        'fr': 'RossiniEnergy rapport pour le parc "{}"',
        'nl': 'RossiniEnergy rapport voor het "{}" park'
    }
    messages = {
        'en': 'Dear Customer,\n\n'
              'Please find attached the summary of the charge sessions at the '
              'chargepoints of the park "{}" carried out between {} and {}.\n\n'
              'Happy charging,\nRossiniEnergy s.a.s.\n\n'
              '+33 (0)3 74 09 01 05\ninfo@rossinienergy.com',
        'it': 'Gentile Cliente,\n\n'
              'In allegato troverà un riepilogo delle ricariche effettuate sulle '
              'colonnine del parco "{}" dal {} al {}.\n\n'
              'Cordialmente,\nRossiniEnergy s.a.s.\n\n'
              '+33 (0)3 74 09 01 05\ninfo@rossinienergy.com',
        'fr': 'Cher Client,\n\n'
              'Ci joint le récapitulatif des sessions de recharge aux bornes du '
              'parc "{}" réalisées entre le {} et le {}.\n\n'
              'Bonnes recharges,\nRossiniEnergy s.a.s.\n\n'
              '+33 (0)3 74 09 01 05\ninfo@rossinienergy.com',
        'nl': 'Beste klant,\n\n'
              'Hierbij vindt u het overzicht van de oplaadbeurten aan de oplaadpunten '
              'van het park "{}" die tussen {} en {} zijn uitgevoerd.\n\n'
              'Goede opladingen,\nRossiniEnergy s.a.s.\n\n'
              '+33 (0)3 74 09 01 05\ninfo@rossinienergy.com',
    }
    park = Park.objects.get(pk=park_id)
    country_code = park.country_alpha2.lower()
    start, stop = get_month_range(month, year)
    test_country = pycountry.countries.get(alpha_2=country_code)
    if not test_country:
        country_code = "fr"
    try:
        _ = subjects[country_code]
        _ = messages[country_code]
    except KeyError:
        country_code = "fr"
    subject = subjects[country_code].format(park.name)
    message = messages[country_code].format(park.name, start.date(), stop.date())
    recepient = park.email
    # QUESTION: Changed to BCC. Better to use the old CC?
    email = EmailMessage(subject, message, EMAIL_HOST_USER, [recepient], cc=settings.EMAIL_PARK_REPORT_BCC)
    email.attach_file(filepath)
    result = email.send(fail_silently=False)
    return result


@shared_task(autoretry_for=(Exception,), retry_backoff=10, max_retries=20, retry_jitter=True)
def generate_moneydestination_report(moneydest_id, month=None, year=None, send_mail=False):
    moneydest = MoneyDestination.objects.get(pk=moneydest_id)
    start, stop = get_month_range(month, year)
    filepath = make_admin_report(moneydest, start, stop)
    if send_mail:
        sendmail_moneydestination_report.delay(filepath, moneydest_id, month)


@shared_task(autoretry_for=(Exception,), retry_backoff=10, max_retries=20, retry_jitter=True)
def generate_park_report(park_id, month=None, year=None, send_mail=False):
    park = Park.objects.get(pk=park_id)
    start, stop = get_month_range(month, year)
    filepath = make_park_report(park, start, stop)
    if send_mail:
        sendmail_park_report.delay(filepath, park_id, month, year)


@shared_task
def schedule_prevmonth_moneydestination_report():
    """YELLOW"""
    now = datetime.datetime.now()
    target_month = (now.month - 2) % 12 + 1
    target_year = now.year
    if target_month > now.month:
        target_year -= 1
    for md in MoneyDestination.objects.exclude(email=""):
        generate_moneydestination_report.delay(md.id, target_month, target_year, send_mail=True)


@shared_task
def schedule_prevmonth_park_report():
    """GREEN"""
    now = datetime.datetime.now()
    target_month = (now.month - 2) % 12 + 1
    target_year = now.year
    if target_month > now.month:
        target_year -= 1
    for park in Park.objects.filter(email_report=True):
        generate_park_report.delay(park.id, target_month, target_year, send_mail=True)


@shared_task(time_limit=2 * 60 * 60)
def send_health_report():
    subject = "Health report"

    html_message = produce_stripe_health_html_table() + "<br/>\n" + produce_park_health_html_table()

    output = {}
    for recipient in settings.HEALTH_STATUS_MAIL_RECIPIENTS:
        email = EmailMultiAlternatives(subject, "", EMAIL_HOST_USER, [recipient])
        email.attach_alternative(html_message, "text/html")
        result = email.send(fail_silently=True)
        output[recipient] = result
    return output
