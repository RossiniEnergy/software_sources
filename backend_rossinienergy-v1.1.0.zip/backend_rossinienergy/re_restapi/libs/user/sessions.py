import logging
import datetime

import pytz
from celery import shared_task
from django.contrib.sessions.models import Session

from django.core.management import call_command

from re_restapi.models import User

logger = logging.getLogger('re.libs.user.sessions')


@shared_task
def clear_expired_sessions():
    call_command("clearsessions")


def delete_all_unexpired_sessions_for_user(user: User):
    logger.debug("Call to delete_all_unexpired_sessions_for_user")
    all_unexpired_sessions = Session.objects.filter(expire_date__gte=datetime.datetime.now(pytz.UTC))
    for session in all_unexpired_sessions:
        # FIXME: Probably this require something like 'user_id' or '_re_restapi_user_id' to work properly
        if str(user.pk) == session.get_decoded().get('_auth_user_id'):
            session.delete()
    logger.info(f"All the opened session for the user {user.username} have been expired correctly")
