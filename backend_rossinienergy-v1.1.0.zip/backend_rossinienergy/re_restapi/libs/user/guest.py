import logging
import time
import random
import datetime
import pytz

from django.db import transaction

from re_restapi.models import User, GuestFeature, ChargeFeature

logger = logging.getLogger("re.libs.user.guest")


def create_guest_user(chargingstation, email=""):
    logger.debug("Call to create_guest_user")
    random_username = "{}_{}".format(int(time.time()), random.randint(0, 1000))
    expire_datetime = datetime.datetime.now(pytz.UTC) + datetime.timedelta(minutes=30)
    with transaction.atomic():
        tmp_user = User.objects.create_user(
            username=random_username,
            password="temp_password",
            email=email,
            scheduled_expire_time=expire_datetime,
            # DIS Expire Policy
            on_expire_readonly=True,
            on_expire_disable=True,
            on_expire_appendtimestamp=False,
        )
        tmp_user.set_unusable_password()
        tmp_user.save()
        chargefeat = ChargeFeature(user=tmp_user)
        chargefeat.authorized_cs.add(chargingstation)
        chargefeat.save()
        GuestFeature.objects.create(user=tmp_user)
    tmp_user.refresh_features_from_db()
    logger.info(f"Created guest user \"{tmp_user.username}\"")
    return tmp_user
