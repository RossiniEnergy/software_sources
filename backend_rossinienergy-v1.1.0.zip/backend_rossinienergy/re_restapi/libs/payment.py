import logging
import stripe

from django.conf import settings
from django.core.exceptions import MultipleObjectsReturned, ObjectDoesNotExist

from re_restapi.libs.payment_utils import cancel_payment_order
from re_restapi.libs.user.expire import expire_user
from re_restapi.models import User, Charge, PaymentOrder

logger = logging.getLogger("re.libs.payment")

stripe.api_key = settings.STRIPE_PRIVATE_KEY


def try_capture_money(charge: Charge):
    logger.debug(f"Call to try_capture_money")
    # Retrieve from the Charge the ChSt and the PayOrd
    cs = charge.chargingstation
    user: User = charge.user
    if not user.has_guest_feat:
        logger.debug(f"No Payment capture for charge {charge.id} because user {user.username} isn't guest.")
        return

    try:
        payord = PaymentOrder.objects.get(chargingstation=cs,
                                          phase=2,  # Confirmed and Capturable
                                          )
    except ObjectDoesNotExist:
        logger.critical(f"No payment order found for charge {charge.id}")
        return
    except MultipleObjectsReturned:
        logger.critical(f"DOUBLE PAYMENT ORDER FOR USER {user.username} AND CS {cs.bnum} FOR CHARGE {charge.id}")
        return
    price_cents_per_kwh = cs.price
    # percentual_commission = cs.com
    energy_used_wh = charge.energy_wh
    # Calculate Net (VAT included)
    energy_total_cents = energy_used_wh * price_cents_per_kwh / 1000
    # Calculate Stripe Commissions
    stripe_comm_cents = 25 + 0.014 * energy_total_cents  # 0.25 eur + 1.4%
    # Calculate VAT separation (without counting the Stripe Commissions)
    # vat_cents = energy_total_cents / 6  # 20% VAT in France 0.2/1.2 * total
    # Calculate RossiniEnergy Commissions
    # rossen_comm_cents = int((energy_total_cents + vat_cents) / 100 * percentual_commission)
    rossen_comm_cents = 0  # TODO: Remove Commissions
    # Calculate total order value
    total_cost_cents = int(energy_total_cents + stripe_comm_cents)
    # Check if the total cost require cancellation or rounding
    if total_cost_cents > settings.AMOUNT_TO_IMPRINT:
        logger.warning("Rounded up the payment for charge "
                       f"{charge.id} from {total_cost_cents} to {settings.AMOUNT_TO_IMPRINT} cents")
        # FIXME: The other values like VAT and Commissions dont reflect this hardcode
        total_cost_cents = settings.AMOUNT_TO_IMPRINT
    elif total_cost_cents < settings.AMOUNT_MINIMAL:
        logger.info(f"Payment Order id {payord.id} requesting less than {settings.AMOUNT_MINIMAL} cents, "
                    "cancelling Payment...")
        cancel_payment_order(payord)  # Cancelling an order complete the database entry
        expire_user(payord.user)
        return

    # Start capture
    # TODO: ERROR HANDLING (make some choice)
    capture = stripe.PaymentIntent.capture(
        payord.imprint_id,
        amount_to_capture=total_cost_cents,
        # application_fee_amount=rossen_comm_cents,
        transfer_data={'amount': int(energy_total_cents)},
    )
    # Write report in PaymentOrder
    payord.phase = 3  # Captured/Closed
    payord.energy_cents = energy_total_cents
    payord.stripe_comm_cents = stripe_comm_cents
    payord.rossen_comm_cents = rossen_comm_cents
    payord.capture_status = capture.status
    payord.save()
    logger.info(f"Prompted expiration of guest user {payord.user.username}")
    # TODO: Remove expire_user from this function to allow close_all_user_charges to be included in expire_user
    expire_user(payord.user)
    if capture.status == 'succeeded':
        logger.info(f"Completed capture for Charge {charge.id} and Payment Order {payord.id}")
    else:
        logger.critical(f"Error capturing Charge {charge.id} and Payment Order {payord.id} with return "
                        f"status \"{payord.capture_status}\"")


def generate_stripeconnect_link(email, country_alpha2, refresh_url, return_url):
    # TODO: error handling
    logger.debug(f"Call to generate_link with email \"{email}\" and country alpha_2 \"{country_alpha2}\"")
    account = stripe.Account.create(
        type="express",
        country=country_alpha2,
        email=email,
        capabilities={"transfers": {"requested": True}, "card_payments": {"requested": True}},
    )
    # TODO: delete account if connection failed, or something like that
    account_link = stripe.AccountLink.create(
        account=account.get("id"),
        refresh_url=refresh_url,
        return_url=return_url,
        type="account_onboarding",
    )
    return account_link.get("url")
