from rest_framework import viewsets
from rest_framework.permissions import BasePermission, IsAdminUser, AllowAny, IsAuthenticated

__all__ = [
    'BasePermission',
    'IsAdminUser',
    'AllowAny',
    'IsAuthenticated',
    'PermissionGenericViewSet',
    'IsAuthenticatedNotExpired',
    'IsHimselfUser',
    'IsBelongerUser',
    'IsParkAdmin',
    'IsStaffForObject',
    'IsParkAdminForUser',
    'IsParkAdminForPark',
    'IsParkAdminForChargingStation',
]


class PermissionGenericViewSet(viewsets.GenericViewSet):
    permission_classes_by_action = {}

    def get_permissions(self):
        try:
            # return permission_classes depending on `action`
            return [permission() for permission in self.permission_classes_by_action[self.action]]
        except KeyError:
            # action is not set return default permission_classes
            return [permission() for permission in self.permission_classes]


# TODO: CHANGE NAME
class IsAuthenticatedNotExpired(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and not request.user.is_readonly)


# TODO: Think about a full refactor of the permission classes
class IsHimselfUser(BasePermission):
    def has_object_permission(self, request, view, obj):
        # If the requester is a parent user of the requested, allow.
        # If same user, allow. Else, deny.
        return bool(request.user and request.user == obj)


class IsBelongerUser(BasePermission):
    def has_object_permission(self, request, view, obj):
        # If the requester is a parent user of the requested, allow.
        return bool(request.user and request.user in obj.admin_users.all())


class IsParkAdmin(BasePermission):
    def has_object_permission(self, request, view, obj):
        return bool(request.user and request.user.has_parkadmin_feat)


class IsStaffForObject(IsAdminUser):
    def has_object_permission(self, request, view, obj):
        return self.has_permission(request, view)


class IsParkAdminForUser(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.has_parkadmin_feat)

    def has_object_permission(self, request, view, obj):
        return bool(request.user and obj in request.user.parkadminfeature.child_users.all())


class IsParkAdminForPark(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.has_parkadmin_feat)

    def has_object_permission(self, request, view, obj):
        return bool(request.user and obj in request.user.parkadminfeature.managed_parks.all())


class IsParkAdminForChargingStation(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.has_parkadmin_feat)

    def has_object_permission(self, request, view, obj):
        return bool(request.user and obj.park in request.user.parkadminfeature.managed_parks.all())
