import logging

from celery import shared_task

import pika
from pika.exceptions import AMQPError

from django.conf import settings

from re_restapi.libs.recoverystatus import format_recovery_status

logger = logging.getLogger("re.libs.orders")

SENDER_TAGS = ['user', 'guest']


@shared_task
def send_order_on(park_name, park_bnum, sender_tag):
    assert sender_tag in SENDER_TAGS
    try:
        logger.debug(f"Sendind \"charge {park_bnum} {sender_tag}\" to park_name={park_name}")
        # Pre v1 ChargingStations
        connection = pika.BlockingConnection(
            pika.connection.URLParameters(settings.LEGACY_PILOTAGE_BROKER_URL)
        )
        channel = connection.channel()
        channel.basic_publish(
            exchange="chargingstation",
            routing_key="CS_{}".format(park_name),
            body=bytes("charge {}".format(park_bnum), 'ascii'),
        )
        channel.close()
        connection.close()
        # v2 ChargingStations
        connection = pika.BlockingConnection(
            pika.connection.URLParameters(settings.PILOTAGE_BROKER_URL)
        )
        channel = connection.channel()
        channel.basic_publish(
            exchange="amq.topic",
            routing_key="CS_{}".format(park_name),
            body=bytes("charge {} {}".format(park_bnum, sender_tag), 'ascii'),
        )
        channel.close()
        connection.close()
    except AMQPError:
        logger.error(f"Problem sending \"charge {park_bnum} {sender_tag}\" to park_name={park_name}")
        return
        # TODO manage error here


@shared_task
def send_order_off(park_name, park_bnum):
    try:
        logger.debug(f"Sendind \"stop_charge {park_bnum}\" to park_name={park_name}")
        # Pre v1 ChargingStations
        connection = pika.BlockingConnection(
            pika.connection.URLParameters(settings.LEGACY_PILOTAGE_BROKER_URL)
        )
        channel = connection.channel()
        channel.basic_publish(
            exchange="chargingstation",
            routing_key="CS_{}".format(park_name),
            body=bytes("stop_charge {}".format(park_bnum), 'ascii'),
        )
        channel.close()
        connection.close()
        # v2 ChargingStations
        connection = pika.BlockingConnection(
            pika.connection.URLParameters(settings.PILOTAGE_BROKER_URL)
        )
        channel = connection.channel()
        channel.basic_publish(
            exchange="amq.topic",
            routing_key="CS_{}".format(park_name),
            body=bytes("stop_charge {}".format(park_bnum), 'ascii'),
        )
        channel.close()
        connection.close()
    except AMQPError:
        logger.error(f"Problem sending \"stop_charge {park_bnum}\" to park_name={park_name}")
        return
        # TODO manage error here


@shared_task(ignore_result=True, store_errors_even_if_ignored=True)
def send_suspend(park_name, park_bnum):
    try:
        logger.debug(f"Sendind \"suspend {park_bnum}\" to park_name={park_name}")
        # v2 ChargingStations
        connection = pika.BlockingConnection(
            pika.connection.URLParameters(settings.PILOTAGE_BROKER_URL)
        )
        channel = connection.channel()
        channel.basic_publish(
            exchange="amq.topic",
            routing_key="CS_{}".format(park_name),
            body=bytes("suspend {}".format(park_bnum), 'ascii'),
        )
        channel.close()
        connection.close()
    except AMQPError:
        logger.error(f"Problem sending \"suspend {park_bnum}\" to park_name={park_name}")
        return
        # TODO manage error here


@shared_task(ignore_result=True, store_errors_even_if_ignored=True)
def send_resume(park_name, park_bnum):
    try:
        logger.debug(f"Sendind \"resume {park_bnum}\" to park_name={park_name}")
        # v2 ChargingStations
        connection = pika.BlockingConnection(
            pika.connection.URLParameters(settings.PILOTAGE_BROKER_URL)
        )
        channel = connection.channel()
        channel.basic_publish(
            exchange="amq.topic",
            routing_key="CS_{}".format(park_name),
            body=bytes("resume {}".format(park_bnum), 'ascii'),
        )
        channel.close()
        connection.close()
    except AMQPError:
        logger.error(f"Problem sending \"resume {park_bnum}\" to park_name={park_name}")
        return
        # TODO manage error here


@shared_task(ignore_result=True, store_errors_even_if_ignored=True)
def send_recovery_state(park_name):
    try:
        logger.debug(f"Sendind \"recoverystatus\" to park_name={park_name}")
        data = format_recovery_status(park_name)
        # v2 ChargingStations
        connection = pika.BlockingConnection(
            pika.connection.URLParameters(settings.PILOTAGE_BROKER_URL)
        )
        channel = connection.channel()
        channel.basic_publish(
            exchange="amq.topic",
            routing_key="CS_{}".format(park_name),
            body=bytes("recoverystatus {}".format(data), 'ascii'),
        )
        channel.close()
        connection.close()
    except AMQPError:
        logger.error(f"Problem sending \"recoverystatus\" to park_name={park_name}")
        return
        # TODO manage error here
