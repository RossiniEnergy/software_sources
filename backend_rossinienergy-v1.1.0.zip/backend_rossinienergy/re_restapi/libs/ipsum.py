import datetime
import logging

import pika
import pytz
import binascii

from pika.exceptions import AMQPError
from py_expression_eval import Parser

from celery import shared_task

from django.conf import settings
from django.db import transaction
from django.db.models import DurationField, F, ExpressionWrapper
from django.db.models.functions import Coalesce

from re_restapi.models import IPSUMPowerTable, IPSUMLastPower, IPSUMDevice, ParkIpsumConf

logger = logging.getLogger('re.libs.ipsum')


@shared_task(ignore_result=True, store_errors_even_if_ignored=True)
def ipsum_powertable_scansave():
    # Prendi tutti gli IPSUMDevice che richiedono un salvataggio
    # Annotate una colonna con quanto tempo è passato dal last save a Now
    # Filtra usando solo quelli la cui colonna annotata è superiore al autosave_min_interval
    datetime_now = datetime.datetime.now(pytz.UTC)
    # Return the IPSUMDevice that we need to save. Skip the one without ipsumlastpower defined
    # Take the IPSUMDevice with a ipsumlastpower that results not already saved
    # This query require that IPSUMLastPower.timestamp defaults to datetime.now
    ipsumdevice_tosave = IPSUMDevice.objects.distinct().select_related('ipsumlastpower').filter(ipsumlastpower__isnull=False) \
        .annotate(elapsed=ExpressionWrapper(datetime_now - F('ipsumlastpower__last_save_timestamp'),
                                            output_field=DurationField())) \
        .filter(elapsed__gt=F('autosave_min_interval'), ipsumlastpower__already_saved=False).order_by('id')
    # Retrieva tutti gli IPSUMLastPower associati, skippa il save per chi non ha lastpower
    powertable_tosave = []
    for ipsumdevice in ipsumdevice_tosave:
        newpt = IPSUMPowerTable(
            ipsumdevice=ipsumdevice,
            timestamp=ipsumdevice.ipsumlastpower.timestamp,
            powers=ipsumdevice.ipsumlastpower.powers,
            extra=ipsumdevice.ipsumlastpower.extra,
        )
        powertable_tosave.append(newpt)
    # Do the writing atomically to prevent partial update (create without update)
    with transaction.atomic():
        # BulkCreate su IPSUMPowerTable
        IPSUMPowerTable.objects.bulk_create(powertable_tosave)
        # BulkUpdate su IPSUMDevice and IPSUMLastPower
        # REMEMBER! Update resolve the queryset, leaving it empty. Don't swap this two statement
        IPSUMLastPower.objects.filter(ipsumdevice__in=ipsumdevice_tosave).update(
            already_saved=True, last_save_timestamp=datetime_now)


@shared_task
def ipsum_drop_powertable():
    datetime_now = datetime.datetime.now(pytz.UTC)
    total_deleted_row = 0
    for ipsumdevice in IPSUMDevice.objects.filter(autodrop_max_interval__isnull=False):
        drop_before = datetime_now - ipsumdevice.autodrop_max_interval
        deleted_rows, _ = IPSUMPowerTable.objects.filter(ipsumdevice=ipsumdevice, timestamp__lt=drop_before).delete()
        total_deleted_row += deleted_rows
    print(f"Deleted Rows: {total_deleted_row}")  # Celery redirect print to standard task logger
    return total_deleted_row


def compute_ipsum_single_avalpower(conf: ParkIpsumConf, formula_number: int):
    parser = Parser()
    assert 1 <= formula_number <= 3
    query = getattr(conf, f'avalpower_formula_{formula_number}')
    if query == "":
        raise ValueError(
            f"avalpower_formula_{formula_number} must be not empty to compute available_power",
            'empty_query'
        )
    variables = {}
    if not conf.linked_ipsums.exists():
        raise ValueError(f"ParkIpsumConf {conf.park_id} doesn't have a linked_ipsums list")
    for ipsum in conf.linked_ipsums.all():
        if not hasattr(ipsum, 'ipsumlastpower'):
            raise ValueError(f"Ipsum {ipsum.id} doesn't have a IPSUMLastPower")
        for i, value in enumerate(ipsum.ipsumlastpower.powers):
            varname = f'D{ipsum.id}P{i + 1}'
            if value is None:
                raise ValueError(f"NaN in var {varname}")
            variables[varname] = value
    # noinspection PyBroadException
    try:
        available_power = parser.parse(query).evaluate(variables)
    except Exception as ex:
        raise ValueError("Error during parsing formula") from ex
    return available_power


def oldest_ipsum_timestamp_parkipsumconf(conf: ParkIpsumConf):
    if not conf.linked_ipsums.exists():
        raise ValueError(f"Park {conf.park_id} doesn't have a linked_ipsums list")
    try:
        oldest_timestamp = conf.linked_ipsums.filter(
            ipsumlastpower__timestamp__isnull=False
        ).latest('ipsumlastpower__timestamp').ipsumlastpower.timestamp
    except IPSUMDevice.DoesNotExist:
        oldest_timestamp = datetime.datetime(2000, 1, 1, 0, 0, tzinfo=pytz.UTC)  # OPTIMIZE: is there a better method?
    return oldest_timestamp.timestamp()


def encode_bytecode_parkipsumconf_v1(conf: ParkIpsumConf, base64_encoding=True) -> bytes:
    """
    How to encode the data to send to the Standard_Raspberry software
    PROTOCOL VERSION 1:
        data are bytestring with this structure: bytenumberx content (type) firstbytenumber-lastbytenumberinclusive
            1x bytecode version (unsigned integer) 0
            8x timestamp UTC (unsigned integer 64 bit) 1-8
            4x available power (signed integer) 9-12

        total bytesyze: 13
        Every number is encoded as BIG ENDIAN.
        Note that in this list the interval is INCLUSIVE, in the list operator in Python the last number is EXCLUSIVE:
            software version is bytes from 1 to 3 (1,2,3) but the list retrieve is data[1:4]=>(1,2,3)
        The Encoding used is: the n-byte contain the number as ASCII characters corresponding to the number that we
            wanted to send for example if we want to send 94 the byte will be \x61 so the bytestring will contain the
            corresponding char 'a'. For example the unsigned 12000 coded for 3 byte will be the bytestring b'\x00.\xe0'
            obtained with the function `numbervariable.to_bytes(nbytes, 'big', signed=False)`
    """
    protocol_version = int(1).to_bytes(1, 'big', signed=False)
    timestamp = int(oldest_ipsum_timestamp_parkipsumconf(conf)).to_bytes(8, 'big', signed=False)
    available_power = int(compute_ipsum_single_avalpower(conf, 1)).to_bytes(4, 'big', signed=True)
    output = protocol_version + timestamp + available_power
    if base64_encoding:
        output = binascii.b2a_base64(output)
    return output


def encode_bytecode_parkipsumconf_v2(conf: ParkIpsumConf, base64_encoding=True) -> bytes:
    """
    How to encode the data to send to the Standard_Raspberry software
    PROTOCOL VERSION 1:
        data are bytestring with this structure: bytenumberx content (type) firstbytenumber-lastbytenumberinclusive
            1x bytecode version (unsigned integer) 0
            8x timestamp UTC (unsigned integer 64 bit) 1-8
            4x available power 1 (signed integer) 9-12
            4x available power 2 (signed integer) 13-16
            4x available power 3 (signed integer) 17-20

        total bytesyze: 21
        Every number is encoded as BIG ENDIAN.
        Note that in this list the interval is INCLUSIVE, in the list operator in Python the last number is EXCLUSIVE:
            software version is bytes from 1 to 3 (1,2,3) but the list retrieve is data[1:4]=>(1,2,3)
        The Encoding used is: the n-byte contain the number as ASCII characters corresponding to the number that we
            wanted to send for example if we want to send 94 the byte will be \x61 so the bytestring will contain the
            corresponding char 'a'. For example the unsigned 12000 coded for 3 byte will be the bytestring b'\x00.\xe0'
            obtained with the function `numbervariable.to_bytes(nbytes, 'big', signed=False)`
    """
    protocol_version = int(2).to_bytes(1, 'big', signed=False)
    timestamp = int(oldest_ipsum_timestamp_parkipsumconf(conf)).to_bytes(8, 'big', signed=False)
    output = protocol_version + timestamp
    for i in range(1, 4):
        available_power = int(0).to_bytes(4, 'big', signed=True)  # Default to reset the variable at every loop
        try:
            available_power = int(compute_ipsum_single_avalpower(conf, i)).to_bytes(4, 'big', signed=True)
        except ValueError as exc:
            if len(exc.args) == 2 and exc.args[1] == 'empty_query':
                available_power = int(0).to_bytes(4, 'big', signed=True)  # Reset the variable in case was modified
            else:
                raise
        finally:
            output += available_power
    if base64_encoding:
        output = binascii.b2a_base64(output)
    return output


@shared_task(ignore_result=True, store_errors_even_if_ignored=True)
def task_post_ipsum_bytecode(coded_data, ipsumtoken):
    """
    How to decode the data sent from Ipsum to the server
    PROTOCOL VERSION 1:
        data are bytestring with this structure: bytenumberx content (type) firstbytenumber-lastbytenumberinclusive
            1x bytecode version (unsigned integer) 0
            3x software version (major.minor.rev) 1-3
            8x timestamp UTC (unsigned integer 64 bit) 4-11
            1x number P of power values in this metric (unsigned integer) 12
            3xP power values (unsigned integer) 13-15
            [ Nx NaN signaling bytes (unsigned integer) with N = 1 + P//8 and binary encoding with p1 = LSB]

        total bytesyze: 15 (1P) - 777 (255P CP)
        Every number is encoded as BIG ENDIAN.
        Note that in this list the interval is INCLUSIVE, in the list operator in Python the last number is EXCLUSIVE:
            software version is bytes from 1 to 3 (1,2,3) but the list retrieve is data[1:4]=>(1,2,3)
        The Encoding used is: the n-byte contain the number as ASCII characters corresponding to the number that we
            wanted to send for example if we want to send 94 the byte will be \x61 so the bytestring will contain the
            corresponding char 'a'. For example the unsigned 12000 coded for 3 byte will be the bytestring b'\x00.\xe0'
            obtained with the function `numbervariable.to_bytes(nbytes, 'big', signed=False)`
    """
    # Check ipsumdevice existance
    try:
        ipsum = IPSUMDevice.objects.get(token=ipsumtoken)
    except IPSUMDevice.DoesNotExist:
        raise RuntimeError(f"Tried post_ipsum for inexistent ipsumdevice token {ipsumtoken}")
    bytestring = binascii.a2b_base64(coded_data.encode())
    # Retrieve protocol version
    protocol_version = bytestring[0]
    if protocol_version == 1:
        # Retrieve software version
        major, minor, revision = bytestring[1:4]
        software_version = f"{major}.{minor}.{revision}"
        # Timestamp UTC
        timestamp_raw = int.from_bytes(bytestring[4:12], 'big')
        _timestamp = datetime.datetime.fromtimestamp(timestamp_raw, pytz.UTC)
        # Number P of powers
        power_quantity = bytestring[12]
        # Retrieve NaN
        low_nan_idx = 13 + 3 * int(power_quantity) + 1
        nan_encoding_length = 1 + int(power_quantity) // 8
        high_nan_idx = low_nan_idx + nan_encoding_length  # exclusive (remember slicing use exclusive high idx)
        nan_encoding = int.from_bytes(bytestring[low_nan_idx:high_nan_idx], 'big')
        #   Int to Bin algorithm (you get a Bool List)
        is_nan = [(nan_encoding & (1 << i)) != 0 for i in range(nan_encoding_length * 8)]
        # Retrieve values
        values = []
        for i in range(power_quantity):
            if is_nan[i]:
                values.append(None)
                continue
            val = int.from_bytes(bytestring[13 + i * 3:16 + i * 3], 'big')
            values.append(val)
        # Check list
        if len(values) != power_quantity:
            raise Exception("Format error with the productions and consumptions lists length")
        # Database Transactions
        with transaction.atomic():
            # Do you will save immediately the new data?
            save_now_flag = ipsum.save_data and ipsum.autosave_min_interval is None
            # Create or update the corrispondent IPSUMLastPower.
            # In defaults there are the new values, outside the filters
            ipsum_lastpower, _created = IPSUMLastPower.objects.update_or_create(
                ipsumdevice=ipsum,
                defaults={
                    'powers': values,
                    'timestamp': datetime.datetime.now(pytz.UTC),
                    'already_saved': save_now_flag,
                }
            )
            # New information in the IPSUMDevice
            ipsum.software_version = software_version
            # Save IPSUMDevice
            ipsum.save()
            # Immediate Save on the powertable if autosave is None
            if save_now_flag:
                newpt = IPSUMPowerTable(
                    ipsumdevice=ipsum,
                    timestamp=ipsum_lastpower.timestamp,
                    powers=ipsum_lastpower.powers,
                    extra=ipsum_lastpower.extra,
                )
                newpt.save()
        # If the Ipsum is associated with a park without ipsum_send_time, send the data to that
        for conf in ipsum.linked_parks.filter(postponed_send_timing__isnull=True):
            send_single_ipsum_lastpower.delay(conf.park_id)
    else:
        raise Exception(f"Received post_ipsum_bytecode with unrecognized protocol_version {protocol_version}")


@shared_task(ignore_result=True, store_errors_even_if_ignored=True)
def send_single_ipsum_lastpower(park_id):
    try:
        conf = ParkIpsumConf.objects.get(pk=park_id)
    except ParkIpsumConf.DoesNotExist:
        raise
    # Expected to use for parks without ipsum_send_time
    datetime_now = datetime.datetime.now(pytz.UTC)
    if conf.avalpower_formula_2 != "" or conf.avalpower_formula_3 != "":
        encoded_message = encode_bytecode_parkipsumconf_v2(conf)
    else:
        encoded_message = encode_bytecode_parkipsumconf_v1(conf)
    if encoded_message.decode() == conf.last_message_sent:
        raise ValueError(f"Message {encoded_message} already sent to park id {park_id}")
    # Pre v1 ChargingStations
    try:
        connection = pika.BlockingConnection(
            pika.connection.URLParameters(settings.LEGACY_PILOTAGE_BROKER_URL)
        )
        channel = connection.channel()
        channel.basic_publish(
            exchange="chargingstation",
            routing_key="CS_{}".format(conf.park.name),
            body=bytes("is ", 'ascii') + encoded_message,
        )
        channel.close()
        connection.close()
    except AMQPError:
        # TODO manage error here
        raise
    # v2 ChargingStations
    try:
        connection = pika.BlockingConnection(
            pika.connection.URLParameters(settings.PILOTAGE_BROKER_URL)
        )
        channel = connection.channel()
        channel.basic_publish(
            exchange="amq.topic",
            routing_key="CS_{}".format(conf.park.name),
            body=bytes("is ", 'ascii') + encoded_message,
        )
        channel.close()
        connection.close()
    except AMQPError:
        # TODO manage error here
        raise
    conf.last_message_sent = encoded_message.decode()
    conf.last_send_timestamp = datetime_now
    conf.save(update_fields=['last_message_sent', 'last_send_timestamp'])


def send_ipsum_lastpower_table():
    datetime_now = datetime.datetime.now(pytz.UTC)
    conf_to_update = ParkIpsumConf.objects.all().annotate(
        elapsed=ExpressionWrapper(
            Coalesce(datetime_now - F('last_send_timestamp'),
                     F('postponed_send_timing') + datetime.timedelta(seconds=1)),
            output_field=DurationField())
    ).filter(elapsed__gt=F('postponed_send_timing'))
    errors = 0
    park_id_with_error = []
    for conf in conf_to_update:
        try:
            if conf.avalpower_formula_2 != "" or conf.avalpower_formula_3 != "":
                encoded_message = encode_bytecode_parkipsumconf_v2(conf)
            else:
                encoded_message = encode_bytecode_parkipsumconf_v1(conf)
        except ValueError as _exc:
            # logger.warning(f"Error during ipsum send for park {park.name}: \"{exc.args[0]}\"")
            park_id_with_error.append(conf.park_id)
            continue
        if encoded_message.decode() == conf.last_message_sent:
            park_id_with_error.append(conf.park_id)
            continue
        # Pre v1 ChargingStations
        try:
            connection = pika.BlockingConnection(
                pika.connection.URLParameters(settings.LEGACY_PILOTAGE_BROKER_URL)
            )
            channel = connection.channel()
            channel.basic_publish(
                exchange="chargingstation",
                routing_key="CS_{}".format(conf.park.name),
                body=bytes("is ", 'ascii') + encoded_message,
            )
            channel.close()
            connection.close()
        except AMQPError as exc:
            logger.error("AMQPError during publish.", exc_info=exc)
            errors += 1
            continue
        # v2 ChargingStations
        try:
            connection = pika.BlockingConnection(
                pika.connection.URLParameters(settings.PILOTAGE_BROKER_URL)
            )
            channel = connection.channel()
            channel.basic_publish(
                exchange="amq.topic",
                routing_key="CS_{}".format(conf.park.name),
                body=bytes("is ", 'ascii') + encoded_message,
            )
            channel.close()
            connection.close()
        except AMQPError as exc:
            logger.error("AMQPError during publish.", exc_info=exc)
            errors += 1
            continue
        conf.last_message_sent = encoded_message.decode()
        conf.save(update_fields=['last_message_sent'])
    conf_to_update.exclude(park_id__in=park_id_with_error).update(last_send_timestamp=datetime_now)
    if errors != 0:
        raise Exception(f"publish errors: {errors}")
