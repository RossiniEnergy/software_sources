import logging
import stripe
from django.conf import settings

from re_restapi.models import PaymentOrder

logger = logging.getLogger("re.libs.payment_utils")

stripe.api_key = settings.STRIPE_PRIVATE_KEY


def cancel_payment_order(payord: PaymentOrder):
    logger.debug("Call to cancel_payment_order")
    if payord.capture_status != "":
        logger.warning(f"We can't cancel the payment id {payord.id} already captured with "
                       "status \"{payord.capture_status}\"")
        # FIXME: Raise exception
        return payord
    # noinspection PyTypeChecker
    response = stripe.PaymentIntent.cancel(payord.imprint_id)
    if response.status == "canceled":
        payord.phase = 0  # Flag as Cancelled
        payord.energy_cents = 0
        payord.stripe_comm_cents = 0
        payord.rossen_comm_cents = 0
        payord.capture_status = response.status
        payord.save()
        logger.info(f"Correclty cancelled the PaymentOrder id {payord.id}")
    else:
        logger.error(f"Error trying to cancel the PaymentOrder id {payord.id} with return status \"{response.status}\"")
    return payord
