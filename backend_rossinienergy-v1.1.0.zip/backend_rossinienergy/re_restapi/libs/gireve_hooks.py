from celery import shared_task

from re_restapi.libs.gireve_utils import update_gireve_status, push_cdr_gireve


@shared_task(bind=True, max_retries=96)
def hook_update_gireve_status(self, cs_bnum):
    try:
        update_gireve_status(cs_bnum)
    except Exception as exc:
        self.retry(exc=exc, countdown=900)  # 15 minutes retry for total 96 (24 hours) tries


@shared_task(bind=True, max_retries=96)
def hook_push_cdr_gireve(self, charge_id):
    try:
        push_cdr_gireve(charge_id)
    except Exception as exc:
        self.retry(exc=exc, countdown=900)  # 15 minutes retry for total 96 (24 hours) tries
