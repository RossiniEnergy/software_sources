from rest_framework import serializers
from django.db import transaction

from re_restapi.models import \
    Park, ChargingStation, Charge, PaymentOrder, ChargingStationPowerTable, ChargingStationLastPower

__all__ = ['ResizetoOutputSerializer', 'shrink_park', 'dilate_park']


# noinspection PyAbstractClass
class ResizetoOutputSerializer(serializers.Serializer):
    chargingstation_created = serializers.IntegerField(default=0)
    chargingstation_deleted = serializers.IntegerField(default=0)
    power_deleted = serializers.IntegerField(default=0)
    charge_deleted = serializers.IntegerField(default=0)
    paymentorder_deleted = serializers.IntegerField(default=0)
    dry_run = serializers.BooleanField()


def shrink_park(park: Park, new_size: int, dry_run=True) -> ResizetoOutputSerializer:
    old_size = park.chargingstation_set.count()
    assert new_size < old_size
    # Shrink
    cs_to_delete = park.chargingstation_set.filter(park_bnum__gt=new_size)
    power_to_delete = ChargingStationPowerTable.objects.filter(chargingstation__in=cs_to_delete)
    charge_to_delete = Charge.objects.filter(chargingstation__in=cs_to_delete)
    po_to_delete = PaymentOrder.objects.filter(chargingstation__in=cs_to_delete)
    lastpower_to_delete = ChargingStationLastPower.objects.filter(chargingstation__in=cs_to_delete)
    # FIXME: Controlla se il delete dei CS pulisce automaticamente i many_to_many associati (authorized_cs per ChargeF)
    shrinkserializer = ResizetoOutputSerializer(data={
        'dry_run': dry_run,
        'chargingstation_deleted': cs_to_delete.count(),
        'power_deleted': power_to_delete.count(),
        'charge_deleted': charge_to_delete.count(),
        'paymentorder_deleted': po_to_delete.count(),
    })
    shrinkserializer.is_valid(raise_exception=True)
    if not dry_run:
        with transaction.atomic():
            po_to_delete.delete()
            charge_to_delete.delete()
            lastpower_to_delete.delete()
            power_to_delete.delete()
            cs_to_delete.delete()
    return shrinkserializer


def dilate_park(park: Park, new_size: int, dry_run=True) -> ResizetoOutputSerializer:
    old_size = park.chargingstation_set.count()
    assert new_size > old_size
    with transaction.atomic():
        for i in range(new_size - old_size):
            if not dry_run:
                _new_cs = ChargingStation.objects.create(
                    park=park,
                    park_bnum=park.chargingstation_set.count() + 1,
                )
    dilateserializer = ResizetoOutputSerializer(data={
        'dry_run': dry_run,
        'chargingstation_created': new_size - old_size,
    })
    dilateserializer.is_valid(raise_exception=True)
    return dilateserializer
