from .chargingstation import *
from .usersystem.user import *
from django.db import models

__all__ = ['PaymentOrder']


class PaymentOrder(models.Model):
    PHASES = [
        (0, 'cancelled'),
        (1, 'imprinted'),
        (2, 'confirmed'),
        (3, 'captured'),
    ]
    chargingstation = models.ForeignKey(ChargingStation, on_delete=models.PROTECT)
    user = models.OneToOneField(User, on_delete=models.PROTECT, null=True, default=None)
    confirm_timestamp = models.DateTimeField(null=True, default=None)
    phase = models.IntegerField(choices=PHASES)
    imprint_id = models.CharField(max_length=100)
    imprinted_cents = models.IntegerField()
    energy_cents = models.IntegerField(default=0)
    stripe_comm_cents = models.IntegerField(default=0)
    rossen_comm_cents = models.IntegerField(default=0)
    capture_status = models.CharField(max_length=30, blank=True)
    last_updated = models.DateTimeField(auto_now=True)
    fingerprint = models.CharField(max_length=30, blank=True, default="")
    last4 = models.CharField(max_length=4, blank=True, default="")
    exp_month = models.CharField(max_length=2, blank=True, default="")
    exp_year = models.CharField(max_length=4, blank=True, default="")
