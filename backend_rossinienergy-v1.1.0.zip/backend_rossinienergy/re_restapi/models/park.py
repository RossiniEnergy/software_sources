from django.db import models
import datetime
from django.utils import timezone
from django.core.exceptions import ValidationError
from django.core.serializers.json import DjangoJSONEncoder

__all__ = ['Park', 'BuildingInfosLastPower', 'BuildingInfosPowerTable']


CUSTOM_MESSAGE_LANGS = {'it', 'en', 'de', 'fr', 'nl'}


def validate_langs(value: str):
    if value not in CUSTOM_MESSAGE_LANGS:
        raise ValidationError(f"The language f{value} is invalid")


def validate_phrases_languages(value: dict):
    invalid_lang = value.keys() - CUSTOM_MESSAGE_LANGS
    if invalid_lang:
        raise ValidationError(f"The languages f{', '.join(invalid_lang)} are invalid")


class Park(models.Model):
    name = models.CharField(max_length=256, unique=True)
    teamviewerid = models.IntegerField(default=-1)
    anydeskid = models.IntegerField(default=-1)
    email = models.EmailField(blank=True, default="")
    email_report = models.BooleanField(default=False)
    creation_date = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(auto_now=True)
    accept_gireve = models.BooleanField(default=False)
    software_version = models.CharField(max_length=20, blank=True, default="")
    installed = models.BooleanField(default=False)
    advenir_user_id = models.CharField(max_length=40, default='91e7d39d-59b4-44f2-854e-19472e63832b')
    show_phrases_frontend = models.BooleanField(default=True)
    note = models.TextField(blank=True, default="")
    address = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=10)
    city = models.CharField(max_length=50)
    country_alpha2 = models.CharField(max_length=2)
    latitude = models.DecimalField(max_digits=10, decimal_places=7)
    longitude = models.DecimalField(max_digits=10, decimal_places=7)
    save_data = models.BooleanField(default=True)
    # min time required after a save to do another save in the database (None = realtime save) ignored if no save data
    autosave_min_interval = models.DurationField(null=True, default=None)  # save_min_delay
    # time required to be passed for a data point in the powertable to be deleted (None = don't drop)
    autodrop_max_interval = models.DurationField(null=True, default=datetime.timedelta(days=180))  # drop_max_delay
    show_custom_message = models.BooleanField(default=False)
    custom_message = models.JSONField(encoder=DjangoJSONEncoder, default=lambda: dict(en=""),
                                      validators=[validate_phrases_languages])
    custom_message_fallback_lang = models.CharField(max_length=2, validators=[validate_langs], default='en')


class BuildingInfosLastPower(models.Model):
    park = models.OneToOneField(
        Park, on_delete=models.PROTECT, primary_key=True
    )
    timestamp = models.DateTimeField(default=timezone.now)
    production = models.IntegerField(default=0)
    consumption = models.IntegerField(default=0)
    available_power = models.IntegerField(default=0)
    already_saved = models.BooleanField(default=False)
    last_save_timestamp = models.DateTimeField(auto_now_add=True)


class BuildingInfosPowerTable(models.Model):
    park = models.ForeignKey(Park, on_delete=models.PROTECT)
    timestamp = models.DateTimeField()
    production = models.IntegerField(default=0)
    consumption = models.IntegerField(default=0)
    available_power = models.IntegerField(default=0)
