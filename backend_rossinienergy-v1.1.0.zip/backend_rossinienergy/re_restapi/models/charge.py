from .chargingstation import *
from .usersystem.user import *
from django.db import models

__all__ = ['Charge']


class Charge(models.Model):
    chargingstation = models.ForeignKey(
        ChargingStation, on_delete=models.PROTECT
    )
    start = models.DateTimeField()
    stop = models.DateTimeField(null=True)
    user = models.ForeignKey(User, on_delete=models.PROTECT)
    last_nonzero_power_time = models.DateTimeField(null=True, default=None)
    energy_wh = models.IntegerField(default=0)
