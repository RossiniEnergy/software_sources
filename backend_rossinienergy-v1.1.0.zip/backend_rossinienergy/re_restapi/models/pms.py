from .park import *
from django.db import models

__all__ = ['PMS', 'PMSPendingRequest']


# PMS - Hotel Management Software
class PMS(models.Model):
    name = models.CharField(max_length=30)
    abbrev = models.CharField(max_length=10, unique=True)


class PMSPendingRequest(models.Model):
    label = models.CharField(max_length=50)
    authorized_parks = models.ManyToManyField(Park)
    registration_token = models.CharField(max_length=24, unique=True)
    pms = models.ForeignKey(PMS, on_delete=models.PROTECT)
