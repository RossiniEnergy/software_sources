from django.db import models

__all__ = ['NewComer']


class NewComer(models.Model):
    name = models.CharField(max_length=256)
    teamviewerid = models.CharField(max_length=256, default="-1")
    anydeskid = models.CharField(max_length=256, default="-1")
    time = models.DateTimeField()
