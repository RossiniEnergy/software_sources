from django.db import models

__all__ = ['MoneyDestination']


class MoneyDestination(models.Model):
    society_name = models.CharField(max_length=50)
    email = models.EmailField(blank=True)
    stripe_id = models.CharField(max_length=100)
    address_1 = models.CharField(max_length=50)
    address_2 = models.CharField(max_length=50)
    postal_code = models.CharField(max_length=10)
    city = models.CharField(max_length=50)
    country_alpha2 = models.CharField(max_length=2, blank=True, default="")
    vat_country_alpha2 = models.CharField(max_length=2)
    phone_number = models.CharField(max_length=20)
    LANGUAGES = [
        ('en', 'English'),
        ('it', 'Italiano'),
        ('fr', 'Français'),
    ]
    receipt_language = models.CharField(max_length=2, choices=LANGUAGES, default='en')
