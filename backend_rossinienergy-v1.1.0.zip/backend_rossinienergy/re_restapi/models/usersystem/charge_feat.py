from django.db import models
import pgtrigger
from .user import *
from ..chargingstation import *

__all__ = ['ChargeFeature']


class ChargeFeature(models.Model):
    user = models.OneToOneField(User, on_delete=models.PROTECT, primary_key=True)
    authorized_cs = models.ManyToManyField(ChargingStation, blank=True, related_name='explicitly_authorized_users')

    @property
    def chargingstation_allowed(self) -> list[ChargingStation]:
        # Special case for administrators
        if self.user.is_superuser or self.user.is_staff:
            user_authorized_cs = list(ChargingStation.objects.all())
        else:
            # Explicit Authorization Bnum List
            user_authorized_cs = list(self.authorized_cs.distinct().all())
            # Take admin's managed parks as authorized
            for admin in self.user.admin_users.all():
                for park in admin.managed_parks.all():
                    user_authorized_cs.extend(list(park.chargingstation_set.all()))
            # Remove duplications
            user_authorized_cs = list(set(user_authorized_cs))
        # Parkadmin Feature Integration
        if self.user.has_parkadmin_feat:
            # Managed Park Bnum List
            for park in self.user.parkadminfeature.managed_parks.all():
                user_authorized_cs.extend(list(park.chargingstation_set.all()))
        # Remove duplications
        user_authorized_cs = list(set(user_authorized_cs))
        return user_authorized_cs

    class Meta:
        triggers = [
            pgtrigger.Trigger(
                name='charge_feat_flag_insert',
                operation=pgtrigger.Insert,
                when=pgtrigger.After,
                func='UPDATE re_restapi_user SET has_charge_feat = TRUE WHERE id = NEW.user_id; RETURN NULL;',
            ),
            pgtrigger.Trigger(
                name='charge_feat_flag_delete',
                operation=pgtrigger.Delete,
                when=pgtrigger.After,
                func='UPDATE re_restapi_user SET has_charge_feat = FALSE WHERE id = OLD.user_id; RETURN NULL;'
            ),
        ]
