from django.db import models
import pgtrigger
from ..pms import PMS
from ..park import Park
from .user import User

__all__ = ['PMSAdminFeature']


class PMSAdminFeature(models.Model):
    user = models.OneToOneField(User, on_delete=models.PROTECT, primary_key=True)
    label = models.CharField(max_length=50)
    pms = models.ForeignKey(PMS, on_delete=models.PROTECT)
    pms_managed_parks = models.ManyToManyField(Park, blank=True, related_name='pms_admins')

    class Meta:
        triggers = [
            pgtrigger.Trigger(
                name='pmsadmin_feat_flag_insert',
                operation=pgtrigger.Insert,
                when=pgtrigger.After,
                func='UPDATE re_restapi_user SET has_pmsadmin_feat = TRUE WHERE id = NEW.user_id; RETURN NULL;',
            ),
            pgtrigger.Trigger(
                name='pmsadmin_feat_flag_delete',
                operation=pgtrigger.Delete,
                when=pgtrigger.After,
                func='UPDATE re_restapi_user SET has_pmsadmin_feat = FALSE WHERE id = OLD.user_id; RETURN NULL;'
            ),
        ]
