from django.db import models

__all__ = ['Logo']


class Logo(models.Model):
    static_file_tag = models.CharField(max_length=50)

    @property
    def static_final_url(self):
        from django.templatetags.static import static
        return static(self.static_file_tag)
