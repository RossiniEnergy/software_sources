from .park import *
from django.db import models
from django.contrib.postgres.fields import ArrayField
from django.core.serializers.json import DjangoJSONEncoder
from django.utils import timezone
import datetime

__all__ = ['IPSUMDevice', 'IPSUMLastPower', 'IPSUMPowerTable', 'ParkIpsumConf']


# IPSUM API (the new old scatolino)
class IPSUMDevice(models.Model):
    token = models.CharField(max_length=20, unique=True)
    alias = models.CharField(max_length=50, unique=True)
    save_data = models.BooleanField(default=True)
    # min time required after a save to do another save in the database (None = realtime save) ignored if no save data
    autosave_min_interval = models.DurationField(null=True, default=None)  # save_min_delay
    # time required to be passed for a data point in the powertable to be deleted (None = don't drop)
    autodrop_max_interval = models.DurationField(null=True, default=datetime.timedelta(days=180))  # drop_max_delay
    expected_clamps = models.IntegerField()  # used only to check validity of available_power_query
    software_version = models.CharField(max_length=20, blank=True, default="", editable=False)
    note = models.TextField(blank=True, default="")


class IPSUMLastPower(models.Model):
    ipsumdevice = models.OneToOneField(IPSUMDevice, on_delete=models.PROTECT, primary_key=True)
    timestamp = models.DateTimeField(default=timezone.now)
    powers = ArrayField(models.IntegerField(blank=True, null=True), default=list)
    already_saved = models.BooleanField(default=False)
    last_save_timestamp = models.DateTimeField(auto_now_add=True)
    extra = models.JSONField(encoder=DjangoJSONEncoder, default=dict)


class IPSUMPowerTable(models.Model):
    ipsumdevice = models.ForeignKey(IPSUMDevice, on_delete=models.PROTECT)
    timestamp = models.DateTimeField()
    powers = ArrayField(models.IntegerField(blank=True, null=True), default=list)
    extra = models.JSONField(encoder=DjangoJSONEncoder, default=dict)


# Relation used to link a Park to their Ipsum and give the information required for the data dispatch
class ParkIpsumConf(models.Model):
    park = models.OneToOneField(Park, on_delete=models.PROTECT, primary_key=True)
    linked_ipsums = models.ManyToManyField(IPSUMDevice, related_name='linked_parks')
    avalpower_formula_1 = models.CharField(max_length=400)
    avalpower_formula_2 = models.CharField(max_length=400, blank=True, default="")
    avalpower_formula_3 = models.CharField(max_length=400, blank=True, default="")
    # Min time to wait between data send to park. (None = send in real time when a related ipsum is updated)
    postponed_send_timing = models.DurationField(null=True, default=datetime.timedelta(seconds=5))  # ipsum_send_time
    last_send_timestamp = models.DateTimeField(null=True, default=None, editable=False)
    last_message_sent = models.CharField(max_length=30, blank=True, default="")  # ipsum_last_message
