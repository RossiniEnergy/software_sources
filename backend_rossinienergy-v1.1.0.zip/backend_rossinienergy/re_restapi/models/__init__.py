# Remember to register new models file here!
from .charge import *
from .chargingstation import *
from .custompanels import *
from .frontend import *
from .ipsum import *
from .moneydestination import *
from .newcomer import *
from .park import *
from .paymentorder import *
from .pms import *
from .usersystem import *
