from django.http import HttpResponseForbidden, JsonResponse

from re_restapi.views.custom.legacy import kiloutou, franceparebrise


def get_custom_permissiontable(request):
    """Get a request from a User and return a JSON {"name custom": "URL"} for every custom panel that user has access"""
    if not request.user.is_authenticated:
        return HttpResponseForbidden("User not authenticated")
    output = {}
    # List of Custom Panels. They're to be registered here manually.
    if franceparebrise.check_user_permission(request.user):
        output["France Pare-Brise"] = "https://example.com"
    if kiloutou.check_user_permission(request.user):
        output["Kiloutou"] = "https://example.com"
    # Finalize and reply
    return JsonResponse(output)
