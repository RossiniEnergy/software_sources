from rest_framework import mixins
from rest_framework.pagination import LimitOffsetPagination
from django_filters import rest_framework as filters

from re_restapi.libs.permissionviewset import *
from re_restapi.filtersets.internal.current.buildinginfos import BuildingInfosPowerTableFilterSet
from re_restapi.serializers.current.buildinginfos import BuildingInfosPowerTableSerializer
from re_restapi.models import BuildingInfosPowerTable


class ParkadminBuildingInfosPagination(LimitOffsetPagination):
    default_limit = 1000
    max_limit = 10000


class ParkadminBuildingInfosViewSet(mixins.ListModelMixin,
                                    mixins.RetrieveModelMixin,
                                    PermissionGenericViewSet):
    serializer_class = BuildingInfosPowerTableSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = BuildingInfosPowerTableFilterSet
    pagination_class = ParkadminBuildingInfosPagination
    permission_classes = [IsAuthenticatedNotExpired, IsParkAdmin]

    def get_queryset(self):
        queryparam_reversed = bool(int(self.request.query_params.get('reversed', 0)))
        queryset = BuildingInfosPowerTable.objects.filter(park__admin_users=self.request.user.parkadminfeature) \
            .order_by("id").distinct()
        if queryparam_reversed:
            queryset = queryset.reverse()
        return queryset
