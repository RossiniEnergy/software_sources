from rest_framework import mixins
from django_filters import rest_framework as filters

from re_restapi.libs.permissionviewset import *
from re_restapi.models import Park
from re_restapi.serializers.v1.park import PublicParkSerializer
from re_restapi.filtersets.public.v1.park import PublicParkFilterSet


class PublicParkViewSet(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    PermissionGenericViewSet
):
    queryset = Park.objects.order_by("id")
    serializer_class = PublicParkSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = PublicParkFilterSet
    permission_classes = [AllowAny]
