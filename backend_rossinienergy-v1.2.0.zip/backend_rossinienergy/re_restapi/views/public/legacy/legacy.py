from rest_framework import serializers, status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from drf_spectacular.utils import extend_schema, inline_serializer
from re_restapi.libs.permissionviewset import *
from re_restapi.serializers.legacy.user import LegacyUserSerializer
from re_restapi.models import User


@extend_schema(responses=inline_serializer(name='LegacyChargePermissions', fields={
    'authorized_qrcode': serializers.ListField(child=serializers.IntegerField(), allow_empty=True),
}))
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def retrieve_user_charge_permissions(request, user_id: int):
    if request.user.pk != user_id:
        return Response("This is not the logged user id", status=status.HTTP_403_FORBIDDEN)
    try:
        instance = User.objects.get(pk=user_id)
    except User.DoesNotExist:
        return Response("Unknown user_id", status=status.HTTP_404_NOT_FOUND)
    if instance.has_charge_feat:
        result = [cs.qrcodeid for cs in instance.chargefeature.chargingstation_allowed 
                  if cs.qrcodeid is not None]
    else:
        result = []
    return Response({'authorized_qrcode': result})


@extend_schema(responses=LegacyUserSerializer)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def legacy_myself(request):
    user = request.user
    serialized_user = LegacyUserSerializer(user)
    return Response(serialized_user.data)
