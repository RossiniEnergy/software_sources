import binascii
import logging
import json

from django.views.decorators.csrf import csrf_exempt
from django.core.exceptions import MultipleObjectsReturned, ObjectDoesNotExist
from django.http import HttpResponse, JsonResponse
from rest_framework import status

from re_restapi.libs.ipsum import encode_bytecode_parkipsumconf_v2, encode_bytecode_parkipsumconf_v1
from re_restapi.libs.postpower import task_post_power_legacy, task_post_power_bytecode
from re_restapi.models import Charge, ChargingStation, Park

logger = logging.getLogger('re.views.legacy.raspberry')


@csrf_exempt
def get_is_charging(_request, bnum):
    logger.debug(f"Call to get_is_charging for bnum {bnum}")
    last_charge = (
        Charge.objects.filter(chargingstation_id=bnum).order_by("-id").first()
    )
    if last_charge is None:
        result = False
    else:
        result = last_charge.stop is None
    ret_val = json.dumps({"ischarging": result})
    return HttpResponse(ret_val)


@csrf_exempt
def get_cs_id_list(_request, park_name):
    try:
        park = Park.objects.get(name=park_name)
    except (MultipleObjectsReturned, ObjectDoesNotExist):
        logger.debug(f"Failed to retrieve the park {park_name}")
        return HttpResponse(status=400)
    cs_query = ChargingStation.objects.filter(park=park).order_by("park_bnum").values_list("bnum", flat=True)
    ret_val = {"cs_id_list": list(cs_query)}
    return HttpResponse(json.dumps(ret_val))


@csrf_exempt
def post_power_bytecode(request, park_name):
    coded_data = binascii.b2a_base64(request.body)
    task_post_power_bytecode.delay(coded_data.decode(), park_name)
    return HttpResponse()


@csrf_exempt
def post_power_legacy(request):
    data = json.loads(request.body)
    task_post_power_legacy.delay(data)
    return HttpResponse()


@csrf_exempt
def manual_retrieve_ipsum(_request, park_name):
    # Manual Pull API for raspberry to take in one swipe all the ipsum of their park.
    try:
        park = Park.objects.get(name=park_name)
    except Park.DoesNotExist:
        return HttpResponse("Park doesn't exist", status=status.HTTP_404_NOT_FOUND)
    if not hasattr(park, 'parkipsumconf'):
        return HttpResponse("Park doesn't have ParkIpsumConf", status=status.HTTP_400_BAD_REQUEST)
    conf = park.parkipsumconf
    # noinspection PyBroadException
    try:
        if conf.avalpower_formula_2 != "" or conf.avalpower_formula_3 != "":
            value = encode_bytecode_parkipsumconf_v2(conf).decode()
        else:
            value = encode_bytecode_parkipsumconf_v1(conf).decode()
    except Exception as ex:
        return HttpResponse(ex.args[0], status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    output = {'available_power': value}
    return JsonResponse(output)
