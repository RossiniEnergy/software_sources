import stripe
import stripe.error
import logging

from django.conf import settings
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework import status

from re_restapi.libs.stripewebhook import handle_stripe_webhook

stripe.api_key = settings.STRIPE_PRIVATE_KEY

logger = logging.getLogger('re.views.legacy.stripewebhook')


@csrf_exempt
def stripe_webhook(request):
    payload = request.body
    sig_header = request.headers['STRIPE_SIGNATURE']
    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, settings.STRIPE_WEBHOOK_ENDPOINT_SECRET
        )
    except ValueError as e:
        # Invalid payload
        logger.warning("Received Stripe Webhook with invalid payload")
        return HttpResponse(status=status.HTTP_400_BAD_REQUEST)
    except stripe.error.SignatureVerificationError as e:
        # Invalid signature
        logger.warning("Received Stripe Webhook with invalid signature")
        return HttpResponse(status=status.HTTP_400_BAD_REQUEST)

    # Handle the event
    if event['type'] == 'account.updated':
        _account = event['data']['object']
        handle_stripe_webhook.delay(event)
    elif event['type'] == 'account.external_account.updated':
        _external_account = event['data']['object']
        handle_stripe_webhook.delay(event)
    elif event['type'] == 'capability.updated':
        _capability = event['data']['object']
        handle_stripe_webhook.delay(event)

    return JsonResponse({'success': True}, status=status.HTTP_200_OK)
