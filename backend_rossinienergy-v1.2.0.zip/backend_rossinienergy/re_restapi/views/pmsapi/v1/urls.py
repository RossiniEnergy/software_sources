from django.urls import path, include
from rest_framework import routers
from rest_framework_nested import routers as nested_routers  # https://github.com/alanjds/drf-nested-routers

from .common import PMSAPIView, PMSChargeController, PMSSubUserView, pms_initialize_token_api

router = routers.DefaultRouter()
router.register(r'pms', PMSAPIView, basename='pmsapi_v1_pms')
nested_pms_router = nested_routers.NestedDefaultRouter(router, r"pms", lookup="pms")
nested_pms_router.register(f'users', PMSSubUserView, basename='pmsapi_v1_pms_n_subuser')
nested_pms_router.register(f'chargecontroller', PMSChargeController, basename='pmsapi_v1_pms_n_chargecontroller')

urlpatterns = [
    path("", include(router.urls)),
    path("", include(nested_pms_router.urls)),
    path("pms/<str:pms_abbrev>/initialize_token/<str:tmp_token>", pms_initialize_token_api,
         name='pmsapi_v1_inittoken'),
]
