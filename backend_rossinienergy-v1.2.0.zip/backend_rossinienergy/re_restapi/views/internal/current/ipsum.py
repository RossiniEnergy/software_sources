from rest_framework import mixins, status
from rest_framework.response import Response
from rest_framework.decorators import action
from drf_spectacular.utils import extend_schema
from django_filters import rest_framework as filters

from re_restapi.libs.permissionviewset import *
from re_restapi.serializers.current.ipsumdevice import IPSUMDeviceSerializer
from re_restapi.serializers.current.ipsumpower import IPSUMLastPowerSerializer
from re_restapi.filtersets.internal.current.ipsum import IPSUMDeviceFilterSet
from re_restapi.models import IPSUMDevice


class IPSUMDeviceViewSet(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.CreateModelMixin,
    mixins.UpdateModelMixin,
    PermissionGenericViewSet
):
    queryset = IPSUMDevice.objects.order_by('id')
    serializer_class = IPSUMDeviceSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = IPSUMDeviceFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser]

    @extend_schema(responses=IPSUMLastPowerSerializer)
    @action(detail=True, methods=['get'])
    def lastpower(self, request, pk=None):
        ipsum = self.get_object()
        if hasattr(ipsum, 'ipsumlastpower'):
            lp = ipsum.ipsumlastpower
        else:
            return Response("nodata", status=status.HTTP_404_NOT_FOUND)
        serialized_lp = IPSUMLastPowerSerializer(lp)
        return Response(serialized_lp.data)
