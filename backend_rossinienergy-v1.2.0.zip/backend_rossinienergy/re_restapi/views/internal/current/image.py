from rest_framework import mixins, viewsets, status
from rest_framework.response import Response
from rest_framework.settings import api_settings
# from django_filters import rest_framework as filters
from drf_spectacular.utils import extend_schema
from drf_spectacular.types import OpenApiTypes

from re_restapi.models import MediaImage
from re_restapi.serializers.current.image import MediaImageSerializer, MediaImageNoImageSerializer
from re_restapi.libs.permissionviewset import *


# noinspection PyMethodMayBeStatic
class MediaImageViewSet(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.DestroyModelMixin,
    viewsets.GenericViewSet,
):
    queryset = MediaImage.objects.order_by('id')
    serializer_class = MediaImageNoImageSerializer
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser]

    @extend_schema(request=MediaImageSerializer)
    def create(self, request, *args, **kwargs):
        serializer = MediaImageSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def perform_create(self, serializer):
        serializer.save()

    def get_success_headers(self, data):
        try:
            return {'Location': str(data[api_settings.URL_FIELD_NAME])}
        except (TypeError, KeyError):
            return {}

    def perform_destroy(self, instance):
        instance.image_file.delete(save=False)  # We don't want to save the instance as "without file"
        instance.delete()  # because we will simply delete it immediately after.
