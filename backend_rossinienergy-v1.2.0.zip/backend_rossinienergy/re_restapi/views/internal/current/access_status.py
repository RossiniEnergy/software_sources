from django.db import connection
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from drf_spectacular.utils import extend_schema
from re_restapi.libs.permissionviewset import *
from re_restapi.serializers.current.access_status import AccessStatusParkSerializer


@extend_schema(responses=AccessStatusParkSerializer(many=True))
@api_view(['GET'])
@permission_classes([IsAuthenticatedNotExpired, IsAdminUser])
def access_status_raw(request):
    with connection.cursor() as cursor:
        cursor.execute("""
SELECT
  rrp.id,
  rrp."name",
  rrp.installed,
  COALESCE(NOW() - rrclp."timestamp" < INTERVAL '1 hour', FALSE) "online"
FROM re_restapi_park rrp, re_restapi_chargingstation rrc LEFT JOIN re_restapi_chargingstationlastpower rrclp ON rrc.bnum = rrclp.chargingstation_id
WHERE rrp.id = rrc.park_id AND rrc.park_bnum = 1
ORDER BY LOWER(rrp."name")
        """)
        columns = [col[0] for col in cursor.description]
        data = [dict(zip(columns, row)) for row in cursor.fetchall()]
    serialized_data = AccessStatusParkSerializer(data, many=True)
    return Response(serialized_data.data)
