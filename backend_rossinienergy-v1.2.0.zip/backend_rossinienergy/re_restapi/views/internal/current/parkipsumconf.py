from rest_framework import mixins
from django_filters import rest_framework as filters

from re_restapi.libs.permissionviewset import *
from re_restapi.serializers.current.parkipsumconf import ParkIpsumConfSerializer
from re_restapi.filtersets.internal.current.parkipsumconf import ParkIpsumConfFilterSet
from re_restapi.models import ParkIpsumConf


class ParkIpsumConfView(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    mixins.CreateModelMixin,
    mixins.DestroyModelMixin,
    PermissionGenericViewSet
):
    queryset = ParkIpsumConf.objects.order_by('park_id')
    serializer_class = ParkIpsumConfSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = ParkIpsumConfFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser]
