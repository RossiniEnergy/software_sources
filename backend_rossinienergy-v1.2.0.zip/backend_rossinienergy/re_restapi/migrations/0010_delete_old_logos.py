from django.db import migrations


# noinspection PyPep8Naming
def delete_old_logos(apps, schema_editor):
    Logo = apps.get_model('re_restapi', 'Logo')
    for lo in Logo.objects.order_by('id'):
        print(f"{lo.id} - {lo.static_file_tag} - {[cs.bnum for cs in lo.chargingstation_set.all()]}")
        for cs in lo.chargingstation_set.all():
            cs.override_logo = None
            cs.save()
    Logo.objects.all().delete()


class Migration(migrations.Migration):

    dependencies = [
        ('re_restapi', '0009_media_image'),
    ]

    operations = [
        migrations.RunPython(delete_old_logos, reverse_code=migrations.RunPython.noop),
    ]
