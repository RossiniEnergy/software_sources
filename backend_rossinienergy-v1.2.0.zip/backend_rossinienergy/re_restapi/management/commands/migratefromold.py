import os
import datetime
import logging
from django.core import management
from django.core.management.base import BaseCommand
from django import db
import psycopg2
import psycopg2.errors
from uuid import uuid4
from sshtunnel import SSHTunnelForwarder

from re_restapi.models import *

logger = logging.getLogger('re.command.migratefromold')


class Command(BaseCommand):
    help = "Migrate from the given command line parameter (sql string and ssh tunnel params) the data in our new DB"

    def handle(self, *args, **options):
        # TODO: Create read transaction on production to prevent the data get modified between SELECT queries
        if bool(int(os.environ['USE_SSHTUNNEL'])):
            print("Opening SSH tunnel to target server")
            server = SSHTunnelForwarder(
                os.environ['SSHTUNNEL_HOST'],
                ssh_username=os.environ['SSHTUNNEL_USER'],
                ssh_pkey=os.environ['SSHTUNNEL_PKEY'],
                remote_bind_address=(
                    os.environ['SSHTUNNEL_REMOTEBIND_HOST'],
                    int(os.environ['SSHTUNNEL_RREMOTEBIND_PORT'])
                ),
                local_bind_address=(
                    os.environ['SSHTUNNEL_LOCALBIND_HOST'],
                    int(os.environ['SSHTUNNEL_LOCALBIND_PORT'])
                ),
            )
            server.start()
        print("Opening SQL connection to production database")
        old_conn = psycopg2.connect(
            host=os.environ['OLDDBHOST'],
            port=int(os.environ['OLDDBPORT']),
            database=os.environ['OLDDBNAME'],
            user=os.environ['OLDDBUSER'],
            password=os.environ['OLDDBPASSWORD'])
        # Start migration
        print("Starting migration")
        oldcursor = old_conn.cursor()
        newcursor = db.connection.cursor()
        # Reset Database Status (cannot use on production because apiaccess doesnt own the schema)
        if bool(int(os.environ.get('DUMP_OLD_DB', 1))):
            print("Resetting target db to post-django migration state... ", end='')
            newcursor.execute(
                "DROP SCHEMA IF EXISTS public CASCADE;"
                "CREATE SCHEMA IF NOT EXISTS public;"
            )
            print("ok")
        management.call_command("migrate")
        # This refresh the status of Django to match the actual DB after manual queries
        # Remember that we DONT do this after every sequence update, so don't trust them!
        db.close_old_connections()
        newcursor = db.connection.cursor()
        # with transaction.atomic():
        # NEWCOMER
        oldcursor.execute("SELECT id, name, teamviewerid, anydeskid, time FROM pienosole_api_newcomer")
        data = oldcursor.fetchall()
        print(f"Migrating {len(data)} NewComer...")
        max_pk = 0
        for pk, name, teamviewerid, anydeskid, time in data:
            max_pk = max(max_pk, pk)
            NewComer.objects.create(
                pk=pk, name=name, teamviewerid=teamviewerid, anydeskid=anydeskid, time=time
            )
        newcursor.execute("ALTER SEQUENCE re_restapi_newcomer_id_seq RESTART WITH %s", [max_pk + 1])
        # MONEYDESTINATION
        oldcursor.execute(
            """
SELECT id, society_name, email, stripe_id, address_1, address_2, city, phone_number, postal_code, 
receipt_language, vat_country_alpha2, country_alpha2 FROM pienosole_api_moneydestination
            """
        )
        data = oldcursor.fetchall()
        print(f"Migrating {len(data)} MoneyDestination...")
        max_pk = 0
        for pk, society_name, email, stripe_id, address_1, address_2, city, phone_number, postal_code, \
                receipt_language, vat_country_alpha2, country_alpha2 in data:
            max_pk = max(max_pk, pk)
            MoneyDestination.objects.create(
                pk=pk, society_name=society_name, email=email, stripe_id=stripe_id, address_1=address_1,
                address_2=address_2, city=city, phone_number=phone_number, postal_code=postal_code,
                receipt_language=receipt_language,
                vat_country_alpha2=vat_country_alpha2, country_alpha2=country_alpha2
            )
        newcursor.execute("ALTER SEQUENCE re_restapi_moneydestination_id_seq RESTART WITH %s", [max_pk + 1])
        # Logo
        oldcursor.execute(
            "SELECT id, static_file_tag FROM pienosole_api_logo"
        )
        data = oldcursor.fetchall()
        print(f"Migrating {len(data)} Logo...")
        max_pk = 0
        for pk, static_file_tag in data:
            max_pk = max(max_pk, pk)
            Logo.objects.create(
                pk=pk, static_file_tag=static_file_tag
            )
        newcursor.execute("ALTER SEQUENCE re_restapi_logo_id_seq RESTART WITH %s", [max_pk + 1])
        # Park
        oldcursor.execute(
            """
SELECT id, name, anydeskid, teamviewerid, creation_date, last_updated, software_version, accept_gireve, 
latitude, longitude, address, city, country_alpha2, postal_code, installed, advenir_user_id, note,
email, email_report, show_phrases_frontend FROM pienosole_api_park ORDER BY id
            """
        )
        data = oldcursor.fetchall()
        print(f"Migrating {len(data)} Park...")
        max_pk = 0
        for pk, name, anydeskid, teamviewerid, creation_date, last_updated, software_version, accept_gireve, \
                latitude, longitude, address, city, country_alpha2, postal_code, installed, advenir_user_id, note, \
                email, email_report, show_phrases_frontend in data:
            max_pk = max(max_pk, pk)
            # last_updated non può venir scritta in modo semplice e non è essenziale farlo
            #   il campo viene utilizzato solo da gireve per capire le colonnine da retrievare
            instance = Park.objects.create(
                pk=pk, name=name, teamviewerid=teamviewerid, anydeskid=anydeskid, email=email,
                email_report=email_report,
                accept_gireve=accept_gireve, software_version=software_version, installed=installed,
                advenir_user_id=advenir_user_id, show_phrases_frontend=show_phrases_frontend, note=note,
                address=address, postal_code=postal_code, city=city, country_alpha2=country_alpha2,
                latitude=latitude, longitude=longitude
            )
            instance.creation_date = creation_date
            instance.save()
        newcursor.execute("ALTER SEQUENCE re_restapi_park_id_seq RESTART WITH %s", [max_pk + 1])
        # ChargingStation
        oldcursor.execute(
            """
SELECT bnum, park_id, park_bnum, com, price, qrcodeid, last_updated, accept_guests, money_receiver_id,
override_logo_id FROM pienosole_api_chargingstation ORDER BY bnum
            """
        )
        data = oldcursor.fetchall()
        print(f"Migrating {len(data)} ChargingStation...")
        max_pk = 0
        for bnum, park_id, park_bnum, com, price, qrcodeid, last_updated, accept_guests, money_receiver_id, \
                override_logo_id in data:
            max_pk = max(max_pk, bnum)
            # last_updated non può venir scritta in modo semplice e non è essenziale farlo
            #   il campo viene utilizzato solo da gireve per capire le colonnine da retrievare
            ChargingStation.objects.create(
                bnum=bnum, park_id=park_id, park_bnum=park_bnum, accept_guests=accept_guests,
                money_receiver_id=money_receiver_id, price=price, com=com, qrcodeid=qrcodeid,
                override_logo_id=override_logo_id
            )
        newcursor.execute("ALTER SEQUENCE re_restapi_chargingstation_bnum_seq RESTART WITH %s", [max_pk + 1])
        # ChargingStationLastPower
        oldcursor.execute("""
SELECT chargingstation_id, "power", "timestamp" 
FROM pienosole_api_power pap
WHERE id IN (
    SELECT last_power_id 
    FROM pienosole_api_chargingstation pac
)
        """)
        data = oldcursor.fetchall()
        print(f"Migrating {len(data)} ChargingStationLastPower from Power")
        cslp_tosave = []
        timestamps = []
        for chargingstation_id, power, timestamp in data:
            instance = ChargingStationLastPower(
                chargingstation_id=chargingstation_id,
                power=power,
                already_saved=False,  # This is the logical truth
            )
            timestamps.append(timestamp)
            # last_save_timestamp need to be set to now becuase the question
            #   if I want to save the new dataset, I need to use the NOW moment
            #   of the first introduction on LastPower as starting point
            cslp_tosave.append(instance)
        cslp_toupdate = ChargingStationLastPower.objects.bulk_create(cslp_tosave)
        for i in range(len(cslp_toupdate)):
            cslp_toupdate[i].timestamp = timestamps[i]
        ChargingStationLastPower.objects.bulk_update(cslp_toupdate, ['timestamp'])
        # Test: Check Integrity park_bnum
        print("Coherence check on park_bnum... ", end='')
        error_flag = False
        empty_parks = []
        for p in Park.objects.all():
            bnums = list(p.chargingstation_set.order_by('park_bnum').values_list('park_bnum', flat=True))
            if len(bnums) == 0:
                empty_parks.append(p)
            elif bnums != list(range(min(bnums), max(bnums) + 1)):
                if not error_flag:
                    print("error")
                error_flag = True
                print(f"COHERENCE ERROR IN PARK {p.id}: park_bnum={bnums}")
        if error_flag:
            raise ValueError("Error during Coherence Check")
        print("ok")
        if empty_parks:
            for prk in empty_parks:
                print(f"Warning! Park ID {prk.pk} NAME {prk.name} results without ChargingStations")
        # PMS
        oldcursor.execute(
            "SELECT id, name, abbrev FROM pienosole_api_pms ORDER BY id"
        )
        data = oldcursor.fetchall()
        print(f"Migrating {len(data)} PMS...")
        max_pk = 0
        for pk, name, abbrev in data:
            max_pk = max(max_pk, pk)
            PMS.objects.create(
                pk=pk, name=name, abbrev=abbrev
            )
        newcursor.execute("ALTER SEQUENCE re_restapi_pms_id_seq RESTART WITH %s", [max_pk + 1])
        # PMSPendingRequest
        oldcursor.execute(
            """
SELECT id, parkadmin_username, authorized_parks, registration_token, pms_id
FROM pienosole_api_pmspendingrequest
            """
        )
        data = oldcursor.fetchall()
        print(f"Migrating {len(data)} PMSPendingRequest...")
        max_pk = 0
        for pk, parkadmin_username, authorized_parks, registration_token, pms_id in data:
            max_pk = max(max_pk, pk)
            instance = PMSPendingRequest.objects.create(
                pk=pk, label=parkadmin_username, registration_token=registration_token, pms_id=pms_id
            )
            for park_id in authorized_parks:
                instance.authorized_parks.add(park_id)
            instance.save()
        newcursor.execute("ALTER SEQUENCE re_restapi_pmspendingrequest_id_seq RESTART WITH %s", [max_pk + 1])
        # User with PMSAdmin
        already_migrated_user_id = []
        oldcursor.execute(
            """
SELECT pmsa.user_id, pmsa.authorization_token, pmsa.pms_id, 
u.password, u.last_login, u.is_superuser, u.username, u.first_name, 
u.last_name, u.email, u.is_staff, u.is_active, u.date_joined, 
uc.authorized_bnum, uc.expire_datetime, uc.expire_policy, uc.expired, uc.guest 
FROM pienosole_api_pmsadminuser pmsa, auth_user u, pienosole_api_userconfig uc 
WHERE pmsa.user_id = u.id AND pmsa.user_id = uc.user_id
            """
        )
        data = oldcursor.fetchall()
        print(f"Migrating {len(data)} PMSAdminUser...")
        for user_id, authorization_token, pms_id, password, last_login, is_superuser, username, first_name, \
                last_name, email, is_staff, is_active, date_joined, authorized_bnum, expire_datetime, \
                expire_policy, expired, guest in data:
            user_instance = User.objects.create(
                pk=user_id,
                username=str(uuid4()),
                password="temp_password",
                first_name=first_name,
                last_name=last_name,
                email="",
                is_active=is_active,
                date_joined=date_joined,
                authorization_token=authorization_token,
                is_readonly=expired,
                scheduled_expire_time=expire_datetime,
            )
            user_instance.set_unusable_password()
            user_instance.save()
            pmsadmin_feat_instance = PMSAdminFeature.objects.create(
                user=user_instance,
                label=username,
                pms_id=pms_id,
            )
            oldcursor.execute(
                "SELECT park_id FROM pienosole_api_userconfig_managed_parks WHERE userconfig_id = %s", (user_id,)
            )
            managed_parks_ids = [t[0] for t in oldcursor.fetchall()]
            pmsadmin_feat_instance.pms_managed_parks.add(*managed_parks_ids)
            already_migrated_user_id.append(user_id)
        # Users with Belonging To related to a PMSAdmin
        oldcursor.execute(
            """
SELECT u.id, u.username, u.password, u.is_active, uc.expire_datetime, uc.expired, pmsa.user_id, uc.authorized_bnum 
FROM pienosole_api_pmsadminuser pmsa, pienosole_api_userconfig_belonging_to b, auth_user u, pienosole_api_userconfig uc 
WHERE pmsa.user_id = b.user_id AND b.userconfig_id = u.id AND u.id = uc.user_id
            """
        )
        data = oldcursor.fetchall()
        print(f"Migrating {len(data)} PMSChildUser...")
        existing_bnums = ChargingStation.objects.all().values_list('bnum', flat=True)
        for pk, username, password, is_active, expire_datetime, expired, pmsadmin_user_id, authorized_bnum in data:
            user_instance = User.objects.create_user(
                pk=pk,
                username=username,
                password=password,
                is_active=is_active,
                is_readonly=expired,
                scheduled_expire_time=expire_datetime,
                on_expire_disable=True,
                on_expire_appendtimestamp=True,
            )
            _new_pmschild_feat = PMSChildFeature.objects.create(
                user=user_instance,
                pms_admin_id=pmsadmin_user_id,
            )
            new_charge_feat = ChargeFeature.objects.create(user=user_instance)
            validated_authorized_bnum = [x for x in authorized_bnum if x in existing_bnums]
            if len(authorized_bnum) != len(validated_authorized_bnum):
                deleted_bnums = [x for x in authorized_bnum if x not in existing_bnums]
                print(f"Warning! Dropping authorizations for inexistant bnums: {deleted_bnums} for PMS child user {pk}")
            new_charge_feat.authorized_cs.add(*validated_authorized_bnum)
            already_migrated_user_id.append(pk)
        # All other users
        oldcursor.execute(
            """
SELECT u.id, u.password, u.last_login, u.is_superuser, u.username, u.first_name,
u.last_name, u.email, u.is_staff, u.is_active, u.date_joined,
uc.authorized_bnum, uc.expire_datetime, uc.expire_policy, uc.expired, uc.guest
FROM auth_user u, pienosole_api_userconfig uc WHERE u.id = uc.user_id ORDER BY u.id;
            """
        )
        data = [x for x in oldcursor.fetchall() if x[0] not in already_migrated_user_id]
        print(f"Migrating {len(data)} remaining Users...")
        user_to_create = []
        charge_feat_to_create = {}
        guest_feat_to_create = []
        for pk, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, \
                is_active, date_joined, authorized_bnum, expire_datetime, expire_policy, expired, guest in data:
            # Expire Policy:
            # ('NPE', 'No Permission'),
            # ('DIS', 'Disable'),
            # ('PAD', 'PMS AppendTimestamp Disable')
            new_user = User(
                pk=pk,
                username=username,
                password=password,
                last_login=last_login,
                is_superuser=is_superuser,
                first_name=first_name,
                last_name=last_name,
                email=email,
                is_staff=is_staff,
                is_active=is_active,
                date_joined=date_joined,
                scheduled_expire_time=expire_datetime,
                is_readonly=expired,
                on_expire_disable=(expire_policy == "DIS" or expire_policy == "PAD"),
                on_expire_appendtimestamp=(expire_policy == "PAD"),
            )
            user_to_create.append(new_user)
            new_charge = ChargeFeature(user=new_user)
            validated_authorized_bnum = [x for x in authorized_bnum if x in existing_bnums]
            if len(authorized_bnum) != len(validated_authorized_bnum):
                deleted_bnums = [x for x in authorized_bnum if x not in existing_bnums]
                print(f"Warning! Dropping authorizations for inexistant bnums: {deleted_bnums} for user {pk}")
            charge_feat_to_create[new_charge] = validated_authorized_bnum
            if guest:
                new_guest = GuestFeature(user=new_user)
                guest_feat_to_create.append(new_guest)
        User.objects.bulk_create(user_to_create)
        ChargeFeature.objects.bulk_create(list(charge_feat_to_create.keys()))
        for cf, auth_bnum in charge_feat_to_create.items():
            if len(auth_bnum) > 0:
                cf.authorized_cs.add(*auth_bnum)
        GuestFeature.objects.bulk_create(guest_feat_to_create)
        # Parkadmin Feature for User with a Managed Park
        oldcursor.execute(
            """
SELECT id, userconfig_id, park_id FROM pienosole_api_userconfig_managed_parks
            """
        )
        managed_parks_table = [x for x in oldcursor.fetchall() if x[1] not in already_migrated_user_id]
        user_to_park_relations = {}
        for _pk, user_id, park_id in managed_parks_table:
            if user_id not in user_to_park_relations:
                user_to_park_relations[user_id] = []
            user_to_park_relations[user_id].append(park_id)
        for user_id, parks in user_to_park_relations.items():
            new_parkadmin = ParkadminFeature.objects.create(user_id=user_id)
            new_parkadmin.managed_parks.add(*parks)
        # Relate Child User
        oldcursor.execute(
            """
SELECT id, userconfig_id, user_id FROM pienosole_api_userconfig_belonging_to
            """
        )
        belonging_to_table = [x for x in oldcursor.fetchall() if x[2] not in already_migrated_user_id]
        admin_to_child_relations = {}
        for _pk, child_id, admin_id in belonging_to_table:
            if admin_id not in admin_to_child_relations:
                admin_to_child_relations[admin_id] = []
            admin_to_child_relations[admin_id].append(child_id)
        for admin_id, childs in admin_to_child_relations.items():
            try:
                parkadmin = ParkadminFeature.objects.get(user_id=admin_id)
            except ParkadminFeature.DoesNotExist:
                print(f"Warning! child user {childs} referencing parkadmin user {admin_id} without managed_parks.\n"
                      "Defaulting to empty (no park) ParkadminFeature...")
                parkadmin = ParkadminFeature.objects.create(user_id=admin_id)
            parkadmin.child_users.add(*childs)
        # Reset User Sequence
        max_pk_user = User.objects.order_by('-id').first()
        if max_pk_user is not None:
            max_pk = max_pk_user.pk
            newcursor.execute("ALTER SEQUENCE re_restapi_user_id_seq RESTART WITH %s", [max_pk + 1])
        # Charge
        oldcursor.execute(
            """
SELECT id, chargingstation_id, start, stop, user_id, last_nonzero_power_time, energy_wh
FROM pienosole_api_charge ORDER BY id
            """
        )
        data = oldcursor.fetchall()
        print(f"Migrating {len(data)} Charge...")
        max_pk = 0
        charge_to_create = []
        for pk, cs_id, start, stop, u_id, lnzpt, energy_wh in data:
            max_pk = max(max_pk, pk)
            new_charge = Charge(
                pk=pk,
                chargingstation_id=cs_id,
                start=start,
                stop=stop,
                user_id=u_id,
                last_nonzero_power_time=lnzpt,
                energy_wh=energy_wh,
            )
            charge_to_create.append(new_charge)
        Charge.objects.bulk_create(charge_to_create)
        newcursor.execute("ALTER SEQUENCE re_restapi_charge_id_seq RESTART WITH %s", [max_pk + 1])
        # PaymentOrder
        oldcursor.execute(
            """
SELECT id, imprint_id, imprinted_cents, energy_cents, stripe_comm_cents, rossen_comm_cents, capture_status,
chargingstation_id, guest_user_id, phase, last_updated, confirm_timestamp, exp_month, exp_year, fingerprint, last4
FROM pienosole_api_paymentorder ORDER BY id
            """
        )
        data = oldcursor.fetchall()
        print(f"Migrating {len(data)} PaymentOrder...")
        max_pk = 0
        paymentorder_to_create = []
        for pk, imprint_id, imprinted_cents, energy_cents, stripe_comm_cents, rossen_comm_cents, capture_status, \
                chargingstation_id, guest_user_id, phase, last_updated, confirm_timestamp, exp_month, exp_year, \
                fingerprint, last4 in data:
            max_pk = max(max_pk, pk)
            new_paymentorder = PaymentOrder(
                pk=pk,
                chargingstation_id=chargingstation_id,
                user_id=guest_user_id,
                confirm_timestamp=confirm_timestamp,
                phase=phase,
                imprint_id=imprint_id,
                imprinted_cents=imprinted_cents,
                energy_cents=energy_cents,
                stripe_comm_cents=stripe_comm_cents,
                rossen_comm_cents=rossen_comm_cents,
                capture_status=capture_status,
                last_updated=last_updated,
                fingerprint=fingerprint,
                last4=last4,
                exp_month=exp_month,
                exp_year=exp_year
            )
            paymentorder_to_create.append(new_paymentorder)
        PaymentOrder.objects.bulk_create(paymentorder_to_create)
        newcursor.execute("ALTER SEQUENCE re_restapi_paymentorder_id_seq RESTART WITH %s", [max_pk + 1])
        # TODO: Ipsum
        # IPSUMDevice
        oldcursor.execute("""
SELECT id, save_min_delay, last_save_timestamp, software_version, drop_max_delay, alias, expected_clamps, note, token
FROM pienosole_api_ipsumconfig ORDER BY id
        """)
        data = oldcursor.fetchall()
        print(f"Migrating {len(data)} IPSUMConfig into IPSUMDevice")
        max_pk = 0
        for pk, save_min_delay, last_save_timestamp, software_version, drop_max_delay, \
                alias, expected_clamps, note, token in data:
            max_pk = max(max_pk, pk)
            if save_min_delay <= datetime.timedelta(minutes=1):
                autosave_min_interval = None
            else:
                autosave_min_interval = save_min_delay
            IPSUMDevice.objects.create(
                pk=pk,
                token=token,
                alias=alias,
                save_data=True,
                autosave_min_interval=autosave_min_interval,
                autodrop_max_interval=drop_max_delay,
                expected_clamps=expected_clamps,
                software_version=software_version,
                note=note,
            )
        newcursor.execute("ALTER SEQUENCE re_restapi_ipsumdevice_id_seq RESTART WITH %s", [max_pk + 1])
        # ParkIpsum
        try:
            oldcursor.execute("""
SELECT DISTINCT ON (pap.id) pap.id, pap.ipsum_avalpower_formula, pap.ipsum_last_send, pap.ipsum_send_time,
pap.ipsum_last_message
FROM pienosole_api_park pap, pienosole_api_ipsumconfig_linked_parks pailp
WHERE pailp.park_id = pap.id
ORDER BY id
            """)
        except psycopg2.errors.UndefinedColumn:
            old_conn.rollback()
            print("pienosole_api_park.ipsum_avalpower_formula missing, trying with "
                  "pienosole_api_park.ipsum_avalpower_formula_1")
            oldcursor.execute("""
SELECT DISTINCT ON (pap.id) pap.id, pap.ipsum_avalpower_formula_1, pap.ipsum_last_send, pap.ipsum_send_time,
pap.ipsum_last_message
FROM pienosole_api_park pap, pienosole_api_ipsumconfig_linked_parks pailp
WHERE pailp.park_id = pap.id
ORDER BY id
            """)
        data = oldcursor.fetchall()
        print(f"Migrating {len(data)} Ipsum data from Park Objects")
        for park_id, ipsum_avalpower_formula, ipsum_last_send, ipsum_send_time, ipsum_last_message in data:
            ParkIpsumConf.objects.create(
                park_id=park_id,
                avalpower_formula_1=ipsum_avalpower_formula,
                postponed_send_timing=ipsum_send_time,
                last_send_timestamp=ipsum_last_send,
                last_message_sent=ipsum_last_message,
            )
        # ParkIpsumConf.linked_ipsum
        oldcursor.execute("""
SELECT ipsumconfig_id, park_id FROM pienosole_api_ipsumconfig_linked_parks
        """)
        data = oldcursor.fetchall()
        print(f"Migrating {len(data)} relations between IpsumConfig and Park")
        parkid_to_ipsumid = {}
        for ipsumconfig_id, park_id in data:
            if park_id in parkid_to_ipsumid:
                parkid_to_ipsumid[park_id].append(ipsumconfig_id)
            else:
                parkid_to_ipsumid[park_id] = [ipsumconfig_id]
        for park_id, ipsumconfig_ids in parkid_to_ipsumid.items():
            ParkIpsumConf.objects.get(park_id=park_id).linked_ipsums.add(*ipsumconfig_ids)
        # IPSUMLastPower
        # We will ignore extra field because was unused in the old software
        oldcursor.execute("""
SELECT pailp.ipsumconfig_id, pailp.timestamp, pailp.powers, pailp.already_saved,
paic.last_save_timestamp
FROM pienosole_api_ipsumlastpower pailp, pienosole_api_ipsumconfig paic 
WHERE pailp.ipsumconfig_id = paic.id
ORDER BY id 
        """)
        data = oldcursor.fetchall()
        print(f"Migrating {len(data)} IPSUMLastPower")
        for ipsumconfig_id, timestamp, powers, already_saved, last_save_timestamp in data:
            instance = IPSUMLastPower.objects.create(
                ipsumdevice_id=ipsumconfig_id,
                timestamp=timestamp,
                powers=powers,
                already_saved=already_saved,
                last_save_timestamp=last_save_timestamp,
            )
            instance.last_save_timestamp = last_save_timestamp
            instance.save()
        # Custom Kiloutou
        oldcursor.execute("""
SELECT park_id, region_iso3166_2, city FROM pienosole_api_customkiloutoupark
        """)
        data = oldcursor.fetchall()
        print(f"Migrating {len(data)} Custom Kiloutou-Park Flags...")
        for park_id, region_iso3166_2, city in data:
            CustomKiloutouPark.objects.create(
                park_id=park_id,
                region_iso3166_2=region_iso3166_2,
                city=city
            )
        # Custom Franceparebrise
        oldcursor.execute("""
SELECT park_id, region_iso3166_2, city FROM pienosole_api_customfranceparebrisepark
        """)
        data = oldcursor.fetchall()
        print(f"Migrating {len(data)} Custom FranceParebrise-Park Flags...")
        for park_id, region_iso3166_2, city in data:
            CustomFranceParebrisePark.objects.create(
                park_id=park_id,
                region_iso3166_2=region_iso3166_2,
                city=city
            )
        # Close connections
        oldcursor.close()
        if bool(int(os.environ['USE_SSHTUNNEL'])):
            # noinspection PyUnboundLocalVariable
            server.stop()
