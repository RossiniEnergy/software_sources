from django.urls import path, include
from django.conf import settings
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView

from re_restapi.views.custom.legacy import urls as custom_legacy_urls
from re_restapi.views.internal import urls as internal_urls
from re_restapi.views.legacy import urls as legacy_urls
from re_restapi.views.parkadmin import urls as parkadmin_urls
from re_restapi.views.pmsapi import urls as pmsapi_urls
from re_restapi.views.pmsapi.legacy import urls as pmsapi_legacy_urls
from re_restapi.views.public import urls as public_urls
from re_restapi.views.public.legacy import urls as public_legacy_urls


if settings.ENABLE_SWAGGER:
    swagger_urlpatterns = [
        path("openapi/", SpectacularAPIView.as_view(), name='openapi-schema'),
        path("swagger-ui/", SpectacularSwaggerView.as_view(url_name='openapi-schema'), name='swagger-ui'),
    ]
else:
    swagger_urlpatterns = []


urlpatterns = [
    # SWAGGER
    path("swagger/", include(swagger_urlpatterns)),
    # CUSTOM API LEGACY URLS
    path("custom/", include(custom_legacy_urls)),
    # INTERNAL MODULE ULRS
    path("internal/", include(internal_urls)),
    # LEGACY MODULE URLS
    path("", include(legacy_urls)),
    # PARKADMIN MODULE URLS
    path("parkadmin/", include(parkadmin_urls)),
    # PUBLIC MODULE URLS
    path("public/", include(public_urls)),
    # Legacy Url Scheme to retrocompatibility
    # PMSAPI MODULE URLS
    path("pmsapi/", include(pmsapi_urls)),
    # PMS LEGACY URLS
    path("", include(pmsapi_legacy_urls)),
    # PUBLIC LEGACY URLS
    path("", include(public_legacy_urls)),
]

if settings.SELFDEPLOY_MEDIA:
    from django.conf.urls.static import static
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
