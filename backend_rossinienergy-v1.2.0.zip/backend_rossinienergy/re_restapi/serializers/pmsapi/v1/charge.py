from rest_framework import serializers

from re_restapi.models import User, Charge, ChargingStation
from re_restapi.serializers.v1.cspower import CSLastPowerSerializer


# noinspection PyAbstractClass
class StartStopChargeSerializer(serializers.ModelSerializer):
    user_id = serializers.IntegerField(source='id', required=True)

    class Meta:
        model = User
        fields = ['user_id']


class PMSChargeSerializer(serializers.ModelSerializer):
    user = StartStopChargeSerializer()
    last_power = CSLastPowerSerializer(source='chargingstation.last_power', required=False)

    class Meta:
        model = Charge
        fields = ['id', 'start', 'stop', 'user', 'last_nonzero_power_time', 'energy_wh', 'last_power']


class PMSChargeControllerSerializer(serializers.ModelSerializer):
    # allow_null=True?
    active_charge = PMSChargeSerializer(required=False)

    class Meta:
        model = ChargingStation
        fields = ['qrcodeid', 'active_charge']
