from rest_framework import serializers

from re_restapi.models import User


# noinspection PyMethodMayBeStatic
class LegacyUserConfigSerializer(serializers.ModelSerializer):
    authorized_bnum = serializers.SerializerMethodField()
    expired = serializers.BooleanField(source='is_readonly')
    expire_datetime = serializers.DateTimeField(source='scheduled_expire_time')
    expire_policy = serializers.SerializerMethodField()
    guest = serializers.BooleanField(source='has_guest_feat')
    belonging_to = serializers.PrimaryKeyRelatedField(source='admin_users', many=True, read_only=True)

    class Meta:
        model = User
        fields = ['authorized_bnum', 'expired', 'expire_datetime', 'expire_policy',
                  'guest', 'belonging_to']
        extra_kwargs = {
            'authorized_bnum': {'allow_empty': True},
            'belonging_to': {'allow_empty': True},
        }

    def get_authorized_bnum(self, obj: User):
        if obj.has_charge_feat:
            return [cs.bnum for cs in obj.chargefeature.authorized_cs.all()]
        else:
            return []

    def get_expire_policy(self, obj: User):
        return "NPE" if not obj.has_pmschild_feat else "PAD"


class LegacyUserSerializer(serializers.ModelSerializer):
    config = LegacyUserConfigSerializer(source="*", required=False)

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'is_active', 'is_staff', 'is_superuser', 'config']
        read_only_fields = ['id', 'is_active', 'is_superuser']
