from rest_framework import serializers

from re_restapi.models import ChargingStationPowerTable, ChargingStationLastPower


class CSPowerTableSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChargingStationPowerTable
        fields = ['chargingstation', 'power', 'timestamp']


class CSLastPowerSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChargingStationLastPower
        fields = ['chargingstation', 'power', 'timestamp']
