from typing import Optional

from rest_framework import serializers
from django.core.serializers.json import DjangoJSONEncoder

from re_restapi.models import User, Charge, ChargingStation
from re_restapi.serializers.v1.cspower import CSLastPowerSerializer


class SimpleUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'has_guest_feat']


class FrontendChargeSerializer(serializers.ModelSerializer):
    user = SimpleUserSerializer()
    last_power = CSLastPowerSerializer(source='chargingstation.last_power', required=False)

    class Meta:
        model = Charge
        fields = ['id', 'start', 'stop', 'user', 'last_nonzero_power_time', 'energy_wh', 'last_power']


class ChargeControllerSerializer(serializers.ModelSerializer):
    # allow_null=True?
    active_charge = FrontendChargeSerializer(required=False)
    latitude = serializers.FloatField(source='park.latitude')
    longitude = serializers.FloatField(source='park.longitude')
    show_phrases_frontend = serializers.BooleanField(source='park.show_phrases_frontend')
    logged_user = serializers.SerializerMethodField()
    has_charge_permission = serializers.SerializerMethodField()
    show_custom_message = serializers.BooleanField(source='park.show_custom_message')
    custom_message = serializers.JSONField(encoder=DjangoJSONEncoder, source='park.custom_message')
    custom_message_fallback_lang = serializers.CharField(source='park.custom_message_fallback_lang')

    def get_logged_user(self, _obj) -> Optional[dict]:
        user: User = self.context.get('user')
        if user:
            return SimpleUserSerializer(user).data
        else:
            return None

    def get_has_charge_permission(self, obj) -> bool:
        user: User = self.context.get('user')
        # Heavy use of short-circuit evaluation
        return bool(user is not None and user.has_charge_feat and obj in user.chargefeature.chargingstation_allowed)

    class Meta:
        model = ChargingStation
        fields = ['qrcodeid', 'active_charge', 'park', 'park_bnum', 'latitude', 'longitude',
                  'accept_guests', 'is_payment_configured', 'price', 'override_logo_url', 'show_phrases_frontend',
                  'logged_user', 'has_charge_permission', 'show_custom_message', 'custom_message',
                  'custom_message_fallback_lang']
