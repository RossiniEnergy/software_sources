from rest_framework import serializers

from re_restapi.models import Park
from re_restapi.serializers.v1.chargingstation import PublicChargingStationSerializer


class PublicParkSerializer(serializers.ModelSerializer):
    chargingstations = PublicChargingStationSerializer(source='chargingstation_set', many=True, read_only=True)

    class Meta:
        model = Park
        fields = [
            # Public
            'id',
            'name',
            'latitude',
            'longitude',
            'address',
            'postal_code',
            'city',
            'country_alpha2',
            'accept_gireve',
            'chargingstations',
            'installed',
        ]
        read_only_fields = fields
