import base64
from uuid import uuid4
from rest_framework import serializers
from django.core.files.base import ContentFile
from re_restapi.models import MediaImage


class MediaImageSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    alias = serializers.CharField(max_length=50)
    file_extension = serializers.CharField(write_only=True)
    image = serializers.CharField(max_length=40_000_000, source='image_file')  # byte->base64 is +33-37%
    url = serializers.URLField(read_only=True)

    def update(self, instance, validated_data):
        raise NotImplementedError('You cannot update image from here, you need to upload a new one.')

    def create(self, validated_data):
        alias = validated_data['alias']
        file_ext = validated_data['file_extension']
        image_base64 = validated_data['image_file']
        image_bytes = base64.decodebytes(image_base64.encode())
        image_file = ContentFile(image_bytes, str(uuid4()) + "." + file_ext)
        instance = MediaImage.objects.create(
            alias=alias,
            image_file=image_file,
        )
        return instance


class MediaImageNoImageSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    alias = serializers.CharField(max_length=50)
    url = serializers.URLField(read_only=True)

    def update(self, instance, validated_data):
        raise NotImplementedError("This is a read-only serializer!")

    def create(self, validated_data):
        raise NotImplementedError("This is a read-only serializer!")

