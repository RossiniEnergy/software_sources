from rest_framework import serializers


class AccessStatusParkSerializer(serializers.Serializer):
    def update(self, instance, validated_data):
        raise NotImplementedError

    def create(self, validated_data):
        raise NotImplementedError

    id = serializers.IntegerField()
    name = serializers.CharField()
    installed = serializers.BooleanField()
    online = serializers.BooleanField()
