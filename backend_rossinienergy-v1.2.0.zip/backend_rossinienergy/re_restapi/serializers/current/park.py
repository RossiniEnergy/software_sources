from django.db import transaction
from rest_framework import serializers

from re_restapi.models import Park, ChargingStation
from re_restapi.serializers.current.chargingstation import InternalChargingStationSerializer, \
    ParkadminChargingStationSerializer


class InternalParkSerializer(serializers.ModelSerializer):
    # QUESTION: Can I order this with park_bnum?
    chargingstations = InternalChargingStationSerializer(source='chargingstation_set', many=True)

    # Remember you can't modify chargingstations directly from InternalParkSerializer

    class Meta:
        model = Park
        fields = [
            # Public
            'id',
            'name',
            'latitude',
            'longitude',
            'address',
            'postal_code',
            'city',
            'country_alpha2',
            'accept_gireve',
            'chargingstations',
            'installed',
            'show_custom_message',
            # Parkadmin
            'email',
            'email_report',
            'show_phrases_frontend',
            'custom_message',
            'custom_message_fallback_lang',
            # Internal
            'teamviewerid',
            'anydeskid',
            'creation_date',
            'last_updated',
            'software_version',
            'autosave_min_interval',
            'autodrop_max_interval',
            'note',
        ]
        extra_kwargs = {
            'creation_date': {'read_only': True, 'required': False},
            'last_updated': {'read_only': True, 'required': False},
            'software_version': {'read_only': True, 'default': ""},
        }

    def create(self, validated_data):
        chargingstations_data = validated_data.pop('chargingstation_set')
        with transaction.atomic():
            park = Park.objects.create(**validated_data)
            for i, ch_data in enumerate(chargingstations_data):
                # FIXME: CHECK IF VALID BEFORE CONFIRMING THE CREATION
                new_cs = ChargingStation.objects.create(
                    park=park,
                    park_bnum=i + 1,
                    **ch_data
                )
        return park


class ParkadminParkSerializer(serializers.ModelSerializer):
    chargingstations = ParkadminChargingStationSerializer(source='chargingstation_set', many=True, read_only=True)

    class Meta:
        model = Park
        fields = [
            # Public
            'id',
            'name',
            'latitude',
            'longitude',
            'address',
            'postal_code',
            'city',
            'country_alpha2',
            'accept_gireve',
            'chargingstations',
            'installed',
            'show_custom_message',
            # Parkadmin
            'email',
            'email_report',
            'show_phrases_frontend',
            'custom_message',
            'custom_message_fallback_lang',
        ]
        read_only_fields = [
            # Public
            'id',
            'name',
            'latitude',
            'longitude',
            'address',
            'postal_code',
            'city',
            'country_alpha2',
            'accept_gireve',
            'chargingstations',
            'installed',
            'show_custom_message',
        ]


class SimpleParkSerializer(serializers.ModelSerializer):
    class Meta:
        model = Park
        fields = [
            # Public
            'id',
            'name',
        ]
        read_only_fields = fields
