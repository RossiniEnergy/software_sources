from collections import OrderedDict

from django.db import transaction
from rest_framework import serializers
from rest_framework.utils import model_meta

from re_restapi.models import \
    User, FeatureNames, ChargeFeature, GuestFeature, ParkadminFeature, PMSChildFeature, PMSAdminFeature
from re_restapi.serializers.current.user_utils import serializer_validate_username


class BaseFeatureSerializer(serializers.ModelSerializer):
    def create(self, validated_data):
        validated_data['user'] = self.context['userinstance']
        return super().create(validated_data)


class ChargeFeatureSerializer(BaseFeatureSerializer):
    class Meta:
        model = ChargeFeature
        exclude = ['user']


class GuestFeatureSerializer(BaseFeatureSerializer):
    class Meta:
        model = GuestFeature
        exclude = ['user']


class ParkadminFeatureSerializer(BaseFeatureSerializer):
    class Meta:
        model = ParkadminFeature
        exclude = ['user']


class PMSChildFeatureSerializer(BaseFeatureSerializer):
    class Meta:
        model = PMSChildFeature
        exclude = ['user']


class PMSAdminFeatureSerializer(BaseFeatureSerializer):
    class Meta:
        model = PMSAdminFeature
        exclude = ['user']


class FeaturesSerializer(serializers.ModelSerializer):
    # Every new feature need to be registered here with the exact name used in the models
    charge = ChargeFeatureSerializer(source='chargefeature', required=False, allow_null=True)
    guest = GuestFeatureSerializer(source='guestfeature', required=False, allow_null=True)
    parkadmin = ParkadminFeatureSerializer(source='parkadminfeature', required=False, allow_null=True)
    pmschild = PMSChildFeatureSerializer(source='pmschildfeature', required=False, allow_null=True)
    pmsadmin = PMSAdminFeatureSerializer(source='pmsadminfeature', required=False, allow_null=True)

    class Meta:
        model = User
        fields = ['charge', 'guest', 'parkadmin', 'pmschild', 'pmsadmin']

    def create(self, validated_data):
        raise NotImplementedError(
            "You cannot use this function! Use update fired from with FeaturedUserSerializer.save()"
        )

    def update(self, instance, validated_data):
        for feat, featdata in self.initial_data.items():
            featmodelname = feat + 'feature'
            if featdata is not None:
                if getattr(instance, f"has_{feat}_feat"):
                    # Modify Feature already existing
                    featinstance = getattr(instance, featmodelname)
                    featserializer = type(self.fields[feat])(
                        featinstance,
                        data=featdata, partial=self.partial,
                    )
                else:
                    # Create Feature that are not already existing
                    featserializer = type(self.fields[feat])(
                        data=featdata,
                        context={'userinstance': instance},
                    )
                featserializer.is_valid(raise_exception=True)
                featserializer.save()
            else:
                # Delete Feature that already exists but are set to null (equal for partial or not, conserative)
                #   If partial=False in theory I need to delete the absent features, but for conservative reasons
                #   I'll let them there without deletion, this help prevents strange data loss from wrong Frontend calls
                featinstance = getattr(instance, featmodelname)
                featinstance.delete()
        instance.refresh_features_from_db()  # If other features use bool flags has_x_feat this need to be in for loop
        return instance

    def to_representation(self, instance):
        result = super().to_representation(instance)
        return OrderedDict([(key, result[key]) for key in result if result[key] is not None])


class FeaturedUserSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=False)
    feature_flags = serializers.SerializerMethodField()
    features = FeaturesSerializer(source='*')

    class Meta:
        model = User
        fields = [
            'id',
            'username',
            'password',
            'email',
            'is_active',
            'is_staff',
            'is_superuser',
            'is_readonly',
            'scheduled_expire_time',
            'on_expire_readonly',
            'on_expire_disable',
            'on_expire_appendtimestamp',
            'feature_flags',
            'features',
            'admin_users',
        ]
        extra_kwargs = {
            'is_active': {'read_only': True},
            'is_superuser': {'read_only': True},
            'admin_users': {'required': False},
        }

    def update(self, instance, validated_data):
        features_data = {}

        with transaction.atomic():
            # Change Password
            if 'password' in validated_data:
                new_password = validated_data.pop('password')
                instance.set_password(new_password)

            info = model_meta.get_field_info(instance)

            # Simply set each attribute on the instance, and then save it.
            # Note that unlike `.create()` we don't need to treat many-to-many
            # relationships as being a special case. During updates we already
            # have an instance pk for the relationships to be associated with.
            m2m_fields = []
            for attr, value in validated_data.items():
                if attr in info.relations and info.relations[attr].to_many:
                    m2m_fields.append((attr, value))
                elif attr.endswith('feature'):
                    initialname = attr.removesuffix('feature')
                    features_data[initialname] = self.initial_data['features'][initialname]
                else:
                    setattr(instance, attr, value)

            instance.save()

            # Note that many-to-many fields are set after updating instance.
            # Setting m2m fields triggers signals which could potentially change
            # updated instance and we do not want it to collide with .update()
            for attr, value in m2m_fields:
                field = getattr(instance, attr)
                field.set(value)

            # Features Update - summon the FeatureSerializer to delegate the update operation to it
            # OPTIMIZE: It's possible to integrate the feature serializer update inside this to remove
            #   the re-serialization overhead for featureserializer.
            #   This can be kept because useful for special checks between features.
            featureserializer = type(self.fields['features'])(instance, data=features_data, partial=self.partial)
            featureserializer.is_valid(raise_exception=True)
            featureserializer.save()
            instance.refresh_features_from_db()
        return instance

    def create(self, validated_data):
        features_data = {}
        username = validated_data.pop('username')
        email = validated_data.pop('email', "")
        password = validated_data.pop('password')

        with transaction.atomic():
            # Remove many-to-many relationships from validated_data.
            # They are not valid arguments to the default `.create()` method,
            # as they require that the instance has already been saved.
            info = model_meta.get_field_info(User)
            many_to_many = {}
            for field_name, relation_info in info.relations.items():
                if relation_info.to_many and (field_name in validated_data):
                    many_to_many[field_name] = validated_data.pop(field_name)
            # Remove features to save later
            for attr in validated_data.copy().keys():
                if attr.endswith('feature'):
                    initialname = attr.removesuffix('feature')
                    features_data[initialname] = self.initial_data['features'][initialname]
                    validated_data.pop(attr)

            # Create User object
            instance = User.objects.create_user(
                username=username,
                email=email,
                password=password,
                **validated_data,
            )
            # Save many-to-many relationships after the instance is created.
            if many_to_many:
                for field_name, value in many_to_many.items():
                    field = getattr(instance, field_name)
                    field.set(value)

            # Features Update - summon the FeatureSerializer to delegate the update operation to it
            # OPTIMIZE: It's possible to integrate the feature serializer update inside this to remove
            #   the re-serialization overhead for featureserializer.
            #   This can be kept because useful for special checks between features.
            featureserializer = type(self.fields['features'])(instance, data=features_data, partial=False)
            featureserializer.is_valid(raise_exception=True)
            featureserializer.save()
            instance.refresh_features_from_db()
        return instance

    # noinspection PyMethodMayBeStatic
    def get_feature_flags(self, instance) -> dict:
        return {feature: getattr(instance, 'has_{}_feat'.format(feature)) for feature in FeatureNames}

    # noinspection PyMethodMayBeStatic
    def validate_username(self, value):
        return serializer_validate_username(value)


class SimpleUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = [
            'id',
            'username',
        ]
        read_only_fields = fields
