from rest_framework import serializers

from re_restapi.models import ChargingStation
from re_restapi.serializers.current.charge import InternalChargeSerializer
from re_restapi.serializers.v1.cspower import CSLastPowerSerializer


class InternalChargingStationSerializer(serializers.ModelSerializer):
    last_power = CSLastPowerSerializer(required=False)
    last_charge = InternalChargeSerializer(read_only=True)

    class Meta:
        model = ChargingStation
        fields = ['park', 'park_bnum', 'bnum', 'accept_guests', 'money_receiver',
                  'price', 'qrcodeid', 'last_power', 'last_charge']
        extra_kwargs = {
            'park': {'read_only': True, 'required': False},
            'park_bnum': {'read_only': True},
            'bnum': {'read_only': True, 'required': False},
            'money_receiver': {'default': None},
            'qrcodeid': {'default': None},
            'last_power': {'read_only': True},
        }


class ParkadminChargingStationSerializer(serializers.ModelSerializer):
    last_power = CSLastPowerSerializer(required=False)

    class Meta:
        model = ChargingStation
        fields = ['park', 'park_bnum', 'bnum', 'accept_guests', 'money_receiver',
                  'price', 'qrcodeid', 'last_power']
        # Let edit only price
        read_only_fields = ['park', 'park_bnum', 'bnum', 'accept_guests',
                            'money_receiver', 'qrcodeid', 'last_power']
