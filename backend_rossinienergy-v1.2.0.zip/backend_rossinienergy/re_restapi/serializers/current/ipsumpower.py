from rest_framework import serializers

from re_restapi.models import IPSUMLastPower


class IPSUMLastPowerSerializer(serializers.ModelSerializer):
    class Meta:
        model = IPSUMLastPower
        fields = ['timestamp', 'powers', 'extra']
