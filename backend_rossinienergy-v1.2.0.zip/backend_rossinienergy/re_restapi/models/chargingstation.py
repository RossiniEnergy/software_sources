from typing import Optional

from .park import *
from .moneydestination import *
from .image import *
from django.db import models
from django.utils import timezone

__all__ = ['ChargingStation', 'ChargingStationLastPower', 'ChargingStationPowerTable']


class ChargingStation(models.Model):
    bnum = models.AutoField(primary_key=True)
    park = models.ForeignKey(Park, on_delete=models.PROTECT, editable=False)
    park_bnum = models.IntegerField(editable=False)
    accept_guests = models.BooleanField(default=True)
    money_receiver = models.ForeignKey(MoneyDestination, on_delete=models.PROTECT, null=True, default=None)
    price = models.IntegerField(default=20)
    com = models.IntegerField(default=0)
    qrcodeid = models.IntegerField(null=True, default=None, unique=True)
    # This is updated when the model is changed. Be wary of adding realtime fields here without modifying this behaviour
    last_updated = models.DateTimeField(auto_now=True)
    suspended = models.BooleanField(default=False, editable=False)
    override_logo = models.ForeignKey(MediaImage, on_delete=models.PROTECT, null=True, default=None)

    @property
    def evse_id(self) -> str:
        return "FR*ROS*E{}*{}".format(self.park_id, self.park_bnum)

    @property
    def already_started_charge(self) -> bool:
        current_charge = self.charge_set.filter(stop__isnull=True).order_by("-id").first()
        if current_charge is None:
            return False
        else:
            return current_charge.last_nonzero_power_time is not None

    @property
    def active_charge(self):
        return self.charge_set.filter(stop__isnull=True).first()

    @property
    def last_charge(self):
        return self.charge_set.order_by('-id').first()

    @property
    def is_payment_configured(self) -> bool:
        return self.money_receiver is not None

    @property
    def payment_enabled(self) -> bool:
        return self.money_receiver is not None and self.accept_guests

    @property
    def override_logo_url(self) -> Optional[str]:
        if self.override_logo is None:
            return None
        else:
            return self.override_logo.url


class ChargingStationLastPower(models.Model):
    chargingstation = models.OneToOneField(
        ChargingStation, on_delete=models.PROTECT, primary_key=True, related_name='last_power'
    )
    power = models.IntegerField(default=0)
    timestamp = models.DateTimeField(default=timezone.now)
    already_saved = models.BooleanField(default=False)
    last_save_timestamp = models.DateTimeField(auto_now_add=True)


class ChargingStationPowerTable(models.Model):
    chargingstation = models.ForeignKey(
        ChargingStation, on_delete=models.PROTECT, null=True
    )
    power = models.IntegerField()
    timestamp = models.DateTimeField()
