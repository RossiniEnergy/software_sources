from django.contrib.auth.models import AbstractUser
from django.db import models

__all__ = ['User', 'FeatureNames']

# Code to automatically generate the update from db function
FeatureNames = (
    'charge',
    'parkadmin',
    'guest',
    'pmschild',
    'pmsadmin'
)
to_refresh = []
for feat in FeatureNames:
    to_refresh.append('has_{}_feat'.format(feat))
    to_refresh.append('{}feature'.format(feat))


# It's ESSENTIAL to write down the feature name in FeatureNames to allow other part of the code to adapt
class User(AbstractUser):
    """
    The change of the has_X_feat flag is done via trigger.
    If you create and save a Feature Profile you need to reload the object from the DB
    for example reinitializing the object or using `userobject.refresh_from_db()`.
    If you need to save other datas in the userobject before refreshing the feature flags
    """
    # Token Authentication
    authorization_token = models.CharField(max_length=32, unique=True, blank=True, null=True, default=None)
    # Expire System
    is_readonly = models.BooleanField(default=False, editable=False)
    scheduled_expire_time = models.DateTimeField(null=True, default=None)
    on_expire_readonly = models.BooleanField(default=True)
    on_expire_disable = models.BooleanField(default=False)
    on_expire_appendtimestamp = models.BooleanField(default=False)
    # Bool Trigger Flags for Features Availability
    has_charge_feat = models.BooleanField(default=False)
    has_parkadmin_feat = models.BooleanField(default=False)
    has_guest_feat = models.BooleanField(default=False)
    has_pmschild_feat = models.BooleanField(default=False)
    has_pmsadmin_feat = models.BooleanField(default=False)

    def refresh_features_from_db(self):
        self.refresh_from_db(fields=to_refresh)

    def get_features_dict(self):
        return {feature: getattr(self, f'{feature}feature')
                for feature in FeatureNames if getattr(self, f'has_{feature}_feat')}
