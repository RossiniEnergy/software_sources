from django.db import models
import pgtrigger
from .user import *
from ..park import *

__all__ = ['ParkadminFeature']


class ParkadminFeature(models.Model):
    user = models.OneToOneField(User, on_delete=models.PROTECT, primary_key=True)
    managed_parks = models.ManyToManyField(Park, blank=True, related_name='admin_users')
    child_users = models.ManyToManyField(User, blank=True, related_name='admin_users')

    class Meta:
        triggers = [
            pgtrigger.Trigger(
                name='parkadmin_feat_flag_insert',
                operation=pgtrigger.Insert,
                when=pgtrigger.After,
                func='UPDATE re_restapi_user SET has_parkadmin_feat = TRUE WHERE id = NEW.user_id; RETURN NULL;',
            ),
            pgtrigger.Trigger(
                name='parkadmin_feat_flag_delete',
                operation=pgtrigger.Delete,
                when=pgtrigger.After,
                func='UPDATE re_restapi_user SET has_parkadmin_feat = FALSE WHERE id = OLD.user_id; RETURN NULL;'
            ),
        ]
