from django.db import models
from django.core.serializers.json import DjangoJSONEncoder
import pgtrigger
from .user import *
from .pmsadmin_feat import *

__all__ = ['PMSChildFeature']


@pgtrigger.register(

)
class PMSChildFeature(models.Model):
    user = models.OneToOneField(User, on_delete=models.PROTECT, primary_key=True)
    pms_admin = models.ForeignKey(PMSAdminFeature, on_delete=models.PROTECT, related_name='pms_childs')
    price = models.IntegerField(default=0)  # Euro Cents per kWh of Energy
    memory = models.JSONField(encoder=DjangoJSONEncoder, default=dict)

    class Meta:
        triggers = [
            pgtrigger.Trigger(
                name='pmschild_feat_flag_insert',
                operation=pgtrigger.Insert,
                when=pgtrigger.After,
                func='UPDATE re_restapi_user SET has_pmschild_feat = TRUE WHERE id = NEW.user_id; RETURN NULL;',
            ),
            pgtrigger.Trigger(
                name='pmschild_feat_flag_delete',
                operation=pgtrigger.Delete,
                when=pgtrigger.After,
                func='UPDATE re_restapi_user SET has_pmschild_feat = FALSE WHERE id = OLD.user_id; RETURN NULL;'
            ),
        ]
