from django.db import models

__all__ = ['MediaImage']


class MediaImage(models.Model):
    """
    Remember that image_file need to be delete MANUALLY with instance.image_file.delete() before/after the
    deletion of an instance of MediaImage if you want to not keep the file on disk.
    The alternatives are a cronjob to delete he dangling files every some time.
    The problem is that the image will remain accessible if someone has the url saved somewhere.
    https://stackoverflow.com/a/16041527/5903025
    """
    alias = models.CharField(max_length=50)
    image_file = models.ImageField(upload_to='images')
    upload_time = models.DateTimeField(auto_now=True)

    @property
    def url(self):
        return self.image_file.url
