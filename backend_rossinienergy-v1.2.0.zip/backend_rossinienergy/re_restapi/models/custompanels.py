from .park import *
from django.db import models

__all__ = ['CustomFranceParebrisePark', 'CustomKiloutouPark']


# CUSTOM MODELS
class CustomFranceParebrisePark(models.Model):
    park = models.OneToOneField(Park, on_delete=models.PROTECT, primary_key=True)
    region_iso3166_2 = models.CharField(max_length=6)
    city = models.CharField(max_length=50)


class CustomKiloutouPark(models.Model):
    park = models.OneToOneField(Park, on_delete=models.PROTECT, primary_key=True)
    region_iso3166_2 = models.CharField(max_length=6)
    city = models.CharField(max_length=50)
