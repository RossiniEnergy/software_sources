from django_filters import rest_framework as filters
from django.db.models import DateTimeField

from re_restapi.models import Charge


class ChargeFilter(filters.FilterSet):
    # If you don't write the lookup_field it's assumed 'exact', so the alias to the "no special lookup, simple equal"
    park_id = filters.NumberFilter(field_name='chargingstation__park_id')
    qrcodeid = filters.NumberFilter(field_name='chargingstation__qrcodeid')
    qrcodeid__isnull = filters.BooleanFilter(field_name='chargingstation__qrcodeid', lookup_expr='isnull')
    user_is_expired = filters.BooleanFilter(field_name='user__userconfig__is_expired')
    user_username = filters.CharFilter(field_name='user__username')
    user_is_active = filters.BooleanFilter(field_name='user__is_active')

    class Meta:
        model = Charge
        fields = {
            'chargingstation': ['exact'],
            'user_id': ['exact'],
            'start': ['lt', 'gt', 'lte', 'gte'],
            'stop': ['lt', 'gt', 'lte', 'gte'],
            'last_nonzero_power_time': ['lt', 'gt', 'lte', 'gte'],
            'energy_wh': ['exact', 'lt', 'gt', 'lte', 'gte'],
        }
        filter_overrides = {
            DateTimeField: {
                'filter_class': filters.IsoDateTimeFilter
            }
        }
