from django_filters import rest_framework as filters
from django.db.models import DateTimeField

from re_restapi.models import User


class ParkadminUserFilterSet(filters.FilterSet):
    # Base User Model
    is_readonly = filters.BooleanFilter()
    scheduled_expire_time__lt = filters.IsoDateTimeFilter(field_name='scheduled_expire_time', lookup_expr='lt')
    scheduled_expire_time__lte = filters.IsoDateTimeFilter(field_name='scheduled_expire_time', lookup_expr='lte')
    scheduled_expire_time__gt = filters.IsoDateTimeFilter(field_name='scheduled_expire_time', lookup_expr='gt')
    scheduled_expire_time__gte = filters.IsoDateTimeFilter(field_name='scheduled_expire_time', lookup_expr='gte')
    # Charge Feature
    authorized_cs = filters.NumberFilter(field_name='chargefeature__authorized_cs')

    class Meta:
        model = User
        fields = [
            'id',
            'username',
            'email',
            'is_active',
            'is_staff',
            'is_superuser',
            'is_readonly',
        ]
        filter_overrides = {
            DateTimeField: {
                'filter_class': filters.IsoDateTimeFilter
            }
        }
