from django_filters import rest_framework as filters
from django.db.models import DateTimeField

from re_restapi.models import ParkIpsumConf


class ParkIpsumConfFilterSet(filters.FilterSet):
    class Meta:
        model = ParkIpsumConf
        fields = {
            'park_id': ['exact'],
            'linked_ipsums': ['exact'],
            'last_send_timestamp': ['exact', 'lt', 'lte', 'gt', 'gte'],
        }
        filter_overrides = {
            DateTimeField: {
                'filter_class': filters.IsoDateTimeFilter
            }
        }
