from django_filters import rest_framework as filters

from re_restapi.models import PMS, PMSPendingRequest


class PMSFilterSet(filters.FilterSet):
    class Meta:
        model = PMS
        fields = [
            'id',
            'name',
            'abbrev',
        ]


class PMSPendingRequestFilterSet(filters.FilterSet):
    class Meta:
        model = PMSPendingRequest
        fields = [
            'id',
            'label',
            'registration_token',
            'authorized_parks',
        ]
