from django_filters import rest_framework as filters
from django.db.models import DateTimeField

from re_restapi.models import User


class InternalUserFilterSet(filters.FilterSet):
    # Base User Model
    is_readonly = filters.BooleanFilter()
    scheduled_expire_time__lt = filters.IsoDateTimeFilter(field_name='scheduled_expire_time', lookup_expr='lt')
    scheduled_expire_time__lte = filters.IsoDateTimeFilter(field_name='scheduled_expire_time', lookup_expr='lte')
    scheduled_expire_time__gt = filters.IsoDateTimeFilter(field_name='scheduled_expire_time', lookup_expr='gt')
    scheduled_expire_time__gte = filters.IsoDateTimeFilter(field_name='scheduled_expire_time', lookup_expr='gte')
    # Charge Feature
    charge__authorized_cs = filters.NumberFilter(field_name='chargefeature__authorized_cs')
    # Parkadmin Feature
    parkadmin__managed_parks = filters.NumberFilter(field_name='parkadminfeature__managed_parks')
    parkadmin__child_users = filters.NumberFilter(field_name='parkadminfeature__child_users')
    # PMSChild Feature
    pmschild__pms_admin_user = filters.NumberFilter(field_name='pmschildfeature__pms_admin_user')

    class Meta:
        model = User
        fields = [
            'id',
            'username',
            'email',
            'is_active',
            'is_staff',
            'is_superuser',
            'is_readonly',
            'on_expire_readonly',
            'on_expire_disable',
            'on_expire_appendtimestamp',
            'has_charge_feat',
            'has_parkadmin_feat',
            'has_guest_feat',
            'has_pmschild_feat',
        ]
        filter_overrides = {
            DateTimeField: {
                'filter_class': filters.IsoDateTimeFilter
            }
        }
