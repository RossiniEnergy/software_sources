import logging
import datetime
import pytz

from celery import shared_task
from django.db import transaction

from re_restapi.libs.orders import send_suspend, send_resume, send_recovery_state

from re_restapi.libs.postpower import task_post_power_bytecode

from re_restapi.models import Charge, ChargingStation

logger = logging.getLogger("re.libs.pilotage")


@shared_task(ignore_result=True, store_errors_even_if_ignored=True)
def task_process_message(args: [str]):
    try:
        command = args[0]
        if command == "asksuspend":
            park_name = args[1]
            park_bnum = int(args[2])
            suspend_cp(park_name, park_bnum)
        elif command == "askresume":
            park_name = args[1]
            park_bnum = int(args[2])
            resume_cp(park_name, park_bnum)
        elif command == "askcpstatus":
            park_name = args[1]
            send_recovery_state.delay(park_name)
        elif command == "m":
            park_name = args[1]
            coded_data = args[2]
            task_post_power_bytecode.delay(coded_data, park_name)
        else:
            logger.warning(f"Unknown command in message {args}")
    except IndexError:
        raise Exception(f"Failed parsing of message {args}")
    except ValueError:
        raise
    except Exception:
        raise Exception(f"Unknown error during parsing of message {args}")


def suspend_cp(park_name, park_bnum):
    """Function called when we receive from the rasp the asksuspend request"""
    try:
        cs = ChargingStation.objects.get(park__name=park_name, park_bnum=park_bnum)
    except ChargingStation.DoesNotExist:
        raise
    if cs.qrcodeid is None:
        raise ValueError("You can't suspend a CP without the QR Code because it's not in QR-Mode")
    if cs.suspended:
        raise ValueError("You can't suspend a CP already supended!")
    current_charge = Charge.objects.filter(stop=None, chargingstation=cs).order_by("-id").first()
    if current_charge is None:
        raise ValueError("You can't suspend a CP where there's no open charge")
    cs.suspended = True
    cs.save(update_fields=['suspended'])
    send_suspend.delay(park_name, park_bnum)


def resume_cp(park_name, park_bnum):
    """Function called when we receive from the rasp the askresume request"""
    try:
        cs = ChargingStation.objects.get(park__name=park_name, park_bnum=park_bnum)
    except ChargingStation.DoesNotExist:
        raise
    if not cs.suspended:
        raise ValueError("You can't resume a CP that isn't suspended!")
    current_charge = Charge.objects.filter(stop=None, chargingstation=cs).order_by("-id").first()
    if current_charge is None:
        # Unreachable
        raise ValueError("You can't resume a CP where there's no open charge!")
    with transaction.atomic():
        # In post_power the timeout on this is 5 minutes, we hardset this to have a 2 minutes timeout
        current_charge.last_nonzero_power_time = datetime.datetime.now(pytz.UTC) - datetime.timedelta(minutes=3)
        current_charge.save(update_fields=['last_nonzero_power_time'])
        cs.suspended = False
        cs.save(update_fields=['suspended'])
    send_resume.delay(park_name, park_bnum)
