import logging
import vat_moss.billing_address
import pycountry

from datetime import datetime
from collections import namedtuple

from reportlab.platypus import SimpleDocTemplate, Table, Paragraph, TableStyle, Image
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle

from django.conf import settings
from django.utils.text import slugify
from django.db.models import Sum, Count, F

from re_restapi.models import Charge, Park

from re_restapi.libs.reports.utils import _build_vocabulary

logger = logging.getLogger('re.libs.reports.park')

ParkReportEntry = namedtuple('ParkReportEntry', ['username', 'n_sessions', 'energy_wh', 'price', 'taxes'])


def _generate_park_report_data(park: Park, begin: datetime, end: datetime, vat_percentage):
    """
    retrieves the data needed to build the table for the admin report
    """
    logger.debug("Call to _generate_admin_report_data")
    # TODO: Be sure this distinct() works without breaking anything
    charges = Charge.objects.distinct().filter(chargingstation__park=park) \
        .filter(stop__gte=begin, stop__lt=end) \
        .values_list('user__id', 'user__username', 'user__has_guest_feat') \
        .annotate(n_sessions=Count('user__id'), total_energy=Sum('energy_wh')) \
        .annotate(total_price_cent=Sum(F('energy_wh') * F('chargingstation__price'))) \
        .exclude(total_energy=0) \
        .order_by('user__has_guest_feat', 'user__username')

    items = []

    for uid, username, is_guest, n_sessions, energy_wh, price in charges:
        if is_guest:
            username = f"guest_{uid}"
        price_eur = price / 100000
        taxes_eur = price_eur * vat_percentage / (100 + vat_percentage)
        items.append(ParkReportEntry(
            username, n_sessions,
            round(energy_wh / 1000, 1), round(price_eur, 2), round(taxes_eur, 2)
        ))
    return items


def make_park_report(park: Park, begin: datetime, end: datetime):
    """
    Creates the receipt for the given park between the requested timepoints, saves it on disk, and
    return the filename
    """
    logger.debug("Call to make_park_report")

    country_code = park.country_alpha2
    test_country = pycountry.countries.get(alpha_2=country_code)
    if not test_country:
        logger.warning(f"Country code {country_code} doesn't exists. Defaulting to FR.")
        country_code = "FR"
    postal_code = park.postal_code
    if postal_code == '' or postal_code is None:
        postal_code = '-'
    vat_percentage = int(vat_moss.billing_address.calculate_rate(country_code, postal_code, '-')[0] * 100)

    t = _build_vocabulary(country_code, vat_percentage)

    def generate_title():
        title_style = ParagraphStyle('title', fontSize=36, leading=46, alignment=2)
        return Paragraph(t("UsersReport"), title_style)

    def today():
        return Paragraph(
            f"<b>{t('Date')}:</b> {datetime.now().date()}", ParagraphStyle("today", alignment=2)
        )

    def logo():
        # TODO: take the logo
        return Image(settings.CORPORATE_LOGO_PATH, width=200, height=35, hAlign='LEFT')

    # TODO: insert number of chargepoints
    def info():
        address = park.address
        nation_obj = pycountry.countries.get(alpha_2=country_code)
        if not nation_obj:
            logger.warning(f"Invalid Nation {park.country_alpha2}, defaulting to France.")
            nation_obj = pycountry.countries.get(alpha_2="FR")
        final_address = f"{address}\n{park.postal_code}  {park.city}\n{nation_obj.name}"

        park_name = park.name
        email = park.email  # "123@123.sas"

        destination = f"{t('ForPark')} {park_name}\n" \
                      f"{t('From')} {begin.date()} {t('To')} {end.date()}\n\n{final_address}\n\n{email}\n"

        data = [[destination]]

        return Table(data, colWidths=150, hAlign="LEFT", style=TableStyle([
            ("VALIGN", (0, 0), (-1, -1), 'TOP')
        ]))

    def generate_price_table():
        """
        generates the table with cp prices
        """
        items = [*enumerate(park.chargingstation_set.order_by('park_bnum').values_list('price', flat=True), 1)]

        data = [[t("CP"), t("Price")]]
        data.extend([cp, f"{price / 100:.2f}"] for cp, price in items)

        cols = len(data[0])
        n_items = len(items)
        style = TableStyle([
            # Items
            ("BOX", (0, 0), (-1, n_items), 1, colors.black),
            ("GRID", (0, 0), (-1, n_items), 1, colors.black),
            ("BACKGROUND", (0, 0), (-1, 0), colors.gray),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("ALIGN", (0, 0), (-1, n_items), "CENTER"),
            ("BACKGROUND", (0, 1), (-1, n_items), colors.lightgreen),

            # Balance
            ("BOX", (cols - 2, n_items + 1), (-1, -1), 1, colors.black),
            ("GRID", (cols - 2, n_items + 1), (-1, -1), 1, colors.black),
            ("ALIGN", (cols - 2, n_items + 1), (cols, -1), "LEFT"),
            ("ALIGN", (cols - 1, n_items + 1), (cols, -1), "RIGHT"),
            ("BACKGROUND", (cols - 2, n_items + 1), (cols - 1, -1), colors.gray),
            ("TEXTCOLOR", (cols - 2, n_items + 1), (cols - 2, -1), colors.whitesmoke),
            ("BACKGROUND", (cols - 1, n_items + 1), (-1, -1), colors.lightgreen),
        ])

        return Table(data, style=style)

    def generate_user_table():
        """
        generates the table with all the data
        """
        items = _generate_park_report_data(park, begin, end, vat_percentage)
        total_energy = sum(item.energy_wh for item in items)
        users = [item for item in items if "guest_" not in item.username]
        guests = [item for item in items if "guest_" in item.username]
        credit_card_guest = ParkReportEntry(f"{t('CCG')}",
                                            sum(i.n_sessions for i in guests),
                                            round(sum(i.energy_wh for i in guests), 2),
                                            "",  # charge cost
                                            "")  # taxes

        total_txt = Paragraph(
            f"<b>{t('Total')}</b>", ParagraphStyle('total', textColor=colors.white, alignment=1)
        )
        total_n_txt = Paragraph(
            f"<b>{total_energy:.1f} kWh</b>", ParagraphStyle('total_n', alignment=1)
        )

        data = [[t("Username"), t("Sessions"), f"{t('Energy')} [kWh]", t("ChargePrice"), t("VAT")]]
        # data.append(["", "", "", "", t("VAT"), f"{taxes_eur:.2f} €"])
        data.extend([username, n_sessions, energy, price, taxes] for
                    username, n_sessions, energy, price, taxes in users + [credit_card_guest])
        data.append(['', '', '', total_txt, total_n_txt])

        cols = len(data[0])
        n_items = len(users) + 1
        style = TableStyle([
            # Items
            ("BOX", (0, 0), (-1, n_items), 1, colors.black),
            ("GRID", (0, 0), (-1, n_items), 1, colors.black),
            ("BACKGROUND", (0, 0), (-1, 0), colors.gray),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("ALIGN", (0, 0), (-1, n_items), "CENTER"),
            ("BACKGROUND", (0, 1), (-1, n_items), colors.lightgreen),

            # Balance
            ("BOX", (cols - 2, n_items + 1), (-1, -1), 1, colors.black),
            ("GRID", (cols - 2, n_items + 1), (-1, -1), 1, colors.black),
            ("ALIGN", (cols - 2, n_items + 1), (cols, -1), "LEFT"),
            ("ALIGN", (cols - 1, n_items + 1), (cols, -1), "RIGHT"),
            ("BACKGROUND", (cols - 2, n_items + 1), (cols - 1, -1), colors.gray),
            ("TEXTCOLOR", (cols - 2, n_items + 1), (cols - 2, -1), colors.whitesmoke),
            ("BACKGROUND", (cols - 1, n_items + 1), (-1, -1), colors.lightgreen),
        ])

        return Table(data, style=style)

    header = Table(
        [[logo(), generate_title()], [info(), today()]],
        style=TableStyle([("VALIGN", (0, 0), (-1, -1), 'TOP')])
    )
    table_title = Paragraph(
        f'<br />{t("Summary")}', style=ParagraphStyle('table_title', fontSize=15, leading=22, alignment=1)
    )
    footer = [
        Paragraph(t("Data retrieved")),
        Paragraph(t("Not an invoice"))
    ]

    parkname_slug = slugify(park.name)
    filename = f"{settings.PARK_REPORT_PATH}{parkname_slug}_{begin.date()}_{end.date()}.pdf"
    filename = filename.replace(" ", "")

    pdf = SimpleDocTemplate(filename, pagesize=A4, topMargin=50, leftMargin=50, rightMargin=50)
    # Auto overwrite of old files
    pdf.build([header, generate_price_table(), table_title, generate_user_table(), *footer])

    logger.info(
        f"Generated report for park {park.id} \"{park.name}\" on path \"{filename}\"")

    return filename
