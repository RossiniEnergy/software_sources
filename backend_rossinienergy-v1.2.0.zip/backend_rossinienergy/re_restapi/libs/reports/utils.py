import logging
import datetime
import pytz

logger = logging.getLogger('re.libs.reports.utils')


def _build_vocabulary(lang, vat_percentage):
    """
    given a language (en, fr, it), return a function which takes a string and returns the tuced
    token
    """
    logger.debug("Call to _build_vocabulary")
    vocabulary = {
        "Date": {"en": "Date", "fr": "Date", "it": "Data", "nl": "Datum"},
        "Report": {"en": "Report", "fr": "Recapitulatif", "it": "Resoconto", "nl": "Overzicht"},
        "UsersReport": {
            "en": "Users report",
            "fr": "Recapitulatif utilsateurs",
            "it": "Resoconto utenti",
            "nl": "Gebruikersoverzicht"
        },
        "Start": {"en": "Start", "fr": "Début", "it": "Inizio", "nl": "Begin"},
        "Stop": {"en": "Stop", "fr": "Fin", "it": "Fine", "nl": "Einde"},
        "From": {"en": "from", "fr": "du", "it": "dal", "nl": "van"},
        "To": {"en": "to", "fr": "au", "it": "al", "nl": "tot"},
        "ForPark": {"en": "For park", "fr": "Pour le parc", "it": "Per il parco", "nl": "Vor het park"},
        "Username": {"en": "User", "fr": "Utilisateur", "it": "Utente", "nl": "Gebruiker"},
        "Parkname": {"en": "Park name", "fr": "Parc", "it": "Parco", "nl": "Park"},
        "Energy": {
            "en": "Total consumed energy",
            "fr": "Total énergie consommée",
            "it": "Energia totale erogata",
            "nl": "Verbruikte energie"
        },
        "Sessions": {
            "en": "Total number of sessions",
            "fr": "Total nombre de sessions",
            "it": "Numero totale di sessioni",
            "nl": "Totaal aantal sessies"
        },
        "ChargePrice": {
            "en": "Charge cost [€]",
            "fr": "Cout de la recharge [€]",
            "it": "Costo ricarica [€]",
            "nl": "Opladen prijs [€]"
        },
        "CP": {
            "en": "Charge-point",
            "fr": "Borne",
            "it": "Colonnina",
            "nl": "Opladen"
        },
        "Price": {
            "en": "Price [€]",
            "fr": "Prix [€]",
            "it": "Prezzo [€]",
            "nl": "Prijs [€]"
        },
        "TotalPrice": {
            "en": "Total cost [€]",
            "fr": "Prix total [€]",
            "it": "Costo totale [€]",
            "nl": "Totale prijs [€]"
        },
        "CCG": {
            "en": "Sessions with credit card",
            "fr": "Sessions avec carte de credit",
            "it": "Sessioni con carta di credito",
            "nl": "Creditcard gast"
        },
        "VAT": {
            "en": f"of which VAT ({vat_percentage}%)",
            "fr": f"dont TVA ({vat_percentage}%)",
            "it": f"di cui IVA ({vat_percentage}%)",  # 22% ?
            "nl": f"Waarvan BTW ({vat_percentage}%)"  # 21% ?
        },
        "Total": {"en": "Total", "fr": "Total", "it": "Totale", "nl": "Totaal"},
        "Summary": {
            "en": "Electric vehicle charging stations: summary of charges",
            "fr": "Bornes de recharge pour voitures électriques: récapitulatif mensuel",
            "it": "Stazione di ricarica per veicoli elettrici: sommario mensile",
            "nl": "Oplaadpunten voor elektrische voertuigen: maandelijks overzicht"
        },
        "Data retrieved": {
            "en": "Data retrieved by RossiniEnergy",
            "fr": "Données récoltées par RossiniEnergy",
            "it": "Dati raccolti da RossiniEnergy",
            "nl": "Gegevens verzameld door RossiniEnergy"
        },
        "Not an invoice": {
            "en": "This document is not an invoice",
            "fr": "Ce document n'a pas de valeur comptable",
            "it": "Questo documento non ha valore contabile",
            "nl": "Dit document is geen factuur"
        },
    }
    if lang not in ["en", "fr", "it", "nl"]:
        lang = "en"
    return lambda term: vocabulary[term][lang]


def get_month_range(month, year):
    start = datetime.datetime(year=year, month=month, day=1, tzinfo=pytz.UTC)
    stop_month = month % 12 + 1
    stop_year = year
    if month > stop_month:
        stop_year += 1
    stop = datetime.datetime(year=stop_year, month=stop_month, day=1, tzinfo=pytz.UTC)
    return start, stop
