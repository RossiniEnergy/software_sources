from rest_framework.authentication import SessionAuthentication, BaseAuthentication
from django.conf import settings
from drf_spectacular.extensions import OpenApiAuthenticationExtension
from rest_framework.exceptions import AuthenticationFailed

from re_restapi.models import User


class CsrfExemptSessionAuthentication(SessionAuthentication):
    def enforce_csrf(self, request):
        return  # To not perform the csrf check previously happening


class CsrfExemptSessionScheme(OpenApiAuthenticationExtension):
    """This class self-register inside drf_spectacular. Clone of SessionScheme from drf_spectacular defaults"""
    target_class = CsrfExemptSessionAuthentication
    name = 'cookieAuth'
    priority = -1

    def get_security_definition(self, auto_schema):
        return {
            'type': 'apiKey',
            'in': 'cookie',
            'name': settings.SESSION_COOKIE_NAME,
        }


class TokenAuthentication(BaseAuthentication):

    def authenticate(self, request):
        token = request.META.get('HTTP_X_RETOKEN')
        if not token:
            return None  # Token missing
        try:
            user = User.objects.get(authorization_token=token)
        except User.DoesNotExist:
            raise AuthenticationFailed('Token unknown')
        return user, token


class TokenScheme(OpenApiAuthenticationExtension):
    """This class self-register inside drf_spectacular. Clone of SessionScheme from drf_spectacular defaults"""
    target_class = TokenAuthentication
    name = 'tokenAuth'
    priority = -1

    def get_security_definition(self, auto_schema):
        return {
            'type': 'apiKey',
            'in': 'header',
            'name': 'X_RETOKEN',
        }
