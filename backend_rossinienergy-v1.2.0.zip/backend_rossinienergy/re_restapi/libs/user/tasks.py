import datetime

import pytz
from celery import shared_task

from re_restapi.libs.charge import close_all_user_charges
from re_restapi.libs.payment_utils import cancel_payment_order
from re_restapi.libs.user.expire import expire_user
from re_restapi.models import User, PaymentOrder


@shared_task(ignore_result=True, store_errors_even_if_ignored=True)
def update_expired_user():
    for user in User.objects.filter(is_active=True, is_readonly=False,
                                    scheduled_expire_time__lt=datetime.datetime.now(pytz.UTC)):
        # TODO: Internalize close_all_user_charges and the cancel_payment_order inside expire_user
        expire_user(user)
        close_all_user_charges(user)
        # Release all associated PaymentOrder if guest. This is needed if the user don't opened a charge
        if user.has_guest_feat:
            related_payord = PaymentOrder.objects.filter(user=user, phase__gt=0, phase__lt=3)
            for payord in related_payord:
                cancel_payment_order(payord)
