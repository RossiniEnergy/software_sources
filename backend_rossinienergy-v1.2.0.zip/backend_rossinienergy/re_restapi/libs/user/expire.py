import logging
import datetime
import pytz

from django.db import transaction

from re_restapi.libs.user.sessions import delete_all_unexpired_sessions_for_user
from re_restapi.models import User

logger = logging.getLogger('re.libs.user.expire')


# TODO: Make close_all_charge as a expire_policy
def expire_user(user: User):
    logger.debug(f"Call to expire_user")
    if not isinstance(user, User):
        logger.critical("Called expire_user with an object that isn't a User instance")
        raise ValueError
    with transaction.atomic():
        updated_fields = set()
        # QUESTION: Make sense to keep this policy? In fact if read_only = expired the we need this always True
        if user.on_expire_readonly:  # No Permission
            user.is_readonly = True
            updated_fields.add('is_readonly')
        if user.on_expire_disable:  # Disable
            user.is_active = False
            updated_fields.add('is_active')
        if user.on_expire_appendtimestamp:
            # Format new username: oldusername_1638278860
            user.username = f"{user.username}_{int(datetime.datetime.now(pytz.UTC).timestamp())}"
            updated_fields.add('username')
        user.save(update_fields=list(updated_fields))
    # Revoke all the sessions for the expired user if it's a Guest
    logger.info(f"User {user.username} has been expired correctly with changes on {updated_fields}")
    if user.has_guest_feat:
        delete_all_unexpired_sessions_for_user(user)


# TODO: You can move the requirement directly inside the User query and calculate it inside the DB and just expire


