import datetime
import logging

import pytz

from celery import shared_task

from django.core.exceptions import MultipleObjectsReturned, ObjectDoesNotExist
from django.conf import settings
from django.db import transaction
from rest_framework.response import Response

from re_restapi.libs.advenir import advenir_send_charge
from re_restapi.libs.gireve_hooks import hook_update_gireve_status, hook_push_cdr_gireve
from re_restapi.libs.orders import send_order_on, send_order_off
from re_restapi.libs.payment import try_capture_money
from re_restapi.libs.exceptions import ExpiredUserError, ForbiddenGuestError, HTTPResponseWrapperError

from re_restapi.models import User, Charge, ChargingStation

logger = logging.getLogger("re.libs.charge")


@shared_task(ignore_result=True, store_errors_even_if_ignored=True)
def close_charge_for_offline_parks():
    charge_to_check = Charge.objects.filter(stop__isnull=True)
    for charge in charge_to_check:
        if charge.last_nonzero_power_time is not None:  # power == 0 and already_started_charge
            if charge.last_nonzero_power_time < \
                    datetime.datetime.now(pytz.utc) - datetime.timedelta(seconds=settings.USED_CHARGE_TIMEOUT):
                stop_opened_charge(charge)
        else:  # charge started but without recent charging
            if charge.user.has_guest_feat:  # Guest User
                timedelta_timeout = datetime.timedelta(seconds=settings.UNUSED_CHARGE_TIMEOUT_GUEST)
            else:  # other users
                timedelta_timeout = datetime.timedelta(seconds=settings.UNUSED_CHARGE_TIMEOUT_USER)
            if charge.start < datetime.datetime.now(pytz.utc) - timedelta_timeout:
                stop_opened_charge(charge)


def closing_charge_logic(current_charge: Charge):
    # TODO: Guarda se è meglio fare su Charge o su ChargingStation come start della query
    power = current_charge.chargingstation.last_power.power
    deltatime_seconds = 30
    deltatime_hours = deltatime_seconds / 60 / 60
    current_charge.energy_wh += power * deltatime_hours  # W * hr = Wh
    if power != 0:
        current_charge.last_nonzero_power_time = datetime.datetime.now(pytz.utc)
        current_charge.save()
    elif current_charge.last_nonzero_power_time is not None:  # power == 0 and already_started_charge
        current_charge.save()
        if current_charge.last_nonzero_power_time < \
                datetime.datetime.now(pytz.utc) - datetime.timedelta(seconds=settings.USED_CHARGE_TIMEOUT):
            logger.info("Closing charge {} for bnum {} because power stopped after erogation".format(
                current_charge.id, current_charge.chargingstation.bnum
            ))
            stop_opened_charge(current_charge)
    else:  # charge started but without recent charging
        current_charge.save()  # do this before stop_opened_charge for now
        if current_charge.user.has_guest_feat:  # Guest User
            timedelta_timeout = datetime.timedelta(seconds=settings.UNUSED_CHARGE_TIMEOUT_GUEST)
        else:  # other users
            timedelta_timeout = datetime.timedelta(seconds=settings.UNUSED_CHARGE_TIMEOUT_USER)
        if current_charge.start < datetime.datetime.now(pytz.utc) - timedelta_timeout:
            logger.info("Closing charge {} for bnum {} because first erogation timeout".format(
                current_charge.id, current_charge.chargingstation.bnum
            ))
            stop_opened_charge(current_charge)


def start_new_charge_bybnum(bnum: int, user: User):
    logger.debug(f"Call to start_new_charge_bybnum with bnum {bnum} and user {user.username}")
    try:
        cs = ChargingStation.objects.get(bnum=bnum)
    except (MultipleObjectsReturned, ObjectDoesNotExist) as ex:
        raise ex
    # Before anything, check if the user is expired or not
    if user.is_readonly:
        raise ExpiredUserError(user.username, 'start_new_charge_bybnum not allowed for expired')
    # Before creating a new charge, check if one is already existing
    already_started_charge = Charge.objects.filter(
        chargingstation=cs, stop__isnull=True
    )
    if already_started_charge.exists():
        logger.error(f"User {user.username} tried to duplicate charge on bnum {bnum}")
        return already_started_charge.first()
    # Before creating a new charge for a guest user, check if the user already has one
    if user.has_guest_feat:
        guest_charges = Charge.objects.filter(user=user)
        if guest_charges.exists():
            logger.warning("A guest user with a charge is asking to create another charge.")
            raise ForbiddenGuestError(user, "A guest user with a charge is asking to create another charge.")
    with transaction.atomic():
        current_charge = Charge(
            chargingstation=cs,
            start=datetime.datetime.now(pytz.utc),
            stop=None,
            user=user,
        )
        current_charge.save()
        # cs.last_updated = datetime.datetime.now(pytz.utc)
        cs.save(update_fields=['last_updated'])
        park = cs.park
        # park.last_updated = datetime.datetime.now(pytz.utc)
        park.save(update_fields=['last_updated'])
    if settings.ENABLE_GIREVE:
        hook_update_gireve_status.delay(cs.bnum)
    if user.has_guest_feat:
        sender_tag = 'guest'
    else:
        sender_tag = 'user'
    send_order_on.delay(cs.park.name, cs.park_bnum, sender_tag)
    logger.info(f"User {user.username} started a new charge (ID={current_charge.id}) on bnum {bnum}")
    # If the user requesting this is a Guest, extend the expiration by 6 days
    if user.has_guest_feat:
        scheduled_expire_time = datetime.datetime.now(pytz.UTC) + datetime.timedelta(days=6)
        user.scheduled_expire_time = scheduled_expire_time
        user.save(update_fields=['scheduled_expire_time'])
    return current_charge


def stop_opened_charge_bybnum(bnum: int):
    """
    Close an opened charge for a specific bnum. This function capture an eventual payment.
    This function just do the charge stopping operations.
    :param bnum: id of the chargingstation where the charge will be closed
    :return closed_charge: the Charge object the function closed
    """
    logger.debug(f"Call to stop_opened_charge_bybnum with bnum {bnum}")
    current_charge = \
        Charge.objects.distinct().filter(stop=None, chargingstation__bnum=bnum).order_by("-id").first()
    if current_charge is None:
        logger.error(f"Trying to stopping a charge on bnum {bnum} were no charge is started")
        raise HTTPResponseWrapperError(Response(status=500))
    stop_opened_charge(current_charge)
    return current_charge


def stop_opened_charge(charge: Charge):
    """
    Close an opened charge object. This function capture an eventual payment.
    This function just do the charge stopping operations.
    :param charge:
    :return:
    """
    logger.debug(f"Call to stop_opened_charge with charge.id {charge.id}")
    with transaction.atomic():
        cs = charge.chargingstation
        charge.stop = datetime.datetime.now(pytz.utc)
        charge.save()
        # cs.last_updated = datetime.datetime.now(pytz.utc)
        cs.suspended = False
        cs.save(update_fields=['last_updated', 'suspended'])
        park = cs.park
        # park.last_updated = datetime.datetime.now(pytz.utc)
        park.save(update_fields=['last_updated'])
    # We run the hook on Advenir and Gireve with a delay to help wait the complete commit of nested transaction on DB
    if settings.ENABLE_ADVENIR:
        advenir_send_charge.s(charge.id).apply_async(countdown=10)
    if settings.ENABLE_GIREVE:
        hook_push_cdr_gireve.s(charge.id).apply_async(countdown=10)
        hook_update_gireve_status.s(cs.bnum).apply_async(countdown=10)
    send_order_off.delay(cs.park.name, cs.park_bnum)
    logger.info(f"Closed a charge with ID {charge.id} on bnum {charge.chargingstation.bnum}")
    try_capture_money(charge)  # The expiration of the user if it's a guest is inside this function
    return charge


def close_all_user_charges(user: User):
    logger.debug(f"Call to close_all_user_charges for user {user.username}")
    # Close charges of specific user (example: expired ones)
    related_charge = Charge.objects.filter(user=user, stop__isnull=True)
    logger.info(f"Closing all opened charge for the user \"{user.username}\"...")
    for charge in related_charge:
        stop_opened_charge(charge)
