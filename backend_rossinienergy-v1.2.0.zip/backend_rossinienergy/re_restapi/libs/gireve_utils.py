import requests
import pycountry

from django.conf import settings
from re_restapi.models import ChargingStationPowerTable, Park, ChargingStation, Charge


def park_json(park):
    cs_list = park.chargingstation_set.all()
    if not cs_list.exists():
        return None
    country = pycountry.countries.get(alpha_2=park.country_alpha2)
    if not ChargingStationPowerTable.objects.filter(chargingstation__in=cs_list).exists():
        return None
    evses = []
    for cs in cs_list:
        evses.append(evse_json(cs))
    parkjson = {
        "id": park.name,
        "type": "UNKNOWN",
        "name": park.name,
        "address": park.address,
        "city": park.city,
        "postal_code": park.postal_code,
        "country": country.alpha_3,
        "coordinates": {
            "latitude": park.latitude,
            "longitude": park.longitude,
        },
        "operator": {
            "name": "FR*ROS",
        },
        "related_locations": [
            {
                "latitude": park.latitude,
                "longitude": park.longitude,
            }
        ],
        "opening_times": {"twentyfourseven": True},
        "last_updated": park.last_updated.strftime('%Y-%m-%dT%H:%M:%SZ'),
        "evses": evses,
    }
    return parkjson


def evse_json(cs):
    park = cs.park
    evse = {
        "status": get_gireve_status(cs),
        "capabilities": ["REMOTE_START_STOP_CAPABLE"],
        "connectors": [
            connector_json(cs)
        ],
        "coordinates": {
            "latitude": cs.park.latitude,
            "longitude": cs.park.longitude,
        },
        "uid": cs.evse_id,
        "evse_id": cs.evse_id,
        "last_updated": cs.last_updated.strftime('%Y-%m-%dT%H:%M:%SZ'),
    }
    return evse


def connector_json(cs):
    connector = {
        "id": "1",
        "standard": "IEC_62196_T2",
        "format": "SOCKET",  # ? socket = prise?, CABLE?
        "voltage": 230,
        "amperage": 32,
        "power_type": "AC_3_PHASE",
        "tariff_id": "1",
        "last_updated": cs.last_updated.strftime('%Y-%m-%dT%H:%M:%SZ'),
    }
    return connector


def evse_id_to_cs(evse_id):
    evse_id = evse_id.replace("FR*ROS*E", "")
    pid = evse_id.split("*")[0]
    pbnum = evse_id.split("*")[1]
    park = Park.objects.get(id=pid)
    cs = ChargingStation.objects.get(park_id=park.id, park_bnum=pbnum)
    return cs


def push_cdr_gireve(charge_id):
    charge = Charge.objects.get(pk=charge_id)
    total_power = charge.energy_wh  # Wh
    evse_id = charge.chargingstation.evse_id
    standard_gireve_price = 20  # cents per kWh (without VAT, 25 with VAT)
    # Calculate Net (VAT excluded)
    energy_total_cents = total_power * standard_gireve_price / 1000
    # Calculate VAT separation
    # vat_cents = energy_total_cents / 6  # 20% VAT in France 0.2/1.2 * total
    # Calculate final total order value
    # final_total_cost_cents = int(energy_total_cents - vat_cents)
    data = {
        "total_energy": total_power / 1000,  # kWh
        "start": str(charge.start),
        "stop": str(charge.stop),
        "evse_id": evse_id,
        "total_cost": energy_total_cents / 100,  # Eur Float without VAT
    }
    headers = {
        "Authorization": f"Token {settings.GIREVE_AUTH_TOKEN}"
    }
    requests.post(
        "https://gireve.rossinienergy.com/cdr", json=data, headers=headers, timeout=5
    )


def update_gireve_status(cs_bnum):
    cs = ChargingStation.objects.get(bnum=cs_bnum)
    status = get_gireve_status(cs)
    location_id = cs.park.name
    evse_id = cs.evse_id
    url = "https://gireve.rossinienergy.com/evse-status/{}/{}/{}".format(
        location_id, evse_id, status
    )
    headers = {
        "Authorization": f"Token {settings.GIREVE_AUTH_TOKEN}"
    }
    requests.get(url, headers=headers, timeout=5)


def get_gireve_status(cs):
    # QUESTION: right now we tell them is Available if there's no charge, not if the cs is really available
    if not cs.active_charge:
        return "AVAILABLE"
    else:
        return "CHARGING"
