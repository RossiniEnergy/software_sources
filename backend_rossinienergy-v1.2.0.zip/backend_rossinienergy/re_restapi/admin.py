from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from re_restapi.models import *


# TODO: Register your models here.


# noinspection PyMethodMayBeStatic
class BaseReadOnlyAdminMixin:
    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


class ChargeModelAdmin(BaseReadOnlyAdminMixin, admin.ModelAdmin):
    pass


admin.site.register(User, UserAdmin)
admin.site.register(Charge, ChargeModelAdmin)
