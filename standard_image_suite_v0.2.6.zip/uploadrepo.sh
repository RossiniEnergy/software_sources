#!/bin/bash
# Required pip3 pip-tools and PATH update
# apt install dh-virtualenv devscripts dpkg-sig
# Remember to have the GPG key in the keyring
#  and the SSH key on the remote server authorized_keys

#####################################################################
# REMEMBER TO CONFIGURE CORRECTLY GPG ON THE LOCAL MACHINE AND THE  #
# REMOTE SERVER, SEE AUTOUPDATE.md FOR MORE INFORMATIONS            #
#####################################################################

set -euo pipefail

readonly KEYNAME="RossiniEnergy_dpkg1"

git pull

read -r -p "Insert the version number in the format major.minor.rev: " VERSION
read -r -p "Are you sure you want to use the new version v$VERSION? [y/N] " asked
case "$asked" in
    [yY][eE][sS]|[yY]) 
	#nothing to do
        ;;
    *)
        echo "Aborting"
	exit 1
        ;;
esac
read -r -p "Insert changelog entry: " changelogentry
dch -v "$VERSION" "$changelogentry"
dch -r --distribution stable ignored

echo "Tagging and committing Release v$VERSION to git"
git add debian/changelog
git commit -m "Deploying Release v$VERSION"
git tag -a "v$VERSION" -m "Release v$VERSION"
git push
git push origin "v$VERSION"

read -r -p "Do you want to update the debian/control dependecies? [y/N] " asked
case "$asked" in
    [yY][eE][sS]|[yY]) 
	sudo mk-build-deps --install debian/control
	sudo apt install "./standard-image-suite-build-deps_${VERSION}_all.deb"
	rm -f "standard-image-suite-build-deps_${VERSION}_all.deb"
        ;;
    *)
        #nothing to do
        ;;
esac

echo "Building package..."
dpkg-buildpackage -uc -us
readonly PKGFILENAME="standard-image-suite_${VERSION}_armhf.deb"
readonly SSHADDR="builduser@buildstation"

read -r -s -p "Insert the Key Passphrase: " PASSPHRASE

cd ..
echo "sign the package..."
readonly TMPFILENAME=$(mktemp)
echo "$PASSPHRASE" > "$TMPFILENAME"
dpkg-sig -k ${KEYNAME} --gpg-options="--batch --no-tty --passphrase-file $TMPFILENAME" --sign repo "$PKGFILENAME"
rm "$TMPFILENAME"

echo "Uploading package..."
scp "$PKGFILENAME" ${SSHADDR}:/www/repo/armhf/

# shellcheck disable=SC2087
ssh -T $SSHADDR << EOF
cd /www/repo
apt-ftparchive --arch armhf packages armhf > Packages
gzip -k -f Packages
apt-ftparchive release . > Release
rm -fr Release.gpg; echo $PASSPHRASE | gpg --batch --yes --passphrase-fd 0 --default-key ${KEYNAME} -abs -o Release.gpg Release
rm -fr InRelease; echo $PASSPHRASE | gpg --batch --yes --passphrase-fd 0 --default-key ${KEYNAME} --clearsign -o InRelease Release
EOF

echo "Update completed"


