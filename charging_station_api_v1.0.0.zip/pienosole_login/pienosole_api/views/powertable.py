import datetime
import json
import logging
import binascii

import pytz

from celery import shared_task

from django.core.exceptions import MultipleObjectsReturned, ObjectDoesNotExist
from django.http import HttpResponse
from django.db import transaction
from django.views.decorators.csrf import csrf_exempt

from ..models import Park, BuildingInfos, Charge, ChargingStation, Power
from ..libs_v2.charge import stop_opened_charge


logger = logging.getLogger("api.powertable")


@shared_task(ignore_result=True)
def task_post_power_bytecode(coded_data, park_name):
    """
    PROTOCOL VERSION 1:
        data are bytestring with this structure: bytenumberx content (type) firstbytenumber-lastbytenumberinclusive
            1x bytecode version (unsigned integer) 0
            3x software version (major.minor.rev) 1-3
            3x available power (signed integer) 4-6
            3x production (signed integer) 7-9
            3x consumption (signed integer) 10-12
            8x timestamp UTC (unsigned integer 64 bit) 13-20
            1x number N of CP in this metric (unsigned integer) 21
            3xN power consumed from CP (unsigned integer) 22-24

        total bytesyze: 25 (1CP) - 46 (8 CP)
        Every number is encoded as BIG ENDIAN.
        Note that in this list the interval is INCLUSIVE, in the list operator in Python the last number is EXCLUSIVE:
            software version is bytes from 1 to 3 (1,2,3) but the list retrieve is data[1:4]=>(1,2,3)
        The Encoding used is: the n-byte contain the number as ASCII characters corresponding to the number that we
            wanted to send for example if we want to send 94 the byte will be \x61 so the bytestring will contain the
            corresponding char 'a'. For example the number 12000 coded for 3 byte will be the bytestring b'\x00.\xe0'
            obtained with the function `numbervariable.to_bytes(nbytes, 'big')`
    """
    # Check park existance
    query = Park.objects.filter(name=park_name).count()
    if query == 0:
        logger.debug(f"Tried post_power on inexistent park {park_name}")
        return  # HttpResponse(status=404)
    elif query > 1:
        logger.critical(f"Tried post_power on duplicated park {park_name}")
        return  # HttpResponse(status=500)
    bytestring = binascii.a2b_base64(coded_data.encode())
    # Retrieve protocol version
    protocol_version = bytestring[0]
    if protocol_version == 1:
        # Retrieve software version
        major, minor, revision = bytestring[1:4]
        software_version = f"{major}.{minor}.{revision}"
        # Available Power
        available_power = int.from_bytes(bytestring[4:7], 'big')
        # Production
        production = int.from_bytes(bytestring[7:10], 'big')
        # Consumption
        consumption = int.from_bytes(bytestring[10:13], 'big')
        # Timestamp UTC
        timestamp_raw = int.from_bytes(bytestring[13:21], 'big')
        timestamp = datetime.datetime.fromtimestamp(timestamp_raw, pytz.UTC)
        # Number of CP
        cp_quantity = bytestring[21]
        # CP Power Consumption
        cp_powers = []
        for i in range(cp_quantity):
            cp = int.from_bytes(bytestring[22 + i * 3:25 + i * 3], 'big')
            cp_powers.append(cp)
        # return
        post_power_elaboration(park_name,
                               software_version,
                               available_power,
                               production, consumption,
                               timestamp,
                               cp_powers)
    else:
        logger.warning(f"Received post_power_bytecode with unrecognized protocol_version {protocol_version}")
        return  # HttpResponse(status=400)


@csrf_exempt
def post_power_bytecode(request, park_name):
    coded_data = binascii.b2a_base64(request.body)
    task_post_power_bytecode.delay(coded_data.decode(), park_name)
    return HttpResponse()


def post_power_elaboration(park_name, software_version, available_power,
                           production, consumption, _timestamp, cp_powers):
    try:
        park = Park.objects.get(name=park_name)
    except (ObjectDoesNotExist, MultipleObjectsReturned):
        logger.error(f"UNREACHABLE in post_power on park {park_name}")
        return HttpResponse(status=500)
    # Software Version update
    park.software_version = software_version
    park.save()
    # BuildingInfos
    bi = BuildingInfos(
        park=park,
        # timestamp=data.get("timestamp"),
        timestamp=datetime.datetime.now(pytz.utc),
        production=production,
        consumption=consumption,
        available_power=available_power,
    )
    bi.save()
    # Prepare Power Objects
    cps_with_error = []
    power_objects = []
    edited_cs = []
    for k, power in enumerate(cp_powers, start=1):
        try:
            cs = ChargingStation.objects.get(park=park, park_bnum=k)
            p = Power(
                power=power,
                # TODO: Implement the use of raspberry's timestamp, with a dynamic integration stepping
                # timestamp=data.get("timestamp"),
                timestamp=datetime.datetime.now(pytz.utc),
                chargingstation=cs,
            )
            cs.last_power = p
            power_objects.append(p)
            edited_cs.append(cs)
        except ObjectDoesNotExist:
            cps_with_error.append(k)
            continue
        current_charge = Charge.objects.filter(stop=None, chargingstation=cs).order_by("-id").first()
        if current_charge is not None:
            deltatime_seconds = 30
            deltatime_hours = deltatime_seconds / 60 / 60
            current_charge.energy_wh += power * deltatime_hours  # W * hr = Wh
            if power != 0:
                current_charge.last_nonzero_power_time = datetime.datetime.now(pytz.utc)
                current_charge.save()
            elif current_charge.last_nonzero_power_time is not None:  # power == 0 and already_started_charge
                current_charge.save()
                if current_charge.last_nonzero_power_time < \
                        datetime.datetime.now(pytz.utc) - datetime.timedelta(minutes=5):
                    logger.debug("Closing charge {0} for bnum {1} because power stopped after erogation".format(
                        current_charge.id, current_charge.chargingstation.bnum
                    ))
                    stop_opened_charge(current_charge)
            else:  # charge started but without recent charging
                current_charge.save()  # do this before stop_opened_charge for now
                if current_charge.user.userconfig.guest:  # Guest User
                    timedelta_timeout = datetime.timedelta(minutes=30)
                else:  # other users
                    timedelta_timeout = datetime.timedelta(hours=12)
                if current_charge.start < datetime.datetime.now(pytz.utc) - timedelta_timeout:
                    logger.debug("Closing charge {0} for bnum {1} because first erogation timeout".format(
                        current_charge.id, current_charge.chargingstation.bnum
                    ))
                    stop_opened_charge(current_charge)
    # Bulk create Power Objects
    #    This automatically append pk because our backend is PostgreSQL
    #    https://docs.djangoproject.com/en/3.2/ref/models/querysets/#bulk-create
    Power.objects.bulk_create(power_objects)
    # Save last_power reference
    with transaction.atomic():
        for cs in edited_cs:
            cs.save(update_fields=['last_power'])
    # Charge Managment Interrupts
    if len(cps_with_error) != 0:
        formatted_list = list(map(int, cps_with_error))
        logger.debug(f"Tried post_power on chargingstations {park_name}:{formatted_list} but they don't exist.")
    return HttpResponse(status=200)


@shared_task(ignore_result=True)
def task_post_power_legacy(data):
    """
    data = {
            "park_name": park_name,
            "timestamp":timestamp,
            1:value,
            2:value,
            x:value}
    """
    # TODO: When you need to edit post_power_elaboration make sure to unify this function with that
    # QUESTION: Why this isinstance with double json load?
    if isinstance(data, str):
        data = json.loads(data)
        park_name = data.get("park_name")
    else:
        logger.warning("Bad post_power request")
        return  # HttpResponse(status=400)
    try:
        park = Park.objects.get(name=park_name)
    except ObjectDoesNotExist:
        logger.debug(f"Tried post_power on inexistent park {park_name}")
        return  # HttpResponse(status=400)
    except MultipleObjectsReturned:
        logger.critical(f"Tried post_power on duplicated park {park_name}")
        return  # HttpResponse(status=400)
    # Software Version update
    software_version = data.get("version", "")
    if software_version != "":
        park.software_version = software_version
        park.save()
    # QUESTION: We know the cp have a specific order and naming with a max number.
    #  We can use this to reduce the bloat about "keys and deleting the used one"
    #  We need more info about the old one, to know if this is possible.
    keys = list(data.keys())
    # TODO: to use the REAL timestamp from the raspberry we need a dynamic integration for energy calculation
    try:
        keys.remove("timestamp")
    except ValueError:
        pass
    try:
        keys.remove("park_name")
    except ValueError:
        pass
    try:
        keys.remove("pannels")
        # QUESTION: I think this is to support old raspberry that used the pannels for "available_power"
    except ValueError:
        pass
    try:
        keys.remove("version")
    except ValueError:
        pass

    if (
            "production" in keys
            or "consumption" in keys
            or "available_power" in keys
    ):
        bi = BuildingInfos(
            park=park,
            # timestamp=data.get("timestamp"),
            timestamp=datetime.datetime.now(pytz.utc),
            production=data.get("production", 0),
            consumption=data.get("consumption", 0),
            available_power=data.get("available_power", 0),
        )
        bi.save()
        try:
            keys.remove("production")
        except ValueError:
            pass
        try:
            keys.remove("consumption")
        except ValueError:
            pass
        try:
            keys.remove("available_power")
        except ValueError:
            pass

    cps_with_error = []
    for k in keys:
        try:
            cs = ChargingStation.objects.get(park=park, park_bnum=int(k))
            power = data.get(k)
            p = Power(
                power=power,
                # TODO: Implement the use of raspberry's timestamp, with a dynamic integration stepping
                # timestamp=data.get("timestamp"),
                timestamp=datetime.datetime.now(pytz.utc),
                chargingstation=cs,
            )
            p.save()
            cs.last_power = p
            cs.save()
            current_charge = Charge.objects.filter(stop=None, chargingstation=cs).order_by("-id").first()
            if current_charge is not None:
                deltatime_seconds = 30
                deltatime_hours = deltatime_seconds / 60 / 60
                current_charge.energy_wh += power * deltatime_hours  # W * hr = Wh
                if power != 0:
                    current_charge.last_nonzero_power_time = datetime.datetime.now(pytz.utc)
                    current_charge.save()
                elif current_charge.last_nonzero_power_time is not None:  # power == 0 and already_started_charge
                    current_charge.save()
                    if current_charge.last_nonzero_power_time < \
                            datetime.datetime.now(pytz.utc) - datetime.timedelta(minutes=5):
                        logger.debug("Closing charge {0} for bnum {1} because power stopped after erogation".format(
                            current_charge.id, current_charge.chargingstation.bnum
                        ))
                        stop_opened_charge(current_charge)
                else:  # charge started but without recent charging
                    current_charge.save()  # do this before stop_opened_charge for now
                    if current_charge.user.userconfig.guest:  # Guest User
                        timedelta_timeout = datetime.timedelta(minutes=30)
                    else:  # other users
                        timedelta_timeout = datetime.timedelta(hours=12)
                    if current_charge.start < datetime.datetime.now(pytz.utc) - timedelta_timeout:
                        logger.debug("Closing charge {0} for bnum {1} because first erogation timeout".format(
                            current_charge.id, current_charge.chargingstation.bnum
                        ))
                        stop_opened_charge(current_charge)
        except ObjectDoesNotExist:
            cps_with_error.append(k)
            continue
    if len(cps_with_error) != 0:
        formatted_list = list(map(int, cps_with_error))
        logger.debug(f"Tried post_power on chargingstations {park_name}:{formatted_list} but they don't exist.")
    return  # HttpResponse(status=200)


@csrf_exempt
def post_power_legacy(request):
    data = json.loads(request.body)
    task_post_power_legacy.delay(data)
    return HttpResponse()
