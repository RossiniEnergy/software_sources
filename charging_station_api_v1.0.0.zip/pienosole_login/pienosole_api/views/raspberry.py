import logging
import json

from django.core.exceptions import MultipleObjectsReturned, ObjectDoesNotExist
from django.http import HttpResponse

from ..models import Charge, ChargingStation, Park

logger = logging.getLogger('api.chargingstation')


def get_is_charging(_request, bnum):
    logger.debug(f"Call to get_is_charging for bnum {bnum}")
    last_charge = (
        Charge.objects.filter(chargingstation_id=bnum).order_by("-id").first()
    )
    if last_charge is None:
        result = False
    else:
        result = last_charge.stop is None
    ret_val = json.dumps({"ischarging": result})
    return HttpResponse(ret_val)


def get_cs_id_list(_request, park_name):
    try:
        park = Park.objects.get(name=park_name)
    except (MultipleObjectsReturned, ObjectDoesNotExist):
        logger.debug(f"Failed to retrieve the park {park_name}")
        return HttpResponse(status=400)
    cs_query = ChargingStation.objects.filter(park=park).order_by("park_bnum").values_list("bnum", flat=True)
    ret_val = {"cs_id_list": list(cs_query)}
    return HttpResponse(json.dumps(ret_val))
