import datetime
import logging
import json

import pytz

from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt

from .gireve_utils import park_json, evse_id_to_cs, evse_json, connector_json
from ..models import (
    Park,
)
from ..libs_v2.charge import start_new_charge_bybnum, stop_opened_charge_bybnum
from ..libs_v2.exceptions import ForbiddenGuestError


logger = logging.getLogger('api.gireve')


@csrf_exempt
def get_gireve_location_params(
        request, location_id, evse_uid=None, connector_id=None
):
    if not request.user.is_authenticated:
        return HttpResponse(status=403)
    park = Park.objects.get(name=location_id)
    if not park.accept_gireve:
        return HttpResponse("Gireve requested a park that not accept it", status=500)
    if evse_uid is None:
        # Return Park
        pjson = park_json(park)
        data = {"data": [pjson]}
        response = JsonResponse(data, safe=False)
    else:
        if connector_id is None:
            # Return evse
            cs = evse_id_to_cs(evse_uid)
            ejson = evse_json(cs)
            data = {"data": [ejson]}
            response = JsonResponse(data, safe=False)
        else:
            # Return connector
            if str(connector_id) != "1":  # 1 is the only used connector id
                return HttpResponse("Gireve requested a unused connector", status=500)
            cs = evse_id_to_cs(evse_uid)
            cjson = connector_json(cs)
            data = {"data": [cjson]}
            response = JsonResponse(data, safe=False)
    return response


@csrf_exempt
def get_gireve_location(request):
    if not request.user.is_authenticated:
        return HttpResponse(status=403)
    limit = int(request.GET.get("limit", 10))
    offset = int(request.GET.get("offset", 0))
    date_from = request.GET.get(
        "date_from", datetime.datetime(year=2000, month=1, day=1, tzinfo=pytz.utc)
    )
    date_to = request.GET.get(
        "date_to", datetime.datetime.now(pytz.utc) + datetime.timedelta(days=1)
    )

    # the order in theory is creation_date but a lot of park have the same one. ID is better and equiv in our case.
    park_query = Park.objects.all().filter(last_updated__range=(date_from, date_to), accept_gireve=True).order_by("id")
    park_paginated = (
        park_query[offset: offset + limit]
    )
    totalcount = park_query.count()
    park_json_list = []
    for park in park_paginated:
        pjson = park_json(park)
        if pjson is not None:
            park_json_list.append(pjson)
    data = {"data": park_json_list}
    response = JsonResponse(data, safe=False)
    new_offset = offset + limit
    if not new_offset >= totalcount:  # If is the last page...
        # make the Link header
        response["Link"] = (
                "<"
                + request.build_absolute_uri("?")
                + "?"
                + (
                    "&date_from=" + request.GET["date_from"]
                    if "date_from" in request.GET
                    else ""
                )
                + (
                    "&date_to=" + request.GET["date_to"]
                    if "date_to" in request.GET
                    else ""
                )
                + "&limit=" + str(limit)
                + "&offset=" + str(new_offset)
                + '>; rel="next"'
        )
        response["Link"] = response["Link"].replace('?&', '?')
    response["X-Total-Count"] = totalcount
    response["X-Limit"] = limit
    return response


@csrf_exempt
def start_evse(request, evse_uid):
    # FIXME: this is the legacy chargingstation_viewset.start_charge() code!
    if not request.user.is_authenticated:
        return HttpResponse(status=403)
    cs = evse_id_to_cs(evse_uid)
    pk = cs.bnum
    logger.debug(f"Received request on start_charge for bnum {pk}")
    if not request.user.is_authenticated:
        logger.warning(f"Requested start_charge on {pk} without authentication")
        return HttpResponse(status=401)
    # Expired user can't start a charge
    if request.user.userconfig.expired:
        logger.info(f"Requested start_charge on {pk} with an expired user \"{request.user.username}\"")
        return HttpResponse(status=401)
    # Check if the user has the permissions
    if not request.user.is_superuser:
        if int(pk) not in request.user.userconfig.authorized_bnum:
            logger.info(f"Requested start_charge on {pk} with an unauthorized user \"{request.user.username}\"")
            return HttpResponse(status=401)
    # FIXME: For now the frontend doesn't expect an error with a double charge,
    #  atm we dont do anything in case of already existing charge (use exceptions and and status!=200)
    try:
        new_charge = start_new_charge_bybnum(pk, request.user)
    except ForbiddenGuestError as e:
        return HttpResponse(e.message, status=403)
    json_start = {"start": str(new_charge.start)}
    return HttpResponse(json.dumps(json_start), status=200)


@csrf_exempt
def stop_evse(request, evse_uid):
    if not request.user.is_authenticated:
        return HttpResponse(status=403)
    cs = evse_id_to_cs(evse_uid)
    pk = cs.bnum
    logger.debug(f"Received request on start_charge for bnum {pk}")
    if not request.user.is_authenticated:
        logger.warning(f"Requested stop_charge on {pk} without authentication")
        return HttpResponse(status=401)
    # Expired user can't manually stop a charge
    if request.user.userconfig.expired:
        logger.info(f"Requested stop_charge on {pk} with an expired user \"{request.user.username}\"")
        return HttpResponse(status=401)
    # Check if the user has the permissions
    if not request.user.is_superuser:
        if int(pk) not in request.user.userconfig.authorized_bnum:
            logger.info(f"Requested start_charge on {pk} with an unauthorized user \"{request.user.username}\"")
            return HttpResponse(status=401)
    _closed_charge = stop_opened_charge_bybnum(pk)
    return HttpResponse(status=200)
