from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework import status

from ..libs_v2.ipsum import encode_bytecode_ipsumpark

from ..models import Park


@csrf_exempt
def manual_retrieve_ipsum(_request, park_name):
    # Manual Pull API for raspberry to take in one swipe all the ipsum of their park.
    try:
        park = Park.objects.get(name=park_name)
    except Park.DoesNotExist:
        return HttpResponse("Park doesn't exist", status=status.HTTP_404_NOT_FOUND)
    # noinspection PyBroadException
    try:
        value = encode_bytecode_ipsumpark(park).decode()
    except Exception as ex:
        return HttpResponse(ex.args[0], status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    output = {'available_power': value}
    return JsonResponse(output)
