import pytz
import logging
import vat_moss.billing_address
import pycountry

from datetime import datetime
from collections import namedtuple

from reportlab.platypus import SimpleDocTemplate, Table, Paragraph, TableStyle, Image
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle

from django.conf import settings
from django.core.exceptions import ObjectDoesNotExist, MultipleObjectsReturned
from django.http import FileResponse, HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.text import slugify
from django.db.models import Sum, Count, F

from ..models import Charge, PaymentOrder, MoneyDestination, Park

import os

logger = logging.getLogger('api.reports')


def _build_vocabulary(lang, vat_percentage):
    """
    given a language (en, fr, it), return a function which takes a string and returns the tuced
    token
    """
    logger.debug("Call to _build_vocabulary")
    vocabulary = {
        "Date": {"en": "Date", "fr": "Date", "it": "Data", "nl": "Datum"},
        "Report": {"en": "Report", "fr": "Recapitulatif", "it": "Resoconto", "nl": "Overzicht"},
        "UsersReport": {
            "en": "Users report",
            "fr": "Recapitulatif utilsateurs",
            "it": "Resoconto utenti",
            "nl": "Gebruikersoverzicht"
        },
        "Start": {"en": "Start", "fr": "Début", "it": "Inizio", "nl": "Begin"},
        "Stop": {"en": "Stop", "fr": "Fin", "it": "Fine", "nl": "Einde"},
        "From": {"en": "from", "fr": "du", "it": "dal", "nl": "van"},
        "To": {"en": "to", "fr": "au", "it": "al", "nl": "tot"},
        "ForPark": {"en": "For park", "fr": "Pour le parc", "it": "Per il parco", "nl": "Vor het park"},
        "Username": {"en": "User", "fr": "Utilisateur", "it": "Utente", "nl": "Gebruiker"},
        "Parkname": {"en": "Park name", "fr": "Parc", "it": "Parco", "nl": "Park"},
        "Energy": {
            "en": "Total consumed energy",
            "fr": "Total énergie consommée",
            "it": "Energia totale erogata",
            "nl": "Verbruikte energie"
        },
        "Sessions": {
            "en": "Total number of sessions",
            "fr": "Total nombre de sessions",
            "it": "Numero totale di sessioni",
            "nl": "Totaal aantal sessies"
        },
        "ChargePrice": {
            "en": "Charge cost [€]",
            "fr": "Cout de la recharge [€]",
            "it": "Costo ricarica [€]",
            "nl": "Opladen prijs [€]"
        },
        "CP": {
            "en": "Charge-point",
            "fr": "Borne",
            "it": "Colonnina",
            "nl": "Opladen"
        },
        "Price": {
            "en": "Price [€]",
            "fr": "Prix [€]",
            "it": "Prezzo [€]",
            "nl": "Prijs [€]"
        },
        "TotalPrice": {
            "en": "Total cost [€]",
            "fr": "Prix total [€]",
            "it": "Costo totale [€]",
            "nl": "Totale prijs [€]"
        },
        "CCG": {
            "en": "Sessions with credit card",
            "fr": "Sessions avec carte de credit",
            "it": "Sessioni con carta di credito",
            "nl": "Creditcard gast"
        },
        "VAT": {
            "en": f"of which VAT ({vat_percentage}%)",
            "fr": f"dont TVA ({vat_percentage}%)",
            "it": f"di cui IVA ({vat_percentage}%)",  # 22% ?
            "nl": f"Waarvan BTW ({vat_percentage}%)"  # 21% ?
        },
        "Total": {"en": "Total", "fr": "Total", "it": "Totale", "nl": "Totaal"},
        "Summary": {
            "en": "Electric vehicle charging stations: summary of charges",
            "fr": "Bornes de recharge pour voitures électriques: récapitulatif mensuel",
            "it": "Stazione di ricarica per veicoli elettrici: sommario mensile",
            "nl": "Oplaadpunten voor elektrische voertuigen: maandelijks overzicht"
        },
        "Data retrieved": {
            "en": "Data retrieved by RossiniEnergy",
            "fr": "Données récoltées par RossiniEnergy",
            "it": "Dati raccolti da RossiniEnergy",
            "nl": "Gegevens verzameld door RossiniEnergy"
        },
    }
    if lang not in ["en", "fr", "it", "nl"]:
        lang = "en"
    return lambda term: vocabulary[term][lang]


def _generate_admin_report_data(moneydest: MoneyDestination, begin: datetime, end: datetime):
    """
    retrieves the data needed to build the table for the admin report
    """
    Entry = namedtuple('Entry', ['start', 'stop', 'parkname', 'qrcodeid', 'energy', 'energy_eur'])

    logger.debug("Call to _generate_admin_report_data")
    charges = Charge.objects.filter(chargingstation__money_receiver=moneydest,
                                    stop__isnull=False,
                                    stop__gte=begin,
                                    stop__lte=end,
                                    user__userconfig__guest=True,
                                    energy_wh__gt=0,
                                    ).order_by("start")

    items = []

    for charge in charges:
        try:
            paymentorder = PaymentOrder.objects.get(guest_user=charge.user)
        except ObjectDoesNotExist:
            logger.error(f"Skipping the charge {charge.id} for PaymentOrder does not exist")
            continue
        except MultipleObjectsReturned:
            logger.error(f"Skipping the charge {charge.id} for PaymentOrder duplicated")
            continue
        start = charge.start
        stop = charge.stop
        parkname = charge.chargingstation.park.name
        qrcodeid = charge.chargingstation.qrcodeid
        energy = charge.energy_wh
        energy_eur = paymentorder.energy_cents / 100
        if (paymentorder.energy_cents + paymentorder.stripe_comm_cents) < 50:
            continue

        items.append(Entry(start, stop, parkname, qrcodeid, energy, energy_eur))
    return items


def make_admin_report(moneydest: MoneyDestination, begin: datetime, end: datetime):
    """
    Creates the receipt for the given money receiver between the requested timepoints, saves it on
    disk, and return the filename
    """
    logger.debug("Call to make_admin_report")
    # Compute VAT Percentage
    country_code = moneydest.vat_country_alpha2
    test_country = pycountry.countries.get(alpha_2=country_code)
    if not test_country:
        logger.warning(f"Country code {country_code} doesn't exists. Defaulting to FR.")
        country_code = "FR"
    postal_code = moneydest.postal_code
    if postal_code == '' or postal_code is None:
        postal_code = '-'
    vat_percentage = int(vat_moss.billing_address.calculate_rate(country_code, postal_code, '-')[0] * 100)

    t = _build_vocabulary(moneydest.receipt_language, vat_percentage)

    def generate_title():
        title_style = ParagraphStyle('title', fontSize=36, leading=46, alignment=2)
        return Paragraph(t("Report"), title_style)

    def today():
        return Paragraph(
            f"<b>{t('Date')}:</b> {datetime.now().date()}", ParagraphStyle("today", alignment=2)
        )

    def logo():
        # TODO: take the logo
        return Image(settings.CORPORATE_LOGO_PATH, width=200, height=35, hAlign='LEFT')

    def parties():
        rossinienergy = (
            "RossiniEnergy\n\n5 rue Horus\nParc de la Haute Borne\n59650  Villeneuve d’Ascq\n"
            "France\n\n+33 (0)3 74 09 01 05\ninfo@rossinienergy.com\n"
        )

        address = moneydest.address_1
        if moneydest.address_2 != '':
            address += '\n' + moneydest.address_2
        nation_obj = pycountry.countries.get(alpha_2=moneydest.country_alpha2)
        if not nation_obj:
            logger.warning(f"Invalid Nation {moneydest.country_alpha2}, defaulting to France.")
            nation_obj = pycountry.countries.get(alpha_2="FR")
        final_address = f"{address}\n{moneydest.postal_code}  {moneydest.city}\n{nation_obj.name}"

        society_name = moneydest.society_name  # "Polnareffland"
        telephone = moneydest.phone_number  # "123"
        email = moneydest.email  # "123@123.sas"

        destination = f"{society_name}\n\n{final_address}\n\n{telephone}\n{email}\n"

        data = [
            # [Paragraph(f"<b>{t('From')}:</b>"), Paragraph(f"<b>{t('To')}:</b>")],
            [rossinienergy, destination]
        ]

        return Table(data, colWidths=150, hAlign="LEFT", style=TableStyle([
            ("VALIGN", (0, 0), (-1, -1), 'TOP')
        ]))

    def generate_table(vat_perc):
        """
        generates the table with all the data
        """
        items = _generate_admin_report_data(moneydest, begin, end)
        total_eur = sum(i.energy_eur for i in items)
        taxes_eur = total_eur * vat_perc / (100 + vat_perc)

        total_txt = Paragraph(
            f"<b>{t('Total')}</b>", ParagraphStyle('total', textColor=colors.white)
        )
        total_n_txt = Paragraph(f"<b>{total_eur:.2f} €</b>", ParagraphStyle('total_n', alignment=2))

        data = [[
            t("Start"), t("Stop"), t("Parkname"), "QR Code", f"{t('Energy')} [Wh]", t('TotalPrice')
        ]]
        for entry in items:
            _, _, parkname, qrcodeid, energy, _ = entry
            start = entry.start.astimezone(pytz.timezone('Europe/Paris')).strftime("%Y/%m/%d %H:%M:%S")
            stop = entry.stop.astimezone(pytz.timezone('Europe/Paris')).strftime("%Y/%m/%d %H:%M:%S")
            energy_eur = f"{entry.energy_eur:.2f}"
            data.append([start, stop, parkname, qrcodeid, energy, energy_eur])

        data.append(["", "", "", "", total_txt, total_n_txt])
        data.append(["", "", "", "", t(f"VAT"), f"{taxes_eur:.2f} €"])

        cols = len(data[0])
        n_items = len(items)
        style = TableStyle([
            # Items
            ("BOX", (0, 0), (-1, n_items), 1, colors.black),
            ("GRID", (0, 0), (-1, n_items), 1, colors.black),
            ("BACKGROUND", (0, 0), (-1, 0), colors.gray),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("ALIGN", (0, 0), (-1, n_items), "CENTER"),
            ("BACKGROUND", (0, 1), (-1, n_items), colors.beige),

            # Balance
            ("BOX", (cols - 2, n_items + 1), (-1, -1), 1, colors.black),
            ("GRID", (cols - 2, n_items + 1), (-1, -1), 1, colors.black),
            ("ALIGN", (cols - 2, n_items + 1), (cols, -1), "LEFT"),
            ("ALIGN", (cols - 1, n_items + 1), (cols, -1), "RIGHT"),
            ("BACKGROUND", (cols - 2, n_items + 1), (cols - 2, -1), colors.gray),
            ("TEXTCOLOR", (cols - 2, n_items + 1), (cols - 2, -1), colors.whitesmoke),
            ("BACKGROUND", (cols - 1, n_items + 1), (-1, -1), colors.beige),
        ])

        return Table(data, style=style)

    header = Table(
        [[logo(), generate_title()], [parties(), today()]],
        style=TableStyle([("VALIGN", (0, 0), (-1, -1), 'TOP')])
    )
    table_title = Paragraph(
        t("Summary"), style=ParagraphStyle('table_title', fontSize=15, leading=22, alignment=1)
    )
    tail = Paragraph(t("Data retrieved"))

    # TODO: better handling of the path in our const file
    societyname_slug = slugify(moneydest.society_name)
    filename = f"{settings.ADMIN_REPORT_PATH}{societyname_slug}_{begin.date()}_{end.date()}.pdf"
    filename = filename.replace(" ", "")

    pdf = SimpleDocTemplate(filename, pagesize=A4, topMargin=50, leftMargin=50, rightMargin=50)
    pdf.build([header, table_title, generate_table(vat_percentage), tail])  # Auto overwrite of old files

    logger.info(
        f"Generated report for MoneyDestination {moneydest.id} \"{moneydest.society_name}\" on path \"{filename}\"")

    return filename


ParkReportEntry = namedtuple('ParkReportEntry', ['username', 'n_sessions', 'energy_wh', 'price'])


def _generate_park_report_data(park: Park, begin: datetime, end: datetime):
    """
    retrieves the data needed to build the table for the admin report
    """
    logger.debug("Call to _generate_admin_report_data")
    charges = Charge.objects.filter(chargingstation__park=park) \
        .filter(stop__gte=begin, stop__lt=end) \
        .values_list('user__id', 'user__username', 'user__userconfig__guest') \
        .annotate(n_sessions=Count('user__id'), total_energy=Sum('energy_wh')) \
        .annotate(total_price_cent=Sum(F('energy_wh') * F('chargingstation__price'))) \
        .exclude(total_energy=0) \
        .order_by('user__userconfig__guest', 'user__username')

    items = []

    for uid, username, is_guest, n_sessions, energy_wh, price in charges:
        if is_guest:
            username = f"guest_{uid}"
        items.append(ParkReportEntry(username, n_sessions, round(energy_wh / 1000, 1), round(price / 100000, 2)))
    return items


def make_park_report(park: Park, begin: datetime, end: datetime):
    """
    Creates the receipt for the given park between the requested timepoints, saves it on disk, and
    return the filename
    """
    logger.debug("Call to make_park_report")

    country_code = park.country_alpha2
    test_country = pycountry.countries.get(alpha_2=country_code)
    if not test_country:
        logger.warning(f"Country code {country_code} doesn't exists. Defaulting to FR.")
        country_code = "FR"

    t = _build_vocabulary(country_code, None)

    def generate_title():
        title_style = ParagraphStyle('title', fontSize=36, leading=46, alignment=2)
        return Paragraph(t("UsersReport"), title_style)

    def today():
        return Paragraph(
            f"<b>{t('Date')}:</b> {datetime.now().date()}", ParagraphStyle("today", alignment=2)
        )

    def logo():
        # TODO: take the logo
        return Image(settings.CORPORATE_LOGO_PATH, width=200, height=35, hAlign='LEFT')

    # TODO: insert number of chargepoints
    def info():
        address = park.address
        nation_obj = pycountry.countries.get(alpha_2=park.country_alpha2)
        if not nation_obj:
            logger.warning(f"Invalid Nation {park.country_alpha2}, defaulting to France.")
            nation_obj = pycountry.countries.get(alpha_2="FR")
        final_address = f"{address}\n{park.postal_code}  {park.city}\n{nation_obj.name}"

        park_name = park.name
        email = park.email  # "123@123.sas"

        destination = f"{t('ForPark')} {park_name}\n" \
                      f"{t('From')} {begin.date()} {t('To')} {end.date()}\n\n{final_address}\n\n{email}\n"

        data = [[destination]]

        return Table(data, colWidths=150, hAlign="LEFT", style=TableStyle([
            ("VALIGN", (0, 0), (-1, -1), 'TOP')
        ]))

    def generate_price_table():
        """
        generates the table with cp prices
        """
        items = [*enumerate(park.chargingstation_set.order_by('park_bnum').values_list('price', flat=True), 1)]

        data = [[t("CP"), t("Price")]]
        data.extend([cp, f"{price/100:.2f}"] for cp, price in items)

        cols = len(data[0])
        n_items = len(items)
        style = TableStyle([
            # Items
            ("BOX", (0, 0), (-1, n_items), 1, colors.black),
            ("GRID", (0, 0), (-1, n_items), 1, colors.black),
            ("BACKGROUND", (0, 0), (-1, 0), colors.gray),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("ALIGN", (0, 0), (-1, n_items), "CENTER"),
            ("BACKGROUND", (0, 1), (-1, n_items), colors.lightgreen),

            # Balance
            ("BOX", (cols - 2, n_items + 1), (-1, -1), 1, colors.black),
            ("GRID", (cols - 2, n_items + 1), (-1, -1), 1, colors.black),
            ("ALIGN", (cols - 2, n_items + 1), (cols, -1), "LEFT"),
            ("ALIGN", (cols - 1, n_items + 1), (cols, -1), "RIGHT"),
            ("BACKGROUND", (cols - 2, n_items + 1), (cols - 1, -1), colors.gray),
            ("TEXTCOLOR", (cols - 2, n_items + 1), (cols - 2, -1), colors.whitesmoke),
            ("BACKGROUND", (cols - 1, n_items + 1), (-1, -1), colors.lightgreen),
        ])

        return Table(data, style=style)

    def generate_user_table():
        """
        generates the table with all the data
        """
        items = _generate_park_report_data(park, begin, end)
        total_energy = sum(item.energy_wh for item in items)
        users = [item for item in items if "guest_" not in item.username]
        guests = [item for item in items if "guest_" in item.username]
        credit_card_guest = ParkReportEntry(f"{t('CCG')}",
                                            sum([i.n_sessions for i in guests]),
                                            round(sum([i.energy_wh for i in guests]), 2),
                                            "")

        total_txt = Paragraph(
            f"<b>{t('Total')}</b>", ParagraphStyle('total', textColor=colors.white, alignment=1)
        )
        total_n_txt = Paragraph(
            f"<b>{total_energy:.1f} kWh</b>", ParagraphStyle('total_n', alignment=1)
        )

        data = [[t("Username"), t("Sessions"), f"{t('Energy')} [kWh]", t("ChargePrice")]]
        data.extend([username, n_sessions, energy, price] for
                    username, n_sessions, energy, price in users + [credit_card_guest])
        data.append(['', '', total_txt, total_n_txt])

        cols = len(data[0])
        n_items = len(users) + 1
        style = TableStyle([
            # Items
            ("BOX", (0, 0), (-1, n_items), 1, colors.black),
            ("GRID", (0, 0), (-1, n_items), 1, colors.black),
            ("BACKGROUND", (0, 0), (-1, 0), colors.gray),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("ALIGN", (0, 0), (-1, n_items), "CENTER"),
            ("BACKGROUND", (0, 1), (-1, n_items), colors.lightgreen),

            # Balance
            ("BOX", (cols - 2, n_items + 1), (-1, -1), 1, colors.black),
            ("GRID", (cols - 2, n_items + 1), (-1, -1), 1, colors.black),
            ("ALIGN", (cols - 2, n_items + 1), (cols, -1), "LEFT"),
            ("ALIGN", (cols - 1, n_items + 1), (cols, -1), "RIGHT"),
            ("BACKGROUND", (cols - 2, n_items + 1), (cols - 1, -1), colors.gray),
            ("TEXTCOLOR", (cols - 2, n_items + 1), (cols - 2, -1), colors.whitesmoke),
            ("BACKGROUND", (cols - 1, n_items + 1), (-1, -1), colors.lightgreen),
        ])

        return Table(data, style=style)

    header = Table(
        [[logo(), generate_title()], [info(), today()]],
        style=TableStyle([("VALIGN", (0, 0), (-1, -1), 'TOP')])
    )
    table_title = Paragraph(
        f'<br />{t("Summary")}', style=ParagraphStyle('table_title', fontSize=15, leading=22, alignment=1)
    )
    tail = Paragraph(t("Data retrieved"))

    parkname_slug = slugify(park.name)
    filename = f"{settings.PARK_REPORT_PATH}{parkname_slug}_{begin.date()}_{end.date()}.pdf"
    filename = filename.replace(" ", "")

    pdf = SimpleDocTemplate(filename, pagesize=A4, topMargin=50, leftMargin=50, rightMargin=50)
    pdf.build([header, generate_price_table(), table_title, generate_user_table(), tail])  # Auto overwrite of old files

    logger.info(
        f"Generated report for park {park.id} \"{park.name}\" on path \"{filename}\"")

    return filename


@csrf_exempt
def get_receipts(request):
    if not request.user.is_authenticated:
        return HttpResponse(status=401)
    if not request.user.is_staff:
        return HttpResponse(status=401)
    files = os.listdir(settings.ADMIN_REPORT_PATH)
    ret_val = {"receipts": files}
    return JsonResponse(ret_val)


@csrf_exempt
def download_receipt(request, receipt_name):
    if not request.user.is_authenticated:
        return HttpResponse(status=401)
    if not request.user.is_staff:
        return HttpResponse(status=401)
    try:
        files = os.listdir(settings.ADMIN_REPORT_PATH)
        if receipt_name not in files:
            return HttpResponse(status=404)
        receipt = open(settings.ADMIN_REPORT_PATH + receipt_name, 'rb')
        return FileResponse(receipt, as_attachment=True)
    except FileNotFoundError:
        return HttpResponse(status=404)
