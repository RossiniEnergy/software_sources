import datetime
import json
import logging

import pytz

from django.core.exceptions import FieldError, ValidationError, MultipleObjectsReturned, ObjectDoesNotExist
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework import serializers
from rest_framework.renderers import JSONRenderer

from ..models import NewComer


logger = logging.getLogger("api.newcomer")


class NewComerSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = NewComer
        fields = ["id", "name", "time", "anydeskid", "teamviewerid"]


@csrf_exempt
def get_newcomers(request):
    if not request.user.is_authenticated:
        return HttpResponse(status=401)
    if not request.user.is_staff:
        return HttpResponse(status=401)
    logger.debug(f"Call to get_newcomers")
    newcomers = NewComer.objects.all().order_by("-id")
    serializer_context = {"request": request}
    serializer = NewComerSerializer(newcomers, many=True, context=serializer_context)
    ret_val = JSONRenderer().render(serializer.data)
    return HttpResponse(ret_val)


@csrf_exempt
def newcomer(request):
    try:
        if request.body:
            b = json.loads(request.body)
            parkname = b.get("parkname", "NOPARKNAME")
            anydesk = b.get("anydesk")
            teamviewer = b.get("teamviewer")
            p = NewComer(
                name=parkname,
                time=datetime.datetime.now(pytz.utc),
                anydeskid=anydesk,
                teamviewerid=teamviewer,
            )
            p.save()
            logger.info("Registered newcomer!")
            return HttpResponse(status=200)
        else:
            logger.warning("Received empty newcomer!")
            return HttpResponse(status=401)
    except (json.JSONDecodeError, FieldError, ValidationError):
        logger.error("Error during newcomer reception!")
        return HttpResponse(status=401)


@csrf_exempt
def cancelnewcomer(request):
    if not request.user.is_authenticated:
        return HttpResponse(status=401)
    if not request.user.is_staff:
        return HttpResponse(status=401)
    logger.debug(f"Call to cancelnewcomer")
    body = json.loads(request.body)
    newcomer_id = body.get("id")
    try:
        newcomer_obj = NewComer.objects.get(id=newcomer_id)
        newcomer_obj.delete()
        return HttpResponse(status=200)
    except (MultipleObjectsReturned, ObjectDoesNotExist):
        return HttpResponse(status=401)


@csrf_exempt
def nowtimeutc(_request):
    now = datetime.datetime.now(pytz.UTC)
    return HttpResponse(f"{now.timestamp()}")
