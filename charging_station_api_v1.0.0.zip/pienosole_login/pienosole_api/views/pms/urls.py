from django.urls import path, include
from rest_framework import routers
from rest_framework_nested import routers as nested_routers  # https://github.com/alanjds/drf-nested-routers

from .common import PMSView, PMSSubUserView, pms_initialize_token_api

router = routers.DefaultRouter()
router.register(r'pms', PMSView, basename='pms-object')
nested_pms_router = nested_routers.NestedDefaultRouter(router, r"pms", lookup="pms")
nested_pms_router.register(f'users', PMSSubUserView, basename='pms-subusers')

urlpatterns = [
    path("", include(router.urls)),
    path("", include(nested_pms_router.urls)),
    path("pms/<str:pms_abbrev>/initialize_token/<str:tmp_token>", pms_initialize_token_api),
]
