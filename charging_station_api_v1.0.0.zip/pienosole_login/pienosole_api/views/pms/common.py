from dateutil.parser import isoparse

from rest_framework import serializers, status, mixins
from rest_framework.authentication import SessionAuthentication
from rest_framework.decorators import action, api_view
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters import rest_framework as filters

from django.db.models import Sum

from ...libs_v2.charge import close_all_user_charges
from ...libs_v2.exceptions import HTTPResponseWrapperError
from ...libs_v2.pms.authtoken import BasePMSTokenAuthentication, initialize_token, NestedIsAuthenticatedAndPMSAdmin
from ...libs_v2.pms.usermanagement import PMSSubUser, create_child_user
from ...libs_v2.permissionviewset import *
from ...libs_v2.user import expire_user

from ...models import User, Charge, PMS, PMSAdminUser


class PMSSerializer(serializers.ModelSerializer):
    class Meta:
        model = PMS
        fields = ['id', 'name', 'abbrev']


class PMSView(
    PermissionGenericViewSet,
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
):
    serializer_class = PMSSerializer
    authentication_classes = [BasePMSTokenAuthentication, SessionAuthentication]
    permission_classes = [IsAuthenticated]
    lookup_field = 'abbrev'
    queryset = PMS.objects.order_by('id')


# Not stonks to use GET in a function with side effects, but this time is better to not have random CORS errors
@api_view(['GET'])
def pms_initialize_token_api(request, pms_abbrev, tmp_token):
    try:
        pms = PMS.objects.get(abbrev=pms_abbrev)
    except PMS.DoesNotExist:
        return Response("Unknown PMS", status=status.HTTP_400_BAD_REQUEST)
    try:
        pmsadmin = initialize_token(tmp_token, pms)
    except HTTPResponseWrapperError as exc:
        return exc.httpresponse
    output = {'authorization_token': pmsadmin.authorization_token}
    return Response(output)


# noinspection PyAbstractClass
class PMSSubUserSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    username = serializers.CharField(max_length=50)
    expire_datetime = serializers.DateTimeField(allow_null=True, default=None)
    expired = serializers.BooleanField(read_only=True)


# noinspection PyAbstractClass
class CreatePMSSubUserSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=50)
    password = serializers.CharField(max_length=50)
    expire_datetime = serializers.DateTimeField(allow_null=True, default=None)

    # noinspection PyMethodMayBeStatic
    def validate_username(self, value):
        if '$' in value:
            raise serializers.ValidationError("'$' is an illegal character for a username")
        elif '#' in value:
            raise serializers.ValidationError("'#' is an illegar character for a username")
        return value


class PMSFilterSet(filters.FilterSet):
    username = filters.CharFilter(method='pms_username_filter')
    expired = filters.BooleanFilter(field_name='userconfig__expired')
    expire_datetime__lt = filters.IsoDateTimeFilter(field_name='userconfig__expire_datetime', lookup_expr='lt')
    expire_datetime__lte = filters.IsoDateTimeFilter(field_name='userconfig__expire_datetime', lookup_expr='lte')
    expire_datetime__gt = filters.IsoDateTimeFilter(field_name='userconfig__expire_datetime', lookup_expr='gt')
    expire_datetime__gte = filters.IsoDateTimeFilter(field_name='userconfig__expire_datetime', lookup_expr='gte')

    class Meta:
        model = User
        fields = []

    def pms_username_filter(self, queryset, name, value):
        logged_user = getattr(self.request, 'user', None)
        if logged_user is None or not logged_user.is_authenticated:
            return queryset
        username_for_filter = f"{logged_user.id}${value}"
        return queryset.filter(username=username_for_filter)


class PMSSubUserView(PermissionGenericViewSet):
    serializer_class = PMSSubUserSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = PMSFilterSet
    authentication_classes = [BasePMSTokenAuthentication]
    permission_classes = [NestedIsAuthenticatedAndPMSAdmin]

    def get_queryset(self):
        if not IsAuthenticatedNotExpired().has_permission(self.request, self):
            return User.objects.none()
        else:
            # Show the user in the list only if at least one of this condition is True:
            # - The user contains the requester user in his belonging_to
            user = self.request.user
            # Check if requester is correlated to the requested PMS
            try:
                if PMSAdminUser.objects.get(user=user).pms.abbrev != self.kwargs['pms_abbrev']:
                    return User.objects.none()
            except PMSAdminUser.DoesNotExist:
                return User.objects.none()
            return User.objects.filter(userconfig__belonging_to=user).distinct()

    def list(self, request, *args, **kwargs):
        users = self.filter_queryset(self.get_queryset())
        pms_users = PMSSubUser.init_list(users)
        serializer = self.get_serializer(pms_users, many=True)
        return Response(serializer.data)

    def retrieve(self, request, pk=None, *args, **kwargs):
        instance = self.get_object()
        pms_user = PMSSubUser(instance)
        serializer = self.get_serializer(pms_user)
        return Response(serializer.data)

    def create(self, request, *args, **kwargs):
        serializer = CreatePMSSubUserSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        username = serializer.validated_data.get('username')
        password = serializer.validated_data.get('password')
        expire_datetime = serializer.validated_data.get('expire_datetime')
        pmssubuser = create_child_user(
            pmsadmin_user=request.user,
            last_username=username,
            password=password,
            expire_datetime=expire_datetime
        )
        output_serializer = self.get_serializer(pmssubuser)
        return Response(output_serializer.data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=['post'])
    def force_expire(self, request, pk=None, *args, **kwargs):
        user = self.get_object()
        if user.userconfig.expired:
            return Response("The user is already expired", status=status.HTTP_400_BAD_REQUEST)
        expire_user(user)
        close_all_user_charges(user)
        serializer = self.get_serializer(PMSSubUser(user))
        return Response(serializer.data)

    @action(detail=True, methods=['post'])
    def change_expire_date(self, request, pk=None, *args, **kwargs):
        user = self.get_object()
        if user.userconfig.expired:
            return Response("The user is already expired", status=status.HTTP_400_BAD_REQUEST)
        expire_datetime_str = request.data.get('expire_datetime')
        if expire_datetime_str is not None:
            try:
                expire_datetime = isoparse(expire_datetime_str)
            except ValueError:
                return Response("Error during the datetime parsing with ISO-8601.", status=status.HTTP_400_BAD_REQUEST)
        else:
            expire_datetime = None
        user.userconfig.expire_datetime = expire_datetime
        user.userconfig.save()
        serializer = self.get_serializer(PMSSubUser(user))
        return Response(serializer.data)

    @action(detail=True, methods=['get'])
    def total_energy_used(self, request, pk=None, *args, **kwargs):
        user = self.get_object()
        user_energy = Charge.objects.filter(user=user).aggregate(Sum('energy_wh'))['energy_wh__sum']
        if user_energy is None:
            user_energy = 0
        return Response({'energy_wh': int(user_energy)})
