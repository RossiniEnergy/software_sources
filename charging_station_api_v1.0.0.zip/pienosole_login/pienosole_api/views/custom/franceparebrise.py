import datetime
import pytz
import pycountry
import logging

from collections import OrderedDict
from io import BytesIO
from dateutil.parser import isoparse
from dateutil.relativedelta import relativedelta

from django.http import JsonResponse, HttpResponse, HttpResponseBadRequest, HttpResponseForbidden, FileResponse
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Sum, DurationField, F, ExpressionWrapper

from rest_framework import viewsets, serializers
from rest_framework.pagination import PageNumberPagination

from ...libs_v2.exceptions import HTTPResponseWrapperError
from ...models import (
    ChargingStation, CustomFranceParebrisePark, Charge, PaymentOrder, User
)

# List of French regions (main subdivision) sorted by ISO3166-2 code
REGION_LIST = sorted(filter(lambda x: x.parent_code is None, pycountry.subdivisions.get(country_code='FR')),
                     key=lambda x: x.code)
REGIONCODE_LIST = list(map(lambda x: x.code, REGION_LIST))


logger = logging.getLogger("api.custom.francearebrise")


def check_user_permission(user: User) -> bool:
    """A user is allowed for this panel when he manage at least one park of the custom ones."""
    return CustomFranceParebrisePark.objects.values_list("park").intersection(
        user.userconfig.managed_parks.values_list("id")
    ).exists()


@csrf_exempt
def api_check_user_permission(request):
    if not request.user.is_authenticated:
        return HttpResponseForbidden("User not authenticated", status=401)
    if check_user_permission(request.user):
        return HttpResponse("Accepted", status=200)
    else:
        return HttpResponseForbidden("Forbidden", status=403)


@csrf_exempt
def get_region_list(_request):
    result = {}
    for region in REGION_LIST:
        result[region.code] = region.name
    return JsonResponse(result)


# - API1
# ricevo regione francese (se non la ricevo ritorna tutti)
# ritorno tabella di chargingstation, appartenenti a parchi con Custom definito. Campi:
# 	- Parkname
# 	- Park_bnum (1-9)
# 	- Ubicazione Parco (Per ora only City)
# 	- Ultimo Aggiornamento Informazioni (last_status)
# 	- Stato attuale: Online Carica/ Online/ Offline
@csrf_exempt
def get_chargingstation_table(request):
    if request.method != 'GET':
        return HttpResponseBadRequest("Required GET method")
    # Check if User is allowed to use this panel
    if not request.user.is_authenticated:
        return HttpResponseForbidden("User not authenticated", status=401)
    if not check_user_permission(request.user):
        return HttpResponseForbidden("Forbidden")
    # Check Region
    region = request.GET.get('iso_region', None)
    if region is not None and region not in REGIONCODE_LIST:
        logger.warning("get_chargingstation_table received invalid region=\"{region}\"")
        return HttpResponseBadRequest(f"Region {region} not present in the region-list")
    # Main
    if region is not None:
        custom_park_table = CustomFranceParebrisePark.objects.filter(region_iso3166_2=region)
    else:
        custom_park_table = CustomFranceParebrisePark.objects.all()
    data = []
    for custom_park in custom_park_table:
        park = custom_park.park
        for cs in park.chargingstation_set.order_by('park_bnum').all():
            parkname = park.name
            local_id = cs.park_bnum
            location = custom_park.city
            # OPTIMIZE: is not a bad idea to have a "Last_Received_Update" in the main system
            last_update_obj = cs.last_power
            if last_update_obj is not None:
                last_update_datetime = last_update_obj.timestamp
            else:
                last_update_datetime = park.creation_date
            last_update = str(last_update_datetime.isoformat(timespec='seconds'))
            if last_update_datetime < datetime.datetime.now(pytz.UTC) - datetime.timedelta(minutes=5):
                status = "offline"
            elif cs.active_charge:
                status = "charging"
            else:
                status = "online"
            latitude = park.latitude
            longitude = park.longitude
            data.append([parkname, local_id, location, latitude, longitude, last_update, status])
    # JSON and return
    result = {'headers': ['parkname', 'local_id', 'location', 'latitude', 'longitude', 'last_update', 'status'],
              'data': data}
    return JsonResponse(result)


def _format_httpget_iso_region_start_stop(request):
    """Return (iso_region, start, stop) if all ok. If failed it returns a Exception wrapping the HttpResponse"""
    if request.method != 'GET':
        raise HTTPResponseWrapperError(HttpResponseBadRequest("Required GET method"))
    # Check Region
    # NOT USE region,  because &reg became "registered mark" and break the url for the paging
    region = request.GET.get('iso_region', None)
    if region is not None and region not in REGIONCODE_LIST:
        logger.warning("get_chargingstation_table received invalid region=\"{region}\"")
        raise HTTPResponseWrapperError(HttpResponseBadRequest(f"Region {region} not present in the region-list"))
    # Check and format datetimes
    now = datetime.datetime.now(pytz.UTC)
    start_current_month = datetime.datetime(now.year, now.month, 1, 0, 0, tzinfo=pytz.UTC)
    try:
        start = request.GET.get('start')
        stop = request.GET.get('stop')
        if start is not None:
            start = start.replace(' ', '+')
            start = isoparse(start)
        else:
            start = start_current_month
        if stop is not None:
            stop = stop.replace(' ', '+')
            stop = isoparse(stop)
        else:
            stop = now
    except ValueError:
        logger.error(f"get_summary_by_date received unformattable request: {list(request.GET.values())}")
        raise HTTPResponseWrapperError(
            HttpResponseBadRequest("Error converting start/stop datetimes.\n"
                                   "Datetime are required in ISO 8601 format.\n"
                                   "You can use as + symbol, %2b or only in this situation the symbol +.\n"
                                   "A tailing Z is the same as +00:00/UTC timezone.\n"
                                   "Example:\n"
                                   "\t2021-08-30T14:56:17+00:00\n"
                                   "\t2021-09-02T04:06:09+01:00\n"
                                   "\t2021-08-30T14:56:17Z"))
    return region, start, stop


# TODO:
#   - API2
#   ricevo Data1, Data2, regione francese. Date in formato ISO 8601 2021-08-30T14:56:17+00:00
#   ritorno tabella (json) con queste righe:
#   	- Numero di Cariche
#   	- kWh consumati totali
#   	- Tempo totale di carica
#   	- kWh consumati per cariche paganti
#   	- Soldi totali trasferiti a loro dai pagamenti
def _main_get_summary_by_date(region, start, stop):
    if region is not None:
        custom_park_table = CustomFranceParebrisePark.objects.filter(region_iso3166_2=region)
    else:
        custom_park_table = CustomFranceParebrisePark.objects.all()
    data = OrderedDict()
    # Number of charges
    # TODO: Tenere conto delle cariche parziali? (Integrale su Power table per cariche tranciate a metà dall'intervallo)
    selected_chs = ChargingStation.objects.filter(park_id__in=custom_park_table.values_list('park_id', flat=True))
    charges = Charge.objects.filter(chargingstation__in=selected_chs, start__gte=start, start__lt=stop)
    data['number_of_charges'] = charges.count()
    if charges.count() == 0:
        data['total_kwh'] = 0
        data['total_chargetime'] = "0:00:00"
        data['payed_kwh'] = 0
        data['eurcents_received'] = 0
        data['co2_ton_notemitted'] = 0
    else:
        # kWh totally consumed
        data['total_kwh'] = charges.aggregate(Sum('energy_wh'))['energy_wh__sum'] / 1000
        # Total Time of charge
        total_timedelta = charges.annotate(
            diff=ExpressionWrapper(F('stop') - F('start'), output_field=DurationField())
        ).aggregate(Sum('diff'))['diff__sum']
        data['total_chargetime'] = str(total_timedelta).split('.')[0].replace(',', '')
        # CO2 not emitted
        equiv_km = data['total_kwh'] * 6  # 6 km for every kwh used
        data['co2_ton_notemitted'] = equiv_km * 150 * 1e-6  # 150 convert km in co2 grams. Then conversion in Mg (ton).
        # Retrieve Paid Charges
        paid_charges = charges.filter(user__userconfig__guest=True)
        # Paid kWh consumed
        if paid_charges.count() == 0:
            data['payed_kwh'] = 0
            data['eurcents_received'] = 0
        else:
            data['payed_kwh'] = paid_charges.aggregate(Sum('energy_wh'))['energy_wh__sum'] / 1000
            # Total money received
            guest_users = paid_charges.values_list('user', flat=True)
            payords = PaymentOrder.objects.filter(guest_user__in=guest_users)
            data['eurcents_received'] = payords.aggregate(Sum('energy_cents'))['energy_cents__sum']
    return data


@csrf_exempt
def get_summary_by_date(request):
    # Check if User is allowed to use this panel
    if not request.user.is_authenticated:
        return HttpResponseForbidden("User not authenticated", status=401)
    if not check_user_permission(request.user):
        return HttpResponseForbidden("Forbidden")
    # Retrieve formatted region, start, stop from HTTP GET iso_region, start, stop
    try:
        region, start, stop = _format_httpget_iso_region_start_stop(request)
    except HTTPResponseWrapperError as exc:
        return exc.httpresponse
    # Main
    data = _main_get_summary_by_date(region, start, stop)
    # JSON and return
    return JsonResponse(data)


def export_get_summary_by_date(request):
    # Check if User is allowed to use this panel
    if not request.user.is_authenticated:
        return HttpResponseForbidden("User not authenticated", status=401)
    if not check_user_permission(request.user):
        return HttpResponseForbidden("Forbidden")
    # Retrieve formatted region, start, stop from HTTP GET iso_region, start, stop
    try:
        region, start, stop = _format_httpget_iso_region_start_stop(request)
    except HTTPResponseWrapperError as exc:
        return exc.httpresponse
    # Main
    data = _main_get_summary_by_date(region, start, stop)
    # Make string CSV
    output = ",".join(data.keys()) + "\n" + ",".join(map(str, data.values()))
    # Format and output
    fmt_output = bytes(output, 'UTF-8')
    if region is None:
        region = "FR"
    filename = f"RE_Summary_{region}_{start.date().isoformat()}_{stop.date().isoformat()}.csv"
    stream_output = BytesIO(fmt_output)
    stream_output.seek(0)
    return FileResponse(stream_output, as_attachment=True, filename=filename)


def get_globalsummary_by_date(request):
    # Check if User is allowed to use this panel
    if not request.user.is_authenticated:
        return HttpResponseForbidden("User not authenticated", status=401)
    if not check_user_permission(request.user):
        return HttpResponseForbidden("Forbidden")
    # Retrieve formatted region, start, stop from HTTP GET iso_region, start, stop
    # In this function region will be ignored
    try:
        _region, start, stop = _format_httpget_iso_region_start_stop(request)
    except HTTPResponseWrapperError as exc:
        return exc.httpresponse
    # Prepare Region_list with park inside
    populated_regioncode_list = \
        CustomFranceParebrisePark.objects.distinct('region_iso3166_2').values_list('region_iso3166_2', flat=True)
    populated_region_list = list(filter(lambda x: x.code in populated_regioncode_list, REGION_LIST))
    # Main
    output = {}
    for region_object in populated_region_list:
        region = region_object.code
        # region_name = region_object.name
        data = _main_get_summary_by_date(region, start, stop)
        output[region] = data
    # JSON and return
    return JsonResponse(output)


def globalexport_get_summary_by_date(request):
    # Check if User is allowed to use this panel
    if not request.user.is_authenticated:
        return HttpResponseForbidden("User not authenticated", status=401)
    if not check_user_permission(request.user):
        return HttpResponseForbidden("Forbidden")
    # Retrieve formatted region, start, stop from HTTP GET iso_region, start, stop
    # In this function region will be ignored
    try:
        _region, start, stop = _format_httpget_iso_region_start_stop(request)
    except HTTPResponseWrapperError as exc:
        return exc.httpresponse
    # Prepare Region_list with park inside
    populated_regioncode_list = \
        CustomFranceParebrisePark.objects.distinct('region_iso3166_2').values_list('region_iso3166_2', flat=True)
    populated_region_list = list(filter(lambda x: x.code in populated_regioncode_list, REGION_LIST))
    # Main
    output = ""
    for region_object in populated_region_list:
        region = region_object.code
        region_name = region_object.name
        data = _main_get_summary_by_date(region, start, stop)
        if len(output) == 0:
            output = "region," + ",".join(data.keys()) + "\n"
        output += f"{region_name}," + ",".join(map(str, data.values())) + "\n"
    # Format and output
    fmt_output = bytes(output, 'UTF-8')
    filename = f"RE_GlobalSummary_{start.date().isoformat()}_{stop.date().isoformat()}.csv"
    stream_output = BytesIO(fmt_output)
    stream_output.seek(0)
    return FileResponse(stream_output, as_attachment=True, filename=filename)


# API that taken a region produce a histogram of consumption per month
# start given and +1 for loop
# stop = start + 1 month
# until stop > givenstop
def get_consumption_kwh_histogram(request):
    # Check if User is allowed to use this panel
    if not request.user.is_authenticated:
        return HttpResponseForbidden("User not authenticated", status=401)
    if not check_user_permission(request.user):
        return HttpResponseForbidden("Forbidden")
    # Retrieve formatted region, start, stop from HTTP GET iso_region, start, stop
    try:
        region, start, stop = _format_httpget_iso_region_start_stop(request)
    except HTTPResponseWrapperError as exc:
        return exc.httpresponse
    # Main
    if region is not None:
        custom_park_table = CustomFranceParebrisePark.objects.filter(region_iso3166_2=region)
    else:
        custom_park_table = CustomFranceParebrisePark.objects.all()
    selected_chs = ChargingStation.objects.filter(park_id__in=custom_park_table.values_list('park_id', flat=True))
    data = OrderedDict()
    # Loop initialization
    query_start = start
    query_stop = start + relativedelta(months=1)
    while query_stop <= stop:
        # Main loop
        charges = Charge.objects.filter(chargingstation__in=selected_chs, start__gte=query_start, start__lt=query_stop)
        if charges.count() == 0:
            total_energy_kwh = 0
        else:
            total_energy_kwh = charges.aggregate(Sum('energy_wh'))['energy_wh__sum'] / 1000
        data[f"{query_start.isoformat(timespec='seconds')}/{query_stop.isoformat(timespec='seconds')}"] = \
            total_energy_kwh
        # Loop incrementation
        query_start = query_stop
        query_stop = query_stop + relativedelta(months=1)
    return JsonResponse(data)


# - API3
# ricevo Data1, Data2, regione francese, PAGE DEFAULTATA A 1, LIMIT DEFAULTATA A n. Date in formato ISO 8601.
# invio ricariche fatte in ordine cronologico inverso (id-) da Charge.
# Paging gestito inviando X-Total-Count = numero di elementi totali;
# X-Limit = limite attualmente impostato per il paging
class ChargeRetrievePagination(PageNumberPagination):
    # Examples:
    # http://api.example.org/accounts/?page=4
    # http://api.example.org/accounts/?page=4&page_size=100
    page_size = 50
    page_size_query_param = 'page_size'
    max_page_size = 200


class ChargeSerializerDefault(serializers.HyperlinkedModelSerializer):
    charge_id = serializers.IntegerField(source="id")
    # TODO: parkname
    parkname = serializers.CharField(source="chargingstation.park.name")
    # TODO: local_id
    local_id = serializers.IntegerField(source="chargingstation.park_bnum")

    class Meta:
        model = Charge
        fields = ["charge_id", "parkname", "local_id", "start", "stop", "energy_wh"]


# noinspection PyMethodMayBeStatic
class ChargeViewSet(viewsets.GenericViewSet):
    serializer_class = ChargeSerializerDefault

    def list(self, request):
        if request.method != 'GET':
            return HttpResponseBadRequest("Required GET method")
        # Check if User is allowed to use this panel
        if not request.user.is_authenticated:
            return HttpResponseForbidden("User not authenticated", status=401)
        if not check_user_permission(request.user):
            return HttpResponseForbidden("Forbidden")
        export_flag = request.GET.get('export', "0")
        if export_flag == "0":
            export_flag = False
        else:
            export_flag = True
        # Retrieve formatted region, start, stop from HTTP GET iso_region, start, stop
        try:
            region, start, stop = _format_httpget_iso_region_start_stop(request)
        except HTTPResponseWrapperError as exc:
            return exc.httpresponse
        # Main
        if region is not None:
            custom_park_table = CustomFranceParebrisePark.objects.filter(region_iso3166_2=region)
        else:
            custom_park_table = CustomFranceParebrisePark.objects.all()
        selected_chs = ChargingStation.objects.filter(
            park_id__in=custom_park_table.values_list('park_id', flat=True))
        charges = Charge.objects.filter(chargingstation__in=selected_chs, start__gte=start, start__lt=stop) \
            .order_by("-id")
        # Output
        if not export_flag:
            # Paging
            paginator = ChargeRetrievePagination()
            page = paginator.paginate_queryset(charges, request, view=self)
            if page is not None:
                serializer = ChargeSerializerDefault(page, many=True)
                return paginator.get_paginated_response(serializer.data)
            else:
                return HttpResponseBadRequest("Paging out of scope")
        else:
            serializer = ChargeSerializerDefault(charges, many=True)
            output = ""
            for entry in serializer.data:
                if len(output) == 0:
                    output = ",".join(entry.keys()) + "\n"
                output += ",".join(map(str, entry.values())) + "\n"
            # Format and output
            fmt_output = bytes(output, 'UTF-8')
            if region is None:
                region = "FR"
            filename = f"RE_Charges_{region}_{start.date().isoformat()}_{stop.date().isoformat()}.csv"
            stream_output = BytesIO(fmt_output)
            stream_output.seek(0)
            return FileResponse(stream_output, as_attachment=True, filename=filename)

    # def retrieve(self, request, pk=None):
    #     queryset = Charge.objects.all()
    #     user = get_object_or_404(queryset, pk=pk)
    #     serializer = UserSerializer(user)
