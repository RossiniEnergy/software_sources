import stripe
import logging

from django.conf import settings

from collections import namedtuple
from collections.abc import Iterable

from ..models import MoneyDestination, Park

logger = logging.getLogger("api.health")

stripe.api_key = settings.STRIPE_PRIVATE_KEY

StripeReport = namedtuple('StripeReport',
                          ['id', 'transfers', 'payout',
                           'capab_transfers', 'capab_cardpayments',
                           'enabled_cp', 'total_cp'])

ParkReport = namedtuple('ParkReport',
                        ['id', 'last_contact'])


def stripe_health_retrieve(moneydestionation: MoneyDestination or Iterable[MoneyDestination], many=False):
    output = []
    if not many:
        moneydestionation = [moneydestionation]
    for md in moneydestionation:
        try:
            account = stripe.Account.retrieve(md.stripe_id)
            transfers = account['charges_enabled']
            payout = account['payouts_enabled']
            total_cp = md.chargingstation_set.count()
            enabled_cp = md.chargingstation_set.filter(accept_guests=True).count()
            transf = account['capabilities'].get("transfers")
            card_pay = account['capabilities'].get("card_payments")
            capab_transfers = (transf == "active")
            capab_cardpayments = (card_pay == "active")
            output.append(
                StripeReport(md.id, transfers, payout, capab_transfers, capab_cardpayments, enabled_cp, total_cp))
            # This was the old condition to exclude the healty MoneyDestination
            # if not (transfers and payout) or enabled_cp != total_cp or not (capab_transfers and capab_cardpayments):
        except Exception:
            output.append(StripeReport(md.id, *[None]*6))
            logger.warning(f"MD {md.id} named {md.society_name} with stripe_id {md.stripe_id} is invalid")
    if not many:
        return output[0]
    else:
        return output


def park_health_retrieve(park: Park or [Park], many=False):
    output = []
    if not many:
        park = [park]
    for pk in park:
        last_contact_timestamp = pk.chargingstation_set.all().values_list('last_power__timestamp', flat=True).first()
        if last_contact_timestamp is None:
            output.append(ParkReport(pk.id, None))
        else:
            output.append(ParkReport(pk.id, last_contact_timestamp))
    if not many:
        return output[0]
    else:
        return output
