from django.urls import path, include
from rest_framework import routers
from rest_framework_nested import routers as nested_routers  # https://github.com/alanjds/drf-nested-routers

from .buildinginfos import BuildingInfosViewSet
from .charge import ChargeViewSet
from .chargingstations import ChargingStationViewSet
from .chargecontroller import ChargeControllerViewSet
from .moneydestination import MoneyDestinationViewSet
from .park import ParkViewSet, NestedChargingStationViewSet
from .pmsadmin import PMSViewSet, PMSPendingRequestViewSet
from .power import PowerViewSet
from .ipsum import IPSUMViewSet
from .user import UserViewSet, ManagedParksViewSet, BelongingToViewSet


router = routers.DefaultRouter()
router.register(r"buildinginfos", BuildingInfosViewSet, basename="buildinginfos"),
router.register(r"charges", ChargeViewSet, basename="charge")
router.register(r"chargingstations", ChargingStationViewSet, basename="chargingstation")
router.register(r"chargecontroller", ChargeControllerViewSet, basename="chargecontroller")
router.register(r"moneydestinations", MoneyDestinationViewSet, basename="moneydestination")
router.register(r"parks", ParkViewSet, basename="park")
router.register(r"pms", PMSViewSet, basename="pmsview")
router.register(r"powers", PowerViewSet, basename="power")
router.register(r"ipsumconfigs", IPSUMViewSet, basename="ipsumconfig")
router.register(r"users", UserViewSet, basename="user")
nested_chs_router = nested_routers.NestedDefaultRouter(router, r"parks", lookup="park")
nested_chs_router.register(r"chargingstations", NestedChargingStationViewSet, basename="nestedchargingstation")
nested_usr_router = nested_routers.NestedDefaultRouter(router, r"users", lookup="user")
nested_usr_router.register(r"managedparks", ManagedParksViewSet, basename="managedparks")
nested_usr_router.register(r"belongingto", BelongingToViewSet, basename="belongingto")
nested_pmspr_router = nested_routers.NestedDefaultRouter(router, r"pms", lookup="pms")
nested_pmspr_router.register(r"pendingrequests", PMSPendingRequestViewSet, basename="pmspendingrequests")
urlpatterns = [
    path("", include(router.urls)),
    path("", include(nested_chs_router.urls)),
    path("", include(nested_usr_router.urls)),
    path("", include(nested_pmspr_router.urls))
]