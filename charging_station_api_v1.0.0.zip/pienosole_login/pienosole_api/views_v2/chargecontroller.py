import datetime
import pytz
import logging
import stripe

from rest_framework import mixins, serializers, status
from rest_framework.decorators import action
from rest_framework.response import Response

from drf_spectacular.utils import extend_schema, inline_serializer
from drf_spectacular.types import OpenApiTypes

from django.conf import settings
from django.contrib.auth import login
from django.core.exceptions import MultipleObjectsReturned, ObjectDoesNotExist

from ..libs_v2.charge import start_new_charge_bybnum, stop_opened_charge_bybnum
from ..libs_v2.exceptions import ForbiddenGuestError
from ..libs_v2.payment import cancel_payment_order
from ..libs_v2.permissionviewset import *
from ..libs_v2.user import create_guest_user, expire_user

from .power import PowerSerializer
from .user import UserSerializer

from ..models import ChargingStation, PaymentOrder, Charge

logger = logging.getLogger("api.v2.views.chargecontroller")

stripe.api_key = settings.STRIPE_PRIVATE_KEY


class FrontendChargeSerializer(serializers.ModelSerializer):
    user = UserSerializer()
    last_power = PowerSerializer(source='chargingstation.last_power', required=False)

    class Meta:
        model = Charge
        fields = ['id', 'start', 'stop', 'user', 'last_nonzero_power_time', 'energy_wh', 'last_power']


class ChargeControllerSerializer(serializers.ModelSerializer):
    # allow_null=True?
    active_charge = FrontendChargeSerializer(required=False)
    latitude = serializers.FloatField(source='park.latitude')
    longitude = serializers.FloatField(source='park.longitude')

    class Meta:
        model = ChargingStation
        fields = ['qrcodeid', 'active_charge', 'park', 'park_bnum', 'latitude', 'longitude',
                  'accept_guests', 'is_payment_configured', 'price', 'override_logo_url']


# noinspection PyAbstractClass
class PaymentApiPaymentMethodEmailSerializer(serializers.Serializer):
    paymentmethod_id = serializers.CharField(allow_blank=False, default="")  # defaulted for compatibility
    skip_fingerprint = serializers.BooleanField(default=False)
    email = serializers.EmailField(default="receipts@rossinienergy.com")


# noinspection PyAbstractClass
class PaymentApiEmailSerializer(serializers.Serializer):
    email = serializers.EmailField(default="receipts@rossinienergy.com")


class ChargeControllerViewSet(mixins.RetrieveModelMixin,
                              PermissionGenericViewSet):
    queryset = ChargingStation.objects.all()
    serializer_class = ChargeControllerSerializer
    lookup_field = 'qrcodeid'
    # No filter because it's better to not have them to not expose unnecessary information to a malevolent public
    permission_classes = [IsAuthenticatedNotExpired]
    permission_classes_by_action = {'retrieve': [AllowAny]}

    @extend_schema(responses=OpenApiTypes.BOOL)
    @action(detail=True, methods=['get'], permission_classes=[AllowAny])
    def is_payment_configured(self, request, qrcodeid=None):
        cs = self.get_object()
        # QUESTION: Create a more precise configured option, for example using Stripe Account API
        return Response(cs.is_payment_configured)

    @extend_schema(request=OpenApiTypes.NONE, responses=FrontendChargeSerializer)
    @action(detail=True, methods=["post"])
    def start_charge(self, request, qrcodeid=None):
        logger.debug(f"Received request on start_charge for qrcodeid {qrcodeid}")
        cs = self.get_object()
        pk = cs.bnum
        # Check if the user has the permissions
        if not request.user.is_superuser:
            if cs.qrcodeid not in request.user.userconfig.qrcodeid_allowed:
                logger.info(f"Requested start_charge on {pk} with an unauthorized user \"{request.user.username}\"")
                return Response(status=status.HTTP_401_UNAUTHORIZED)
        # FIXME: For now the frontend doesn't expect an error with a double charge,
        #  atm we dont do anything in case of already existing charge (use exceptions and and status!=200)
        try:
            new_charge = start_new_charge_bybnum(pk, request.user)
        except ForbiddenGuestError as e:
            return Response(e.message, status=status.HTTP_403_FORBIDDEN)
        serialized = FrontendChargeSerializer(new_charge)
        return Response(serialized.data)

    @extend_schema(request=OpenApiTypes.NONE, responses=FrontendChargeSerializer)
    @action(detail=True, methods=["post"])
    def stop_charge(self, request, qrcodeid=None):
        logger.debug(f"Received request on start_charge for qrcodeid {qrcodeid}")
        cs = self.get_object()
        pk = cs.bnum
        # Check if the user has the permissions
        if not request.user.is_superuser:
            if cs.qrcodeid not in request.user.userconfig.qrcodeid_allowed:
                logger.info(f"Requested start_charge on {pk} with an unauthorized user \"{request.user.username}\"")
                return Response(status=status.HTTP_401_UNAUTHORIZED)
        closed_charge = stop_opened_charge_bybnum(pk)
        serialized = FrontendChargeSerializer(closed_charge)
        return Response(serialized.data)

    @extend_schema(request=PaymentApiPaymentMethodEmailSerializer, responses={
        200: inline_serializer(
            name="ClientSecret",
            fields={
                'client_secret': serializers.CharField(),
            }),
        400: OpenApiTypes.STR,
        403: OpenApiTypes.STR,
        500: OpenApiTypes.STR,
    })
    @action(
        detail=True, methods=["post"],
        permission_classes=[AllowAny],
        url_path='payment/imprint',
    )
    def imprint(self, request, qrcodeid=None):
        serialized = PaymentApiPaymentMethodEmailSerializer(data=request.data)
        if not serialized.is_valid():
            msg = f"Invalid imprint data (check email address \"{serialized.initial_data.get('email')}\")"
            logger.error(msg)
            return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        email = serialized.data.get("email", "")
        paymentmethod_id = serialized.data.get("paymentmethod_id", "")
        skip_fingerprint = serialized.data.get("skip_fingerprint", False)
        cs = self.get_object()
        bnum = cs.bnum
        logger.debug(f"Call to imprint_bybnum with bnum={bnum} qrcode={qrcodeid} and email=\"{email}\"")

        if not cs.accept_guests:
            msg = f"Imprint rejected because ChargingStation bnum {bnum} doesn't accept guests"
            logger.info(msg)
            return Response(msg, status=status.HTTP_403_FORBIDDEN)
        if cs.money_receiver is None:
            msg = f"Imprint rejected because ChargingStation bnum {bnum} doesn't have a money receiver configured"
            logger.info(msg)
            return Response(msg, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        if paymentmethod_id != "":
            # Check if PaymentMethod has been used recently checking card fingerprint
            # Take note we use logic shortcircuit in the if
            # We do the time query on confirm_timestamp. If a payment as not been confirmed this field will be Null,
            #   so automatically skipped from the query.
            paymentmethod = stripe.PaymentMethod.retrieve(paymentmethod_id)
            card = paymentmethod['card']
            pm_id = paymentmethod['id']
            fingerprint = card['fingerprint']
            last4 = card['last4']
            exp_month = card['exp_month']
            exp_year = card['exp_year']
            logger.debug(f"PaymentMethodID: {pm_id} - fingerprint: {fingerprint}")
            logger.debug(f"Card: last4 {last4} exp {exp_month}/{exp_year}")

            threshold = datetime.datetime.now(pytz.UTC) - datetime.timedelta(minutes=30)
            if not skip_fingerprint and \
                    PaymentOrder.objects.filter(confirm_timestamp__gt=threshold, fingerprint=fingerprint).count() >= 2:
                msg = f"Card: last4 {last4} exp {exp_month}/{exp_year} fingerprint: {fingerprint} used before. Rejected"
                return Response({
                    'error_code': 2002,
                    'error_msg': msg,
                }, status=status.HTTP_400_BAD_REQUEST)
        else:
            fingerprint = "LEGACY"
            last4 = "LGCY"
            exp_month = "L"
            exp_year = "LGCY"

        # Check if a PaymentOrder not captured for the bnum already exist
        # when this happens, cancel the old one and create a new one
        old_payment_order = PaymentOrder.objects.filter(chargingstation=cs,
                                                        phase__gt=0,  # Not Cancelled Payment
                                                        phase__lt=3,  # Not Captured Payment
                                                        ).first()
        # Policy for redoing the imprint
        if old_payment_order is not None:
            phase_text = old_payment_order.get_phase_display()
            logger.warning(
                f"Trying to create a new imprint for bnum {bnum} but one already exist with phase {phase_text}.")
            if old_payment_order.phase == 1:
                cancel_payment_order(old_payment_order)
                logger.warning("Closing old imprint to create a new one...")
            elif old_payment_order.phase == 2:
                has_guest_charges = old_payment_order.guest_user.charge_set.exists()
                if has_guest_charges:
                    msg = "We dont want to close and reimprint for phase 2 with an open charge."
                    logger.error(msg)
                    return Response(msg, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
                else:
                    cancel_payment_order(old_payment_order)
                    expire_user(old_payment_order.guest_user)
                    logger.warning("Closing old confirmed to create a new one...")

        if paymentmethod_id == "":
            receiver_id = cs.money_receiver.stripe_id
            intent = stripe.PaymentIntent.create(
                amount=settings.AMOUNT_TO_IMPRINT,
                currency="eur",
                metadata={"id_chargingstation": str(bnum)},
                capture_method="manual",
                transfer_data={
                    "destination": receiver_id
                },
                on_behalf_of=receiver_id,
                receipt_email=email,
            )
        else:
            receiver_id = cs.money_receiver.stripe_id
            intent = stripe.PaymentIntent.create(
                amount=settings.AMOUNT_TO_IMPRINT,
                currency="eur",
                metadata={"id_chargingstation": str(bnum)},
                capture_method="manual",
                transfer_data={
                    "destination": receiver_id
                },
                on_behalf_of=receiver_id,
                receipt_email=email,
                payment_method=paymentmethod_id,
            )
        # QUESTION: There is a better method to check if the intent is good?
        if intent is None:
            msg = "Missing Stripe Intent"
            logger.warning(msg)
            return Response(msg, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        imprint_id = intent.id
        # Redo the check to prevent race condition
        # Check if a PaymentOrder not captured for the bnum already exist
        # when this happens, cancel the old one and create a new one
        old_payment_order = PaymentOrder.objects.filter(chargingstation=cs,
                                                        phase__gt=0,  # Not Cancelled Payment
                                                        phase__lt=3,  # Not Captured Payment
                                                        ).first()
        # Policy for redoing the imprint
        if old_payment_order is not None:
            msg = f"DESYNC ERROR - the imprint found out a old_payment_order right before the save. Skipping..."
            logger.warning(msg)
            return Response(msg, status=status.HTTP_200_OK)
        # Create PaymentOrder object:
        order = PaymentOrder(
            chargingstation=cs,
            phase=1,  # Imprinted
            imprint_id=imprint_id,
            imprinted_cents=settings.AMOUNT_TO_IMPRINT,
            fingerprint=fingerprint,
            last4=last4,
            exp_month=exp_month,
            exp_year=exp_year,
        )
        order.save()
        logger.info(f"Imprinted payment order for chargingstation {cs.bnum} for "
                    f"amount {settings.AMOUNT_TO_IMPRINT} cents")
        # Send the client_secret
        rep = {"client_secret": intent.client_secret}
        return Response(rep)

    @extend_schema(request=PaymentApiEmailSerializer, responses=OpenApiTypes.NONE)
    @action(
        detail=True, methods=["post"],
        permission_classes=[AllowAny],
        url_path='payment/confirm_auth',
    )
    def confirm_auth(self, request, qrcodeid=None):
        serialized = PaymentApiEmailSerializer(data=request.data)
        if not serialized.is_valid():
            msg = f"Invalid imprint email address \"{serialized.initial_data.get('email')}\""
            logger.error(msg)
            return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        email = serialized.data.get("email", "")
        cs = self.get_object()
        bnum = cs.bnum

        # Retrieve PaymentIntent
        try:
            payord = PaymentOrder.objects.get(chargingstation=cs, phase=1)  # Imprinted but not confirmed
        except ObjectDoesNotExist:
            msg = f"Tried to confirm payment for ChargingStation bnum {bnum} that is without open PaymentOrder"
            logger.error(msg)
            return Response(msg, status=status.HTTP_404_NOT_FOUND)
        except MultipleObjectsReturned:
            msg = f"Multiple PaymentOrder are in imprinted phase for the ChargingStation bnum {bnum}"
            logger.critical(msg)
            return Response(msg, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        retr = stripe.PaymentIntent.retrieve(payord.imprint_id)
        if retr.status == 'requires_capture':
            tmp_user = create_guest_user(chargingstation=cs, email=email)
            payord.phase = 2
            payord.guest_user = tmp_user
            payord.confirm_timestamp = datetime.datetime.now(pytz.UTC)
            payord.save()
            login(request, tmp_user)
            logger.info(
                f"Confirmed payment id {payord.id} for chargingstation {bnum} for guest user {tmp_user.username}"
            )
            return Response()
        else:
            msg = f"PaymentOrder id {payord.id} for cs {bnum} not confirmed, with status \"{retr.status}\""
            logger.error(msg)
            return Response(msg, status=status.HTTP_403_FORBIDDEN)
