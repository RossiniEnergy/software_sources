from rest_framework import mixins, serializers
from rest_framework.pagination import LimitOffsetPagination
from django_filters import rest_framework as filters
from django.db.models import DateTimeField

from ..libs_v2.permissionviewset import PermissionGenericViewSet, IsAuthenticatedNotExpired, IsParkAdmin, IsAdminUser

from ..models import Power


class PowerPagination(LimitOffsetPagination):
    default_limit = 1000
    max_limit = 10000


class PowerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Power
        fields = '__all__'


class PowerFilterSet(filters.FilterSet):
    park_id = filters.NumberFilter(field_name='chargingstation__park_id')
    park_name = filters.CharFilter(field_name='chargingstation__park__name')
    park_bnum = filters.NumberFilter(field_name='chargingstation__park_bnum')
    chargingstation = filters.NumberFilter(field_name='chargingstation__bnum')

    class Meta:
        model = Power
        fields = {
            'id': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'power': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'timestamp': ['lt', 'lte', 'gt', 'gte'],
        }
        filter_overrides = {
            DateTimeField: {
                'filter_class': filters.IsoDateTimeFilter
            }
        }


class PowerViewSet(mixins.ListModelMixin,
                   mixins.RetrieveModelMixin,
                   PermissionGenericViewSet):
    serializer_class = PowerSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = PowerFilterSet
    pagination_class = PowerPagination
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser | IsParkAdmin]

    def get_queryset(self):
        queryparam_reversed = bool(int(self.request.query_params.get('reversed', 0)))
        queryset = Power.objects.order_by("id")
        if queryparam_reversed:
            queryset = queryset.reverse()
        return queryset
