from rest_framework import mixins, serializers
from rest_framework.permissions import IsAdminUser
from django_filters import rest_framework as filters

from .power import PowerSerializer

from ..libs_v2.permissionviewset import PermissionGenericViewSet, IsAuthenticatedNotExpired

from ..models import ChargingStation


# TODO: Introduce the active_charge in the same manner it's done in chargecontroller
# TODO: can i fuse this and the user one? Only the edit settings change. Be careful about the money_receiver default!
class StaffChargingStationSerializer(serializers.ModelSerializer):
    last_power = PowerSerializer(required=False)

    class Meta:
        model = ChargingStation
        fields = ['park', 'park_bnum', 'bnum', 'accept_guests', 'money_receiver',
                  'price', 'com', 'qrcodeid', 'last_power']
        extra_kwargs = {
            'park': {'read_only': True, 'required': False},
            'park_bnum': {'read_only': True},
            'bnum': {'read_only': True, 'required': False},
            'money_receiver': {'default': None},  # 'required': False,
            'qrcodeid': {'default': None},
            'last_power': {'read_only': True},
        }


class UserChargingStationSerializer(serializers.ModelSerializer):
    last_power = PowerSerializer(required=False)

    class Meta:
        model = ChargingStation
        fields = ['park', 'park_bnum', 'bnum', 'accept_guests', 'money_receiver',
                  'price', 'com', 'qrcodeid', 'last_power']
        read_only_fields = ['park', 'park_bnum', 'bnum', 'accept_guests',
                            'money_receiver', 'qrcodeid']


class ChargingStationFilterSet(filters.FilterSet):
    latitude = filters.RangeFilter()
    longitude = filters.RangeFilter()

    class Meta:
        model = ChargingStation
        fields = {
            'park': ['exact'],
            'park_bnum': ['exact'],
            'bnum': ['exact'],
            'accept_guests': ['exact'],
            'money_receiver': ['exact', 'isnull'],
            'price': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'com': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'qrcodeid': ['exact', 'isnull', 'in'],
        }


class ChargingStationViewSet(mixins.ListModelMixin,
                             mixins.RetrieveModelMixin,
                             mixins.UpdateModelMixin,
                             PermissionGenericViewSet):
    queryset = ChargingStation.objects.order_by("bnum")
    serializer_class = StaffChargingStationSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = ChargingStationFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser]
