import logging
import random
import datetime
import pytz

from dateutil.parser import isoparse

from rest_framework import mixins, serializers, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from drf_spectacular.utils import extend_schema, inline_serializer
from drf_spectacular.types import OpenApiTypes
from django_filters import rest_framework as filters

from django.conf import settings
from django.db.models import Q
from django.contrib.auth import login, authenticate, logout
from django.core.exceptions import MultipleObjectsReturned, ObjectDoesNotExist

from ..libs_v2.charge import close_all_user_charges
from ..libs_v2.permissionviewset import *
from ..libs_v2.user import create_new_user, expire_user

from .park import ParkSerializer, StaffParkSerializer, ParkFilterSet

from ..models import Park, User, UserConfig, ChargingStation, PMSAdminUser

logger = logging.getLogger("api.v2.views.user")


# ManyToMany are default READONLY
#  https://www.django-rest-framework.org/api-guide/relations/#manytomanyfields-with-a-through-model
class UserConfigSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserConfig
        fields = ['authorized_bnum', 'expired', 'expire_datetime', 'expire_policy',
                  'guest', 'managed_parks', 'belonging_to']
        read_only_fields = ['guest']


class UserSerializer(serializers.ModelSerializer):
    config = UserConfigSerializer(source="userconfig")
    # username is already UNIQUE in auth_user model

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'is_active', 'is_staff', 'is_superuser', 'config']
        read_only_fields = ['id', 'is_active', 'is_superuser']

    def update(self, instance, validated_data):
        if 'config' in validated_data:
            nested_serializer = self.fields['config']
            nested_instance = instance.userconfig
            nested_data = validated_data.pop('config')

            # Runs the update on whatever serializer the nested data belongs to
            nested_serializer.update(nested_instance, nested_data)

        # Runs the original parent update(), since the nested fields were
        # "popped" out of the data
        return super(UserSerializer, self).update(instance, validated_data)


class UserFilterSet(filters.FilterSet):
    expired = filters.BooleanFilter(field_name='userconfig__expired')
    expire_datetime__lt = filters.IsoDateTimeFilter(field_name='userconfig__expire_datetime', lookup_expr='lt')
    expire_datetime__lte = filters.IsoDateTimeFilter(field_name='userconfig__expire_datetime', lookup_expr='lte')
    expire_datetime__gt = filters.IsoDateTimeFilter(field_name='userconfig__expire_datetime', lookup_expr='gt')
    expire_datetime__gte = filters.IsoDateTimeFilter(field_name='userconfig__expire_datetime', lookup_expr='gte')
    expire_policy = filters.ChoiceFilter(field_name='userconfig__expire_policy', choices=UserConfig.EXPIRE_POLICIES)
    guest = filters.BooleanFilter(field_name='userconfig__guest')
    managing_park_id = filters.NumberFilter(field_name='userconfig__managed_parks')
    belonging_to_user_id = filters.NumberFilter(field_name='userconfig__belonging_to')

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'is_active', 'is_staff', 'is_superuser']


# noinspection PyAbstractClass
class CreateUserSerializer(serializers.Serializer):
    username = serializers.CharField(required=True)
    password = serializers.CharField(required=True)
    email = serializers.CharField(allow_blank=True, default='')
    qrcodes = serializers.CharField(allow_blank=True, default='')
    managed_parks_parknames = serializers.CharField(allow_blank=True, default='')
    belonging_to_users = serializers.CharField(allow_blank=True, default='')


# noinspection PyAbstractClass
class CreateTempUserSerializer(serializers.Serializer):
    username = serializers.CharField(required=False)
    password = serializers.CharField(required=False)
    email = serializers.CharField(required=False)
    authorized_bnum = serializers.CharField(required=False)
    expire_datetime = serializers.DateTimeField(required=False)


# TODO: Stats module
class UserViewSet(mixins.ListModelMixin,
                  mixins.RetrieveModelMixin,
                  mixins.UpdateModelMixin,
                  PermissionGenericViewSet):
    serializer_class = UserSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = UserFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsStaffForObject | IsHimselfUser | IsBelongerUser]
    # Bitwise OR | can be used to compose permissions. Check of every entry is "and" the others.
    # Retrieve old permissions: IsStaffForObject | IsBelongerUser | IsHimselfUser
    permission_classes_by_action = {'list': [IsAuthenticatedNotExpired],
                                    'retrieve': [IsAuthenticatedNotExpired],
                                    'update': [IsAuthenticatedNotExpired, IsStaffForObject | IsBelongerUser],
                                    'partial_update': [IsAuthenticatedNotExpired, IsStaffForObject | IsBelongerUser],
                                    'create': [IsAuthenticatedNotExpired, IsAdminUser]}

    def get_queryset(self):
        if not IsAuthenticatedNotExpired().has_permission(self.request, self):
            return User.objects.none()
        elif IsAdminUser().has_permission(self.request, self):
            # If a user is Admin, show every user
            return User.objects.order_by("id")
        else:
            # Show the user in the list only if at least one of this condition is True:
            # - The user is himself
            # - The user contains the requester user in his belonging_to
            user = self.request.user
            return User.objects.filter(Q(pk=user.pk) | Q(userconfig__belonging_to=user)).distinct()

    @extend_schema(request=CreateUserSerializer)
    def create(self, request, *args, **kwargs):
        serialized_input = CreateUserSerializer(data=request.data)
        if not serialized_input.is_valid():
            msg = "Error validating request format."
            return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        username = serialized_input.data['username']
        password = serialized_input.data['password']
        email = serialized_input.data.get('email', '')
        # TODO: send me lists of id and not strings
        qrcodes = serialized_input.data.get("qrcodes", "")
        # list of park names comma-separed
        managed_parks_parknames = serialized_input.data.get("managed_parks_parknames", "")
        # list of user usernames comma-separed
        belonging_to_users = serialized_input.data.get("belonging_to_users", "")

        qrcodes_list = qrcodes.split(",")
        try:
            qrcodes_list = [int(qrstr.strip()) for qrstr in qrcodes_list if qrstr.strip() != '']
        except ValueError:
            msg = "Error casting a qrcode list to integer list."
            logger.error(msg)
            return Response(msg, status=status.HTTP_400_BAD_REQUEST)

        managed_parks_list = managed_parks_parknames.split(",")
        try:
            managed_parks_list = \
                [Park.objects.get(name=parkstr.strip()) for parkstr in managed_parks_list if parkstr.strip() != '']
        except ObjectDoesNotExist:
            msg = "Error casting a managed_parks_parknames list to a Park list."
            logger.error(msg)
            return Response(msg, status=status.HTTP_404_NOT_FOUND)

        belonging_to_users = belonging_to_users.split(",")
        try:
            belonging_to_users = \
                [User.objects.get(username=userstr.strip()) for userstr in belonging_to_users if userstr.strip() != '']
        except ObjectDoesNotExist:
            msg = "Error casting a belonging_to_users list to a User list."
            logger.error(msg)
            return Response(msg, status=status.HTTP_404_NOT_FOUND)

        bnum_list = []
        for qr in qrcodes_list:
            try:
                cs = ChargingStation.objects.get(qrcodeid=qr)
            except (MultipleObjectsReturned, ObjectDoesNotExist):
                msg = f"The QR Code {qr} doesn't have a correlated ChargingStation"
                logger.error(msg)
                return Response(msg, status=status.HTTP_404_NOT_FOUND)
            bnum_list.append(cs.bnum)
        user = create_new_user(username=username,
                               password=password,
                               email=email,
                               authorized_bnum=bnum_list,
                               managed_parks=managed_parks_list,
                               belonging_to=belonging_to_users,
                               )
        logger.info(f"Created user \"{username}\" with customcreateuser")
        serialized_user = self.get_serializer(user)
        return Response(serialized_user.data, status=status.HTTP_201_CREATED)

    @extend_schema(request=CreateTempUserSerializer)
    @action(detail=False, methods=['post'], permission_classes=[IsAuthenticatedNotExpired, IsParkAdmin])
    def new_temp_user(self, request):
        serialized_input = CreateTempUserSerializer(data=request.data)
        if not serialized_input.is_valid():
            msg = "Error validating request format."
            return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        parent_user = request.user
        already_existing_usernames = User.objects.all().values_list('username', flat=True)
        # FIXME: siamo davvero sicuri di voler lasciare ai parkadmin la possibilità di scegliere nomi completamente
        #   liberi? Non è forse meglio FORZARE l'uso di un prefisso così che non collidano tra di loro e con noi?
        #   Tipo ad esempio l'utente magravio quando passa un username, il finale sarà sempre magr_username.
        if "username" in serialized_input.data:
            random_username = request.data.get("username")
            if random_username in already_existing_usernames:
                msg = "Username already used in our systems."
                logger.error(msg)
                return Response(msg, status=status.HTTP_403_FORBIDDEN)
        else:
            # Find unused random_username with a sequential available suffix number
            i = 1
            while i < 1_000_000:
                random_username = "{}_{}".format(parent_user.username, i)
                if random_username not in already_existing_usernames:
                    break
                i += 1
            else:
                msg = "Trying to create a temp user with id over 1'000'000. This is a sign of database saturation."
                logger.error(msg)
                return Response(msg, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        # Continue configuration
        random_password = serialized_input.data.get("password", str(random.randint(1_000_000, 9_999_999)))
        email = serialized_input.data.get("email", None)
        # Configure qrcode from parent if not given, or from json if given
        cs_id_list = serialized_input.data.get("authorized_bnum")
        if cs_id_list is not None:
            authorized_bnum = cs_id_list.split(",")
            try:
                authorized_bnum = [int(bnumstr.strip()) for bnumstr in authorized_bnum if bnumstr.strip() != '']
            except ValueError:
                msg = "Error casting a bnum list to integer list."
                logger.error(msg)
                return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        else:
            managed_parks = parent_user.userconfig.managed_parks.all()
            authorized_bnum = []
            for park in managed_parks:
                authorized_bnum.extend(list(park.chargingstation_set.all().values_list('bnum', flat=True)))
        # Expiration calculation
        expire_datetime_str = serialized_input.data.get("expire_datetime")
        belonging_to = [parent_user]
        if expire_datetime_str is not None:
            expire_datetime = isoparse(expire_datetime_str)
            if expire_datetime < datetime.datetime.now(pytz.UTC):
                msg = f"Trying to create a user with expire_datetime {expire_datetime} already passed."
                logger.error(msg)
                return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        else:
            expire_datetime = None  # This tell to create_new_user to not insert an expire_datetime
        tmp_user = create_new_user(username=random_username,
                                   password=random_password,
                                   email=email,
                                   authorized_bnum=authorized_bnum,
                                   expire_datetime=expire_datetime,
                                   expire_policy='DIS',  # Disable!
                                   belonging_to=belonging_to)
        logger.info(f"Created tmp user with username \"{tmp_user.username}\" and expire date \"{expire_datetime}\" for "
                    f"the user \"{parent_user.username}\".")
        serialized_user = self.get_serializer(tmp_user)
        data = serialized_user.data
        data['password'] = random_password
        return Response(data, status=status.HTTP_201_CREATED)

    @extend_schema(request=inline_serializer(
            name="NewPassword",
            fields={
                'new_password': serializers.CharField(),
            }),
        responses=OpenApiTypes.STR)
    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticatedNotExpired,
                                                               IsStaffForObject | IsBelongerUser | IsHimselfUser])
    def reset_password(self, request, pk=None):
        user = self.get_object()
        new_password = request.data['new_password']
        user.set_password(new_password)
        user.save()
        logger.info(f"Resetted password for User {user.username}")
        return Response("Password Resetted correctly")

    # TODO: myself is a routing alias to /users/{request.user.id}/ so you can use all the ViewSet function from here
    @action(detail=False, methods=['get'], permission_classes=[IsAuthenticated])
    def myself(self, request):
        user = request.user
        serialized_user = self.get_serializer(user)
        return Response(serialized_user.data)

# CRSF Exempt for Django Rest Framework: https://stackoverflow.com/a/30875830
    @extend_schema(request=inline_serializer(name='Login', fields={
        'username': serializers.CharField(),
        'password': serializers.CharField(),
        'qrcodeid': serializers.IntegerField(required=False)
    }))
    @action(
        detail=False, methods=['post'],
        permission_classes=[AllowAny],
    )
    def login(self, request):
        try:
            username = request.data['username']
            password = request.data['password']
            qrcodeid = request.data.get('qrcodeid')
        except KeyError:
            msg = "Bad Request. Expecting `username` and `password` in POST Request body (POSTForm or JSON)"
            return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        if '#' in username or '$' in username:
            return Response("Invalid use of special characters # or $ in username", status=status.HTTP_403_FORBIDDEN)
        # Check if a prefix is needed for the username
        if qrcodeid:
            try:
                cs = ChargingStation.objects.get(qrcodeid=qrcodeid)
                park = cs.park
                pmsadmin = PMSAdminUser.objects.filter(user__userconfig__managed_parks=park).distinct().first()
                if pmsadmin:
                    username = f"{pmsadmin.user.id}${username}"
            except ChargingStation.DoesNotExist:
                pass
        # Authenticate
        user = authenticate(request, username=username, password=password)
        if user is not None:
            if user.userconfig.expired:
                return Response("User requested is expired", status=status.HTTP_401_UNAUTHORIZED)
            login(request, user)
            serialized_user = self.get_serializer(user)
            return Response(serialized_user.data)
        else:
            return Response("Invalid User/Password combination", status=status.HTTP_401_UNAUTHORIZED)

    @extend_schema(responses=OpenApiTypes.NONE)
    @action(detail=False, methods=['get'], permission_classes=[AllowAny])
    def logout(self, request):
        csrf_domain = settings.CSRF_COOKIE_DOMAIN
        logout(request)
        response = Response()
        response.delete_cookie("sessionid", samesite='Lax')  # Delete old sessionid from before the domain change
        response.delete_cookie("csrftoken", domain=csrf_domain, samesite='Lax')  # Delete csrftoken at logout
        return response

    @extend_schema(responses=inline_serializer(name='ChargePermissions', fields={
        'authorized_qrcode': serializers.ListField(child=serializers.IntegerField())}))
    @action(detail=True, methods=['get'], permission_classes=[IsAuthenticatedNotExpired, IsAuthenticated])
    def charge_permissions(self, request, pk=None):
        user = self.get_object()
        # user_authorized_cs = user.userconfig.chargingstation_allowed
        # user_authorized_bnum = list(cs.bnum for cs in user_authorized_cs)
        user_authorized_qrcode = user.userconfig.qrcodeid_allowed
        return Response({'authorized_qrcode': user_authorized_qrcode})

    @extend_schema(request=OpenApiTypes.NONE, responses=OpenApiTypes.NONE)
    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticatedNotExpired,
                                                               IsStaffForObject | IsBelongerUser])
    def expire(self, request, pk=None):
        user = self.get_object()
        if user.userconfig.expired:
            msg = f"Trying to force expiration of the already expired user \"{user.username}\""
            logger.warning(msg)
            return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        else:
            expire_user(user)
            close_all_user_charges(user)
            return Response()

    @extend_schema(request=OpenApiTypes.NONE)
    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticatedNotExpired, IsAdminUser])
    def sudo(self, request, pk=None):
        user = self.get_object()
        login(request, user)
        serialized_user = self.get_serializer(user)
        return Response(serialized_user.data)


# Nest in the user Viewset the managed_park and belonging_to as separated viewset with
#   list, retrieve, register, unregister
#   The idea is to have a method under the UserViewset called managed_parks that returns
#   a list of Park. Pratically a ModelViewSet hand-maded.
#   users/1/managed_parks/ -> returns the park list
#   users/1/managed_parks/4/ -> returns the park with park_id=4 if it exists
#   users/1/managed_parks/register/ POST park_id to make managed
#   users/1/managed_parks/4/unregister/ GET but remove the park_id from the managed
class ManagedParksViewSet(mixins.ListModelMixin,
                          mixins.RetrieveModelMixin,
                          PermissionGenericViewSet):
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = ParkFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsStaffForObject | IsBelongerUser | IsHimselfUser]

    def get_serializer_class(self):
        if bool(self.request.user and self.request.user.is_staff):
            return StaffParkSerializer
        else:
            return ParkSerializer

    def get_user(self):
        return User.objects.get(pk=self.kwargs['user_pk'])

    def check_object_permissions(self, request, obj):
        user = self.get_user()
        super().check_object_permissions(request, user)

    def get_queryset(self):
        try:
            return self.get_user().userconfig.managed_parks.all()
        except ObjectDoesNotExist:  # Queryset when the parent query does not exist
            return Park.objects.none()
        except KeyError:  # For Schema Generation
            return Park.objects.none()

    @extend_schema(request=inline_serializer(name="RegisterPark", fields={'park_id': serializers.IntegerField()}),
                   responses=OpenApiTypes.NONE)
    @action(detail=False, methods=['post'], permission_classes=[IsAuthenticatedNotExpired,
                                                                IsStaffForObject | IsBelongerUser])
    def register(self, request, user_pk=None):
        try:
            user = self.get_user()
        except ObjectDoesNotExist:
            return Response(status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        park_id = request.data.get("park_id")
        if park_id is not None:
            try:
                park = Park.objects.get(pk=park_id)
            except ObjectDoesNotExist:
                msg = "The 'id' given doesn't correspond to a valid Park."
                return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        else:
            msg = "At least one between 'id' and 'name' is required to register a new managed park."
            return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        userconf = user.userconfig
        userconf.managed_parks.add(park)
        userconf.save()
        return Response()

    @extend_schema(request=OpenApiTypes.NONE, responses=OpenApiTypes.NONE)
    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticatedNotExpired,
                                                               IsStaffForObject | IsBelongerUser])
    def unregister(self, request, pk=None, user_pk=None):
        try:
            user = self.get_user()
        except ObjectDoesNotExist:
            return Response(status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        park = self.get_object()
        userconf = user.userconfig
        userconf.managed_parks.remove(park)
        userconf.save()
        return Response()

    @extend_schema(request=inline_serializer(name='OverwriteParks', fields={
        'park_id_list': serializers.ListField(child=serializers.IntegerField())
    }), responses=OpenApiTypes.NONE)
    @action(detail=False, methods=['post'], permission_classes=[IsAuthenticatedNotExpired,
                                                                IsStaffForObject | IsBelongerUser])
    def overwrite(self, request, user_pk=None):
        try:
            user = self.get_user()
        except ObjectDoesNotExist:
            return Response(status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        park_id_list = request.data.get("park_id_list")
        try:
            parks = [Park.objects.get(pk=int(x)) for x in park_id_list]
        except ValueError:
            msg = "Generic error during parsing"
            return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        except ObjectDoesNotExist:
            msg = "One of the Park requested doesn't exist."
            return Response(msg, status=status.HTTP_404_NOT_FOUND)
        userconf = user.userconfig
        userconf.managed_parks.clear()
        for park in parks:
            userconf.managed_parks.add(park)
        userconf.save()
        return Response()


class BelongingToViewSet(mixins.ListModelMixin,
                         mixins.RetrieveModelMixin,
                         PermissionGenericViewSet):
    serializer_class = UserSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = UserFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsStaffForObject | IsBelongerUser | IsHimselfUser]

    def get_user(self):
        return User.objects.get(pk=self.kwargs['user_pk'])

    def check_object_permissions(self, request, obj):
        user = self.get_user()
        super().check_object_permissions(request, user)

    def get_queryset(self):
        try:
            return self.get_user().userconfig.belonging_to.all()
        except ObjectDoesNotExist:  # Queryset when the parent query does not exist
            return User.objects.none()
        except KeyError:  # For Schema Generation
            return User.objects.none()

    @extend_schema(request=inline_serializer(name="RegisterUser", fields={'user_id': serializers.IntegerField()}),
                   responses=OpenApiTypes.NONE)
    @action(detail=False, methods=['post'], permission_classes=[IsAuthenticatedNotExpired,
                                                                IsStaffForObject | IsBelongerUser])
    def register(self, request, user_pk=None):
        try:
            user = self.get_user()
        except ObjectDoesNotExist:
            return Response(status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        user_id = request.data.get("user_id")
        if user_id is not None:
            try:
                belonged_user = User.objects.get(pk=user_id)
            except ObjectDoesNotExist:
                msg = "The 'id' given doesn't correspond to a valid User."
                return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        else:
            msg = "At least one between 'id' and 'username' is required to register a new managed park."
            return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        userconf = user.userconfig
        userconf.belonging_to.add(belonged_user)
        userconf.save()
        return Response()

    @extend_schema(request=OpenApiTypes.NONE, responses=OpenApiTypes.NONE)
    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticatedNotExpired,
                                                               IsStaffForObject | IsBelongerUser])
    def unregister(self, request, pk=None, user_pk=None):
        try:
            user = self.get_user()
        except ObjectDoesNotExist:
            return Response(status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        belonged_user = self.get_object()
        userconf = user.userconfig
        userconf.belonging_to.remove(belonged_user)
        userconf.save()
        return Response()

    @extend_schema(request=inline_serializer(name='OverwriteUsers', fields={
        'user_id_list': serializers.ListField(child=serializers.IntegerField())
    }), responses=OpenApiTypes.NONE)
    @action(detail=False, methods=['post'], permission_classes=[IsAuthenticatedNotExpired,
                                                                IsStaffForObject | IsBelongerUser])
    def overwrite(self, request, user_pk=None):
        try:
            user = self.get_user()
        except ObjectDoesNotExist:
            return Response(status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        user_id_list = request.data.get("user_id_list")
        try:
            belongerusers = [User.objects.get(pk=int(x)) for x in user_id_list]
        except ValueError:
            msg = "Generic error during parsing"
            return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        except ObjectDoesNotExist:
            msg = "One of the User requested doesn't exist."
            return Response(msg, status=status.HTTP_404_NOT_FOUND)
        userconf = user.userconfig
        userconf.belonging_to.clear()
        for belongeruser in belongerusers:
            userconf.belonging_to.add(belongeruser)
        userconf.save()
        return Response()
