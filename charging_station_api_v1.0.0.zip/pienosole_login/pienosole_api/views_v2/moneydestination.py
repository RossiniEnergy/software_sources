import logging

from rest_framework import mixins, serializers, status
from rest_framework.decorators import action
from rest_framework.permissions import IsAdminUser
from rest_framework.response import Response
from drf_spectacular.utils import extend_schema
from drf_spectacular.types import OpenApiTypes
from django_filters import rest_framework as filters
from django.http import FileResponse
from django.db.models.deletion import ProtectedError

from ..libs_v2.payment import generate_stripeconnect_link
from ..libs_v2.permissionviewset import PermissionGenericViewSet, IsAuthenticatedNotExpired
from ..views.reports import make_admin_report

from ..models import MoneyDestination

logger = logging.getLogger('api.v2.views.moneydestination')


class MoneyDestinationSerializer(serializers.ModelSerializer):
    class Meta:
        model = MoneyDestination
        fields = ['id', 'society_name', 'email', 'stripe_id', 'address_1', 'address_2', 'postal_code', 'city',
                  'country_alpha2', 'vat_country_alpha2', 'phone_number', 'receipt_language']


class MoneyDestinationFilterSet(filters.FilterSet):
    class Meta:
        model = MoneyDestination
        fields = ['society_name', 'email', 'address_1', 'address_2', 'postal_code', 'city', 'country_alpha2',
                  'vat_country_alpha2', 'phone_number', 'receipt_language']


# noinspection PyAbstractClass
class GenerateLinkSerializer(serializers.Serializer):
    email = serializers.EmailField(default="")
    iban_nationality = serializers.CharField(default="FR")  # TODO: use ChooseField with PyCountry alpha2 list
    refresh_url = serializers.URLField()
    return_url = serializers.URLField()


# noinspection PyAbstractClass
class GeneratePaymentReportSerializer(serializers.Serializer):
    moneydestination = serializers.PrimaryKeyRelatedField(queryset=MoneyDestination.objects.all(), read_only=False)
    timestamp_from = serializers.DateTimeField()
    timestamp_to = serializers.DateTimeField()

    def validate(self, data):
        if not data['timestamp_from'] < data['timestamp_to']:
            raise serializers.ValidationError("'timestamp_to need to be after 'timestamp_from'")
        return data


class MoneyDestinationViewSet(mixins.ListModelMixin,
                              mixins.RetrieveModelMixin,
                              mixins.UpdateModelMixin,
                              mixins.CreateModelMixin,
                              mixins.DestroyModelMixin,
                              PermissionGenericViewSet):
    queryset = MoneyDestination.objects.order_by("id")
    serializer_class = MoneyDestinationSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = MoneyDestinationFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser]

    def destroy(self, request, *args, **kwargs):
        try:
            return super().destroy(request, *args, **kwargs)
        except ProtectedError:
            msg = "MoneyDestination protected by relation with other objects."
            logger.error(f"Error trying to delete {msg}")
            return Response(msg, status=status.HTTP_403_FORBIDDEN)

    @extend_schema(request=GenerateLinkSerializer, responses=OpenApiTypes.URI)
    @action(detail=False, methods=['post'], permission_classes=[IsAuthenticatedNotExpired])
    def generate_stripeconnect_link(self, request):
        serialized = GenerateLinkSerializer(data=request.data)
        if not serialized.is_valid():
            msg = "Error validating request format."
            return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        url = generate_stripeconnect_link(serialized.data['email'],
                                          serialized.data['iban_nationality'],
                                          serialized.data['refresh_url'],
                                          serialized.data['return_url'])
        return Response(url, status=status.HTTP_201_CREATED)

    @extend_schema(request=GeneratePaymentReportSerializer, responses=OpenApiTypes.BINARY)
    @action(detail=True, methods=['post'])
    def make_payment_report(self, request):
        serializer = GeneratePaymentReportSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        moneydestination = serializer.validated_data['moneydestination']
        timestamp_from = serializer.validated_data['timestamp_from']
        timestamp_to = serializer.validated_data['timestamp_to']
        filename = make_admin_report(moneydestination, timestamp_from, timestamp_to)
        return FileResponse(open(filename, 'rb'), as_attachment=True)
