from rest_framework import mixins, serializers
from rest_framework.permissions import IsAuthenticated
from rest_framework.pagination import LimitOffsetPagination
from django_filters import rest_framework as filters
from django.db.models import Q, DateTimeField

from ..models import Charge
from ..libs_v2.permissionviewset import PermissionGenericViewSet
from .user import UserSerializer


class ChargeSetPagination(LimitOffsetPagination):
    default_limit = 1000
    max_limit = 10000


class ChargeSerializer(serializers.ModelSerializer):
    qrcodeid = serializers.IntegerField(source='chargingstation.qrcodeid')
    park_id = serializers.IntegerField(source='chargingstation.park_id')
    user = UserSerializer()

    class Meta:
        model = Charge
        fields = ['id', 'chargingstation', 'qrcodeid', 'start', 'stop', 'user', 'last_nonzero_power_time', 'energy_wh',
                  'park_id']


class ChargeFilter(filters.FilterSet):
    # If you don't write the lookup_field it's assumed 'exact', so the alias to the "no special lookup, simple equal"
    park_id = filters.NumberFilter(field_name='chargingstation__park_id')
    qrcodeid = filters.NumberFilter(field_name='chargingstation__qrcodeid')
    qrcodeid__isnull = filters.BooleanFilter(field_name='chargingstation__qrcodeid', lookup_expr='isnull')
    user_is_expired = filters.BooleanFilter(field_name='user__userconfig__is_expired')
    user_username = filters.CharFilter(field_name='user__username')
    user_is_active = filters.BooleanFilter(field_name='user__is_active')

    class Meta:
        model = Charge
        fields = {
            'chargingstation': ['exact'],
            'user_id': ['exact'],
            'start': ['lt', 'gt', 'lte', 'gte'],
            'stop': ['lt', 'gt', 'lte', 'gte'],
            'last_nonzero_power_time': ['lt', 'gt', 'lte', 'gte'],
            'energy_wh': ['exact', 'lt', 'gt', 'lte', 'gte'],
        }
        filter_overrides = {
            DateTimeField: {
                'filter_class': filters.IsoDateTimeFilter
            }
        }


class ChargeViewSet(mixins.ListModelMixin,
                    mixins.RetrieveModelMixin,
                    PermissionGenericViewSet):
    serializer_class = ChargeSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = ChargeFilter
    pagination_class = ChargeSetPagination
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user is None or not user.is_authenticated:
            # Not authenticated user see no charge
            queryset = Charge.objects.none()
        elif user.is_staff:
            # Staff user see all the charge
            queryset = Charge.objects.order_by("id")
        else:
            # Everyone else see self charge and managed_parks charges and belonging_user charges
            queryset = Charge.objects.order_by("id").filter(
                Q(user=user) |
                Q(chargingstation__park__in=user.userconfig.managed_parks.all()) |
                Q(user__userconfig__belonging_to=user)
            )
        queryparam_reversed = bool(int(self.request.query_params.get('reversed', 0)))
        if queryparam_reversed:
            queryset = queryset.reverse()
        return queryset
