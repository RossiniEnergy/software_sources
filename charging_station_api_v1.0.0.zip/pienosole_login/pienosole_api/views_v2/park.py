import logging

from rest_framework import mixins, serializers, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAdminUser
from drf_spectacular.utils import extend_schema
from drf_spectacular.types import OpenApiTypes
from django_filters import rest_framework as filters
from py_expression_eval import Parser
from django.conf import settings

from ..libs_v2.advenir import advenir_send_test_charge
from ..libs_v2.permissionviewset import PermissionGenericViewSet, IsAuthenticatedNotExpired, \
    IsParkAdminForChargingStation

from .chargingstations import StaffChargingStationSerializer, UserChargingStationSerializer, ChargingStationFilterSet

from ..models import Park, ChargingStation, IPSUMConfig


logger = logging.getLogger('api.v2.views.park')


class ParkSerializer(serializers.ModelSerializer):
    chargingstations = StaffChargingStationSerializer(source='chargingstation_set', many=True, read_only=True)

    class Meta:
        model = Park
        fields = ['id', 'name', 'latitude', 'longitude', 'address', 'postal_code', 'city', 'country_alpha2',
                  'accept_gireve', 'chargingstations', 'installed']
        read_only_fields = fields


class StaffParkSerializer(serializers.ModelSerializer):
    # TODO: Can I order this with park_bnum?
    chargingstations = StaffChargingStationSerializer(source='chargingstation_set', many=True)
    # Remember you can't modify chargingstations directly from StaffParkSerializer

    class Meta:
        model = Park
        fields = ['id', 'name', 'latitude', 'longitude', 'email', 'email_report',
                  'address', 'postal_code', 'city', 'country_alpha2',
                  'accept_gireve', 'chargingstations', 'teamviewerid', 'anydeskid', 'creation_date',
                  'last_updated', 'software_version', 'installed', 'linked_ipsums', 'ipsum_send_time',
                  'ipsum_last_send', 'ipsum_avalpower_formula', 'note']
        extra_kwargs = {
            'creation_date': {'read_only': True, 'required': False},
            'last_updated': {'read_only': True, 'required': False},
            'software_version': {'read_only': True, 'default': ""},  # 'required': False,
            'linked_ipsums': {'allow_empty': True},
            'ipsum_avalpower_formula': {'default': ""},
        }

    # noinspection PyMethodMayBeStatic
    def validate(self, data):
        # Retrieve the list of linked ipsums
        if 'linked_ipsums' in data:
            linked_ipsums = [obj.id for obj in data['linked_ipsums']]
        elif self.partial:
            linked_ipsums = self.instance.linked_ipsums.values_list('id', flat=True)
        else:
            linked_ipsums = []
            # raise serializers.ValidationError("Unable to parse ipsum_avalpower_formula: missing linked_ipsums")
        # Retrieve the ipsum_avalpower_formula
        if 'ipsum_avalpower_formula' in data:
            ipsum_avalpower_formula = data['ipsum_avalpower_formula']
        elif self.partial:
            ipsum_avalpower_formula = self.instance.ipsum_avalpower_formula
        else:
            raise serializers.ValidationError("Unable to parse ipsum_avalpower_formula: missing value")
        # Start parsing
        if not ipsum_avalpower_formula == "":
            try:
                parser = Parser()
                parsed = parser.parse(ipsum_avalpower_formula)
                for var in parsed.variables():
                    # Verify that variables are in the format and pattern D21P3
                    if var[0] == 'D':
                        splitted = var[1:].split('P')
                        if len(splitted) != 2:
                            raise serializers.ValidationError(f"Invalid variable name {var}")
                        ipsum_id, power_id = (int(x) for x in splitted)
                        # Check if ipsum_id is valid
                        try:
                            ipconf = IPSUMConfig.objects.get(pk=ipsum_id)
                        except IPSUMConfig.DoesNotExist:
                            raise serializers.ValidationError(f"Ipsum with id {ipsum_id} doesn't exist")
                        if ipsum_id not in linked_ipsums:  # ipconf in linked_ipsums
                            raise serializers.ValidationError(f"Ipsum with id {ipsum_id} is not linked")
                        # Check if power_id is valid
                        expected_clamps = ipconf.expected_clamps
                        if power_id < 0 or power_id > expected_clamps:
                            raise serializers.ValidationError(
                                f"Variable D{ipsum_id}P number need to be between 1 and expected_clamps {expected_clamps}")
            except KeyError:
                raise serializers.ValidationError("Unable to parse ipsum_avalpower_formula: Variable Format Error")
            except serializers.ValidationError:
                raise
            except Exception:
                raise serializers.ValidationError("Unable to parse ipsum_avalpower_formula")
        return data

    def create(self, validated_data):
        chargingstations_data = validated_data.pop('chargingstation_set')
        linked_ipsums = validated_data.pop('linked_ipsums')
        park = Park.objects.create(**validated_data)
        park.linked_ipsums.set(linked_ipsums)
        # TODO: We dont need to search everytime the new primary key, the database will do it for me
        #  This require a reset of the sequence in the database instance.
        bnum_previous = ChargingStation.objects.order_by("-bnum").first()
        if bnum_previous is None:
            bnum_previous = 0
        else:
            bnum_previous = bnum_previous.bnum
        for i, ch_data in enumerate(chargingstations_data):
            # FIXME: CHECK IF VALID BEFORE CONFIRMING THE CREATION
            new_cs = ChargingStation.objects.create(
                park=park,
                park_bnum=i+1,
                bnum=bnum_previous + 1,
                **ch_data
            )
            bnum_previous += 1
        return park


# noinspection PyAbstractClass
class SendAdvenirTestDataSerializer(serializers.Serializer):
    transaction_id = serializers.IntegerField(default=1)


class ParkFilterSet(filters.FilterSet):
    class Meta:
        model = Park
        fields = ['name', 'country_alpha2', 'accept_gireve', 'software_version']


class ParkViewSet(mixins.ListModelMixin,
                  mixins.RetrieveModelMixin,
                  mixins.UpdateModelMixin,
                  mixins.CreateModelMixin,
                  PermissionGenericViewSet):
    queryset = Park.objects.order_by("id")
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = ParkFilterSet
    permission_classes_by_action = {'list': [AllowAny],
                                    'retrieve': [AllowAny],
                                    'update': [IsAuthenticatedNotExpired, IsAdminUser],
                                    'partial_update': [IsAuthenticatedNotExpired, IsAdminUser],
                                    'create': [IsAuthenticatedNotExpired, IsAdminUser]}

    def get_serializer_class(self):
        if bool(self.request.user and self.request.user.is_staff):
            return StaffParkSerializer
        else:
            return ParkSerializer

    @extend_schema(request=StaffChargingStationSerializer, responses=StaffChargingStationSerializer)
    @action(detail=True, methods=['POST'], permission_classes=[IsAuthenticatedNotExpired, IsAdminUser])
    def add_chargingstation(self, request, pk=None):
        serializer = StaffChargingStationSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        park = self.get_object()
        bnum_previous = ChargingStation.objects.order_by("-bnum").first()
        if bnum_previous is None:
            bnum_previous = 0
        else:
            bnum_previous = bnum_previous.bnum
        new_cs = ChargingStation.objects.create(
            park=park,
            park_bnum=park.chargingstation_set.count() + 1,
            bnum=bnum_previous + 1,
            **serializer.validated_data
        )
        reply_serializer = StaffChargingStationSerializer(new_cs)
        return Response(reply_serializer.data, status=status.HTTP_201_CREATED)

    @extend_schema(request=SendAdvenirTestDataSerializer, responses=OpenApiTypes.NONE)
    @action(detail=True, methods=['POST'], permission_classes=[IsAuthenticatedNotExpired, IsAdminUser])
    def send_advenir_test_data(self, request, pk=None):
        serializer = SendAdvenirTestDataSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        transaction_id = serializer.data['transaction_id']
        park = self.get_object()
        for ch in park.chargingstation_set.all():
            if settings.STAGING:
                logger.info(f"[STAGING] Launched advenir_test_charge with params {ch.bnum}, {transaction_id}")
            else:
                advenir_send_test_charge.delay(ch.bnum, transaction_id)
        return Response()


class NestedChargingStationViewSet(mixins.ListModelMixin,
                                   mixins.RetrieveModelMixin,
                                   mixins.UpdateModelMixin,
                                   PermissionGenericViewSet):
    lookup_field = "park_bnum"
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = ChargingStationFilterSet
    permission_classes_by_action = {'list': [AllowAny],
                                    'retrieve': [AllowAny],
                                    'update': [IsAuthenticatedNotExpired, IsParkAdminForChargingStation],
                                    'partial_update': [IsAuthenticatedNotExpired, IsParkAdminForChargingStation]}

    def get_queryset(self):
        try:
            return ChargingStation.objects.filter(park_id=self.kwargs['park_pk']).order_by('park_bnum')
        except KeyError:
            return ChargingStation.objects.none()

    def get_serializer_class(self):
        if bool(self.request.user and self.request.user.is_staff):
            return StaffChargingStationSerializer
        else:
            return UserChargingStationSerializer
