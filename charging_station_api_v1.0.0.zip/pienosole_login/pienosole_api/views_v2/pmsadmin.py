import logging
from rest_framework import mixins, serializers
from django_filters import rest_framework as filters

from ..libs_v2.permissionviewset import *

from ..models import Park, PMSPendingRequest, User, PMS


logger = logging.getLogger('api.v2.views.pmsadmin')


class PMSSerializer(serializers.ModelSerializer):
    class Meta:
        model = PMS
        fields = ['id', 'name', 'abbrev']


class PMSPendingRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = PMSPendingRequest
        fields = ['id', 'parkadmin_username', 'authorized_parks', 'registration_token', 'pms']

    # noinspection PyMethodMayBeStatic
    def validate_authorized_parks(self, value):
        # Check if list contains duplicates
        if len(value) != len(set(value)):
            raise serializers.ValidationError("authorized_parks contains duplicates.")
        # Check if authorized_parks contains only valid park_ids
        for park_id in value:
            if not Park.objects.filter(pk=park_id).exists():
                raise serializers.ValidationError(f"Park with ID {park_id} doesn't exists.")
        # Check if there's another Pending Request for these parks
        for park_id in value:
            query = PMSPendingRequest.objects.filter(authorized_parks__contains=[park_id])
            if query.count() == 1 and self.instance is not None:
                # If you found an instance with the same park, there's a chance it's the actual instance we are working
                #   with, in that case is normal that there's a correspondence.
                # This can happen a lot for full update (PUT) that don't edit the authorized_parks field.
                if not query.first().id == self.instance.id:
                    raise serializers.ValidationError(f"Already existing pending request for Park ID {park_id}")
            elif query.count() >= 1:
                raise serializers.ValidationError(f"Multiple existing pending request for Park ID {park_id}")
        return value

    # noinspection PyMethodMayBeStatic
    def validate(self, data):
        # Retrieve the pms
        if 'pms' in data:
            pms_id = data['pms']
        elif self.partial:
            pms_id = self.instance.pms.id
        else:
            raise serializers.ValidationError("Unable to parse pms: missing value")
        # Retrieve parkadmin_username
        if 'parkadmin_username' in data:
            parkadmin_username = data['parkadmin_username']
        elif self.partial:
            parkadmin_username = self.instance.parkadmin_username
        else:
            raise serializers.ValidationError("Unable to parse parkadmin_username: missing value")
        # Check if parkadmin_username is not an already existing username
        generated_username = f"{pms_id}#{parkadmin_username}"
        if User.objects.filter(username=generated_username).exists():
            raise serializers.ValidationError(
                f"Combination of PMS {pms_id} and parkadmin_username {parkadmin_username} already used."
            )
        # Check if another pending request for this pms use the same parkadmin_username
        # OPTIMIZE: is this a UniqueTogether condition? We can do this with a better premade validator?
        queryset = PMSPendingRequest.objects.filter(pms_id=pms_id, parkadmin_username=parkadmin_username)
        if self.instance is not None:
            queryset.exclude(pk=self.instance.pk)
        if queryset.count() > 0:
            raise serializers.ValidationError(
                f"Pending Request for PMS {pms_id} and parkadmin_username {parkadmin_username} already exists."
            )
        return data


class PMSFilterSet(filters.FilterSet):
    class Meta:
        model = PMS
        fields = ['id', 'name', 'abbrev']


class PMSPendingRequestFilterSet(filters.FilterSet):
    class Meta:
        model = PMSPendingRequest
        fields = ['id', 'parkadmin_username', 'registration_token']


class PMSViewSet(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    mixins.CreateModelMixin,
    mixins.DestroyModelMixin,
    PermissionGenericViewSet
):
    queryset = PMS.objects.order_by('id')
    serializer_class = PMSSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = PMSFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser]


class PMSPendingRequestViewSet(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    mixins.CreateModelMixin,
    mixins.DestroyModelMixin,
    PermissionGenericViewSet
):
    queryset = PMSPendingRequest.objects.order_by('id')
    serializer_class = PMSPendingRequestSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = PMSPendingRequestFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser]

    def get_queryset(self):
        try:
            return PMSPendingRequest.objects.filter(pms_id=self.kwargs['pms_pk']).order_by('id')
        except KeyError:
            return PMSPendingRequest.objects.none()

    def get_pms_object(self):
        try:
            pms = PMS.objects.get(pk=self.kwargs['pms_pk'])
        except PMS.DoesNotExist:
            raise
        return pms

    def create(self, request, *args, **kwargs):
        request.data['pms'] = self.kwargs['pms_pk']
        return super().create(request, *args, **kwargs)
