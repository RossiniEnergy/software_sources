from rest_framework import mixins, serializers
from rest_framework.pagination import LimitOffsetPagination
from django_filters import rest_framework as filters
from django.db.models import DateTimeField

from ..libs_v2.permissionviewset import PermissionGenericViewSet, IsAuthenticatedNotExpired, IsAdminUser

from ..models import BuildingInfos


class BuildingInfosPagination(LimitOffsetPagination):
    default_limit = 1000
    max_limit = 10000


class BuildingInfosSerializer(serializers.ModelSerializer):
    class Meta:
        model = BuildingInfos
        fields = '__all__'


class BuildingInfosFilterSet(filters.FilterSet):
    park_id = filters.NumberFilter(field_name='park')
    park_name = filters.CharFilter(field_name='park__name')

    class Meta:
        model = BuildingInfos
        fields = {
            'id': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'production': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'consumption': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'available_power': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'timestamp': ['lt', 'lte', 'gt', 'gte'],
        }
        filter_overrides = {
            DateTimeField: {
                'filter_class': filters.IsoDateTimeFilter
            }
        }


class BuildingInfosViewSet(mixins.ListModelMixin,
                           mixins.RetrieveModelMixin,
                           PermissionGenericViewSet):
    serializer_class = BuildingInfosSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = BuildingInfosFilterSet
    pagination_class = BuildingInfosPagination
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser]

    def get_queryset(self):
        queryparam_reversed = bool(int(self.request.query_params.get('reversed', 0)))
        queryset = BuildingInfos.objects.order_by("id")
        if queryparam_reversed:
            queryset = queryset.reverse()
        return queryset
