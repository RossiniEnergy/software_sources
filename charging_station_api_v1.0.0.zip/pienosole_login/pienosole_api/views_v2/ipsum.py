from rest_framework import mixins, serializers, status
from rest_framework.response import Response
from rest_framework.decorators import action
from drf_spectacular.utils import extend_schema
from django_filters import rest_framework as filters

from ..libs_v2.permissionviewset import *

from ..models import IPSUMConfig, IPSUMLastPower


class IPSUMSerializer(serializers.ModelSerializer):
    class Meta:
        model = IPSUMConfig
        fields = ['id', 'token', 'alias', 'linked_parks', 'save_min_delay', 'drop_max_delay', 'expected_clamps',
                  'last_save_timestamp', 'software_version', 'note']
        read_only_fields = ['last_save_timestamp', 'software_version']
        extra_kwargs = {'linked_parks': {'allow_empty': True}}

    # noinspection PyMethodMayBeStatic
    def validate_expected_clamps(self, value):
        if value < 1:
            raise serializers.ValidationError("Unable to parse expected_clamps: need to be greater than 1")
        return value


class IPSUMLastPowerSerializer(serializers.ModelSerializer):
    class Meta:
        model = IPSUMLastPower
        fields = ['timestamp', 'powers', 'extra']


class IPSUMFilterSet(filters.FilterSet):
    class Meta:
        model = IPSUMConfig
        fields = {
            'id': ['exact'],
            'token': ['exact'],
            'alias': ['exact'],
            'linked_parks': ['exact'],
            'save_min_delay': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'drop_max_delay': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'expected_clamps': ['exact', 'lt', 'lte', 'gt', 'gte'],
            'last_save_timestamp': ['lt', 'lte', 'gt', 'gte'],
            'software_version': ['exact'],
        }


class IPSUMViewSet(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.CreateModelMixin,
    mixins.UpdateModelMixin,
    PermissionGenericViewSet
):
    queryset = IPSUMConfig.objects.order_by('id')
    serializer_class = IPSUMSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = IPSUMFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsAdminUser]

    @extend_schema(responses=IPSUMLastPowerSerializer)
    @action(detail=True, methods=['get'])
    def lastpower(self, request, pk=None):
        ipsum = self.get_object()
        if hasattr(ipsum, 'ipsumlastpower'):
            lp = ipsum.ipsumlastpower
        else:
            return Response("nodata", status=status.HTTP_404_NOT_FOUND)
        serialized_lp = IPSUMLastPowerSerializer(lp)
        return Response(serialized_lp.data)
