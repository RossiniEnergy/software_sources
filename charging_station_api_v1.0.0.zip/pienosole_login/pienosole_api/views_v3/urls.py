from django.urls import path, include
from rest_framework import routers
from rest_framework_nested import routers as nested_routers  # https://github.com/alanjds/drf-nested-routers

from .park import ParkadminParkViewset, NestedChargingStationViewset
from .user import NewUserViewSet

router = routers.DefaultRouter()
router.register("adminparks", ParkadminParkViewset, basename="adminparks"),
router.register("users", NewUserViewSet, basename="usersv3")
nested_chs_router = nested_routers.NestedDefaultRouter(router, "adminparks", lookup="park")
nested_chs_router.register("chargingstations", NestedChargingStationViewset, basename="nestedadminparkchargingstations")

urlpatterns = [
    path("", include(router.urls)),
    path("", include(nested_chs_router.urls)),
]