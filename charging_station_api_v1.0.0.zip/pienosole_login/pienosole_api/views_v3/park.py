import logging

from rest_framework import mixins, serializers
from rest_framework.permissions import AllowAny
from django_filters import rest_framework as filters

from ..libs_v2.permissionviewset import PermissionGenericViewSet, IsAuthenticatedNotExpired, IsParkAdminForPark, \
    IsParkAdminForChargingStation

from ..views_v2.chargingstations import \
    UserChargingStationSerializer, \
    ChargingStationFilterSet

from ..models import Park, ChargingStation

logger = logging.getLogger('api.v3.views.park')

# TODO: Parkview per gli amministratori


class ParkadminParkSerializer(serializers.ModelSerializer):
    chargingstations = UserChargingStationSerializer(source='chargingstation_set', many=True, read_only=True)

    class Meta:
        model = Park
        fields = ['id', 'name', 'email', 'email_report', 'address', 'postal_code',
                  'city', 'country_alpha2', 'latitude', 'longitude',
                  'accept_gireve', 'chargingstations']
        extra_kwargs = {
            'name': {'read_only': True},
            'address': {'read_only': True},
            'postal_code': {'read_only': True},
            'city': {'read_only': True},
            'country_alpha2': {'read_only': True},
            'latitude': {'read_only': True},
            'longitude': {'read_only': True},
            'accept_gireve': {'read_only': True},
        }


class ParkFilterSet(filters.FilterSet):
    class Meta:
        model = Park
        fields = ['name', 'country_alpha2', 'accept_gireve', 'software_version']


class ParkadminParkViewset(
    PermissionGenericViewSet,
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
):
    serializer_class = ParkadminParkSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = ParkFilterSet
    permission_classes = [AllowAny]
    permission_classes_by_action = {
        'update': [IsAuthenticatedNotExpired, IsParkAdminForPark],
    }

    def get_queryset(self):
        if not IsAuthenticatedNotExpired().has_permission(self.request, self):
            return Park.objects.none()
        user = self.request.user
        return Park.objects.filter(admin_users=user.userconfig).distinct()


class NestedChargingStationViewset(
    PermissionGenericViewSet,
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
):
    lookup_field = "park_bnum"
    serializer_class = UserChargingStationSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = ChargingStationFilterSet
    permission_classes = [AllowAny]
    permission_classes_by_action = {'list': [AllowAny],
                                    'retrieve': [AllowAny],
                                    'update': [IsAuthenticatedNotExpired, IsParkAdminForChargingStation],
                                    'partial_update': [IsAuthenticatedNotExpired, IsParkAdminForChargingStation]}

    def get_queryset(self):
        try:
            return ChargingStation.objects.filter(park_id=self.kwargs['park_pk']).order_by('park_bnum')
        except KeyError:
            return ChargingStation.objects.none()
