import logging
import random
import datetime
import pytz
import re

from rest_framework import mixins, serializers, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.utils import model_meta
from drf_spectacular.utils import extend_schema, inline_serializer
from drf_spectacular.types import OpenApiTypes
from django_filters import rest_framework as filters

from django.conf import settings
from django.db import transaction
from django.db.models import Q
from django.contrib.auth import login, authenticate, logout

from ..libs_v2.charge import close_all_user_charges
from ..libs_v2.permissionviewset import *
from ..libs_v2.user import create_new_user, expire_user

from ..models import User, UserConfig, ChargingStation, PMSAdminUser


logger = logging.getLogger("api.v3.views.user")


class UserConfigSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserConfig
        fields = ['authorized_bnum', 'expired', 'expire_datetime', 'expire_policy',
                  'guest', 'managed_parks', 'belonging_to']
        extra_kwargs = {
            'expired': {'read_only': True},
            'guest': {'read_only': True},
            'authorized_bnum': {'allow_empty': True},
            'managed_parks': {'allow_empty': True},
            'belonging_to': {'allow_empty': True},
        }

    # noinspection PyMethodMayBeStatic
    def validate_authorized_bnum(self, value):
        # Check duplicates
        value_len = len(value)
        if value_len != len(set(value)):
            raise serializers.ValidationError(
                "authorized_bnum contains duplicate elements."
            )
        # Check if bnum exists
        query_len = ChargingStation.objects.filter(bnum__in=value).count()
        if value_len != query_len:
            raise serializers.ValidationError(
                "authorized_bnum contains non-existent charging stations bnum"
            )
        # Valid
        return value


class UserSerializer(serializers.ModelSerializer):
    config = UserConfigSerializer(source="userconfig", required=False)
    password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ['id', 'username', 'password', 'email', 'is_active', 'is_staff', 'is_superuser', 'config']
        read_only_fields = ['id', 'is_active', 'is_superuser']

    # noinspection PyMethodMayBeStatic
    def validate_username(self, value):
        regex = r"^[A-zÀ-ù][^$#@\s]*$"  # start with letter, follow zero or more char that are not $, #, @ or space.
        match = re.compile(regex).match(value)
        if match is None:
            return serializers.ValidationError(
                "Username need to respsect start with letter, follow zero or more char that are not $, #, @ or space."
            )
        elif match[0] != value:
            return serializers.ValidationError(
                "The validator match on username returned an uncomplete value, report to administrator."
            )
        return value

    # OPTIMIZE: validate password using django validation
    #  Possible help from: https://stackoverflow.com/q/36414804

    def update(self, instance, validated_data):
        config_data = validated_data.pop('userconfig', dict())

        with transaction.atomic():
            # Change Password
            if 'password' in validated_data:
                new_password = validated_data.pop('password')
                instance.set_password(new_password)

            info = model_meta.get_field_info(instance)

            # Simply set each attribute on the instance, and then save it.
            # Note that unlike `.create()` we don't need to treat many-to-many
            # relationships as being a special case. During updates we already
            # have an instance pk for the relationships to be associated with.
            m2m_fields = []
            for attr, value in validated_data.items():
                if attr in info.relations and info.relations[attr].to_many:
                    m2m_fields.append((attr, value))
                else:
                    setattr(instance, attr, value)

            instance.save()

            # Note that many-to-many fields are set after updating instance.
            # Setting m2m fields triggers signals which could potentially change
            # updated instance and we do not want it to collide with .update()
            for attr, value in m2m_fields:
                field = getattr(instance, attr)
                field.set(value)

            # UserConfig Update - Do the same as before but on instance.userconfig
            info = model_meta.get_field_info(UserConfig)
            # Unless the application properly enforces that this field is
            # always set, the following could raise a `DoesNotExist`, which
            # would need to be handled.
            userconfig = instance.userconfig

            m2m_fields = []
            for attr, value in config_data.items():
                if attr in info.relations and info.relations[attr].to_many:
                    m2m_fields.append((attr, value))
                else:
                    setattr(userconfig, attr, value)

            userconfig.save()

            for attr, value in m2m_fields:
                field = getattr(userconfig, attr)
                field.set(value)

        return instance

    def create(self, validated_data):
        config_data = validated_data.pop('userconfig', dict())
        username = validated_data.pop('username')
        email = validated_data.pop('email', "")
        password = validated_data.pop('password')

        with transaction.atomic():
            # Remove many-to-many relationships from validated_data.
            # They are not valid arguments to the default `.create()` method,
            # as they require that the instance has already been saved.
            info = model_meta.get_field_info(User)
            many_to_many = {}
            for field_name, relation_info in info.relations.items():
                if relation_info.to_many and (field_name in validated_data):
                    many_to_many[field_name] = validated_data.pop(field_name)
            # Create User object
            user = User.objects.create_user(
                username=username,
                email=email,
                password=password,
                **validated_data,
            )
            # Save many-to-many relationships after the instance is created.
            if many_to_many:
                for field_name, value in many_to_many.items():
                    field = getattr(user, field_name)
                    field.set(value)

            # Remove many-to-many relationships from validated_data.
            # They are not valid arguments to the default `.create()` method,
            # as they require that the instance has already been saved.
            info = model_meta.get_field_info(UserConfig)
            many_to_many = {}
            for field_name, relation_info in info.relations.items():
                if relation_info.to_many and (field_name in config_data):
                    many_to_many[field_name] = config_data.pop(field_name)
            # Create UserConfig object
            userconfig = UserConfig.objects.create(user=user, **config_data)
            # Save many-to-many relationships after the instance is created.
            if many_to_many:
                for field_name, value in many_to_many.items():
                    field = getattr(userconfig, field_name)
                    field.set(value)

        return user


class TempUserDefaultUsername:
    """
    May be applied as a `default=...` value on a serializer field.
    Returns the current user.
    """
    requires_context = True

    def __call__(self, serializer_field):
        # Retrieve parent user from the request
        parent_user = serializer_field.context['request'].user
        # Find unused random_username with a sequential available suffix number
        i = 1
        while i < 1_000_000:
            random_username = "{}_{}".format(parent_user.username, i)
            if not User.objects.filter(username=random_username).exists():
                break
            i += 1
        else:
            msg = "Trying to create a temp user with id over 1'000'000. This is a sign of database saturation."
            logger.error(msg)
            raise ValueError(msg)
        return random_username


class TempUserDefaultAuthorizedBnum:
    """
    May be applied as a `default=...` value on a serializer field.
    Returns the current user.
    """
    requires_context = True

    def __call__(self, serializer_field):
        # Retrieve parent user from the request
        parent_user = serializer_field.context['request'].user
        # Retrieve the managed parks
        managed_parks = parent_user.userconfig.managed_parks.all()
        # Generate the authorized_bnum list
        authorized_bnum = []
        for park in managed_parks:
            authorized_bnum.extend(list(park.chargingstation_set.all().values_list('bnum', flat=True)))
        return authorized_bnum


class TempUserSerializer(serializers.ModelSerializer):
    new_password = serializers.CharField(
        default=lambda: str(random.randint(1_000_000, 9_999_999)),
        write_only=True
    )
    password = serializers.SerializerMethodField()
    authorized_bnum = serializers.ListField(
        child=serializers.IntegerField(),
        source='userconfig.authorized_bnum',
        default=TempUserDefaultAuthorizedBnum(),
        allow_empty=True,
    )
    expire_datetime = serializers.DateTimeField(
        source='userconfig.expire_datetime',
        allow_null=True,
        default=None,
    )

    # noinspection PyMethodMayBeStatic
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.temp_password = None

    def get_password(self, obj):
        if self.temp_password is None:
            return ""
        else:
            return self.temp_password

    # noinspection PyMethodMayBeStatic
    def validate_authorized_bnum(self, value):
        # Use the same custom validator defined in UserConfigSerializer
        return UserConfigSerializer().validate_authorized_bnum(value)

    # noinspection PyMethodMayBeStatic
    def validate_expire_datetime(self, value):
        if value is not None and value < datetime.datetime.now(pytz.UTC):
            raise serializers.ValidationError(
                "Trying to create a user with expire_datetime in the past."
            )
        return value

    # noinspection PyMethodMayBeStatic
    def validate_username(self, value):
        return UserSerializer().validate_username(value)

    class Meta:
        model = User
        fields = ['id', 'username', 'password', 'new_password', 'email', 'authorized_bnum', 'expire_datetime']
        extra_kwargs = {
            'username': {'default': TempUserDefaultUsername()},
        }

    def create(self, validated_data):
        parent_user = self.context['request'].user
        userconf_data = validated_data.pop('userconfig')
        self.temp_password = validated_data.pop('new_password')
        userconf_data['expire_policy'] = 'DIS'  # Disable!
        userconf_data['belonging_to'] = [parent_user.id]
        userconf_data['managed_parks'] = []
        validated_data['config'] = userconf_data
        validated_data['email'] = ""
        validated_data['password'] = self.temp_password
        tmp_user_serializer = UserSerializer(data=validated_data)
        tmp_user_serializer.is_valid(raise_exception=True)
        tmp_user_serializer.save()
        tmp_user = tmp_user_serializer.instance
        logger.info(f"Created tmp user with username \"{tmp_user.username}\" for the user \"{parent_user.username}\".")
        return tmp_user


class UserFilterSet(filters.FilterSet):
    expired = filters.BooleanFilter(field_name='userconfig__expired')
    expire_datetime__lt = filters.IsoDateTimeFilter(field_name='userconfig__expire_datetime', lookup_expr='lt')
    expire_datetime__lte = filters.IsoDateTimeFilter(field_name='userconfig__expire_datetime', lookup_expr='lte')
    expire_datetime__gt = filters.IsoDateTimeFilter(field_name='userconfig__expire_datetime', lookup_expr='gt')
    expire_datetime__gte = filters.IsoDateTimeFilter(field_name='userconfig__expire_datetime', lookup_expr='gte')
    expire_policy = filters.ChoiceFilter(field_name='userconfig__expire_policy', choices=UserConfig.EXPIRE_POLICIES)
    guest = filters.BooleanFilter(field_name='userconfig__guest')
    managing_park_id = filters.NumberFilter(field_name='userconfig__managed_parks')
    belonging_to_user_id = filters.NumberFilter(field_name='userconfig__belonging_to')

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'is_active', 'is_staff', 'is_superuser']


class NewUserViewSet(
    PermissionGenericViewSet,
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    mixins.CreateModelMixin,
):
    serializer_class = UserSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = UserFilterSet
    permission_classes = [IsAuthenticatedNotExpired, IsStaffForObject | IsHimselfUser | IsBelongerUser]
    # Bitwise OR | can be used to compose permissions. Check of every entry is "and" the others.
    # Retrieve old permissions: IsStaffForObject | IsBelongerUser | IsHimselfUser
    permission_classes_by_action = {
        'list': [IsAuthenticatedNotExpired],
        'retrieve': [IsAuthenticatedNotExpired],
        'update': [IsAuthenticatedNotExpired, IsStaffForObject | IsBelongerUser],
        'partial_update': [IsAuthenticatedNotExpired, IsStaffForObject | IsBelongerUser],
        'create': [IsAuthenticatedNotExpired, IsAdminUser]
    }

    def get_queryset(self):
        if not IsAuthenticatedNotExpired().has_permission(self.request, self):
            return User.objects.none()
        elif IsAdminUser().has_permission(self.request, self):
            # If a user is Admin, show every user
            return User.objects.order_by("id")
        else:
            # Show the user in the list only if at least one of this condition is True:
            # - The user is himself
            # - The user contains the requester user in his belonging_to
            user = self.request.user
            return User.objects.filter(Q(pk=user.pk) | Q(userconfig__belonging_to=user)).distinct()

    @extend_schema(request=TempUserSerializer, responses=TempUserSerializer)
    @action(detail=False, methods=['post'], permission_classes=[IsAuthenticatedNotExpired, IsParkAdmin])
    def new_temp_user(self, request):
        serializer = TempUserSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @extend_schema(request=inline_serializer(
        name="NewPassword",
        fields={
            'new_password': serializers.CharField(),
        }),
        responses=OpenApiTypes.STR)
    @action(
        detail=True,
        methods=['post'],
        permission_classes=[IsAuthenticatedNotExpired, IsStaffForObject | IsBelongerUser | IsHimselfUser]
    )
    def reset_password(self, request, pk=None):
        user = self.get_object()
        try:
            new_password = request.data['new_password']
        except KeyError:
            return Response("Bad Request", status=status.HTTP_404_NOT_FOUND)
        user.set_password(new_password)
        user.save()
        logger.info(f"Resetted password for User {user.username}")
        return Response("Password Resetted correctly")

    # TODO: myself is a routing alias to /users/{request.user.id}/ so you can use all the ViewSet function from here
    @action(detail=False, methods=['get'], permission_classes=[IsAuthenticated])
    def myself(self, request):
        user = request.user
        serialized_user = self.get_serializer(user)
        return Response(serialized_user.data)

    # CRSF Exempt for Django Rest Framework: https://stackoverflow.com/a/30875830
    @extend_schema(request=inline_serializer(name='Login', fields={
        'username': serializers.CharField(),
        'password': serializers.CharField(),
        'qrcodeid': serializers.IntegerField(required=False)
    }))
    @action(
        detail=False, methods=['post'],
        permission_classes=[AllowAny],
    )
    def login(self, request):
        try:
            username = request.data['username']
            password = request.data['password']
            qrcodeid = request.data.get('qrcodeid')
        except KeyError:
            msg = "Bad Request. Expecting `username` and `password` in POST Request body (POSTForm or JSON)"
            return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        if '#' in username or '$' in username:
            return Response("Invalid use of special characters # or $ in username",
                            status=status.HTTP_403_FORBIDDEN)
        # Check if a prefix is needed for the username
        if qrcodeid:
            try:
                cs = ChargingStation.objects.get(qrcodeid=qrcodeid)
                park = cs.park
                pmsadmin = PMSAdminUser.objects.filter(user__userconfig__managed_parks=park).distinct().first()
                if pmsadmin:
                    username = f"{pmsadmin.user.id}${username}"
            except ChargingStation.DoesNotExist:
                pass
        # Authenticate
        user = authenticate(request, username=username, password=password)
        if user is not None:
            if user.userconfig.expired:
                return Response("User requested is expired", status=status.HTTP_401_UNAUTHORIZED)
            login(request, user)
            serialized_user = self.get_serializer(user)
            return Response(serialized_user.data)
        else:
            return Response("Invalid User/Password combination", status=status.HTTP_401_UNAUTHORIZED)

    @extend_schema(responses=OpenApiTypes.NONE)
    @action(detail=False, methods=['get'], permission_classes=[AllowAny])
    def logout(self, request):
        csrf_domain = settings.CSRF_COOKIE_DOMAIN
        logout(request)
        response = Response()
        response.delete_cookie("sessionid", samesite='Lax')  # Delete old sessionid from before the domain change
        response.delete_cookie("csrftoken", domain=csrf_domain, samesite='Lax')  # Delete csrftoken at logout
        return response

    @extend_schema(responses=inline_serializer(name='ChargePermissions', fields={
        'authorized_qrcode': serializers.ListField(child=serializers.IntegerField())}))
    @action(detail=True, methods=['get'], permission_classes=[IsAuthenticatedNotExpired, IsAuthenticated])
    def charge_permissions(self, request, pk=None):
        user = self.get_object()
        # user_authorized_cs = user.userconfig.chargingstation_allowed
        # user_authorized_bnum = list(cs.bnum for cs in user_authorized_cs)
        user_authorized_qrcode = user.userconfig.qrcodeid_allowed
        return Response({'authorized_qrcode': user_authorized_qrcode})

    @extend_schema(request=OpenApiTypes.NONE, responses=OpenApiTypes.NONE)
    @action(
        detail=True,
        methods=['post'],
        permission_classes=[IsAuthenticatedNotExpired, IsStaffForObject | IsBelongerUser]
    )
    def expire(self, request, pk=None):
        user = self.get_object()
        if user.userconfig.expired:
            msg = f"Trying to force expiration of the already expired user \"{user.username}\""
            logger.warning(msg)
            return Response(msg, status=status.HTTP_400_BAD_REQUEST)
        else:
            expire_user(user)
            close_all_user_charges(user)
            return Response()

    @extend_schema(request=OpenApiTypes.NONE)
    @action(detail=True, methods=['get', 'post'], permission_classes=[IsAuthenticatedNotExpired, IsAdminUser])
    def sudo(self, request, pk=None):
        user = self.get_object()
        login(request, user)
        serialized_user = self.get_serializer(user)
        return Response(serialized_user.data)
