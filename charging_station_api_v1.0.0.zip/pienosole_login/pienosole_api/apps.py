from django.apps import AppConfig


class PienosoleApiConfig(AppConfig):
    name = 'pienosole_api'
