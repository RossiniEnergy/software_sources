import time
import datetime
import logging
import pytz
from django.core.management.base import BaseCommand

# noinspection PyUnresolvedReferences
from pienosole_api.libs_v2.ipsum import send_ipsum_lastpower_table

logger = logging.getLogger('api.command.runipsumrouter')


class Command(BaseCommand):
    help = "Run the Data Table Dispatcher for Ipsum"

    def handle(self, *args, **options):
        max_time_delay_seconds = datetime.timedelta(seconds=1).total_seconds()
        results = []  # (errcode, delay)
        while True:
            datetime_used = datetime.datetime.now(pytz.UTC)
            errcode = 0
            # noinspection PyBroadException
            try:
                send_ipsum_lastpower_table()
            except Exception:
                errcode = 1
            datetime_now = datetime.datetime.now(pytz.UTC)
            delay = datetime_now.timestamp() - datetime_used.timestamp()
            results.append((errcode, delay))
            seconds_left_to_wait = max_time_delay_seconds - delay
            if seconds_left_to_wait > 0:
                time.sleep(seconds_left_to_wait)
            ticks = len(results)
            if ticks >= 60 * 10:
                errcodes, delays = zip(*results)
                avg = sum(delays) / ticks
                logger.info(f"Results avg: {avg} min: {min(delays)} max: {max(delays)} errors: {sum(errcodes)}")
                results = []
