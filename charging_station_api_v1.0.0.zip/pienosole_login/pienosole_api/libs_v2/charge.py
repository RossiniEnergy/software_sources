import datetime
import logging

import pytz

from django.core.exceptions import MultipleObjectsReturned, ObjectDoesNotExist
from django.http import HttpResponse
from django.conf import settings
from django.db import transaction

from .advenir import advenir_send_charge
from .girevehooks import hook_update_gireve_status, hook_push_cdr_gireve
from .orders import send_order_on, send_order_off
from .payment import try_capture_money
from .exceptions import ExpiredUserError, ForbiddenGuestError

from ..models import Charge, ChargingStation


logger = logging.getLogger("api.v2.charge")


def start_new_charge_bybnum(bnum, user):
    logger.debug(f"Call to start_new_charge_bybnum with bnum {bnum} and user {user.username}")
    try:
        cs = ChargingStation.objects.get(bnum=bnum)
    except (MultipleObjectsReturned, ObjectDoesNotExist) as ex:
        raise ex
    # Before anything, check if the user is expired or not
    if user.userconfig.expired:
        raise ExpiredUserError(user.username, 'start_new_charge_bybnum not allowed for expired')
    # Before creating a new charge, check if one is already existing
    # FIXME: Switch this to get for single charge check
    already_started_charge = Charge.objects.filter(
        chargingstation=cs, stop__isnull=True
    )
    if already_started_charge.exists():
        logger.error(f"User {user.username} tried to duplicate charge on bnum {bnum}")
        return already_started_charge.first()
    # Before creating a new charge for a guest user, check if the user already has one
    if user.userconfig.guest:
        guest_charges = Charge.objects.filter(user=user)
        if guest_charges.exists():
            logger.warning("A guest user with a charge is asking to create another charge.")
            raise ForbiddenGuestError(user, "A guest user with a charge is asking to create another charge.")
    with transaction.atomic():
        current_charge = Charge(
            chargingstation=cs,
            start=datetime.datetime.now(pytz.utc),
            stop=None,
            user=user,
        )
        current_charge.save()
        cs.last_updated = datetime.datetime.now(pytz.utc)
        cs.save()
        park = cs.park
        park.last_updated = datetime.datetime.now(pytz.utc)
        park.save()
    if not settings.STAGING:
        try:
            hook_update_gireve_status.delay(cs.bnum)
        except:
            logger.warning("Unexpected Gireve error on start_new_charge_bybnum")
    send_order_on.delay(cs.park.name, cs.park_bnum)
    logger.info(f"User {user.username} started a new charge (ID={current_charge.id}) on bnum {bnum}")
    # If the user requesting this is a Guest, extend the expiration by 6 days
    if user.userconfig.guest:
        expire_datetime = datetime.datetime.now(pytz.UTC) + datetime.timedelta(days=6)
        user.userconfig.expire_datetime = expire_datetime
        user.userconfig.save(update_fields=['expire_datetime'])
    return current_charge


def stop_opened_charge_bybnum(bnum):
    """
    Close an opened charge for a specific bnum. This function capture an eventual payment.
    This function just do the charge stopping operations.
    :param bnum: id of the chargingstation where the charge will be closed
    :return closed_charge: the Charge object the function closed
    """
    logger.debug(f"Call to stop_opened_charge_bybnum with bnum {bnum}")
    current_charge = \
        Charge.objects.filter(stop=None, chargingstation__bnum=bnum).order_by("-id").first()
    if current_charge is None:
        logger.error(f"Trying to stopping a charge on bnum {bnum} were no charge is started")
        return HttpResponse(status=500)
    stop_opened_charge(current_charge)
    return current_charge


def stop_opened_charge(charge):
    """
    Close an opened charge object. This function capture an eventual payment.
    This function just do the charge stopping operations.
    :param charge:
    :return:
    """
    logger.debug(f"Call to stop_opened_charge with charge.id {charge.id}")
    with transaction.atomic():
        cs = charge.chargingstation
        charge.stop = datetime.datetime.now(pytz.utc)
        charge.save()
        cs.last_updated = datetime.datetime.now(pytz.utc)
        cs.save()
        park = cs.park
        park.last_updated = datetime.datetime.now(pytz.utc)
        park.save()
    if not settings.STAGING:
        try:
            advenir_send_charge.delay(charge.id)
            hook_push_cdr_gireve.delay(charge.id)
            hook_update_gireve_status.delay(cs.bnum)
        except:
            logger.warning("Unexpected Gireve error on stop_opened_charge")
    send_order_off.delay(cs.park.name, cs.park_bnum)
    logger.info(f"Closed a charge with ID {charge.id} on bnum {charge.chargingstation.bnum}")
    try_capture_money(charge)  # The expiration of the user if it's a guest is inside this function
    return charge


def close_all_user_charges(user):
    logger.debug(f"Call to close_all_user_charges for user {user.username}")
    # Close charges of specific user (example: expired ones)
    related_charge = Charge.objects.filter(user=user, stop__isnull=True)
    logger.info(f"Closing all opened charge for the user \"{user.username}\"...")
    for charge in related_charge:
        stop_opened_charge(charge)
