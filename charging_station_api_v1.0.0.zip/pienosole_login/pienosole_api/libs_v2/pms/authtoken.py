from hashlib import blake2b

from rest_framework import status
from rest_framework.authentication import BaseAuthentication
from rest_framework.response import Response
from rest_framework.exceptions import AuthenticationFailed
from rest_framework.permissions import BasePermission


from django.db import transaction

from ..exceptions import HTTPResponseWrapperError
from ..user import create_new_user

from ...models import PMSPendingRequest, PMSAdminUser, Park


class BasePMSTokenAuthentication(BaseAuthentication):

    def authenticate(self, request):
        token = request.META.get('HTTP_X_RETOKEN')
        if not token:
            return None  # Token missing
        try:
            pmsadmin = PMSAdminUser.objects.get(authorization_token=token)
        except PMSAdminUser.DoesNotExist:
            raise AuthenticationFailed('Token unknown')
        return pmsadmin.user, token


# TODO: pass PMS code from function
def initialize_token(tmp_token, pms):
    try:
        pending_request = PMSPendingRequest.objects.get(registration_token=tmp_token, pms=pms)
    except PMSPendingRequest.DoesNotExist:
        raise HTTPResponseWrapperError(
            Response(f"No pending request corresponding to token {tmp_token}",
                     status=status.HTTP_404_NOT_FOUND)
        )
    internal_username = f"{pending_request.pms.pk}#{pending_request.parkadmin_username}"
    hasher = blake2b(digest_size=16)
    hasher.update(internal_username.encode())  # This way if the username is unique, probably the token is unique too
    token = hasher.hexdigest()
    try:
        authorized_parks_list = [Park.objects.get(pk=i) for i in pending_request.authorized_parks]
    except Park.DoesNotExist:
        raise HTTPResponseWrapperError(
            Response(f"Internal error during parsing. Contact system administrator.",
                     status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        )
    with transaction.atomic():
        user = create_new_user(
            username=internal_username,
            password="tmppassword",
            managed_parks=authorized_parks_list,
        )
        user.set_unusable_password()
        pmsadmin = PMSAdminUser.objects.create(
            user=user,
            authorization_token=token,
            pms=pms,
        )
        pending_request.delete()
    # TODO: Try/except for consistency after transaction?
    return pmsadmin


class NestedIsAuthenticatedAndPMSAdmin(BasePermission):
    # Retrevo PMS da view utilizzando il self keys definito dal router! Se mancante, droppo False.
    def has_permission(self, request, view):
        try:
            pms_abbrev = view.kwargs['pms_abbrev']
        except KeyError:
            return False  # Not found the nested key in the view kwargs
        if request.user is None:
            return False
        elif not request.user.is_authenticated:
            return False
        elif PMSAdminUser.objects.filter(pms__abbrev=pms_abbrev, user=request.user).first() is None:
            return False
        else:
            return True
