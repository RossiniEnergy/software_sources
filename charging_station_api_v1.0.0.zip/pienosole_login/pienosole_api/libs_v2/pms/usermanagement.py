from datetime import datetime

from ..user import create_new_user

from ...models import User


class PMSSubUser:
    def __init__(self, user: User):
        if '$' not in user.username:
            raise ValueError("Username without $, sure it's a PMSSubUser?")
        self.username = '$'.join(user.username.split('$')[1:])
        self.id = user.id
        self.expire_datetime = user.userconfig.expire_datetime
        self.expired = user.userconfig.expired
        self.model_instance = user

    @classmethod
    def init_list(cls, users):
        output = []
        for user in users:
            output.append(cls(user))
        return output


def create_child_user(pmsadmin_user: User, last_username, password, expire_datetime: datetime) -> PMSSubUser:
    child_username = f"{pmsadmin_user.id}${last_username}"
    admin_managed_parks = pmsadmin_user.userconfig.managed_parks.all()
    authorized_bnum = []
    for park in admin_managed_parks:
        authorized_bnum.extend(list(park.chargingstation_set.all().values_list('bnum', flat=True)))
    user = create_new_user(
        username=child_username,
        password=password,
        authorized_bnum=authorized_bnum,
        expire_datetime=expire_datetime,
        expire_policy='PAD',
        belonging_to=[pmsadmin_user],
    )
    return PMSSubUser(user)
