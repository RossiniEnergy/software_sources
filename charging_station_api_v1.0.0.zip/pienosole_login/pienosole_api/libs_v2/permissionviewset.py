from rest_framework import viewsets
# noinspection PyUnresolvedReferences
from rest_framework.permissions import BasePermission, IsAdminUser, AllowAny


class PermissionGenericViewSet(viewsets.GenericViewSet):
    permission_classes_by_action = {}

    def get_permissions(self):
        try:
            # return permission_classes depending on `action`
            return [permission() for permission in self.permission_classes_by_action[self.action]]
        except KeyError:
            # action is not set return default permission_classes
            return [permission() for permission in self.permission_classes]


class IsAuthenticatedNotExpired(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and not request.user.userconfig.expired)


class IsHimselfUser(BasePermission):
    def has_object_permission(self, request, view, obj):
        # If the requester is a parent user of the requested, allow.
        # If same user, allow. Else, deny.
        return bool(request.user and request.user == obj)


class IsBelongerUser(BasePermission):
    def has_object_permission(self, request, view, obj):
        # If the requester is a parent user of the requested, allow.
        return bool(request.user and request.user in obj.userconfig.belonging_to.all())


class IsParkAdmin(BasePermission):
    def has_object_permission(self, request, view, obj):
        return bool(request.user and request.user.userconfig.managed_parks.exists())


class IsStaffForObject(IsAdminUser):
    def has_object_permission(self, request, view, obj):
        return self.has_permission(request, view)


class IsParkAdminForPark(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.userconfig.managed_parks.exists())

    def has_object_permission(self, request, view, obj):
        return bool(request.user and obj in request.user.userconfig.managed_parks.all())


class IsParkAdminForChargingStation(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.userconfig.managed_parks.exists())

    def has_object_permission(self, request, view, obj):
        return bool(request.user and obj.park in request.user.userconfig.managed_parks.all())
