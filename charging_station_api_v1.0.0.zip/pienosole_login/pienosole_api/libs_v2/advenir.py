from celery import shared_task
import datetime
import pytz
from datetime import timedelta

import requests

from django.db.models import Window, F, Func, Value, ExpressionWrapper
from django.db.models.fields import FloatField
from django.db.models.functions import Lag, Coalesce

from ..models import Power, Charge, ChargingStation


# noinspection PyAbstractClass
class ExtractEpoch(Func):
    function = 'EXTRACT'
    template = "(%(function)s( epoch FROM %(expressions)s))"


# noinspection DuplicatedCode
@shared_task(bind=True, max_retries=96)
def advenir_send_charge(self, charge_id):
    username = 'guillaume@rossinienergy.com'
    password = 'RossiniEnergy123!'
    # user_id = '91e7d39d-59b4-44f2-854e-19472e63832b'
    advenir_url = 'https://mon.advenir.mobi/api/courbe/put'
    connect_timeout = 5.0
    read_timeout = 30.0

    charge = Charge.objects.get(pk=charge_id)
    user_id = charge.chargingstation.park.advenir_user_id
    transaction_id = str(charge.id)
    station_id = charge.chargingstation.evse_id
    charge_powers_db = list(
        Power.objects.filter(
            chargingstation=charge.chargingstation,
            timestamp__gte=charge.start,
            timestamp__lte=charge.stop,
        ).annotate(
            deltatime=ExtractEpoch(
                Coalesce(
                    F('timestamp') - Window(Lag('timestamp'), order_by=F('id').asc()),
                    Value(timedelta(seconds=30))
                )
            )
        ).annotate(
            integrando=ExpressionWrapper(F('deltatime') * F('power'), output_field=FloatField())
        ).order_by('id').values_list('timestamp', 'integrando')
    )
    charge_powers = []
    cumulative_power = 0
    for timestamp, integrando in charge_powers_db:
        cumulative_power += integrando
        charge_powers.append({
            'timestamp': int(timestamp.timestamp()),
            'value': int(cumulative_power / 3600),  # Upscale Ws to Wh
        })

    request_data = {
        user_id: {
            station_id: {
                transaction_id: charge_powers
            }
        }
    }

    try:
        reply = requests.post(
            url=advenir_url,
            json=request_data,
            auth=(username, password),
            timeout=(connect_timeout, read_timeout),
        )
        reply_status = reply.json()['statut']
        if reply_status != 'OK':
            raise Exception(f"reply_status={reply_status}")
    except Exception as exc:
        self.retry(exc=exc, countdown=900)  # 15 minutes retry for total 96 (24 hours) tries


# noinspection DuplicatedCode
@shared_task(bind=True)
def advenir_send_test_charge(self, chargingstation_id, transaction_id):
    username = 'guillaume@rossinienergy.com'
    password = 'RossiniEnergy123!'
    # user_id = '91e7d39d-59b4-44f2-854e-19472e63832b'
    advenir_url = 'https://mon.advenir.mobi/api/courbe/put'
    connect_timeout = 5.0
    read_timeout = 30.0

    charge_powers = []
    cumulative_power = 0
    power_step = 3124  # W measured every 30 seconds
    time_moment = datetime.datetime.now(pytz.UTC) - datetime.timedelta(minutes=1)
    for i in range(3):  # 1 minute of charge (0, 1, 2 -> 0, 30, 60 seconds)
        cumulative_power += power_step
        charge_powers.append({
            'timestamp': int(time_moment.timestamp()),
            'value': int(cumulative_power / 3600),
        })
        time_moment += datetime.timedelta(seconds=30)
    # every 30 second add 3124 Wh to the integrando and save it in the request_data.
    # Use transaction ID from arguments, but default to 1.

    chargingstation = ChargingStation.objects.get(bnum=chargingstation_id)
    user_id = chargingstation.park.advenir_user_id
    station_id = chargingstation.evse_id

    request_data = {
        user_id: {
            station_id: {
                transaction_id: charge_powers
            }
        }
    }

    try:
        reply = requests.post(
            url=advenir_url,
            json=request_data,
            auth=(username, password),
            timeout=(connect_timeout, read_timeout),
        )
        reply_status = reply.json()['statut']
        if reply_status != 'OK':
            raise Exception(f"reply_status={reply_status}")
    except Exception as exc:
        self.retry(exc=exc, countdown=60)
