import datetime
import logging
import random
import time

import pytz
from django.contrib.auth.models import User
from django.contrib.sessions.models import Session
from django.db import transaction, IntegrityError

from ..models import ChargingStation, UserConfig

logger = logging.getLogger('api.user_utils')


# TODO: Try to replace every use of this with the v3 UserSerializer
def create_new_user(username,
                    password,
                    email=None,  # Email in string format
                    authorized_bnum=None,  # Use list of authorized int bnum for ChargingStation
                    expire_datetime=None,  # Use datetime.datetime with pytz.UTC
                    expire_policy='NPE',  # UserConfig.EXPIRE_POLICIES[0][0]
                    managed_parks=None,  # Use list of Park objects
                    belonging_to=None,  # Use list of User objects
                    guest=False,  # If the account is a Guest account
                    ):
    # Pythonic management of empty managed_parks and belonging_to
    if authorized_bnum is None:
        authorized_bnum = []
    if managed_parks is None:
        managed_parks = []
    if belonging_to is None:
        belonging_to = []

    # Check validity authorized_bnum
    for bnum in authorized_bnum:
        if not ChargingStation.objects.filter(bnum=bnum).exists():
            msg = f"Trying to create a user with unexisting ChargingStation bnum {bnum}"
            logger.error(msg)
            raise ValueError(msg)
    # Create and save the User object
    try:
        user = User.objects.create_user(username, email=email, password=password)
    except IntegrityError as ex:
        msg = f"Trying to create a user with already existing username {username}."
        logger.error(msg)
        raise ValueError(msg) from ex
    # FIXME: Check if expire_datetime is a date?
    # Create the UserConfig object
    uconfig = UserConfig(user=user,
                         authorized_bnum=authorized_bnum,
                         expire_datetime=expire_datetime,
                         guest=guest)
    # Check and set expire_policy
    if expire_policy is not None:
        if expire_policy in [i[0] for i in UserConfig.EXPIRE_POLICIES]:
            uconfig.expire_policy = expire_policy
        else:
            msg = f"Trying to create a user with unexisting expire_policy \"{expire_policy}\""
            logger.error(msg)
            user.delete()  # Delete the already created User, we don't want incomplete user in db
            raise ValueError(msg)
    # Pre-save to let me configure the ManyToManyField
    user.save()
    uconfig.save()
    # Set managed_parks
    for park in managed_parks:
        uconfig.managed_parks.add(park)
    # Set belonging_to
    for admin_user in belonging_to:
        uconfig.belonging_to.add(admin_user)
    # Save the final version of the objects
    user.save()  # User.objects.create_user() just create AND SAVE the User instance
    uconfig.save()
    # Return the User instance
    return user


def create_guest_user(chargingstation, email=""):
    logger.debug("Call to create_guest_user")
    random_username = "{}_{}".format(int(time.time()), random.randint(0, 1000))
    expire_datetime = datetime.datetime.now(pytz.UTC) + datetime.timedelta(minutes=30)
    tmp_user = create_new_user(username=random_username,
                               password="temp_password",
                               email=email,
                               authorized_bnum=[chargingstation.bnum],
                               expire_datetime=expire_datetime,
                               guest=True)
    tmp_user.set_unusable_password()
    tmp_user.save()
    logger.info(f"Created guest user \"{tmp_user.username}\"")
    return tmp_user


def expire_user(user):
    logger.debug(f"Call to expire_user")
    if not isinstance(user, User):
        logger.critical("Called expire_user with an object that isn't a User instance")
        raise ValueError
    user.userconfig.expired = True
    with transaction.atomic():
        if user.userconfig.expire_policy == 'NPE':  # No Permission
            pass
        elif user.userconfig.expire_policy == 'DIS':  # Disable
            user.is_active = False
            user.save(update_fields=['is_active'])
        elif user.userconfig.expire_policy == 'PAD':  # PMS AppendTimestamp Disable
            user.is_active = False
            user.username = f"{user.username}_{int(datetime.datetime.now(pytz.UTC).timestamp())}"  # olduser_1638278860
            user.save(update_fields=['username', 'is_active'])
        user.userconfig.save(update_fields=['expired'])
    # Revoke all the sessions for the expired user if it's a Guest
    logger.info(f"User {user.username} has been expired correctly with"
                f" policy \"{user.userconfig.get_expire_policy_display()}\"")
    if user.userconfig.guest:
        delete_all_unexpired_sessions_for_user(user)


def delete_all_unexpired_sessions_for_user(user):
    logger.debug("Call to delete_all_unexpired_sessions_for_user")
    all_unexpired_sessions = Session.objects.filter(expire_date__gte=datetime.datetime.now(pytz.UTC))
    for session in all_unexpired_sessions:
        if str(user.pk) == session.get_decoded().get('_auth_user_id'):
            session.delete()
    logger.info(f"All the opened session for the user {user.username} have been expired correctly")