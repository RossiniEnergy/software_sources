import logging

from celery import shared_task

import pika
from pika.exceptions import AMQPError

from django.conf import settings

logger = logging.getLogger("api.orders")


@shared_task
def send_order_on(park_name, park_bnum):
    try:
        logger.debug(f"Sendind \"charge {park_bnum}\" to park_name={park_name}")
        connection = pika.BlockingConnection(
            pika.connection.URLParameters(settings.ORDERS_BROKER_RABBITMQ)
        )
        channel = connection.channel()
        channel.basic_publish(
            exchange="chargingstation",
            routing_key="CS_{}".format(park_name),
            body=bytes("charge {}".format(park_bnum), 'ascii'),
        )
    except AMQPError:
        logger.error(f"Problem sending \"charge {park_bnum}\" to park_name={park_name}")
        return
        # TODO manage error here


@shared_task
def send_order_off(park_name, park_bnum):
    try:
        logger.debug(f"Sendind \"stop_charge {park_bnum}\" to park_name={park_name}")
        connection = pika.BlockingConnection(
            pika.connection.URLParameters(settings.ORDERS_BROKER_RABBITMQ)
        )
        channel = connection.channel()
        channel.basic_publish(
            exchange="chargingstation",
            routing_key="CS_{}".format(park_name),
            body=bytes("stop_charge {}".format(park_bnum), 'ascii'),
        )
    except AMQPError:
        logger.error(f"Problem sending \"stop_charge {park_bnum}\" to park_name={park_name}")
        return
        # TODO manage error here
