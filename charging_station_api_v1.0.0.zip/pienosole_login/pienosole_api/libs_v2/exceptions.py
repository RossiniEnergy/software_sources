class BaseChargingStationApiError(Exception):
    """Base class for exceptions in this application."""
    pass


class HTTPResponseWrapperError(BaseChargingStationApiError):
    """Exception raised when a HTTPResponse object needs to be raised by the main function"""

    def __init__(self, httpresponse_wrapped):
        self.httpresponse = httpresponse_wrapped


class ExpiredUserError(BaseChargingStationApiError):
    """Exception raised for unauthorized operations with expired user"""

    def __init__(self, username, message):
        self.username = username
        self.message = message


class ForbiddenGuestError(BaseChargingStationApiError):
    """Exception raised for unauthorized operations with guest user"""

    def __init__(self, user_obj, message):
        self.user_obj = user_obj
        self.message = message
