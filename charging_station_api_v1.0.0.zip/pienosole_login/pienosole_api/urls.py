from django.urls import path, include
from django.contrib import admin
from django.conf import settings
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView

from .views_v2 import urls as api_v2_urls_module

from .views_v3 import urls as api_v3_urls_module

from .views.pms import urls as pms_urls_module

from .views.custom import urls as custom_urls_module

from .views.raspberry import get_is_charging, get_cs_id_list

from .views.reports import get_receipts, download_receipt

from .views.gireve import (
    get_gireve_location,
    get_gireve_location_params,
    start_evse,
    stop_evse,
)
from .views.newcomer import get_newcomers, newcomer, cancelnewcomer, nowtimeutc
from .views.powertable import post_power_legacy, post_power_bytecode
from .views.ipsum import manual_retrieve_ipsum
from .views.stripewebhook import stripe_webhook


if settings.STAGING:
    staging_urlpatterns = [
        # INTERNAL DOCUMENTATION
        path("openapi/", SpectacularAPIView.as_view(), name='openapi-schema'),
        path("swagger-ui/", SpectacularSwaggerView.as_view(url_name='openapi-schema'), name='swagger-ui'),
        # TESTING ADMIN PANEL
        path("admin/", admin.site.urls),
    ]
else:
    staging_urlpatterns = []


urlpatterns = [
    # STAGING SPECIAL URLS
    path("staging/", include(staging_urlpatterns)),
    # CUSTOM API URLS
    path("custom/", include(custom_urls_module)),
    # APIv2 URLS
    path("v2/", include(api_v2_urls_module)),
    # APIv3 URLS
    path("v3/", include(api_v3_urls_module)),
    # PMS API URLS
    path("", include(pms_urls_module)),
    # RASPBERRY API
    path(r"ischarging/<int:bnum>", get_is_charging),
    path(r"csidlist/<str:park_name>", get_cs_id_list),
    # STRIPE WEBHOOK API
    path(r"handlers/strwebhook/", stripe_webhook),
    # RECEIPTS
    path(r"get_receipts/", get_receipts),
    path(r"download_receipt/<str:receipt_name>", download_receipt),
    # NEWCOMER API
    path("get_newcomers/", get_newcomers),
    path("newcomer/", newcomer),
    path("cancelnewcomer/", cancelnewcomer),
    path("nowtimeutc/", nowtimeutc),
    # POWERTABLE API
    path("post_power/v1/<str:park_name>", post_power_bytecode),  # HTTP
    path("post_power/<str:park_name>", post_power_bytecode),  # HTTPS/Old config
    path("post_power/", post_power_legacy),
    # IPSUM API
    path("retrieve_ipsum/<str:park_name>", manual_retrieve_ipsum),
    # GIREVE API
    path("gireve/locations", get_gireve_location),
    path("gireve/locations/<str:location_id>/<str:evse_uid>/<str:connector_id>", get_gireve_location_params),
    path("gireve/locations/<str:location_id>/<str:evse_uid>", get_gireve_location_params),
    path("gireve/locations/<str:location_id>", get_gireve_location_params),
    path('gireve/<str:evse_uid>/start', start_evse),
    path('gireve/<str:evse_uid>/stop', stop_evse),
]
