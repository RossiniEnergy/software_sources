import pycountry
import datetime
import logging
import pytz

from celery import shared_task

from django.conf import settings
from django.conf.global_settings import EMAIL_HOST_USER
from django.core.mail import EmailMessage, EmailMultiAlternatives  # send_mail
from django.core.management import call_command
from smtplib import SMTPException

from ..models import User, UserConfig, MoneyDestination, Park, PaymentOrder
from ..views.reports import make_admin_report, make_park_report
from ..views.health import stripe_health_retrieve, park_health_retrieve
from ..libs_v2.charge import close_all_user_charges
from ..libs_v2.user import expire_user
from ..libs_v2.payment import cancel_payment_order


logger = logging.getLogger('api.tasks')


def check_do_expire_user(user):
    """
    This function is runned by the scheduler every 10 seconds with the objective of
      flagging the expired user as "expired" in the omonimal flag.
    This function do a User and UserConfig save.
    :param user: model User instance
    :return: True if the user has been flagged expired and I runned the expiring procedure
    """
    if not user.is_active:
        return False  # If the user is not active, no expiration check is done
    elif user.userconfig.expired:
        return False  # If the user is already expired, don't do anything
    elif user.userconfig.expire_datetime is not None and \
            user.userconfig.expire_datetime < datetime.datetime.now(pytz.UTC):
        expire_user(user)
        close_all_user_charges(user)
        # Release all associated PaymentOrder if guest. This is needed if the user don't opened a charge
        if user.userconfig.guest:
            related_payord = PaymentOrder.objects.filter(guest_user=user, phase__gt=0, phase__lt=3)
            for payord in related_payord:
                cancel_payment_order(payord)
        return True


@shared_task(ignore_result=True)
def update_expired_user():
    # logger.debug("Scheduled update_expired_user running")
    for user in User.objects.all():
        if not hasattr(user, 'userconfig'):
            logger.warning(f"The user {user.username} was without UserConfig. Generated a default one.")
            uconf = UserConfig(user=user)
            uconf.save()
        result = check_do_expire_user(user)
        if result:
            logger.info(
                f"The user {user.username} expired with policy \"{user.userconfig.get_expire_policy_display()}\""
            )


def last_month_range(month_offset):
    today = datetime.date.today()
    target_month = (today.month - 2 + month_offset) % 12 + 1
    target_year = today.year
    if target_month > today.month:
        target_year -= 1
    stop = datetime.datetime(year=today.year, month=today.month, day=1)
    start = datetime.datetime(year=target_year, month=target_month, day=1)
    return start, stop, target_month


# FIXME: SISTEMARE STA FUNZIONE IN MODO CHE FUNZIONI CON I TEST
@shared_task
def send_mail_report_last_month(month_offset=0):  # Expected to be called the day n of every month for the past one
    logger.info("Scheduled send_mail_report running")
    # Calculate datetime
    start, stop, target_month = last_month_range(month_offset)
    logger.info(f"Starting report-gen loop with start and stop date: {start.isoformat()} -> {stop.isoformat()}")
    # Starting report-mail loop
    total_attempts = 0
    good_attempts = 0

    def month_name_dictionary(num):
        month_name_dict = {
            'en': [
                'January', 'February', 'March', 'April', 'May', 'June',
                'July', 'August', 'September', 'October', 'November', 'December'
             ],
            'it': [
                'Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno',
                'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'
             ],
            'fr': [
                'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
                'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
             ],
            'nl': [
                'Januari', 'Februari', 'Maart', 'April', 'Mei', 'Juni',
                'Juli', 'Augustus', 'September', 'Oktober', 'November', 'December'
            ]
        }

        def _month_name_impl(lang):
            return month_name_dict[lang][num - 1]
        return _month_name_impl

    month_name = month_name_dictionary(target_month)

    subjects = {
        'en': f'RossiniEnergy report month of {month_name("en")}',
        'it': f'Report mensile per il mese di {month_name("it")} da RossiniEnergy',
        'fr': f'RossiniEnergy rapport mois de {month_name("fr")}',
        'nl': f'RossiniEnergy rapport maand {month_name("nl")}'
    }
    messages = {
        'en': f'Dear Customer,\n\n'
              f'Please find attached the summary of the charge sessions paid out by credit card '
              f'at your chargepoints for the month of {month_name("en")}.\n\n'
              f'Happy charging,\nRossiniEnergy s.a.s.\n\n'
              f'+33 (0)3 74 09 01 05\ninfo@rossinienergy.com',
        'it': f'Gentile Cliente,\n\n'
              f'In allegato troverà un riepilogo delle ricariche a pagamento effettuate sul '
              f'vostro parco di colonnine nel mese di {month_name("it")}.\n\n'
              f'Cordialmente,\nRossiniEnergy s.a.s.\n\n'
              f'+33 (0)3 74 09 01 05\ninfo@rossinienergy.com',
        'fr': f'Cher Client,\n\n'
              f'Ci joint le récapitulatif des sessions de recharge payantes sur votre parc de '
              f'bornes de recharge pour le mois de {month_name("fr")}.\n\n'
              f'Bonnes recharges,\nRossiniEnergy s.a.s.\n\n'
              f'+33 (0)3 74 09 01 05\ninfo@rossinienergy.com',
        'nl': f'Beste klant,\n\n'
              f'Hierbij vindt u het overzicht van de betaalde oplaadbeurten voor uw wagenpark '
              f'voor de maand {month_name("fr")}.\n\n'
              f'Goede opladingen,\nRossiniEnergy s.a.s.\n\n'
              f'+33 (0)3 74 09 01 05\ninfo@rossinienergy.com',
    }

    for moneydest in MoneyDestination.objects.all():
        if moneydest.email == "":
            continue
        total_attempts += 1
        filepath = make_admin_report(moneydest, start, stop)
        subject = subjects[moneydest.receipt_language]
        message = messages[moneydest.receipt_language]
        recepient = moneydest.email
        # TODO: Make this configurable
        copy_mail = "comptabilite@rossinienergy.com"
        info_mail = "info@rossinienergy.com"
        # Don't send staging mail to other rossinienergy!
        if settings.STAGING:
            email = EmailMessage(subject, message, EMAIL_HOST_USER, [recepient])
        else:
            email = EmailMessage(subject, message, EMAIL_HOST_USER, [recepient], cc=[copy_mail, info_mail])
        email.attach_file(filepath)
        # TODO: better error handling
        try:
            result = email.send(fail_silently=False)
            if result > 0:
                good_attempts += 1
                logger.info(f"Report sent correctly to \"{moneydest.society_name}\"")
            else:
                logger.error(f"Error while sending report of \"{moneydest.society_name}\" "
                             f"to email \"{moneydest.email}\"")
        except SMTPException as exc:
            logger.error(f"Exception while sending report of \"{moneydest.society_name}\" "
                         f"to email \"{moneydest.email}\": {exc}")

    logger.info(f"Report-mail loop ended with sent mail over attempt: {good_attempts}/{total_attempts}")


@shared_task
def send_mail_park_report_last_month(month_offset=0):  # Expected to be called the day n of every month for the past one
    logger.info("Scheduled send_park_mail_report running")
    start, stop, _ = last_month_range(month_offset)
    logger.info(f"Starting park-report-gen loop with start and stop date: {start.isoformat()} -> {stop.isoformat()}")
    total_attempts = 0
    good_attempts = 0

    subjects = {
        'en': 'RossiniEnergy report for park "{}"',
        'it': 'Report mensile per il parco "{}" da RossiniEnergy',
        'fr': 'RossiniEnergy rapport pour le parc "{}"',
        'nl': 'RossiniEnergy rapport voor het "{}" park'
    }
    messages = {
        'en': 'Dear Customer,\n\n'
              'Please find attached the summary of the charge sessions at the '
              'chargepoints of the park "{}" carried out between {} and {}.\n\n'
              'Happy charging,\nRossiniEnergy s.a.s.\n\n'
              '+33 (0)3 74 09 01 05\ninfo@rossinienergy.com',
        'it': 'Gentile Cliente,\n\n'
              'In allegato troverà un riepilogo delle ricariche effettuate sulle '
              'colonnine del parco "{}" dal {} al {}.\n\n'
              'Cordialmente,\nRossiniEnergy s.a.s.\n\n'
              '+33 (0)3 74 09 01 05\ninfo@rossinienergy.com',
        'fr': 'Cher Client,\n\n'
              'Ci joint le récapitulatif des sessions de recharge aux bornes du '
              'parc "{}" réalisées entre le {} et le {}.\n\n'
              'Bonnes recharges,\nRossiniEnergy s.a.s.\n\n'
              '+33 (0)3 74 09 01 05\ninfo@rossinienergy.com',
        'nl': 'Beste klant,\n\n'
              'Hierbij vindt u het overzicht van de oplaadbeurten aan de oplaadpunten '
              'van het park "{}" die tussen {} en {} zijn uitgevoerd.\n\n'
              'Goede opladingen,\nRossiniEnergy s.a.s.\n\n'
              '+33 (0)3 74 09 01 05\ninfo@rossinienergy.com',
    }

    failed_list = []

    for park in Park.objects.filter(email_report=True):
        country_code = park.country_alpha2.lower()
        test_country = pycountry.countries.get(alpha_2=country_code)
        if not test_country:
            logger.warning(f"Country code {country_code} doesn't exists. Defaulting to FR.")
            country_code = "fr"
        try:
            _ = subjects[country_code]
            _ = messages[country_code]
        except KeyError:
            logger.warning(f"Using invalid country code {country_code} - defaulting to FR")
            country_code = "fr"

        total_attempts += 1
        try:
            filepath = make_park_report(park, start, stop)
        except Exception:
            failed_list.append(park.name)
            continue

        subject = subjects[country_code].format(park.name)
        message = messages[country_code].format(park.name, start.date(), stop.date())
        recepient = park.email
        # Don't send staging mail to other rossinienergy!
        email = EmailMessage(subject, message, EMAIL_HOST_USER, [recepient], cc=settings.PARK_REPORT_CC)
        email.attach_file(filepath)
        # TODO: better error handling
        try:
            result = email.send(fail_silently=False)
            if result > 0:
                good_attempts += 1
                logger.info(f"Report sent correctly to park \"{park.name}\"")
            else:
                failed_list.append(park.name)
                logger.error(f"Error while sending report of the park "
                             f"\"{park.name}\" to email \"{recepient}\"")
        except SMTPException as exc:
            failed_list.append(park.name)
            logger.error(f"Exception while sending report of park \"{park.name}\" "
                         f"to email \"{recepient}\": {exc}")

    logger.info(f"Park report-mail loop ended with sent mail over attempt: {good_attempts}/{total_attempts}")
    return failed_list


def produce_park_health_html_table():
    now = datetime.datetime.now(pytz.UTC)

    def park_not_good(park_report):
        last_c = park_report.last_contact
        return last_c is None or now - last_c > datetime.timedelta(hours=1)

    park_reports_mixed = [
        p for p in park_health_retrieve(Park.objects.filter(installed=True), many=True) if park_not_good(p)
    ]
    # Sorting to have park in decreased contacttime order, with None at the end of the table
    park_reports = [p for p in park_reports_mixed if p.last_contact is not None]
    park_reports.sort(key=lambda x: x.last_contact, reverse=True)
    park_reports_withnone = [p for p in park_reports_mixed if p.last_contact is None]
    park_reports.extend(park_reports_withnone)

    park_table = "<h2>Offline parks</h2>"
    park_table += "<div>Every park's last contact has been resetted during an update the December 16 2021.<br/>"
    park_table += "Only the data after December 01 2021 are showed in this report.</div>"
    park_table += "<br/><table>"
    park_table += "<tr><th>Park name (id)</th><th>Last contact</th><th>Days offline</th></tr>"
    style = 'style="border: 1px solid black; text-align:center; padding: 3px"'
    for pid, last_contact in park_reports:
        if last_contact is None:
            last_contact = "<font color='red'>None</font>"
            delta = "<font color='red'>???</font>"
        else:
            short = last_contact.strftime('%d/%m/%Y %H:%M:%S')
            delta = now - last_contact
            delta_days = int(delta.total_seconds()) // (60 * 60 * 24)
            if delta > datetime.timedelta(days=14):
                last_contact = f"<font color='orange'>{short}</font>"
                delta = f"<font color='orange'>{delta_days}</font>"
            elif delta > datetime.timedelta(days=30):
                last_contact = f"<font color='red'>{short}</font>"
                delta = f"<font color='red'>{delta_days}</font>"
            else:
                last_contact = short
                delta = f"{delta_days}"
        pname = Park.objects.get(id=pid).name
        park_table += (
                f'<tr><td {style}>{pname} ({pid})</td>'
                f'<td {style}>{last_contact}</td>'
                f'<td {style}>{delta}</td></tr>\n'
        )
    park_table += "</table>\n"

    return park_table


def produce_stripe_health_html_table():
    def stripe_not_good(stripe_report):
        # noinspection PyShadowingNames
        _, transfers, payout, capab_transfer, capab_cardpayment, enabled_cp, tot_cp = stripe_report
        return not (transfers and payout) \
            or enabled_cp != tot_cp \
            or not (capab_transfer and capab_cardpayment)

    stripe_reports = stripe_health_retrieve(MoneyDestination.objects.all(), many=True)
    bad_stripe_status = [report for report in stripe_reports if stripe_not_good(report)]
    table_header = [
            "Society (moneyreceiver id)", "Can transfer", "Can payout",
            "CP enabled", "Capability: transfer", "Capability: card payment"
    ]
    valid_receivers = [table_header]
    invalid_receivers = [table_header[0]]
    for report in bad_stripe_status:
        name = MoneyDestination.objects.get(id=report.id).society_name
        scname = f"{name} ({report.id})"
        if None in report:
            invalid_receivers.append(scname)
            continue
        transf = report.transfers
        payout = report.payout
        bornes = f"{report.enabled_cp}/{report.total_cp}"
        cap_tr = report.capab_transfers
        cap_cp = report.capab_cardpayments
        valid_receivers.append([scname, transf, payout, bornes, cap_tr, cap_cp])

    if len(valid_receivers) > 1:
        valid_receivers_table = "<h2>Money receivers with errors</h2><br/>\n<table>\n"
        header = True
        for line in valid_receivers:
            html_line = "<tr>"
            for field in line:
                tag = "th" if header else "td"
                style = 'style="border: 1px solid black; text-align:center; padding: 3px"'
                header = False
                if not isinstance(field, str):
                    if field:
                        field = "<font color='green'>OK</font>"
                    else:
                        field = "<font color='red'><b>NO!</b></font>"
                html_line += f'<{tag} {style}>{field}</{tag}>'
            html_line += "</tr>\n"
            valid_receivers_table += html_line
        valid_receivers_table += "</table>\n"
    else:
        valid_receivers_table = ""

    if len(invalid_receivers) > 1:
        invalid_receivers_table = "<h2>Invalid money receivers</h2><br/>\n<table>\n"
        header = True
        for receiver in invalid_receivers:
            tag = "th" if header else "td"
            style = 'style="border: 1px solid black; text-align:center; padding: 3px"'
            header = False
            invalid_receivers_table += f'<tr><{tag} {style}>{receiver}</{tag}></tr>\n'
        invalid_receivers_table += "</table>\n"
    else:
        invalid_receivers_table = ""

    return valid_receivers_table + "<br/>\n" + invalid_receivers_table


@shared_task(time_limit=2 * 60 * 60)
def send_health_report():
    subject = "Health report"

    html_message = produce_stripe_health_html_table() + "<br/>\n" + produce_park_health_html_table()

    for recipient in settings.HEALTH_STATUS_MAIL_RECIPIENTS:
        email = EmailMultiAlternatives(subject, "", EMAIL_HOST_USER, [recipient])
        email.attach_alternative(html_message, "text/html")
        result = email.send(fail_silently=True)
        if result > 0:
            logger.info(f"Health status mail sent correctly to {recipient}")
        else:
            logger.error(f"Error while health status mail to {recipient}")


@shared_task
def clear_expired_sessions():
    call_command("clearsessions")
