# Migration written manually with Django 3.1.7 on 2021-03-15 15:30

from django.db import migrations


def delete_duplicated_overlapped_charge(apps, schema_editor):
    charge_model = apps.get_model('pienosole_api', 'Charge')
    charginstation_model = apps.get_model('pienosole_api', 'ChargingStation')
    user_model = apps.get_model('auth', 'User')
    for cs in charginstation_model.objects.all():
        related_chare = charge_model.objects.filter(chargingstation=cs)
        for user in user_model.objects.all():
            user_charge = related_chare.filter(user=user).order_by("id")
            incorporated_charges = []
            for ch in user_charge:
                if ch in incorporated_charges:
                    continue
                tmp_incorporated_charges = []
                for ch2 in user_charge:
                    if ch2.id <= ch.id:
                        continue
                    if ch2.start > ch.stop:
                        break
                    if ch2.start <= ch.stop:
                        # Overlapping
                        new_stop = max(ch.stop, ch2.stop)
                        ch.stop = new_stop
                        ch.save()
                        tmp_incorporated_charges.append(ch2)
                incorporated_charges.extend(tmp_incorporated_charges)
            for inc_charge in incorporated_charges:
                inc_charge.delete()
    # END


class Migration(migrations.Migration):

    dependencies = [
        ('pienosole_api', '0013_auto_20210209_1013'),
    ]

    operations = [
        migrations.RunPython(delete_duplicated_overlapped_charge, reverse_code=migrations.RunPython.noop),
    ]
