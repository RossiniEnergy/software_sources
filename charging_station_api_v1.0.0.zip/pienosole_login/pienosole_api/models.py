import datetime

from django.db import models
from django.contrib.auth.models import User
from django.contrib.postgres.fields import ArrayField
from django.core.serializers.json import DjangoJSONEncoder


class NewComer(models.Model):
    # OPTIMIZE: Remove ALL THE UNNECESSARY NULLABLE ENTRY!!! (null=True without any reason)
    name = models.CharField(max_length=256, null=True)
    teamviewerid = models.CharField(max_length=256, null=True, default="-1")
    anydeskid = models.CharField(max_length=256, null=True, default="-1")
    time = models.DateTimeField(null=True)


class Park(models.Model):
    name = models.CharField(max_length=256, unique=True)
    teamviewerid = models.IntegerField(default=-1)
    anydeskid = models.IntegerField(default=-1)
    ipsum_avalpower_formula = models.CharField(max_length=400, blank=True, default="")
    ipsum_send_time = models.DurationField(null=True, default=datetime.timedelta(seconds=5))
    ipsum_last_send = models.DateTimeField(null=True, editable=False)
    email = models.EmailField(blank=True, default="")
    email_report = models.BooleanField(default=False)
    address = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=10)
    city = models.CharField(max_length=50)
    country_alpha2 = models.CharField(max_length=2)
    latitude = models.DecimalField(max_digits=10, decimal_places=7)
    longitude = models.DecimalField(max_digits=10, decimal_places=7)
    creation_date = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(null=True, auto_now=True)  # TODO: remove nullable
    accept_gireve = models.BooleanField(default=False)
    software_version = models.CharField(max_length=20, blank=True, default="")
    installed = models.BooleanField(default=False)
    advenir_user_id = models.CharField(max_length=40, default='91e7d39d-59b4-44f2-854e-19472e63832b')
    note = models.TextField(blank=True, default="")


class MoneyDestination(models.Model):
    society_name = models.CharField(max_length=50)
    email = models.EmailField(blank=True)
    stripe_id = models.CharField(max_length=100)
    address_1 = models.CharField(max_length=50)
    address_2 = models.CharField(max_length=50)
    postal_code = models.CharField(max_length=10)
    city = models.CharField(max_length=50)
    country_alpha2 = models.CharField(max_length=2, blank=True, default="")
    vat_country_alpha2 = models.CharField(max_length=2)
    phone_number = models.CharField(max_length=20)
    LANGUAGES = [
        ('en', 'English'),
        ('it', 'Italiano'),
        ('fr', 'Français'),
    ]
    receipt_language = models.CharField(max_length=2, choices=LANGUAGES, default='en')


class Logo(models.Model):
    static_file_tag = models.CharField(max_length=50)

    @property
    def static_final_url(self):
        from django.templatetags.static import static
        return static(self.static_file_tag)


class ChargingStation(models.Model):
    bnum = models.AutoField(primary_key=True)
    # QUESTION: think about the possibility to use ForeignKey(null=True)
    #  with a link to the ongoing charge
    park = models.ForeignKey(Park, on_delete=models.PROTECT, editable=False)
    park_bnum = models.IntegerField(editable=False)
    accept_guests = models.BooleanField(default=True)
    money_receiver = models.ForeignKey(MoneyDestination, on_delete=models.PROTECT, null=True, default=None)
    price = models.IntegerField(default=20)
    com = models.IntegerField(default=0)
    qrcodeid = models.IntegerField(null=True, default=None, unique=True)
    last_updated = models.DateTimeField(null=True, auto_now=True)  # TODO: remove nullable
    override_logo = models.ForeignKey(Logo, on_delete=models.PROTECT, null=True, default=None)
    last_power = models.ForeignKey("Power", on_delete=models.PROTECT, null=True, default=None, related_name='+')

    @property
    def evse_id(self):
        return "FR*ROS*E{}*{}".format(self.park_id, self.park_bnum)

    @property
    def already_started_charge(self):
        current_charge = Charge.objects.filter(stop__isnull=True, chargingstation=self).order_by("-id").first()
        if current_charge is None:
            return False
        else:
            return current_charge.last_nonzero_power_time is not None

    @property
    def active_charge(self):
        return self.charge_set.filter(stop__isnull=True).first()

    @property
    def is_payment_configured(self):
        return self.money_receiver is not None

    @property
    def last_power_query(self):
        """ Deprecated in favor of systemic last_power field """
        return Power.objects.filter(chargingstation=self).order_by("-id").first()

    @property
    def override_logo_url(self):
        if self.override_logo is None:
            return None
        else:
            return self.override_logo.static_final_url


class Charge(models.Model):
    # OPTIMIZE: make sense to use a index with stop, chargingstation_id for fast access in post_power?
    chargingstation = models.ForeignKey(
        ChargingStation, on_delete=models.PROTECT
    )
    start = models.DateTimeField()
    stop = models.DateTimeField(null=True)
    user = models.ForeignKey(User, on_delete=models.PROTECT)
    last_nonzero_power_time = models.DateTimeField(null=True, default=None)
    energy_wh = models.IntegerField(default=0)


class Power(models.Model):
    power = models.IntegerField()
    timestamp = models.DateTimeField()
    chargingstation = models.ForeignKey(
        ChargingStation, on_delete=models.PROTECT, null=True
    )


class BuildingInfos(models.Model):
    park = models.ForeignKey(Park, on_delete=models.PROTECT)
    timestamp = models.DateTimeField(auto_now_add=True)
    production = models.IntegerField(default=0)
    consumption = models.IntegerField(default=0)
    available_power = models.IntegerField(default=0)


# FIXME: Unify this with User creating a custom User Model
class UserConfig(models.Model):
    EXPIRE_POLICIES = [
        ('NPE', 'No Permission'),
        ('DIS', 'Disable'),
        ('PAD', 'PMS AppendTimestamp Disable')
    ]
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    authorized_bnum = ArrayField(models.IntegerField(blank=True), default=list)
    # authorized_bnum = models.ManyToManyField(ChargingStation, related_name='authorized_users')
    expired = models.BooleanField(default=False, editable=False)
    expire_datetime = models.DateTimeField(null=True, default=None)
    expire_policy = models.CharField(max_length=3, choices=EXPIRE_POLICIES, default='NPE')
    guest = models.BooleanField(default=False, editable=False)
    managed_parks = models.ManyToManyField(Park, related_name='admin_users')
    belonging_to = models.ManyToManyField(User, related_name='managed_users')

    @property
    def chargingstation_allowed(self) -> [ChargingStation]:
        if self.user.is_superuser or self.user.is_staff:
            user_authorized_cs = ChargingStation.objects.all()
        else:
            # Explicit Authorization Bnum List
            user_authorized_cs = list(ChargingStation.objects.filter(bnum__in=self.authorized_bnum))
            # Managed Park Bnum List
            for park in self.managed_parks.all():
                user_authorized_cs.extend(list(park.chargingstation_set.all()))
            user_authorized_cs = list(set(user_authorized_cs))
        return user_authorized_cs

    @property
    def qrcodeid_allowed(self) -> [int]:
        return list(cs.qrcodeid for cs in self.chargingstation_allowed if cs.qrcodeid is not None)


class PaymentOrder(models.Model):
    PHASES = [
        (0, 'cancelled'),
        (1, 'imprinted'),
        (2, 'confirmed'),
        (3, 'captured'),
    ]
    chargingstation = models.ForeignKey(ChargingStation, on_delete=models.PROTECT)
    guest_user = models.OneToOneField(User, on_delete=models.PROTECT, null=True, default=None)
    fingerprint = models.CharField(max_length=30, blank=True, default="")
    last4 = models.CharField(max_length=4, blank=True, default="")
    exp_month = models.CharField(max_length=2, blank=True, default="")
    exp_year = models.CharField(max_length=4, blank=True, default="")
    confirm_timestamp = models.DateTimeField(null=True, default=None)
    phase = models.IntegerField(choices=PHASES)
    imprint_id = models.CharField(max_length=100)
    imprinted_cents = models.IntegerField()
    energy_cents = models.IntegerField(default=0)
    stripe_comm_cents = models.IntegerField(default=0)
    rossen_comm_cents = models.IntegerField(default=0)
    capture_status = models.CharField(max_length=30, blank=True)
    last_updated = models.DateTimeField(auto_now=True)


# CUSTOM MODELS
class CustomFranceParebrisePark(models.Model):
    park = models.OneToOneField(Park, on_delete=models.PROTECT, primary_key=True)
    region_iso3166_2 = models.CharField(max_length=6)
    city = models.CharField(max_length=50)


class CustomKiloutouPark(models.Model):
    park = models.OneToOneField(Park, on_delete=models.PROTECT, primary_key=True)
    region_iso3166_2 = models.CharField(max_length=6)
    city = models.CharField(max_length=50)


# PMS - Hotel Management Software
class PMS(models.Model):
    name = models.CharField(max_length=30)
    abbrev = models.CharField(max_length=10, unique=True)


class PMSPendingRequest(models.Model):
    parkadmin_username = models.CharField(max_length=50)
    authorized_parks = ArrayField(models.IntegerField())
    registration_token = models.CharField(max_length=24, unique=True)
    pms = models.ForeignKey(PMS, on_delete=models.PROTECT)


class PMSAdminUser(models.Model):
    user = models.OneToOneField(User, on_delete=models.PROTECT, primary_key=True)
    authorization_token = models.CharField(max_length=32, unique=True)
    pms = models.ForeignKey(PMS, on_delete=models.PROTECT)
    customconfig = models.JSONField(encoder=DjangoJSONEncoder, default=dict)


# IPSUM API (the new old scatolino)
class IPSUMConfig(models.Model):
    token = models.CharField(max_length=20, unique=True)
    alias = models.CharField(max_length=50, unique=True)
    linked_parks = models.ManyToManyField(Park, related_name='linked_ipsums')
    save_min_delay = models.DurationField()
    drop_max_delay = models.DurationField(null=True, default=None)
    expected_clamps = models.IntegerField()  # used only to check validity of available_power_query
    last_save_timestamp = models.DateTimeField(auto_now_add=True)  # editable=False
    software_version = models.CharField(max_length=20, blank=True, default="")  # editable=False
    note = models.TextField(blank=True, default="")


class IPSUMLastPower(models.Model):
    ipsumconfig = models.OneToOneField(IPSUMConfig, on_delete=models.PROTECT, primary_key=True)
    timestamp = models.DateTimeField(auto_now=True)
    powers = ArrayField(models.IntegerField(blank=True, null=True), default=list)
    extra = models.JSONField(encoder=DjangoJSONEncoder, default=dict)


class IPSUMPowerTable(models.Model):
    ipsumconfig = models.ForeignKey(IPSUMConfig, on_delete=models.PROTECT)
    timestamp = models.DateTimeField()
    powers = ArrayField(models.IntegerField(blank=True, null=True), default=list)
    extra = models.JSONField(encoder=DjangoJSONEncoder, default=dict)
