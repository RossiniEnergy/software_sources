from datetime import datetime, timedelta
import time
import logging
import pytz

from ipsum.core.web import init_pika, upload
from ipsum.core.measure import measure
from ipsum.utils.conf import CONF, __version__


def setup_logger():
    """
    creates and configures the main logger
    """
    local_logger = logging.getLogger("ipsum")
    local_logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    formatter = logging.Formatter('\033[1m[%(asctime)s|%(levelname)s]\033[0m: %(name)s: %(message)s')
    formatter.converter = time.gmtime
    handler.setFormatter(formatter)
    local_logger.addHandler(handler)
    return local_logger


def main():
    logger = setup_logger()
    logger.info(f"starting ipsum v{__version__}")
    update_timer = timedelta(seconds=CONF.get("update_timer"))
    broker_url = CONF.get("broker_url")
    connection, channel = None, None
    while True:
        try:
            connection, channel = init_pika(connection, broker_url)
            start = datetime.now(pytz.utc)
            while True:
                now = datetime.now(pytz.utc)
                measure_dict = measure()
                logger.info(f"parsed: {measure_dict}")
                if measure_dict is not None and now >= start + update_timer:
                    upload(measure_dict, channel)
                    start = now
        except Exception as exc:
            logger.exception(f"Got exception: {exc}")
            if channel is not None and not channel.is_closed:
                channel.close()


if __name__ == "__main__":
    main()
