from collections import namedtuple
from ipsum.secrets import secrets
import logging

logger = logging.getLogger("ipsum.validator")


def integer_list(lst):
    return isinstance(lst, list) and len(lst) > 0 and all(isinstance(x, int) for x in lst)


def integer(x):
    return isinstance(x, int)


def number(x):
    return isinstance(x, float) or integer(x)


def positive(x):
    return x > 0


def non_empty_string(s):
    return isinstance(s, str) and len(s) > 0


def id_rule(name):
    try:
        if name[0:2] != "IP":
            return False
    except TypeError:
        return False
    try:
        _ = [int(x) for x in name[3:]]
    except ValueError:
        return False
    return True


def specific_calibration_factors_validator(lst):
    if not isinstance(lst, list):
        return 1
    errors = 0
    for item in lst:
        if not isinstance(item, dict):
            errors += 1
            continue
        if not integer(item.get("clamp", None)):
            errors += 1
        if not number(item.get("factor", None)):
            errors += 1
    return errors


# Here I define an assertion rule in this way:
# - name: the name of the entry on which we want to run the assertion
# - assertion: a function which takes the option from the conf as an argument and checks if the
#   desired entry is ok. It can be either
#   - a predicate which returns 'True' if all is ok, 'False' if an error is encountered
#   - a function which return the number of errors encountered (if the check is complex
#     and cannot be expressed as multiple simple predicates)
# - error: the text of the error to display if the assertion fails. The name of the option will be
#   prepended to the message, and the entered value will be appended
# - required: if this field is True and the field from the conf.toml does not exists or is None,
#   the check will automatically fail
# - default: a default value if no field has been found in the conf.
Rule = namedtuple(
        'Rule', ['name', 'assertion', 'error', 'required', 'default'], defaults=(True, None))
validation_rules = [
    Rule('ipsum_id', id_rule, "must be the string IP followed by some digits"),
    Rule('default_calibration_factor', number, "must be a number", required=False, default=1.0),
    Rule('specific_calibration_factors', specific_calibration_factors_validator,
         "must be an array of { clamp: int, factor: float } pairs", required=False, default={}),

    # System entries
    Rule('update_timer', integer, "must be a positive integer", required=False, default=30),
    Rule('broker_url',
         lambda u: non_empty_string(u) and u.startswith("amqp"), "must be an amqp url",
         default=secrets["default_broker_url"]),
    Rule('exchange',
         non_empty_string, "must be a non empty string", default=secrets["default_exchange"]),
    Rule('routing_key', non_empty_string, "must be a non empty string",
         default=secrets["default_routing_key"]),
]


def assert_rule(conf, name, assertion, error, required, default):
    """
    Given a rule as defined before, check if the rule is respected from the given configuration.
    Returns a pair containing
    - an object to be placed in the resulting dictionary. It can be the original value of the
      option if everything is ok, the default value if no value has been found in the conf,
      or None if the assertion fails
    - the total number of errors found in the assertion
    """
    opt = conf.get(name, default)
    if required and opt is None:
        logger.error(f"Field '{name}' required but not present in the file")
        return None, 1
    try:
        res = assertion(opt)
        if isinstance(res, bool):
            if not res:
                logger.error(f"Error: {name} {error} (used value {opt})")
                return None, 1
            return opt, 0
        if isinstance(res, int):
            if res > 0:
                logger.error(f"Errors ({res}): {name} {error} (used value {opt})")
                return None, res
            return opt, 0
        logger.error("Error: invalid validator (must be return bool or int).")
        logger.error("Please contact the developers")
        logger.error(f"(name: '{name}', value: '{opt}')")
    except Exception as exc:
        logger.exception(f"Exception thrown from the validator of '{name}', value '{opt}'.")
        logger.exception("Please contact the developers")
    return None, 1


def check_config(conf):
    """
    Given a conf dictionary, run all the assertions on it and return a pair containing
    the complete conf (merged with defaults) and if there has been an error
    """
    errors = 0
    canonical_options = set()
    # For each rule compute the assertion, print the total number of errors and save all the
    # used names
    for rule in validation_rules:
        # Check each rule, insert the values returned by the assert rules in the conf object
        res, errs = assert_rule(conf, *rule)
        errors += errs
        conf[rule.name] = res
        canonical_options.add(rule.name)
    logger.info(f"Validation completed with {errors} errors")
    # Print the names used in the config that do not exist in the rules - they probably contain
    # some typo or are not yet implemented
    used_options = set(conf.keys())
    unknown_options = used_options.difference(used_options)
    if len(unknown_options) > 0:
        # Warning
        logger.warning(f"Found {len(unknown_options)} unknown options:")
        for entry in unknown_options:
            print(entry)
    return conf, errors == 0
