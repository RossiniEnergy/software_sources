import sys
import toml
from .validation import check_config


def load_conf():
    """ load the conf file and test all the assertions """
    try:
        conf = toml.load("/etc/ipsum/conf.toml")
    except FileNotFoundError:
        print("File '/etc/ipsum/conf.toml' not found")
        sys.exit(1)
    except toml.TomlDecodeError as exc:
        print(f"Error while decoding the conf.toml: {exc}")
        sys.exit(1)

    conf, all_ok = check_config(conf.get("CONF", {}))
    if not all_ok:
        sys.exit(1)
    return conf


CONF = load_conf()


# DON'T EDIT THIS LINE. THIS IS DONE BY THE AUTOBUILDER
__version__ = '0.0.1'
