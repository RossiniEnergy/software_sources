import logging
import binascii
import pika

from ipsum.utils.conf import CONF, __version__
from .measure import Measure


def encode(metrics: Measure):
    """
    PROTOCOL VERSION 1:
    data are bytestring with this structure:
    bytenumberx content (type) firstbytenumber-lastbytenumberinclusive
        1x bytecode version (unsigned integer) 0
        3x software version (major.minor.rev) 1-3
        8x timestamp UTC (unsigned integer 64 bit) 4-11
        1x number P of power values in this metric (unsigned integer) 12
        3xP power values (unsigned integer) 13-15

        total bytesyze: 15 (1P) - 777 (255P)
        Every number is encoded as BIG ENDIAN.
        Note that in this list the interval is INCLUSIVE, in the list operator in Python the last
        number is EXCLUSIVE:
            software version is bytes from 1 to 3 (1,2,3) but the list retrieve is
            data[1:4]=>(1,2,3)
        The Encoding used is:
            the n-byte contain the number as ASCII characters corresponding to the number that we
            want to send, for example if we want to send 94 the byte will be \x61 so the bytestring
            will contain the corresponding char 'a', the number 12000 coded for 3 byte will be the
            bytestring b'\x00.\xe0', obtained with the function
            `numbervariable.to_bytes(nbytes, 'big')`
    """

    bytecode_version = int(1).to_bytes(1, 'big', signed=False)
    major, minor, rev = [int(x).to_bytes(1, 'big', signed=False) for x in __version__.split('.')]

    timestamp = int(metrics.timestamp).to_bytes(8, 'big', signed=False)
    how_many = int(len(metrics.measure)).to_bytes(1, 'big', signed=False)
    values = b''.join([int(m or 0).to_bytes(3, 'big', signed=False) for m in metrics.measure])
    msg = bytecode_version + \
        major + minor + rev + \
        timestamp + how_many + values

    if None in metrics.measure:
        nan_pos = 0
        for i in range(0, len(metrics.measure)):
            if metrics.measure[i] is None:
                nan_pos += 2**i
        nan_pos_enc = nan_pos.to_bytes(1 + (len(metrics.measure) - 1) // 8, 'big', signed=False)
        msg += nan_pos_enc

    return msg


def upload(measure_dict: Measure, channel):
    """ Uploads the encoded measure to the rabbitmq broker """
    logger = logging.getLogger("ipsum.upload")
    ipsum_id = CONF.get("ipsum_id")
    if measure_dict is None:
        logger.error("tried to send a None measure")
        return
    data = encode(measure_dict)
    payload = binascii.b2a_base64(data).decode()
    exchange = CONF.get("exchange")
    routing_key = CONF.get('routing_key')
    try:
        logger.info(f"sending measure {measure_dict}")
        packet = f"{ipsum_id} {payload}"
        channel.basic_publish(exchange=exchange, routing_key=routing_key, body=bytes(packet, 'ascii'))
        logger.info(f"measure sent: {packet}")
    except pika.exceptions.AMQPError:
        logger.error(f"Can't publish data to exchange {exchange}, key {routing_key}")
        raise


def init_pika(connection, broker_url):
    if connection is None or connection.is_closed:
        connection = pika.BlockingConnection(pika.connection.URLParameters(broker_url))
    channel = connection.channel()
    return connection, channel
