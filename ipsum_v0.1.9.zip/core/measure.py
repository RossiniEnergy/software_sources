import datetime
import logging
from dataclasses import dataclass
import pytz
import serial

from ipsum.utils.conf import CONF

ser = serial.Serial("/dev/ttyAMA0", 38400, timeout=10)

default_factor = CONF.get("default_calibration_factor", 1.0)
specific_factors = dict(x.values() for x in CONF.get("specific_calibration_factors", {}))


@dataclass
class Measure:
    """ simple aggregate representing a measure """
    measure: list
    timestamp: int

    def __init__(self, measure_list):
        self.measure = measure_list
        self.timestamp = int(datetime.datetime.now(pytz.utc).timestamp())


def reset_serial():
    """ resets the serial state """
    global ser
    ser = serial.Serial("/dev/ttyAMA0", 38400, timeout=10)


def parse(raw_string: bytes) -> Measure:
    """
    return metrics for every clamp defined in conf
    """
    logger = logging.getLogger("ipsum.parse")
    try:
        logger.info(f"Serial read: {raw_string}")
        measurements_string = raw_string.replace(b"1\x001", b"11").strip()
        power_values = []
        for x in measurements_string.split(b' '):
            if x.lower() == b'nan':
                power_values.append(None)  # biggest negative with a signed 3 byte integer
            else:
                power_values.append(int(float(x)))
        if power_values[0] != 11:
            logger.warning("string from serial without leading 11")

        metrics = []
        for cp_num, value in enumerate(power_values):
            if cp_num == 0:
                continue
            coeff = specific_factors.get(cp_num, default_factor)
            if value is None:
                metrics.append(None)
            else:
                metrics.append(value * coeff)

        return Measure(metrics)
    except Exception as exc:
        logger.error("Impossible to determinate available power", exc_info=exc)
        return None


def measure() -> Measure:
    """
    Try to get a measure; returns the dictionary with the adjusted value for each clamp, or None on
    failure
    """
    logger = logging.getLogger("ipsum.measurements")
    try:
        line = ser.readline()
        if line != "":
            measure_result = parse(line)
            # if measure_result == {}:  # or metrics_dict is None:
            #     return None
            return measure_result
        reset_serial()
    except serial.SerialException as exc:
        logger.error("Serial port exception handled", exc_info=exc)
        reset_serial()
    except Exception as exc:
        logger.error("Unable to complete the Measurements step", exc_info=exc)
    return None
