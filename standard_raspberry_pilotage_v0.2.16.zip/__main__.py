import logging
import time
from multiprocessing import Queue

from standard_raspberry.utils.conf import CONF
from standard_raspberry.core.cpmanager import CPManager
from standard_raspberry.core.measurements import Measurements
from standard_raspberry.core.orders import orders
from standard_raspberry.core.send_metrics import SendMetrics
from standard_raspberry.core.supply import Supply
from standard_raspberry.core.pilotageinterface import hardware_class
from standard_raspberry.core.ipsum import recover_ipsum
from standard_raspberry.utils.sync import AtomicResource, ThreadStatus


# TODO: Better error signaling where I assert now
def check_conf():
    """
        check the consistency of the information in the config
    """
    lowest_power_level_default = CONF.get("lowest_power_level_default")
    min_mono_charging_power = CONF.get("min_mono_charging_power")
    assert lowest_power_level_default < hardware_class().MAX_POWER_LEVEL
    assert min_mono_charging_power < hardware_class().get_power_given_level(True, lowest_power_level_default)
    already_used_clamps = []
    # Check Production
    production_counting = CONF.get("production_counting")
    if production_counting:
        production = CONF.get("production")
        for elem in production:
            assert isinstance(elem, dict)
            assert elem.get("phase") in ("mono", "three")
            assert isinstance(elem.get("clamps"), list)
            for clamp in elem.get("clamps"):
                assert isinstance(clamp, int)
                already_used_clamps.append(clamp)
    # Check Building
    building_counting = CONF.get("building_counting")
    if building_counting:
        building = CONF.get("building")
        for elem in building:
            assert elem.get("phase") in ("mono", "three")
            assert isinstance(elem.get("clamps"), list)
            for clamp in elem.get("clamps"):
                assert isinstance(clamp, int)
                already_used_clamps.append(clamp)
    # Check if we are Enterprise, if we have enough guaranteed_min_power
    if CONF.get("receive_orders"):
        guaranteed_min_power = CONF.get("guaranteed_min_power")
        lowest_power_level_default = CONF.get("lowest_power_level_default")
        disable_pilotage_on_cs = CONF.get("disable_pilotage_on_cs")
        min_needed = 0
        for k in range(CONF.get("cp")):
            if k+1 in disable_pilotage_on_cs:
                continue
            clamps = CONF.get("cs_{}".format(k + 1))
            already_used_clamps += clamps
            if len(clamps) == 1:
                # Support only Mono
                min_needed += hardware_class().get_power_given_level(True, lowest_power_level_default)
            elif len(clamps) > 1:
                # Support Mono and Three, use Three
                min_needed += hardware_class().get_power_given_level(False, lowest_power_level_default)
        if not guaranteed_min_power >= min_needed:
            error_border = "#" * 71 + "\n"
            error_body = "# {:^67} #\n".format(f"Required guaranteed_min_power: {min_needed} W")
            error_hint = "# {:^67} #\n".format("If you have enough power available increase it in the conf file")
            raise AssertionError(
                "\n\n" +
                error_border +
                error_body +
                error_hint +
                error_border +
                "\n"
            )
    # Check if some clamps are repeated
    clamps_repeated = [el for el in already_used_clamps if already_used_clamps.count(el) > 1]
    if len(clamps_repeated) > 0:
        raise AssertionError(
            f"Repeated clamps {clamps_repeated} in the configuration file. Every clamp must be used a single time")
    # Scatolino
    with_scatolino = CONF.get("with_scatolino")
    if with_scatolino:
        assert CONF.get("scatolino") != "MISSINGSCATOLINOID"
        assert CONF.get("scatolino_calculation") != "MISSINGCALCULATION"


def setup_logger():
    """
    creates and configures the main logger
    """
    local_logger = logging.getLogger("rpi")
    local_logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    formatter = logging.Formatter('\033[1m[%(asctime)sZ|%(levelname)s]\033[0m: %(name)s: %(message)s')
    formatter.converter = time.gmtime
    handler.setFormatter(formatter)
    local_logger.addHandler(handler)
    return local_logger


def main():
    logger = setup_logger()

    # INJECTION
    import subprocess
    scriptcheck = "exit $(dpkg-query -W -f=\'${Status}\' standard-image-suite 2>/dev/null | grep -c \"ok installed\")"
    result = subprocess.run(scriptcheck, shell=True)
    if result.returncode == 0:
        logger.info("Package standard-image-suite missing. Starting installation...")
        scriptkek = [
            "update_repo rossinienergy",
            "apt -y -o Dpkg::Options::=\"--force-confdef\" -o Dpkg::Options::=\"--force-confnew\" -o Dpkg::Options::=\"--force-overwrite\" install standard-image-suite",
        ]
        for scpt in scriptkek:
            result = subprocess.run(scpt, shell=True)
            logger.info(f"Command \"{scpt}\" returned {result.returncode}")
        logger.info("Installation sequence completed!")
    else:
        logger.info("Package standard-image-suite already installed")
    # END INJECTION

    try:
        check_conf()
    except (AssertionError, KeyError) as exc:
        logger.critical("Config File Error. Abort.", exc_info=exc)
        import sys
        sys.exit(1)

    # <----- SMART DEBUG BEGIN ----->
    try:
        if CONF.get("smart_debug"):
            from standard_raspberry.core.debug_options_scanner import Debug

            debug = Debug()
            debug.start()
    except (AssertionError, KeyError) as exc:
        logger.critical("Debug Config File Error. Abort.", exc_info=exc)
        import sys
        sys.exit(1)
    # <----- SMART DEBUG END ----->

    shared_last_measure = AtomicResource(None)
    thread_status = ThreadStatus()
    ipsum_buffer = AtomicResource(None)
    timer_queue = Queue()
    cpmanager = CPManager(CONF.get("cp"), shared_last_measure)

    measurements = Measurements(shared_last_measure, thread_status, ipsum_buffer)
    send_metrics = SendMetrics(shared_last_measure, timer_queue, thread_status)
    supply = Supply(cpmanager, thread_status)

    # recover ipsum
    if CONF.get("with_ipsum"):
        logger.info("Retrieving ipsum data...")
        try:
            recover_ipsum(ipsum_buffer)
            logger.info("Ipsum data retrieved")
        except Exception:
            logger.info("Failed to retrieve ipsum data - starting in fallback mode")
            thread_status.orders_err(3)

    measurements.start()
    send_metrics.start()
    supply.start()

    if CONF.get("receive_orders") or CONF.get("with_ipsum"):
        orders(cpmanager, timer_queue, thread_status, ipsum_buffer)
    else:
        from time import sleep

        while True:
            sleep(5)


if __name__ == '__main__':
    main()
