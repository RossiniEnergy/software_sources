from dynaconf import Validator
from standard_raspberry.secrets import secrets

VALIDATORS = [
    # User and Power Configuration
    Validator("CONF.cp", must_exist=True, gte=1),
    Validator("CONF.metrics_url", default=secrets['metrics_url']),
    Validator("CONF.get_cs_state_url", default=secrets['get_cs_state_url']),
    Validator("CONF.get_cs_list_url", default=secrets['get_cs_list_url']),
    Validator("CONF.rabbitmq_url", default=secrets['rabbitmq_url']),
    Validator("CONF.park_name", must_exist=True),
    Validator("CONF.production_counting", "CONF.building_counting", "CONF.receive_orders",
              must_exist=True),
    Validator("CONF.building_include_chargepoint", default=True),
    Validator("CONF.fixed_power_from_grid", must_exist=True),
    Validator("CONF.guaranteed_min_power", must_exist=True, gte=0),
    Validator("CONF.max_available_power", default=None),
    Validator("CONF.lowest_power_level_default", must_exist=True),
    Validator("CONF.min_mono_charging_power", default=400),
    Validator("CONF.clamp_power_cutoff", default=300),
    Validator("CONF.smart_debug", default=True),
    Validator("CONF.debug_config_file", default="/etc/standard-raspberry/debug_options.toml"),
    # Clamps enumeration
    Validator(*(f"CONF.cs_{i}" for i in range(1, 7)), default=[], len_max=3),
    Validator("CONF.disable_pilotage_on_cs", default=[]),
    Validator("CONF.unpilotated_default_power_level", default=7),
    Validator("CONF.building", "CONF.production", must_exist=True),
    Validator("CONF.default_calibration_factor", default=1.0, gte=0.0),
    Validator("CONF.specific_calibration_factors", default=[]),
    # Timers and system configurations
    Validator("CONF.hardware_pilotage_version", default=0, gte=0),
    Validator("CONF.supply_loop_timing", default=10, gte=2),
    Validator("CONF.low_activity_metrics_timer", default=120, gte=8),
    Validator("CONF.high_activity_metrics_timer", default=30, gte=8),
    Validator("CONF.shuffle_timer", default=900, gte=8),
    Validator("CONF.power_attenuation_check_timer", default=300, gte=8),
    Validator("CONF.bootstrap_cp_time", default=60, gte=8),
    Validator("CONF.nan_buffer_length", default=0, gte=0),
    Validator("CONF.ghost_power_hotfix", default=False),
    # Scatolino - remote power probing
    Validator("CONF.with_scatolino", must_exist=True),
    Validator("CONF.scatolino", default="MISSINGSCATOLINOID"),
    Validator("CONF.scatolino_calculation", default="MISSINGCALCULATION"),
    Validator("CONF.scatolino_include_chargepoint", default=False),
    Validator("CONF.scatolino_timeout", default=50),
    # IPSUM - the new scatolino
    Validator("CONF.with_ipsum", default=False),
    Validator("CONF.ipsum_recovery_api", default=secrets["ipsum_recovery_api"]),
    Validator("CONF.ipsum_timeout", default=50),

]
