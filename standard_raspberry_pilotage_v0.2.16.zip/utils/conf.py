from dynaconf import Dynaconf
from standard_raspberry.utils.conf_validator import VALIDATORS

settings = Dynaconf(
    # envvar_prefix="STDRASP",
    settings_files=['/etc/standard-raspberry/conf.toml'],  # Files in loading order
    validators=VALIDATORS,
)

CONF = settings.get("CONF")

# DONT EDIT THIS LINE. THIS IS DONE BY THE AUTOBUILDER
__version__ = '0.0.1'
