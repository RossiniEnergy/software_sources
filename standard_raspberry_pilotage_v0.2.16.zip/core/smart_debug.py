import logging
from standard_raspberry.core.pilotageinterface import hardware_class
from standard_raspberry.utils.conf import CONF

debug_options = {}


def energy_balance(cp_list, power_available, last_residue, is_fallback: bool):
    debug_energy_balance_flag = debug_options.get("energy_balance_in_out")
    if debug_energy_balance_flag is not None and debug_energy_balance_flag.read():
        if not is_fallback:
            out_string = f"Power supply\nPower available: {power_available} W"
        else:
            out_string = "Power supply in fallback mode"
        with cp_list.locked() as cp_list:
            for i, cp in enumerate(cp_list):
                power_consume = \
                    hardware_class().get_power_given_level(cp.state.mono, cp.state.power_level)
                status = f"{'on' if cp.state.charging else 'off'}-balance"
                if i + 1 in CONF.get("disable_pilotage_on_cs"):
                    status += ' (pilotage disabled)'
                out_string += \
                    f"\n  Chargepoint {i+1}: {power_consume:>5} W  {status}"
                if cp.state.mono and cp.state.charging and CONF.get("ghost_power_hotfix"):
                    out_string += f" x3 [ghost power]: {power_consume * 3:>5} W"
        out_string += f"\nResidue: {last_residue} W"
        logging.getLogger("rpi.debug.energy_balance").debug(out_string)


def scatolino_power(power_available, last_time):
    debug_scatolino_power = debug_options.get("scatolino_power")
    if debug_scatolino_power:
        logger = logging.getLogger("rpi.debug.scatolino")
        logger.debug(f"retrieved power from scatolino: {power_available} W ({last_time})")


def cp_list_general_status(cp_list):
    debug_cp_list_general_status = debug_options.get("chargepoint_list_general_status")
    if debug_cp_list_general_status is not None and debug_cp_list_general_status.read():
        out_string = "Current chargepoint status:"
        with cp_list.locked() as cp_list:
            for i, cp in enumerate(cp_list):
                if i + 1 in CONF.get("disable_pilotage_on_cs"):
                    out_string += f"\n  Chargepoint {i+1:<3}pilotage disabled"
                else:
                    probing = cp.state.probe_active
                    charging = cp.state.charging
                    state = [['free', 'suspended'], ['probing', 'charging']][probing][charging]
                    out_string += \
                        f"\n  Chargepoint {i+1:<3}" + \
                        f"state: {state:<10}" + \
                        f"power level: {cp.state.power_level:<3}" + \
                        f"{'monophase' if cp.state.mono else 'threephase':<12}" + \
                        f"pwratt: {str(cp.state.power_attenuation_level):<7}" + \
                        f"pwratt timer: {str(cp.state.power_attenuation_timer)}"  # :<34
        logging.getLogger("rpi.debug.general_status").debug(out_string)


def raw_serial(data):
    debug_raw_serial = debug_options.get("raw_serial")
    if debug_raw_serial is not None and debug_raw_serial.read():
        logging.getLogger("rpi.debug.raw_serial").debug(f"Latest serial data:\n\t'{data}'")


def raw_serial_after_calibration(values):
    debug_raw_serial = debug_options.get("raw_serial")
    if debug_raw_serial is not None and debug_raw_serial.read():
        vs = ' '.join(f"{v}" for v in values)
        logging.getLogger("rpi.debug.raw_serial").debug(f"Latest serial data (recalibrated):\n\t'{vs}'")


def last_measure(metrics):
    debug_last_measure = debug_options.get("last_measure_update")
    if debug_last_measure is not None and debug_last_measure.read():
        logging.getLogger("rpi.debug.last_measure").debug(f"Latest metrics:\n\t{metrics}")


def timers(new_timer, queue_size):
    debug_timers_flag = debug_options.get("sendmetrics_timers")
    if debug_timers_flag is not None and debug_timers_flag.read():
        logging.getLogger("rpi.debug.timers")\
                .debug("SendMetrics's timer set to %s (%s events in queue)", new_timer, queue_size)


def notify_new_order(order):
    debug_orders_flag = debug_options.get("new_orders")
    if debug_orders_flag is not None and debug_orders_flag.read():
        logging.getLogger("rpi.debug.new_order").debug("New order: \"%s\"", order)


def global_status(cp_manager, thread_status):
    flag = debug_options.get("global_status", None)
    if flag is not None and flag.read():
        logging.getLogger("rpi.debug.global_status")\
                .debug(f"\n{cp_manager.serialize_for_debug('')}\n{thread_status.serialize_for_debug('')}")
