import datetime
import logging
import random
from standard_raspberry.core import smart_debug
from copy import copy
from time import time, sleep
from threading import Lock
from contextlib import contextmanager

from standard_raspberry.utils.conf import CONF
from standard_raspberry.core.chargepoint import ChargePoint
from standard_raspberry.core.measurements import Metrics
from standard_raspberry.core.pilotageinterface import hardware_class
from standard_raspberry.utils.sync import AtomicResource

logger = logging.getLogger("rpi.cpmanager")

DEFAULT_PWRLV = CONF.get("lowest_power_level_default")
PWRATT_CUTOFF = CONF.get("min_mono_charging_power")
MAX_POWER_LEVEL = hardware_class().get_max_power_level()


def generate_seed_every_tot_time(tot_time_in_seconds):
    # TODO: Shift from module time to module datetime
    next_shuffle_seed_time = time() + tot_time_in_seconds  # Change shuffle seed every n sec
    seed = random.random()
    while True:
        if time() > next_shuffle_seed_time:
            logger.info("Reshuffle seed changed")
            seed = random.random()
            next_shuffle_seed_time = time() + tot_time_in_seconds
        yield seed


class LockedCPList:
    def __init__(self, number_of_cp: int):
        self._cp_list = []
        for i in range(number_of_cp):
            self._cp_list.append(ChargePoint(i+1, i+1 not in CONF.get("disable_pilotage_on_cs")))
        self._resource_lock = Lock()

    @contextmanager
    def locked(self):
        """ This method is designed to be used via the `with` statement. """
        try:
            self._resource_lock.acquire()
            yield self._cp_list
        finally:
            self._resource_lock.release()


class CPManager:
    def __init__(self, number_of_cp: int, shared_last_measure: AtomicResource):
        self._hardware_interface = hardware_class()(number_of_cp)  # This func return a class, so we need to init it
        self._cp_list = LockedCPList(number_of_cp)
        self._shared_last_measure = shared_last_measure
        self._order_system_enabled = CONF.get("receive_orders")
        self._shuffle_seed_generator = generate_seed_every_tot_time(CONF.get("shuffle_timer"))  # 15 mins is good

    def serialize_for_debug(self, prefix) -> str:
        cp_serialized = ""
        with self._cp_list.locked() as list:
            for cp in list:
                cp_serialized += f"{cp.serialize_for_debug(prefix=prefix+'  ')}"

        return (
            f"{prefix}CP MANAGER\n"
            f"{prefix}  Hardware interface: {type(self._hardware_interface)}\n"
            f"{prefix}  Shared last measure: {self._shared_last_measure.read()}\n"
            f"{prefix}  QR codes: {'enabled' if self._order_system_enabled else 'disabled'}\n"
            f"{prefix}CP LIST:\n{cp_serialized}"
        )

    # External Interface Functions (ORDERS)
    def flag_charging(self, num: int, flag: bool):
        # num is cp number from 1 to n, so the index is num-1
        with self._cp_list.locked() as cp_list:
            cp = cp_list[num - 1]
            cp.state.charging = flag
            cp.state.charge_started = False
            cp.state.reset_budget()  # FIXME: i dont think this do anything useful (the erogate resets anyway)

    # FIXME: make sense to move order first init (states recovery) here?
    def no_order_first_initialization(self):
        if not self._order_system_enabled:
            logger.info("Start no order first initialization...")
            with self._cp_list.locked() as cp_list:
                for i, cp in enumerate(cp_list):
                    if not cp.state.pilotated:
                        continue
                    self._hardware_interface.apply_power_level(cp.cpnum, DEFAULT_PWRLV)
                    sleep(CONF.get("bootstrap_cp_time"))
                    last_metrics: Metrics = self._shared_last_measure.read()
                    # FIXME: check if 01/10 is a good choice for first init (alt. 10/11)
                    if last_metrics.get_cp_power(i + 1) > 1000:
                        cp.state.probe_active = False
                        cp.state.charging = True
                        logger.info("CP {} is flagged as Charging".format(i + 1))
                    else:
                        cp.state.probe_active = True
                        cp.state.charging = False
                        logger.info("CP {} is flagged as Not Charging".format(i + 1))
                    self._hardware_interface.apply_power_level(cp.cpnum, 0)
                logger.info("Finished no order first initialization.")

    # Subroutines
    def __prepare_states(self, cp_list: [ChargePoint], last_metrics: Metrics):
        # Clear old timeout and power budgets from cp_list
        for i, cp in enumerate(cp_list):
            if not cp.state.pilotated:
                continue
            metrics_power = last_metrics.get_cp_power(i + 1)
            # If the C = 0 we need to reset to default the mono because we don't have a car in place
            if not cp.state.charging:
                cp.state.reset_mono()
            # Write down mono/three-phased flags if the cp in the state PC = 11
            elif cp.state.probe_active:
                cp.state.mono = last_metrics.is_mono(i + 1)
            # Read, Assign, Reset power_attenuation
            #  cap power is a lower bound
            #  If we have power assigned 4 and effective to 3.5 we have a cap at 3. If our effective go under 3 (2.9) we
            #  flag the power_attenuation at 3, so we can free the power 3to4 for another charge point

            # we now check what's the first power level with a power greater than the one measuring
            cap_power = self._hardware_interface.get_power_given_level(cp.state.mono, max(cp.state.power_level - 1, 0))
            # we now have our max power, and I compare it with the one measured. If this last one is the smaller, we
            # stop charging

            if cp.state.power_level == DEFAULT_PWRLV:
                if cp.state.mono:
                    cap_power = PWRATT_CUTOFF
                else:
                    cap_power = PWRATT_CUTOFF * 3

            # here our charging point is "suspended", meaning there is an active order but no available power
            if not cp.state.probe_active and cp.state.charging:
                # so we can reset the pwratt timer
                cp.state.reset_power_attenuation_timer()

            # if instead we are actually charging, we need to check for how much power the charging point is using
            elif cp.state.power_attenuation_timer is not None:
                # Check timer lift (level power 2)

                # if we measure more power than the max power we set earlier we can unlock the pwratt timer
                if metrics_power > cap_power:
                    # all this is to check if we need to lower the power to our charging station or not, here we see
                    # that clearly the car is able to pull more power than we calculated earlier, so we unlock the timer
                    cp.state.reset_power_attenuation_timer()

                # now we check if we can update power_attenuation:
                # first we check if its timer is expired
                elif datetime.datetime.now(datetime.timezone.utc) > cp.state.power_attenuation_timer:
                    # is so, we set the new power level

                    # if our cap power is equal to the cutoff we cut the power
                    if cp.state.power_level == DEFAULT_PWRLV:
                        new_level = 0
                    else:
                        new_level = self._hardware_interface.get_higher_level_given_power(cp.state.mono, metrics_power)
                        if new_level <= DEFAULT_PWRLV:
                            new_level = DEFAULT_PWRLV

                    cp.state.power_attenuation_level = new_level

            # Check if we can generate a new Power Attenuation Timer
            elif cp.state.probe_active and cp.state.charging and \
                    metrics_power < cap_power:
                # if we are measure less than our cap power we generate a new timer
                if cp.state.charge_started:
                    cp.state.new_power_attenuation_timer(
                        datetime.timedelta(seconds=CONF.get("power_attenuation_check_timer")))

            # if we are not charging we reset the pwratt level
            elif not cp.state.charging:
                cp.state.power_attenuation_level = MAX_POWER_LEVEL  # Reset when not charging
            # Reset Power Budgets
            cp.state.reset_budget()
        # (NO ORDER) Flag the charging stations
        if not self._order_system_enabled:
            for i, cp in enumerate(cp_list):
                if not cp.state.pilotated:
                    continue
                if cp.state.probe_active:
                    cp.state.charging = last_metrics.get_cp_power(i + 1) > 700
                    cp.state.charge_started = cp.state.charging
                # Reset eventually unreachable PC = 00 status  ( fix unreachable 00 )
                if not cp.state.probe_active and not cp.state.charging:
                    cp.state.probe_active = True
                    logger.error("Chargepoint {} with unreachable state PC = 00, resetting to PC = 10".format(i))
        # (ORDER) Flag the charge started
        else:
            for i, cp in enumerate(cp_list):
                if cp.state.charging:
                    power_flowing = last_metrics.get_cp_power(i + 1) > 700
                    cp.state.charge_started = power_flowing
                else:
                    cp.state.charge_started = False

    def __distribute_min_power(self, cp_list: [ChargePoint], power_available: int) -> int:
        need_energy = [i for i, cp in enumerate(cp_list) if cp.state.charging and cp.state.pilotated]
        # Regenerate seed
        seed_shuffle = next(self._shuffle_seed_generator)
        # Shurima Shuffle!
        random.shuffle(need_energy, lambda: seed_shuffle)
        need_energy.sort(key=lambda x: cp_list[x].state.power_attenuation_level == 0)  # Low Priority at Full
        for i in need_energy:
            cp = cp_list[i]
            if cp.state.request_minimal_power() < power_available:
                cp.state.probe_active = True
                power_available = cp.state.give_minimum_power(power_available)
            else:
                cp.state.probe_active = False
                cp.state.override_power_level(0)
        # FIXME: write a better code
        for cp in cp_list:
            if not cp.state.charging:
                if self._order_system_enabled:
                    cp.state.probe_active = False
                    cp.state.override_power_level(0)
                else:
                    cp.state.probe_active = True  # This can replace the "fix unreachable 00"
                    cp.state.override_power_level(DEFAULT_PWRLV)  # Off-budget energy
        return power_available

    def __distribute_surplus_power(self, cp_list: [ChargePoint], power_available: int) -> int:
        # Regenerate seed
        seed_shuffle = next(self._shuffle_seed_generator)
        # Need_energy erogation
        need_energy = [i for i, cp in enumerate(cp_list) if
                       cp.state.probe_active and cp.state.charging and cp.state.pilotated]
        random.shuffle(need_energy, lambda: seed_shuffle)

        def need_energy_sort_key(j):
            chargepoint = cp_list[j]
            if chargepoint.state.power_attenuation_level == 0 or chargepoint.state.power_level >= MAX_POWER_LEVEL or \
                    chargepoint.state.power_level >= chargepoint.state.power_attenuation_level:
                # I want the "Full chargepoint" as the ABSOLUTE LATEST in need energy priority
                import math
                return math.inf
            return chargepoint.state.request_next_level_total_power()

        last_cycle_power_available = 0
        if len(need_energy) != 0:
            while last_cycle_power_available != power_available:
                last_cycle_power_available = copy(power_available)
                # Create new priority list for the distribution
                need_energy.sort(key=need_energy_sort_key)  # First have priority, Last have low priority
                erogate_index = need_energy[0]
                # Assign Energy!
                power_available = cp_list[erogate_index].state.give_next_level_power(power_available)
        return power_available

    def erogate(self):
        with self._cp_list.locked() as cp_list:
            # Retrieve the last metrics available
            last_metrics: Metrics = self._shared_last_measure.read()
            power_available = last_metrics.available_power
            # Start Erogation subroutines
            self.__prepare_states(cp_list, last_metrics)
            power_available = self.__distribute_min_power(cp_list, power_available)
            power_available = self.__distribute_surplus_power(cp_list, power_available)
            # Charge: Apply the Effective Charge Level
            for cp in cp_list:
                cp.apply_power_budget(self._hardware_interface)

        # Smart debug hooks
        smart_debug.energy_balance(self._cp_list, last_metrics.available_power, power_available, False)
        smart_debug.cp_list_general_status(self._cp_list)

    def erogate_fallback(self):
        # Bypass Metrics Thread for fallback
        available_power = CONF.get("guaranteed_min_power")
        with self._cp_list.locked() as cp_list:
            for cp in cp_list:
                cp.state.reset_budget()
            # In fallback we give priority to CP numerically first (1>2>3>...)
            for cp in cp_list:
                needed_power = cp.state.request_minimal_power()
                if needed_power < available_power:
                    available_power = cp.state.give_minimum_power(available_power)
                else:
                    break
            for cp in cp_list:
                cp.apply_power_budget(self._hardware_interface)
        # Smart debug hooks
        smart_debug.energy_balance(self._cp_list, None, available_power, True)
        smart_debug.cp_list_general_status(self._cp_list)
