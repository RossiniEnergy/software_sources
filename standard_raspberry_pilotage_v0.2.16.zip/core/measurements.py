import json
import logging

import pytz

from standard_raspberry.core import smart_debug
from standard_raspberry.secrets import secrets
from datetime import datetime, timedelta
from threading import Thread

import pymysql
import serial

from standard_raspberry.utils.conf import CONF
from standard_raspberry.utils.sync import AtomicResource, ThreadStatus


PWRATT_CUTOFF = CONF.get("min_mono_charging_power")
CLAMP_CUTOFF = CONF.get("clamp_power_cutoff")

logger = logging.getLogger("rpi.measurements")

# TODO: create a real object
# 20 is a first buffer dimension
buffer = [[0, 0] for i in range(20)]  # [ [value, nan appeared before a real measure] , ... ]


class Metrics:
    def __init__(self, measure: dict, mono_phased_list: list):
        """
        measure: dict = {"power_available": power, 1: power, 2, ..., n}
        power is int
        """
        self._available_power = measure["available_power"]
        self._production = measure["production"]  # TODO: property?
        self._consumption = measure["consumption"]  # TODO: property?
        self._cp_metrics = [measure[i] for i in range(1, CONF.get("cp") + 1)]
        self._timestamp = datetime.now()
        # If system is only mono, then ALL is only mono
        self._mono_erogation_list = mono_phased_list

    @property
    def available_power(self):
        return self._available_power

    @property
    def timestamp(self):
        return self._timestamp

    def is_mono(self, n: int):
        return self._mono_erogation_list[n - 1]

    def get_cp_power(self, n: int):
        return self._cp_metrics[n - 1]

    def dictionarize(self):
        dic = {
            "available_power": self.available_power,
            "production": self._production,
            "consumption": self._consumption,
            "timestamp": str(self.timestamp)
        }
        for i, cs in enumerate(self._cp_metrics):
            dic[i + 1] = cs
        return dic

    def jsonize(self):
        return json.dumps(self.dictionarize())

    def __repr__(self):
        return self.jsonize()


class Measurements(Thread):
    def __init__(self, shared_last_measure: AtomicResource, thread_status: ThreadStatus, ipsum_buffer: AtomicResource):
        super().__init__(daemon=True)
        self._shared_last_measure = shared_last_measure
        self._thread_status = thread_status
        self._ipsum_buffer = ipsum_buffer
        self._ser = serial.Serial("/dev/ttyAMA0", 38400, timeout=10)
        logger.info("Serial port initialized")

    def reset_ser(self):
        self._ser = serial.Serial("/dev/ttyAMA0", 38400, timeout=10)
        logger.warning("Serial port resetted")

    def run(self):
        while True:
            try:
                line = self._ser.readline()
                if line != "":
                    smart_debug.raw_serial(line)
                    # CS in Metrics_Dict are with numbers as keys
                    metrics_dict, mono_phased_list = parse(line, self._ipsum_buffer)
                    if metrics_dict == {}:
                        continue
                    for i in range(1, CONF.get('cp') + 1):
                        if metrics_dict[i] < PWRATT_CUTOFF:
                            metrics_dict[i] = 0
                    self._thread_status.measurements_ok()
                    metrics = Metrics(metrics_dict, mono_phased_list)
                    self._shared_last_measure.write(metrics)

                    # Smart debug hooks
                    smart_debug.last_measure(metrics)
                else:
                    self.reset_ser()
            except serial.SerialException as exc:
                self._thread_status.measurements_err(1)  # TODO: errcode
                logger.error("Serial port exception handled", exc_info=exc)
                self.reset_ser()
            except Exception as exc:
                self._thread_status.measurements_err(1)  # TODO: errcode
                logger.error("Unable to complete the Measurement parsing cycle", exc_info=exc)
                self.reset_ser()


def parse(measurements_string: bytes, ipsum_buffer: AtomicResource) -> (dict, list):
    """
        return metrics dict and mono list with for every charge points defined in conf
    """
    # power used
    try:
        # Clear some \0 that can appear in the leading 11
        measurements_string = measurements_string.replace(b"1\x001", b"11").strip()
        default_factor = CONF.get("default_calibration_factor")
        power_levels = []
        for i, x in enumerate(measurements_string.split(b" ")):
            if i == 0:
                if int(float(x)) == 11:
                    power_levels.append(11)  # All the code after this expected the 0-pos to contain a unused value
                    continue
                else:
                    logger.warning("String from serial without leading 11")
            if i > len(buffer):
                buffer.append([0, 0])
            if x.lower() == b'nan':
                can_ignore = True
                for cp in range(1, CONF.get('cp') + 1):
                    clamps = CONF.get("cs_{}".format(cp))
                    if i in clamps:
                        can_ignore = False
                for c in CONF.get('production'):
                    if i in c["clamps"]:
                        can_ignore = False
                for c in CONF.get('building'):
                    if i in c["clamps"]:
                        can_ignore = False
                if can_ignore:
                    continue
                value = buffer[i-1][0]
                if buffer[i-1][1] >= CONF.get("nan_buffer_length"):
                    raise ValueError("Not A Number found outside the buffer configuration")
                buffer[i-1][1] += 1
            else:
                calibration_factor = default_factor
                for entry in CONF.get("specific_calibration_factors"):
                    if entry.get("clamp") == i:
                        calibration_factor = entry.get("factor")
                        break
                value = int(float(x) * calibration_factor)
                buffer[i-1][0] = value
                buffer[i-1][1] = 0
            power_levels.append(value)

        if len(CONF.get("specific_calibration_factors")) != 0 or default_factor != 1.0:
            smart_debug.raw_serial_after_calibration([elem[0] for elem in buffer])

        chargepoint_power = {}
        mono_phased = []

        # cs_1 to cs_N
        for i in range(1, CONF.get('cp') + 1):
            clamps = CONF.get("cs_{}".format(i))
            if len(clamps) == 0:
                pass
            elif len(clamps) == 1:
                # Monophase
                chargepoint_power[i] = power_levels[clamps[0]]
                mono_phased.append(True)
            elif len(clamps) == 2:
                if power_levels[clamps[0]] > CLAMP_CUTOFF and power_levels[clamps[1]] > CLAMP_CUTOFF:
                    # Three-phase (overestimates the three-phase consume)
                    chargepoint_power[i] = max(power_levels[clamps[0]], power_levels[clamps[1]]) * 3
                    mono_phased.append(False)
                else:
                    # Monophase
                    chargepoint_power[i] = max(power_levels[clamps[0]], power_levels[clamps[1]])
                    mono_phased.append(True)
            elif len(clamps) == 3:
                if power_levels[clamps[0]] > CLAMP_CUTOFF and power_levels[clamps[1]] > CLAMP_CUTOFF and power_levels[clamps[2]] > CLAMP_CUTOFF:
                    # Three-phase
                    chargepoint_power[i] = sum([power_levels[clamps[i]] for i in range(3)])
                    mono_phased.append(False)
                else:
                    # Monophase
                    chargepoint_power[i] = max([power_levels[clamps[i]] for i in range(3)])
                    mono_phased.append(True)
    except Exception as exc:
        logger.error("Impossible to determinate power in use", exc_info=exc)
        raise RuntimeError
    # power_available
    final_dict = add_power_balance(power_levels, chargepoint_power, ipsum_buffer)
    return final_dict, mono_phased


def add_power_balance(split: [int], chargepoint_dict: {int: int}, ipsum_buffer: AtomicResource) -> dict:
    """
    return the dictionary with the measurments "production", "consumption" (building), "available_power"
    """
    try:
        production = 0
        consumption = 0  # building consumption
        available_power = 0
        if CONF.get("with_scatolino"):
            # TODO: How to populate dict production and consumption if we are using Scatolino?
            available_power += get_power_scatolino()
            if CONF.get("scatolino_include_chargepoint"):
                for i in range(1, CONF.get("cp")+1):
                    available_power += chargepoint_dict[i]
        else:

            def parse_mph_tph_list(mph_tph_list: list) -> int:
                """parser for Mph and Tph lists"""
                result = 0
                for entry in mph_tph_list:
                    phase = entry.get("phase")
                    clamps = entry.get("clamps")
                    if phase.lower().startswith("mono"):
                        # Monophased
                        result += split[clamps[0]]
                    elif phase.lower().startswith("three"):
                        # Three-phased
                        if len(clamps) == 1:
                            result += split[clamps[0]] * 3
                        elif len(clamps) == 2:
                            # Use the average to accurately estimate the third clamp value
                            avg_clamp = (split[clamps[0]] + split[clamps[1]])/2
                            result += avg_clamp * 3
                        elif len(clamps) == 3:
                            result += sum(split[clamps[x]] for x in range(3))
                return result

            total_cp_consumption = sum(chargepoint_dict[i + 1] for i in range(CONF.get("cp")))

            # production counting
            if CONF.get("production_counting"):
                production = parse_mph_tph_list(CONF.get("production"))
            # building consumption
            if CONF.get("building_counting"):
                consumption = parse_mph_tph_list(CONF.get("building"))
                building = int(consumption)
                if CONF.get("building_include_chargepoint"):
                    building -= total_cp_consumption
                else:
                    consumption += total_cp_consumption
            else:
                consumption = total_cp_consumption
                building = 0
            # retrieve Ipsum available power
            if CONF.get("with_ipsum"):
                max_inactivity = timedelta(seconds=CONF.get("ipsum_timeout"))
                ipsum_data = ipsum_buffer.read()
                ipsum_avalpower = 0
                time_delta = datetime.now(pytz.UTC) - ipsum_data.timestamp
                if time_delta > max_inactivity:
                    raise RuntimeError(
                        f"Ipsum data are out-of-date by {time_delta.total_seconds()} s"
                    )
                # if building_include_chargepoint, we want to remove cp power from building or ipsum
                if CONF.get("building_include_chargepoint") and not CONF.get("building_counting"):
                    ipsum_avalpower += total_cp_consumption
                ipsum_avalpower += ipsum_data.available_power
            else:
                ipsum_avalpower = 0
            # base available power
            available_power = ipsum_avalpower + production - building
        # Subtract unpilotated cs from available_power (they have building-like priority)
        for cp_num in CONF.get("disable_pilotage_on_cs"):
            available_power -= chargepoint_dict[cp_num]
        # fixed power from grid always available
        available_power += int(CONF.get("fixed_power_from_grid"))
        # check if respect the guaranteed minimum power level
        min_power = int(CONF.get("guaranteed_min_power"))
        available_power = max(available_power, min_power)
        # check if you're overcapping max_available_power
        max_available_power = CONF.get("max_available_power")
        if max_available_power is not None:
            available_power = min(available_power, int(max_available_power))
        final_dict = {**chargepoint_dict,
                      "available_power": available_power,
                      "production": production,
                      "consumption": consumption}
        return final_dict
    except Exception as exc:
        logger.error("Impossible to determinate available power", exc_info=exc)
        raise RuntimeError


def get_power_scatolino() -> int:
    """
        get scatolino's informations
    """
    result = 0
    db = None
    # TODO: Think if some 30sec cache is needed to reduce db load
    try:
        db = pymysql.connect(
            host=secrets['scatolino_host'],
            user=secrets['scatolino_user'],
            password=secrets['scatolino_password'],
            db=secrets['scatolino_db']
        )
        # TODO: We can delegate Mono/Three-phased calculation to the SQL Query?
        with db.cursor() as cursor:
            query = secrets['scatolino_query'].format(
                CONF.get("scatolino_calculation"), "TimeHuman", CONF.get("scatolino")
            )
            cursor.execute(query)
            fetch_res = cursor.fetchone()
            result = int(fetch_res[0])
            last_time = fetch_res[1]
            smart_debug.scatolino_power(result, last_time)
            max_inactivity = timedelta(seconds=CONF.get("scatolino_timeout"))
            time_delta = datetime.now() - last_time
            if time_delta > max_inactivity:
                raise RuntimeError(f"Scatolino did not sent new data in {time_delta.total_seconds()}")
    except Exception as exc:
        logger.error("Connection error with scatolino", exc_info=exc)
        raise RuntimeError
    finally:
        if db is not None:
            db.close()
    return result
