import logging
from threading import Thread
from time import sleep

from standard_raspberry.utils.conf import CONF
from standard_raspberry.core.cpmanager import CPManager
from standard_raspberry.utils.sync import ThreadStatus
from standard_raspberry.core import smart_debug

logger = logging.getLogger("rpi.supply")


class Supply(Thread):
    def __init__(self, cp_manager: CPManager, thread_status: ThreadStatus):
        super().__init__(daemon=True)
        self._cp_manager = cp_manager
        self._thread_status = thread_status

    def run(self):
        # Reset to 0 every chargepoint at the beginning
        # for i in range(CONF.get("cp")):
        #     self._cp_manager.reset_cp(i + 1)
        # TODO: I want this everytime we exit from fallback in no order mode
        # Retry to do the no order first init if something fail
        while True:
            try:
                self._cp_manager.no_order_first_initialization()
            except Exception as exc:
                logger.error("Error during first initialization, restarting it after 3 seconds", exc_info=exc)
                sleep(3)
            else:
                break
        # Main Loop
        supply_loop_timing = CONF.get("supply_loop_timing")
        # If Solar i want the first wait to be longer than normal
        first_loop_flag = not CONF.get("receive_orders")
        if CONF.get("receive_orders"):
            sleep(16)  # Give time to the other threads to start correctly
        while True:
            try:
                # Check other thread status
                measuremenets_code = self._thread_status.status_code_measurements()
                orders_code = self._thread_status.status_code_orders()
                sendmetrics_code = self._thread_status.status_code_sendmetrics()
                if measuremenets_code != 0:
                    logger.error(f"Power supply cycle in Fallback for Measurements error {measuremenets_code}")
                    self._cp_manager.erogate_fallback()
                elif orders_code != 0:
                    logger.error(f"Power supply cycle in Fallback for Orders error {orders_code}")
                    self._cp_manager.erogate_fallback()
                elif sendmetrics_code != 0 and CONF.get("receive_orders"):
                    logger.error(
                        f"Power supply cycle (QRcode enabled) in Fallback Mode for SendMetric error {sendmetrics_code}")
                    self._cp_manager.erogate_fallback()
                else:
                    self._cp_manager.erogate()
            except Exception as exc:
                logger.critical("Unable to complete the Supply cycle, going Fallback", exc_info=exc)
                self._cp_manager.erogate_fallback()

            smart_debug.global_status(self._cp_manager, self._thread_status)
            # Sleep between cycles
            if first_loop_flag:
                sleep(60)  # First Loop loooooonger
                first_loop_flag = False
            else:
                sleep(supply_loop_timing)
