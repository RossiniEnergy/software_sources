import logging
from multiprocessing import Queue

import requests

from standard_raspberry.utils.conf import CONF
from standard_raspberry.core.cpmanager import CPManager
from standard_raspberry.utils.sync import AtomicCounter

logger = logging.getLogger("rpi.recovery")


def _get_cs_state(cs_id: int) -> int:
    r = requests.get("{}{}".format(CONF.get('get_cs_state_url'), cs_id))
    return 1 if r.json().get("ischarging") else 0


def _get_cs_id_list() -> [int]:
    park_name = CONF.get('park_name')
    data = requests.get("{}{}".format(CONF.get('get_cs_list_url'), park_name))
    return data.json().get("cs_id_list")


def _get_charge_states() -> {int: int}:
    """
        retrieve from the server the list of the charge states for this device
    """
    nb_cp = CONF.get('cp')
    cs_id_list = _get_cs_id_list()
    charge_states = {}
    for i in range(nb_cp):
        charge_states[i + 1] = _get_cs_state(cs_id_list[i])
    return charge_states


def recover_states(cs_list: CPManager, timer_queue: Queue, nb_charging: AtomicCounter):
    """
        restore the states of the charge points before the reboot
    """
    logger.info("Restoring charging station status from remote db")
    for idx in range(CONF.get("cp")):
        cs_list.flag_charging(idx + 1, False)

    states = _get_charge_states()

    charging_list = [idx for idx, state in states.items() if state == 1]
    if len(charging_list) != 0:
        for idx in charging_list:
            cs_list.flag_charging(idx, True)
            nb_charging.increment()
        timer_queue.put(CONF.get("high_activity_metrics_timer"))
    else:
        timer_queue.put(CONF.get("low_activity_metrics_timer"))
