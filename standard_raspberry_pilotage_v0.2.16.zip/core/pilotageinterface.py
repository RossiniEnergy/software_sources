import logging

from bisect import bisect_left
from abc import ABC, abstractmethod
from threading import Lock

# noinspection PyUnresolvedReferences
import RPi.GPIO as GPIO
# noinspection PyUnresolvedReferences
import spidev

from standard_raspberry.utils.conf import CONF

logger = logging.getLogger('rpi.pilotageinterface')


class HardwareInterface(ABC):
    @abstractmethod
    def __init__(self, _max_cp_number: int):
        pass

    @abstractmethod
    def apply_power_level(self, cp_number: int, power_level: int):
        pass

    @abstractmethod
    def reset(self):
        pass

    @classmethod
    @abstractmethod
    def get_power_list(cls, mono: bool) -> [int]:
        pass

    @classmethod
    @abstractmethod
    def get_power_given_level(cls, mono: bool, level: int) -> int:
        pass

    @classmethod
    @abstractmethod
    def get_lower_level_given_power(cls, mono: bool, power: int) -> int:
        pass

    @classmethod
    @abstractmethod
    def get_higher_level_given_power(cls, mono: bool, power: int) -> int:
        pass

    @classmethod
    @abstractmethod
    def get_max_power_level(cls) -> int:
        pass

    # TODO: Add zero_power_level if offset is reqeuired


def hardware_class():
    pilotage_version = CONF.get("hardware_pilotage_version")
    if pilotage_version == 0:
        return GPIOBoard
    elif pilotage_version == 1:
        return DigitalPotentiometer
    else:
        logger.critical("INVALID HARDWARE PILOTAGE VERSION")
        import sys
        sys.exit(1)


class GPIOBoard(HardwareInterface):
    GPIOS = {
        1: (18, 17, 8),
        2: (23, 22, 27),
        3: (7, 25, 24),
        4: (12, 6, 5),
        5: (16, 19, 13),
        6: (21, 20, 26),
    }

    LEVEL = {
        0: (0, 1, 0),
        1: (0, 1, 1),
        2: (0, 0, 0),
        3: (0, 0, 1),
        4: (1, 1, 0),
        5: (1, 1, 1),
        6: (1, 0, 0),
        7: (1, 0, 1),
    }

    MAX_POWER_LEVEL = 7  # Included

    # Power corresponding to every level if the user is three-phased
    MAX_POWER_FOR_LEVEL_THREE = [0, int(4212 / 2), 4212, 9126, 14040, 17550, 20358, 22464]

    # The power level 1 can't charge most of the cars, the value is 1/2 of power level 2
    #  We use this value as a "full charge level" to know if a car is almost fully charge

    @classmethod
    def _get_gpio_given_cpnum(cls, charge_point_number):
        """
            charge_point_number int: the number of the charge_point_number
            return tuple: return gpios to manage the power of the charge point
        """
        return cls.GPIOS.get(charge_point_number)

    @classmethod
    def _get_level_bits(cls, level):
        """
            return wich pin need power for each level
            :level int: level of charge wanted
            :return tuple: gpios
        """
        if level > cls.MAX_POWER_LEVEL:
            level = cls.MAX_POWER_LEVEL
        return cls.LEVEL.get(level)

    def __init__(self, max_cp_number: int):
        assert max_cp_number >= 1
        out = "Hardware Interface 0 Monophased Power Levels:\n"
        for i, power in enumerate(self.get_power_list(True)):
            idx = f"{i}:"
            out += f"\t{idx:<3} {power:>4}W\n"
        logger.info(out)
        self.max_cp_number = max_cp_number
        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BCM)
        self.reset()

    def apply_power_level(self, cp_number: int, power_level: int):
        assert power_level <= self.MAX_POWER_LEVEL
        gpios = self._get_gpio_given_cpnum(cp_number)
        pin_level = self._get_level_bits(power_level)
        if pin_level[0]:
            GPIO.output(gpios[0], GPIO.HIGH)
        else:
            GPIO.output(gpios[0], GPIO.LOW)
        if pin_level[1]:
            GPIO.output(gpios[1], GPIO.HIGH)
        else:
            GPIO.output(gpios[1], GPIO.LOW)
        if pin_level[2]:
            GPIO.output(gpios[2], GPIO.HIGH)
        else:
            GPIO.output(gpios[2], GPIO.LOW)

    def reset(self):
        for i in range(0, self.max_cp_number):
            gpios = self._get_gpio_given_cpnum(i + 1)
            GPIO.setup(gpios[0], GPIO.OUT)
            GPIO.setup(gpios[1], GPIO.OUT)
            GPIO.setup(gpios[2], GPIO.OUT)
            self.apply_power_level(i + 1, 0)

    @classmethod
    def get_power_list(cls, mono: bool) -> [int]:
        if mono:
            return list(map(lambda p: int(p / 3), cls.MAX_POWER_FOR_LEVEL_THREE))
        else:
            return cls.MAX_POWER_FOR_LEVEL_THREE

    @classmethod
    def get_power_given_level(cls, mono: bool, level: int) -> int:
        if level > cls.MAX_POWER_LEVEL:
            level = cls.MAX_POWER_LEVEL
        return cls.get_power_list(mono)[level]

    @classmethod
    def get_lower_level_given_power(cls, mono: bool, power: int) -> int:
        """
            return the immediately lower charging level for a needed power
        """
        return max(bisect_left(cls.get_power_list(mono), power) - 1, 0)

    @classmethod
    def get_higher_level_given_power(cls, mono: bool, power: int) -> int:
        """
            return the immediately greater charging level for a needed power
        """
        return max(bisect_left(cls.get_power_list(mono), power), 0)

    @classmethod
    def get_max_power_level(cls) -> int:
        return cls.MAX_POWER_LEVEL


# TODO: Complete the definition of this class
class DigitalPotentiometer(HardwareInterface):

    # Old Fit
    # @classmethod
    # def _convert_power_to_step(cls, power):
    #     a = 3.3492e-7
    #     b = 1.9939e-3
    #     c = 2.3044192
    #     return int(a * power ** 2 + b * power + c)

    MONOPHASE_LEVEL = [0, int(1599 / 6), int(1599 / 5), int(1599 / 4), int(1599 / 3), int(1599 / 2), 1599, 1868, 2156,
                       2412, 2672, 2921, 3168, 3406, 3632, 3864, 4086, 4306, 4508, 4716, 4920, 5107, 5298, 5476, 5667,
                       5836, 6010, 6183, 6336, 6502, 6653, 6810, 6961, 7107, 7251, 7390, 7531, 7661, 7799, 7926, 8055]

    LEVEL_SELECT = [0, 5, 7, 9, 11, 14, 18, 21, 25, 29, 34]

    @classmethod
    def get_power_list(cls, mono: bool) -> [int]:
        filtered_list = [power for i, power in enumerate(cls.MONOPHASE_LEVEL) if i in cls.LEVEL_SELECT]
        if mono:
            return filtered_list
        else:
            return list(map(lambda p: int(p * 3), filtered_list))

    MAX_POWER_LEVEL = len(LEVEL_SELECT) - 1

    def __init__(self, _max_cp_number: int):
        out = "Hardware Interface 1 Monophased Power Levels:\n"
        for i, power in enumerate(self.get_power_list(True)):
            idx = f"{i}:"
            out += f"\t{idx:<3} {power:>4}W\n"
        logger.info(out)
        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BOARD)
        GPIO.setup(37, GPIO.OUT, initial=GPIO.LOW)
        self.spi = spidev.SpiDev()
        self.spi_lock = Lock()

    def apply_power_level(self, cp_number: int, power_level: int):
        assert 0 <= power_level <= self.MAX_POWER_LEVEL
        hardware_power_level = self.LEVEL_SELECT[power_level]
        with self.spi_lock:
            if cp_number <= 4:
                self.spi.open(0, 0)  # Open the communictaion with the potentiometer 1
                self.spi.max_speed_hz = 976000
                if cp_number == 1:
                    command_byte = 0b01110000
                elif cp_number == 2:
                    command_byte = 0b01100000
                elif cp_number == 3:
                    command_byte = 0b00000000
                elif cp_number == 4:
                    command_byte = 0b00010000
            else:
                self.spi.open(0, 1)  # Open the communictaion with the potentiometer 2
                self.spi.max_speed_hz = 976000
                if cp_number == 5:
                    command_byte = 0b01110000
                elif cp_number == 6:
                    command_byte = 0b01100000
                elif cp_number == 7:
                    command_byte = 0b00000000
                elif cp_number == 8:
                    command_byte = 0b00010000
            result = (self.spi.xfer([command_byte, hardware_power_level]) == [255, 255])
            # result -> Bool True if the message has been correctly sent

            self.spi.close()  # Close the communictaion with the potentiometer

            if result:
                # Switch on the potentiometers of the viridian if all the messages have been correctly sent
                GPIO.output(37, GPIO.HIGH)
            else:
                logger.error("Error sending the command to the potentiometer")
                # TODO: Insert an exception and manage it on the program everywhere is used apply_power_level
                # raise ValueError
                # GPIO.output(37, GPIO.LOW)
                self.reset()

    def reset(self):
        """
        This function is actually not a real reset but a simple
        "disconnect and reconnect the potentiometer to the bus"
        without a real reset of the IC.
        """
        from time import sleep
        GPIO.output(37, GPIO.LOW)
        sleep(2)

    @classmethod
    def get_power_given_level(cls, mono: bool, level: int) -> int:
        if level > cls.MAX_POWER_LEVEL:
            level = cls.MAX_POWER_LEVEL
        return cls.get_power_list(mono)[level]

    @classmethod
    def get_lower_level_given_power(cls, mono: bool, power: int) -> int:
        return max(bisect_left(cls.get_power_list(mono), power) - 1, 0)

    @classmethod
    def get_higher_level_given_power(cls, mono: bool, power: int) -> int:
        return max(bisect_left(cls.get_power_list(mono), power), 0)

    @classmethod
    def get_max_power_level(cls) -> int:
        return cls.MAX_POWER_LEVEL
