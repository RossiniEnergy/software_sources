import logging

import requests.exceptions

from standard_raspberry.core import smart_debug
from multiprocessing import Queue
from time import sleep

import pika

from standard_raspberry.utils.conf import CONF
from standard_raspberry.core.cpmanager import CPManager
from standard_raspberry.core.ipsum import IpsumMetrics, recover_ipsum
from standard_raspberry.core.states_recovery import recover_states
from standard_raspberry.utils.sync import AtomicCounter, AtomicResource, ThreadStatus

logger = logging.getLogger("rpi.orders")


def __build_callback(cs_list: CPManager, timer_queue: Queue, nb_charging: AtomicCounter, ipsum_buffer: AtomicResource):
    """
        builds a callback which will parse the message and will start or
        stop the charge for the requested charging point
    """

    def start_charge(num: int):
        with nb_charging.incremented() as _ctr:
            timer_queue.put(CONF.get("high_activity_metrics_timer"))
            cs_list.flag_charging(num, True)

    def stop_charge(num: int):
        with nb_charging.decremented() as ctr:
            if ctr == 0:
                timer_queue.put(CONF.get("low_activity_metrics_timer"))
            cs_list.flag_charging(num, False)

    def ipsum_receive(data: bytes):
        ipsum_data = IpsumMetrics.from_encoded_msg(data)
        ipsum_buffer.write(ipsum_data)

    def callback(_channel, _method, _properties, body):
        body = body.decode()

        # smart debug
        smart_debug.notify_new_order(body)

        command, data = body.split(" ")
        if command == "charge":
            start_charge(int(data))
        elif command == "stop_charge":
            stop_charge(int(data))
        elif command == "is":
            ipsum_receive(data.encode())
        else:
            logger.warning("Received invalid command \"%s\"", body)

    return callback


def __pika_init(cs_list: CPManager, timer_queue: Queue, nb_charging: AtomicCounter, ipsum_buffer: AtomicResource):
    queue_name = "CS_{}".format(CONF.get('park_name'))

    connection = pika.BlockingConnection(
        pika.URLParameters(
            CONF.get("rabbitmq_url"))
    )
    # TODO: Try to merge main_channel into consumer_channel
    main_channel = connection.channel()
    main_channel.queue_declare(
        queue=queue_name, auto_delete=True
    )
    consumer_channel = connection.channel()
    main_channel.queue_bind(
        exchange="chargingstation",
        queue=queue_name,
        routing_key=queue_name
    )

    consumer_channel.basic_consume(queue_name, __build_callback(cs_list, timer_queue, nb_charging, ipsum_buffer),
                                   auto_ack=True)

    return main_channel, consumer_channel


def orders(cs_list: CPManager, timer_queue: Queue, thread_status: ThreadStatus, ipsum_buffer: AtomicResource):
    while True:
        try:
            nb_charging = AtomicCounter(0)
            if CONF.get("receive_orders"):
                # reload every order state in case of reboot
                recover_states(cs_list, timer_queue, nb_charging)

            if CONF.get("with_ipsum") and thread_status.status_code_orders() > 0:
                # recover ipsum
                recover_ipsum(ipsum_buffer)

            main_channel, consumer_channel = __pika_init(cs_list, timer_queue, nb_charging, ipsum_buffer)

            logger.info("Start order consuming")
            thread_status.orders_ok()
            consumer_channel.start_consuming()
        # TODO: differentiate between exceptions
        except requests.exceptions.RequestException as exc:
            thread_status.orders_err(2)
            logger.error("Connection error from Requests")
        except Exception as exc:
            thread_status.orders_err(1)
            logger.error("Unexpected error when receiving orders", exc_info=exc)
        logger.error("Retrying order retrieve and start in 10 seconds...")
        sleep(10)
