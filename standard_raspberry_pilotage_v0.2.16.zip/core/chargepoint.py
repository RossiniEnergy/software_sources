import datetime
import logging

from standard_raspberry.core.pilotageinterface import hardware_class
from standard_raspberry.utils.conf import CONF

logger = logging.getLogger("rpi.chargepoint")

DEFAULT_PWRLV = CONF.get("lowest_power_level_default")
PWRATT_CUTOFF = CONF.get("min_mono_charging_power")
GHOST_POWER_HOTFIX = CONF.get("ghost_power_hotfix")
MAX_POWER_LEVEL = hardware_class().get_max_power_level()


class InternalState:
    def __init__(self, can_be_threephase: bool, pilotated=True):
        # Zero Level - Energy Balance
        self._power_level = 0
        self._power_budget = 0
        self._default_mono = not can_be_threephase
        self._is_mono = self._default_mono
        # First Level - Probe and Min Energy
        self._probe_active = False
        # Second Level - I'm charging something atm?
        self._charging = False
        # Third Level - Inhibit overpower distribution
        self._power_attenuation = MAX_POWER_LEVEL
        self._power_attenuation_cutoff = PWRATT_CUTOFF
        self._power_attenuation_timer = None
        self._pilotated = pilotated
        # Fourth Level - Don't Inhibit overpower when in Order mode when charge not started
        self._charge_started = False

    def serialize_for_debug(self, prefix) -> str:
        return (
            f"{prefix}Power level: {self._power_level}\n"
            f"{prefix}Power budget: {self._power_budget}\n"
            f"{prefix}Phase: {'mono' if self._is_mono else 'three'}\n"
            f"{prefix}Probe active: {self._probe_active}\n"
            f"{prefix}Charging: {self._charging}\n"
            f"{prefix}Power attenuation: {self._power_attenuation}\n"
            f"{prefix}Power att timer: {self._power_attenuation_timer}\n"
            f"{prefix}Power att cutoff: {self._power_attenuation_cutoff}\n"
            f"{prefix}Pilotated: {self._pilotated}\n"
            f"{prefix}Charge started: {self._charge_started}\n"
        )

    # Zero Level Methods
    def override_power_level(self, power_level: int):
        self._power_level = power_level
        self._power_budget = hardware_class().get_power_given_level(self._is_mono, power_level)

    @property
    def charge_started(self) -> bool:
        return self._charge_started

    @charge_started.setter
    def charge_started(self, x: bool):
        self._charge_started = x

    @property
    def pilotated(self):
        return self._pilotated

    @property
    def power_level(self) -> int:
        return self._power_level

    @property
    def power_budget(self) -> int:
        return self._power_budget

    @property
    def mono(self) -> bool:
        return self._is_mono

    @mono.setter
    def mono(self, x: bool):
        self._is_mono = x

    def reset_mono(self):
        self._is_mono = self._default_mono

    def give_all_power_unconditional(self, power) -> int:
        """
        give the max quantity of power to the power budget, enough to close the geatest level achievable
        and return the residue
        """
        if not self._pilotated:
            return power
        total_budget = self._power_budget + power
        self._power_level = hardware_class().get_lower_level_given_power(self._is_mono, total_budget)
        self._power_budget = hardware_class().get_power_given_level(self._is_mono, self._power_level)
        residue = total_budget - self._power_budget
        return residue

    def give_minimum_power(self, power) -> int:
        """
        give power to the power budget, starting from zero, enough to achieve the minimum working level
        """
        if not self._pilotated:
            return power
        if self._power_attenuation < DEFAULT_PWRLV:
            self._power_level = 0
            return power
        else:
            self._power_level = DEFAULT_PWRLV
            # HOTFIX MONOPHASE GHOST POWER
            if GHOST_POWER_HOTFIX:
                is_mono = False
            else:
                is_mono = self._is_mono
            self._power_budget = hardware_class().get_power_given_level(is_mono, self._power_level)
        return power - self._power_budget  # Residue

    def give_next_level_power(self, power) -> int:
        """
        give the min quantity of power to the power budget, enough to increase the level of 1, if possible
        and return the residue
        """
        if not self._pilotated:
            return power
        if self._power_level >= self._power_attenuation or self._power_level >= MAX_POWER_LEVEL:
            return power
        next_level_power_delta = self.request_next_level_total_power() - self._power_budget
        if power >= next_level_power_delta:
            self._power_level += 1
            self._power_budget += next_level_power_delta
            return power - next_level_power_delta
        else:
            return power

    def request_next_level_total_power(self) -> int:
        """
        request and get the amount of power needed by the next power_level
        """
        if not self._pilotated:
            return 0
        if self._power_level >= self._power_attenuation:
            return 0  # FIXME: ar u sure?
        # HOTFIX MONOPHASE GHOST POWER
        if GHOST_POWER_HOTFIX:
            is_mono = False
        else:
            is_mono = self._is_mono
        return hardware_class().get_power_given_level(is_mono, self._power_level + 1)

    def request_minimal_power(self):
        if not self._pilotated:
            return 0
        if self._power_level >= self._power_attenuation:
            return 0  # FIXME: ar u sure?
        # HOTFIX MONOPHASE GHOST POWER
        if GHOST_POWER_HOTFIX:
            is_mono = False
        else:
            is_mono = self._is_mono
        return hardware_class().get_power_given_level(is_mono, DEFAULT_PWRLV)

    def reset_budget(self):
        self._power_level = 0
        self._power_budget = 0

    # First Level
    @property
    def probe_active(self) -> bool:
        return self._probe_active

    @probe_active.setter
    def probe_active(self, x: bool):
        self._probe_active = x

    # Second Level
    @property
    def charging(self) -> bool:
        return self._charging

    @charging.setter
    def charging(self, x: bool):
        if not x:
            self._power_attenuation = MAX_POWER_LEVEL
            self._power_attenuation_timer = None
        self._charging = x

    # Third Level
    @property
    def power_attenuation_level(self):
        return self._power_attenuation

    @power_attenuation_level.setter
    def power_attenuation_level(self, x: int):
        assert 0 <= x <= MAX_POWER_LEVEL
        self._power_attenuation = x
        self._power_attenuation_timer = None

    @property
    def power_attenuation_timer(self):
        return self._power_attenuation_timer

    def new_power_attenuation_timer(self, duration: datetime.timedelta):
        self._power_attenuation_timer = datetime.datetime.now(datetime.timezone.utc) + duration

    def reset_power_attenuation_timer(self):
        self._power_attenuation_timer = None


class ChargePoint:
    def __init__(self, num: int, pilotated=True):
        assert num >= 1
        self._cpnum = num
        can_be_threephase = len(CONF.get(f"cs_{num}")) > 1
        self._state = InternalState(can_be_threephase, pilotated)

    def serialize_for_debug(self, prefix) -> str:
        return f"{prefix}CHARGEPOINT {self._cpnum}\n" + self._state.serialize_for_debug(prefix=prefix+"  ")

    @property
    def cpnum(self):
        return self._cpnum

    @property
    def state(self):
        return self._state

    # def manually_apply_charge_level(self, level: int):
    #     self.state.override_power_level(level)
    #     self.hardware.apply_power_level(level)

    def apply_power_budget(self, hardware_interface):
        if self.state.pilotated:
            hardware_interface.apply_power_level(self._cpnum, self.state.power_level)
        else:
            unpilotated_power_level = CONF.get('unpilotated_default_power_level')
            self.state.override_power_level(unpilotated_power_level)
            hardware_interface.apply_power_level(self._cpnum, unpilotated_power_level)
