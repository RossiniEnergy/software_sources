"""
Contains various constants and stuff
"""

BONKNET_SERVER = "SERVER_IP"
