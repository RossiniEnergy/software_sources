"""
Implementation of various commands for the bonknet client
"""
import re
import sys
import time
import shlex
import subprocess
from getpass import getpass
import requests
from config import BONKNET_SERVER
from minirpcrequester import MiniRpcRequester
from typing import Optional


def common_ssh_options(want_logs):
    """
    Creates a basic set of common options for ssh
    """
    basic = ["-o StrictHostKeychecking=no", "-o UserKnownHostsFile=/dev/null"]
    if not want_logs:
        return [*basic, "-o LogLevel=quiet"]
    return basic


def substitute_wildcards(user: str, cmd: str, port: int) -> str:
    """
    Take a command as argument and formats it with
    """
    return cmd \
        .replace("REMOTE_IP", f"{BONKNET_SERVER}")     \
        .replace("REMOTE", f"{user}@{BONKNET_SERVER}") \
        .replace("USER", user)                         \
        .replace("PORT", f"{port}")


def retrieve_alias(alias: str, discard_session: bool):
    """
    given an alias, tries to retrieve the remote id
    """
    session = requests.Session()
    has_cookies = False
    try:
        import appdirs
        import pickle
        import os

        datadir = appdirs.user_data_dir('bonk', 'RossiniEnergy')
        if not os.path.exists(datadir):
            os.makedirs(datadir)
        if discard_session:
            os.remove(datadir + '/session')
        else:
            try:
                with open(datadir + '/session', 'rb') as file:
                    try:
                        session.cookies.update(pickle.load(file))
                    except Exception as _:
                        pass
            except FileNotFoundError:
                pass
        has_cookies = True
    except ModuleNotFoundError:
        print("Warn: to enable a persistent session, install the modules `appdirs` and `pickle`",
              file=sys.stderr)

    myself = session.get("https://api.charge.re/v2/users/myself/")
    if myself.status_code == requests.codes.ok:
        print(f"Logged in as user '{myself.json()['username']}'", file=sys.stderr)
    else:
        print("You need to login to search for aliases.", file=sys.stderr)
        print("Username: ", file=sys.stderr, end='')
        username = input()
        pwd = getpass(stream=sys.stderr)
        resp = session.post(
            url="https://api.charge.re/v2/users/login/",
            json={"username": username, "password": pwd}
        )
        if resp.status_code != requests.codes.ok:
            print(f"error: {resp.text}", file=sys.stderr)
            return None
    if has_cookies:
        with open(datadir + '/session', 'wb') as file:
            pickle.dump(session.cookies, file)
    resp = session.get(f"https://api.charge.re/v2/ipsumconfigs/?alias={alias}")

    parks = resp.json()
    if len(parks) == 0:
        print(f"alias '{alias}' not found, using as identifier", file=sys.stderr)
        return alias
    if len(parks) > 1:
        while True:
            print("Choose a park: ", file=sys.stderr)
            print("\t0: exit", file=sys.stderr)
            for i, park in enumerate(parks, 1):
                print(f"\t{i}: {park['token']}", file=sys.stderr)
            print('> ', file=sys.stderr)
            choice = int(input())
            if choice == 0:
                sys.exit(0)
            if 1 <= choice <= len(parks):
                return parks[choice - 1]['token']
    return parks[0]['token']


def connect_ssh(user: str, port: int, want_ssh_logs: bool):
    """
    Connect via ssh to the requested port
    """
    with subprocess.Popen([
        "ssh", *common_ssh_options(want_ssh_logs), "-p", f"{port}", f"{user}@{BONKNET_SERVER}"
    ]) as proc:
        return proc.wait()


def connect_vnc(user: str, port: int, start_viewer: bool, want_ssh_logs: bool):
    """
    Connect via vnc to the requested port
    """
    time.sleep(2)
    bridge_cmd = (
        f"ssh -L 5900:localhost:5900 {user}@{BONKNET_SERVER} -p {port} -N -f " +
        " ".join(common_ssh_options(want_ssh_logs))
    )
    ssh_res = subprocess.run(shlex.split(bridge_cmd), check=False).returncode
    no_viewer = False

    print("Attempting to connect..", end='', flush=True, file=sys.stderr)
    failure_counter = 0
    while failure_counter < 10 and ssh_res == 255:
        if failure_counter % 3 == 0:
            print(".", end='', flush=True, file=sys.stderr)
        ssh_res = subprocess.run(shlex.split(bridge_cmd), check=False).returncode
        failure_counter = failure_counter + 1
        time.sleep(0.5)
    print("", file=sys.stderr)

    if ssh_res != 0:
        print(f"Error - cannot create a connection with the rpi (error code {ssh_res})", file=sys.stderr)
    else:
        try:
            if start_viewer:
                try:
                    vnc_res = subprocess.run(
                        ["vncviewer", "localhost::5900"], check=True
                    ).returncode
                except FileNotFoundError:
                    print("vncviewer executable not found", file=sys.stderr)
                    no_viewer = True
            if not start_viewer or no_viewer:
                print("Bridge to the remote opened\n"
                      "ip:   localhost\n"
                      "port: 5900\n"
                      "Example: vncviewer localhost::5900", file=sys.stderr)
                print("Press Ctrl-C to close the bridge", file=sys.stderr)
                while True:
                    try:
                        time.sleep(120)
                    except KeyboardInterrupt:
                        break
        except Exception as exc:
            print(f"Got exception while opening vnc subprocess: {exc}", file=sys.stderr)

    pgrep = subprocess.Popen(
        ("pgrep", "-f", bridge_cmd), stdout=subprocess.PIPE, stderr=subprocess.STDOUT
    )
    head = subprocess.Popen(
        ("head", "-1"), stdin=pgrep.stdout, stdout=subprocess.PIPE, stderr=subprocess.STDOUT
    )
    try:
        pid = int(subprocess.check_output(('awk', '"{print $2}"'), stdin=head.stdout,))
        pgrep.stdout.close()
    except ValueError:
        return -1

    try:
        print("killin'", file=sys.stderr)
        subprocess.run(('kill', f'{pid}'), check=True)
    except subprocess.CalledProcessError:
        subprocess.run(('kill', '-9', f'{pid}'), check=False)
    return vnc_res


def use_scp(user: str, port: int, source: str, target: str, want_ssh_logs: bool):
    """
    Copy a file from/to the remote
    """
    source = substitute_wildcards(user, source, port)
    target = substitute_wildcards(user, target, port)
    return subprocess.run([
        "scp", *common_ssh_options(want_ssh_logs), f'-P {port}', source, target,
    ], check=False).returncode
    """
    Copy a file from/to the remote
    """
    source = substitute_wildcards(user, source, port)
    target = substitute_wildcards(user, target, port)
    return subprocess.run([
        "scp", *common_ssh_options, f'-P {port}', source, target,
    ], check=False).returncode


def send_close(rpc: MiniRpcRequester, remote_id: str, port: int):
    """
    Send a CLOSE message to the server
    """
    reply = rpc.send(f"CLOSE {remote_id} {port}")
    tokens = shlex.split(reply)
    if tokens[0] != "DONE":
        error = " ".join(tokens[2:])
        print(f"Error: {error}", file=sys.stderr)
        return -1
    return 0


def send_restart(rpc: MiniRpcRequester, remote_id: str):
    """
    Ask a remote to restart
    """
    reply = rpc.send(f"RESTART {remote_id}")
    tokens = shlex.split(reply)
    if tokens[0] != "DONE":
        error = " ".join(tokens[3:])
        print(f"Error: {error}", file=sys.stderr)
        return -1
    if len(tokens) == 3:
        print(
            "Warning - the remote did not respond to the message. It could require a couple of "
            "minutes for the restart to be effective"
        , file=sys.stderr)
    return 0


def request_clientlist(rpc: MiniRpcRequester, pattern: Optional[str], raw: bool):
    """
    Request the clientlist to the server
    """
    reply = rpc.send("CLIENTLIST")
    tokens = shlex.split(reply)
    if tokens[0] != "DONE":
        error = " ".join(tokens[2:])
        print(f"Error: {error}", file=sys.stderr)
        return -1

    def clean_str(line):
        return line.strip(",").strip("[").strip("]")

    to_ignore = ['SERVER', 'name']
    parks = [clean_str(token) for token in tokens[2:] if ("amq." not in token and clean_str(token) not in to_ignore)]
    if pattern is not None:
        regex = re.compile(f".*{pattern}.*", re.IGNORECASE)
        matches = [regex.match(park)[0] for park in parks if regex.match(park)]
        # for match in matches:
        #     print(match)
        parks = matches

    ipsum_regex = re.compile(R"^IP(\d+)")
    parks.sort(key=str.casefold)
    ipsums = [ipsum_regex.match(park)[0] for park in parks if ipsum_regex.match(park)]
    parks = [park for park in parks if not ipsum_regex.match(park)]
    border = None
    if not raw and len(parks) != 0:
        border = '#' * 30
        parks_string = f"\n# {'Park list':^26} #\n"
        print(f"{border}{parks_string}{border}")
    for park in parks:
        print(park)

    if not raw and len(ipsums) != 0:
        ipsums_string = f"\n# {'Ipsum list':^26} #\n"
        print(f'\n{border}{ipsums_string}{border}')
    for ipsum in ipsums:
        print(ipsum)
    return 0


def is_online(rpc: MiniRpcRequester, remote_id: str):
    """
    Ask the server if a remote is online
    """
    reply = rpc.send(f"ISONLINE {remote_id}")
    tokens = shlex.split(reply)
    if tokens[0] != 'DONE':
        error = " ".join(tokens[2:])
        print(f"Error: {error}", file=sys.stderr)
        return -1
    return tokens[2].lower() == "true"


def interactive(rpc: MiniRpcRequester):
    """
    Run the interactive console
    """
    print("Starting interactive console - press Ctrl-D or Ctrl-C to exit")
    while True:
        try:
            query = input('command: ')
            reply = rpc.send(query)
            print(f"response: {reply}")
        except EOFError:
            break


def sshcommand(user: str, port: int, commands: list):
    """
    Connects to the remote using a custom command
    """
    full_command = substitute_wildcards(user, " ".join(commands), port)

    return subprocess.run(shlex.split(full_command), check=False).returncode


def sshexec(user: str, port: int, commands: list, want_ssh_logs: bool):
    """
    Connects to the remote and runs a command
    """
    with subprocess.Popen([
        "ssh", *common_ssh_options(want_ssh_logs),
        "-p", f"{port}", f"{user}@{BONKNET_SERVER}", "-t", " ".join(commands)
    ]) as proc:
        return proc.wait()
