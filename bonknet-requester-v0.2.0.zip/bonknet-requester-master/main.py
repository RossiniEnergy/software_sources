"""
the main for the bonknet requester
"""
import sys
import time
import shlex
import argparse
import pika
from minirpcrequester import MiniRpcRequester
from commands import (
    connect_ssh, connect_vnc, use_scp, 
    send_close, send_restart, request_clientlist, is_online,
    sshcommand, sshexec, interactive,
    retrieve_alias,
)


def parse_args_tmp():
    """
    parse arguments
    """
    additional_info = """Wildcards:
    REMOTE:       user@remote_id
    REMOTE_IP:    remote_id
    USER:         user
    PORT:         port

Examples:
    $ bonk demotest
        connect to remote "demotest" via ssh
    $ bonk ssh demotest
        the same as the previous
    $ bonk demotest --wait
        wait for the remote to be online, then connect
    $ bonk vnc Polnareffland1
        connect to remote "Polnareffland1" via vnc
    $ bonk scp demotest file_to_copy.txt REMOTE:~/
        copy "file_to_copy.txt" from your computer to the demotest's desktop
    $ bonk scp Polnareffland1 REMOTE:Downloads/taralli.jpg ~/Pictures
        copy "Downloads/taralli.jpg" from Polnareffland1 to the local Pictures folder
    $ bonk sshcommand demotest nc REMOTE_IP PORT
        connect to demotest using netcat
    $ bonk exec demotest touch /home/pi/new_remote_file.txt
        execute the command 'touch /home/pi/new_remote_file.txt' on the remote demotest

    You can check for specific help usage by running bonk <subcommand> without additional arguments:
    $ bonk ssh"""

    global_parser = argparse.ArgumentParser(
        formatter_class=argparse.RawTextHelpFormatter,
        epilog=additional_info
    )
    subparsers = global_parser.add_subparsers(title="subcommands", dest="mode")

    global_options = argparse.ArgumentParser(add_help=False)
    global_options.add_argument("remote_id", help="the name of the remote id")
    global_options.add_argument("--user", default="pi", help="user that must be used to connect")
    global_options.add_argument(
            "--alias", default=False, action="store_true",
            help="use the remote_id as an alias instead (IPSUM only)")
    global_options.add_argument(
            "--discard-session", default=False, action="store_true",
            help="discard the current session for charge.re and force a new login")
    global_options.add_argument(
            "--wait", default=False, action="store_true",
            help="wait for the remote to be online before connecting")
    global_options.add_argument(  # hehe
            "--chill", default=False, action="store_true", help=argparse.SUPPRESS
    )
    global_options.add_argument(
            "--show-ssh-logs", default=False, action="store_true",
            help="do not set the ssh log as quiet"
    )

    # ssh
    subparsers.add_parser(
        "ssh", help="connect via ssh to the given remote_id (default)", parents=[global_options]
    )

    # vnc
    vnc = subparsers.add_parser(
        "vnc", help="connect via vnc to the given remote_id", parents=[global_options]
    )
    vnc.add_argument(
        "--no-viewer",
        default=False, action='store_true',
        help="disable the viewer, retrieve only ip and port",
    )

    # scp
    scp = subparsers.add_parser(
        "scp", parents=[global_options],
        help="send a file from source to remote. This command uses scp syntax and must\n"
        "contain wildcards to work (see examples)."
    )
    scp.add_argument("source", help="the source to copy from")
    scp.add_argument("target", help="where to copy")

    # sshcommand
    command = subparsers.add_parser(
        "sshcommand", parents=[global_options],
        help="connect to the remote using the custom command passed ad argument.\n"
        "You must use wildcards to make the command work."
    )
    command.add_argument("command", nargs='+', help="the command you want to use for connecting")

    # exec
    exec_ = subparsers.add_parser(
        "exec", help="execute a command on a remote", parents=[global_options]
    )
    exec_.add_argument("command", nargs="+", help="the command to be executed on the remote")

    # request
    subparsers.add_parser(
        "request", parents=[global_options],
        help="request to the server to open a port for the given remote_id"
    )

    # close
    close = subparsers.add_parser(
        "close", parents=[global_options],
        help="request to the server to close the open port for the given remote_id"
    )
    close.add_argument("port", help="the port on the remote you want to close", type=int)

    # restart
    subparsers.add_parser(
        "restart", parents=[global_options],
        help="request a restart of the bonk service on remote_id"
    )

    # clientlist
    clientlist = subparsers.add_parser(
        "clientlist", help="retrieve the list with the clients in use and their ports"
    )
    clientlist.add_argument("pattern", nargs='?', help="an optional name to match (case insensitive)")
    clientlist.add_argument(
        '--raw', default=False, action="store_true", help="do not format the clientlist"
    )

    # interactive
    subparsers.add_parser(
        "interactive",
        help="open the interactive terminal to directly communicate with the relay server"
    )

    # help
    subparsers.add_parser("help", help="show this message")

    argv = sys.argv
    argv.pop(0)
    subcommands_with_args = [
        "ssh", "vnc", "scp", "sshcommand", "exec",
        "request", "close", "restart"
    ]
    subcommands = [*subcommands_with_args, "clientlist", "interactive", "help"]
    if len(argv) == 0:
        argv.append("--help")
    if len(argv) == 1 and argv[0] in subcommands_with_args:
        argv.append("--help")
    elif len(argv) > 0 and argv[0] not in subcommands:
        if "-h" in argv or "--help" in argv:
            argv = ["help"]
        else:
            argv.insert(0, "ssh")
    args = global_parser.parse_args(argv)
    if "chill" in args and args.chill:
        args.wait = True

    if args.mode == "help":
        global_parser.print_help()
        sys.exit(0)

    return args


def main():
    args = parse_args_tmp()
    mode = args.mode
    rpc = MiniRpcRequester()
    remote_id = args.remote_id if hasattr(args, 'remote_id') else None

    if "alias" in args:
        if args.alias and remote_id is not None:
            remote_id = retrieve_alias(remote_id, args.discard_session)
            if remote_id is None:
                return 0

    remote_id = f"'{remote_id}'" if remote_id is not None else None

    if mode == "interactive":
        interactive(rpc)
        sys.exit(0)
    if mode == "close":
        sys.exit(send_close(rpc, remote_id, args.port))
    if mode == "restart":
        sys.exit(send_restart(rpc, remote_id))
    if mode == "clientlist":
        sys.exit(request_clientlist(rpc, args.pattern, args.raw))

    if "wait" in args:
        if args.wait:
            dots = 0
            while not is_online(rpc, remote_id):
                message = f"remote {remote_id} is offline. Waiting..."
                print(f"\r{message}{'.' * dots}", end='', flush=True, file=sys.stderr)
                dots = dots + 1
                time.sleep(2)
            if dots > 0:
                if args.chill:
                    base_str = f"\r{message}{'.' * dots}"
                    for i in range(len(base_str)):
                        print(f"\r{' ' * i}\033[93m{('c','C')[i % 2]}\033[39;49m{base_str[i + 1:]}",
                              end='', flush=True, file=sys.stderr)
                        time.sleep(3.5 / len(base_str))
                    print(f'\r{" " * len(base_str)}', end='', flush=True, file=sys.stderr)
                else:
                    print('', file=sys.stderr)
        else:
            if not is_online(rpc, remote_id):
                print(f"Remote {remote_id} is not online.", file=sys.stderr)
                sys.exit(0)

    reply = rpc.send(f"REQUEST {remote_id}")
    tokens = shlex.split(reply)
    user = args.user
    sshlogs = "show_ssh_logs" in args and args.show_ssh_logs

    if tokens[0] != "DONE":
        error = " ".join(tokens[2:])
        print("Error: operation not done: ", error, file=sys.stderr)
        sys.exit(1)

    try:
        if len(tokens) > 3:
            port = tokens[2]

            def dispatch_command():
                if mode == "ssh":
                    status_code = connect_ssh(user, port, sshlogs)
                    if status_code == 255:
                        status_code = None
                elif mode == "vnc":
                    use_viewer = not args.no_viewer
                    status_code = connect_vnc(user, port, use_viewer, sshlogs)
                elif mode == "scp":
                    status_code = use_scp(user, port, args.source, args.target, sshlogs)
                elif mode == "sshcommand":
                    status_code = sshcommand(user, port, args.command)
                elif mode == "exec":
                    status_code = sshexec(user, port, args.command, sshlogs)
                elif mode == "request":
                    print(port)
                    status_code = 0
                elif mode != "close":
                    print(f"Unknown mode {mode}", file=sys.stderr)
                    status_code = 1
                return status_code

            status_code = None
            for _ in range(15):
                time.sleep(1)
                status_code = dispatch_command()
                if status_code is not None:
                    break
            else:
                print("Cannot connect with the requested client", file=sys.stderr)
        else:
            print("Requested remote id is not available", file=sys.stderr)
    except Exception as exc:
        print(f"got exception: {exc}", file=sys.stderr)
    finally:
        if port is not None and mode != "request":
            try:
                reply = rpc.send(f"CLOSE {remote_id} {port}")
            except pika.exceptions.StreamLostError:
                # Sometimes pika lose the connection during a ssh session. If that happens,
                #  the close request will fail; to prevent this, we need to restore the connection
                #  and send the close
                rpc = MiniRpcRequester()
                reply = rpc.send(f"CLOSE {remote_id} {port}")
    return status_code


if __name__ == '__main__':
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        pass
