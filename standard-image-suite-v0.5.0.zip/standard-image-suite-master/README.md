# Tools included in the suite

## Logging
- `follow_logs`: prints logs in real time
- `today_logs`: prints all the logs since today
- `last_boot_logs`: prints all logs since the last reboot
- `dump_logs`: prints all the logs present on the system

For a more granular search in the logs you can pass some options to those commands:  
`--since=<date and time>` will show all the logs registered after this date  
`--until=<date and time>` will show all the logs registered before this date  
Some examples:
```
dump_logs --since="2022-11-10"
dump_logs --since="2022-11-10 10:40:22" --until="2022-11-15"
dump_logs --since="yesterday"
```

## Pilotage and ipsum services
- `restart_service`: restarts the service
- `enable_service`: enable and start the service
- `disable_service`: diable and stop the service

## Configuration
- `edit_config`: edit the configuration
- `kb`: set the keyboard layout. Possible choiches: `fr`, `it`, `us` or `ansi`
    Example: `kb fr`, `kb ansi`
