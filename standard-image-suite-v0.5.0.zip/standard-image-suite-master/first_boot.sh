#!/bin/bash

set -euo pipefail

if [[ $EUID -ne 0 ]];
then
    echo "Run as root"
    exit 1
fi

readonly lockfile="/home/pi/remote_id.lock"
readonly first_image_mac="MAC"

# log [echo-args] [--no-header] <text>...
# Prints <text> to stderr.
# - echo-args: an arbitrary number of arguments starting with '-' to pass to `echo`.
# - --no-header: avoid writing the header in the message
# - <text>: an arbitrary number of arguments to print
#
# Forwards to 'echo' each argument starting with `-`, then an header
#  unless --no-header is specified, then the <text>. The whole output is
#  redirected to stderr.
function log {
    local echo_args="";
    local header="[first-boot] ";
    while [[ $# -gt 0 ]] && [[ $(echo "${1}x" | head -c 1) == '-' ]];
    do
        if [[ "$1" == "--no-header" ]];
        then
            header="";
        else
            echo_args="${echo_args} $1";
        fi;
        shift;
    done;
    echo $(printf "%s" "${echo_args}") "${header}"$@ >&2;
}

# identify_program
# Discover wether the raspberry is programmed to be a pilotage or an ipsum and return the
# correspondent name.
function identify_program {
    if [[ -e /etc/standard-raspberry/conf.toml ]];
    then
        echo "pilotage"
    elif [[ -e /etc/ipsum/conf.toml ]];
    then
        echo "ipsum"
    else
        echo ""
    fi
}

# assert_do_not_run_on_matrix_station
# Asserts the MAC is not the same as the matrix station, or terminate the program. Return nothing.
function assert_do_not_run_on_matrix_station {
    readonly this_station_mac="$(ip addr show eth0 | grep ether | awk '{ print $2 }')"
    if [[ "${this_station_mac}" == "${first_image_mac}" ]];
    then
        log "Running on the matrix station"
        exit 0
    fi
    log "Running on a new machine..."
}

# assert_do_not_run_on_a_configured_station
# Asserts the lockfile do not exists, or terminate the program. Return nothing.
# If there is already a lockfile, there is no need to run this script since the raspberry is already
# configured
function assert_do_not_run_on_a_configured_station {
    if [[ -f "${lockfile}" ]];
    then
        log "Lockfile already exists, exit."
        systemctl disable first_boot
        exit 0
    fi
}

# update
# Check if an update is available and eventually do it. Return nothing.
function update {
    log "Check if there's some update to do"
    readonly name="rossinienergy"
    update_repo ${name}
    oneifdoesntupdate="$({ apt -o Dir::Etc::sourcelist="sources.list.d/${name}.list" \
                               -o Dir::Etc::sourceparts="-" \
                               -o Dpkg::Options::="--force-confdef" \
                               -o Dpkg::Options::="--force-confold" \
                               -o Dpkg::Options::="--force-overwrite" \
                               list --upgradable || true; } | 2>/dev/null wc -l)"
    if [[ $oneifdoesntupdate -ne 1 ]]; then
        echo "There's an update to do! Wait for it..."
        set +e
        upgrade_rossinienergy_repo
        if [[ $? -eq 0 ]];  # maybe if [[ upgrade_rossinienergy_repo ]] is better
        then
            log "Update process Completed! Restarting service..."
            systemctl restart first_boot
        else
            log "Update suspended. Resuming the first boot configuration..."
        fi
        set -e
    else
        log "No update to do. Progress with the normal flow"
    fi
}

# generate_anydesk_id
# Generates and return AnyDesk ID
function generate_anydesk_id {
    if [[ "$(command -v anydesk)" == "" ]];
    then
        log "Anydesk is not installed in this machine."
        log "The code will be set to UNSUPPORTED"
        echo "UNSUPPORTED"
        return 0
    fi
    log "Stopping anydesk..."
    systemctl stop anydesk
    sleep 1
    log "Deleting old configurations..."
    rm -r /etc/anydesk/
    sleep 1
    log "Starting anydesk..."
    systemctl start anydesk
    sleep 2
    log -n "Getting id..."
    set +euo pipefail
    local anydesk_id="$(anydesk --get-id)"
    while [[ "${anydesk_id}" == "" ]];
    do
        log -n --no-header "."
        sleep 0.5
        anydesk_id="$(anydesk --get-id)"
    done
    set -euo pipefail
    log --no-header "!"
    log "Anydesk ID is ${anydesk_id}"
    log "Setting password..."
    echo "ilsoleil123" | anydesk --set-password
    sleep 2

    echo "${anydesk_id}"
}

# generate_random_id <program-type>
# - <program-type>: must be "pilotage" or "ipsum"
# Generates and return a park-id/bonknet-id
function generate_random_id_for {
    log "Checking for the park name..."
    # local -r running_as="$(identify_program)"
    local -r running_as="${1}"
    case ${running_as} in
        "pilotage")
            local -r conf_file="/etc/standard-raspberry/conf.toml"
            local -r match="park_name"
            local -r default_name="PARK_NAME"
            ;;
        "ipsum")
            local -r conf_file="/etc/ipsum/conf.toml"
            local -r match="ipsum_id"
            local -r default_name="IPSUM_ID"
            ;;
        *)
            # TODO: fire an error
            log "Error: generating random id for device of type '${running_as}'"
            exit 1
    esac
    set -e
    local id="$(grep "${match}" "${conf_file}" | cut -d '"' -f2)"
    if [[ "${id}" == "${default_name}" ]];
    then
        log "Found the default park name - generating a new one"
        id="$(date --utc '+%Y%m%d%H%M')"
        if [[ "${running_as}" == "ipsum" ]];
        then
            set +e
            local timestampid=$(curl NOWTIMEAPI)
            if [[ $? -eq 0 ]] && [[ "${timestampid}x" != "x" ]];
            then
                id="IP${timestampid%.*}"
            else
                log "Cannot retrieve the timestamp from the server. Retrying..."
                echo "IP_INVALID"
                return
            fi
            set -e
        fi
        sed -i "s/${default_name}/${id}/" "${conf_file}"
    fi
    local -r bonknet_id="${id}"
    log "Bonknet ID is ${bonknet_id}"
    systemctl restart bonknet-client

    echo "${bonknet_id}"
}

#teamviewer daemon stop
#sleep 1
#rm -rf /opt/teamviewer/config/global.conf
#teamviewer daemon start
#sleep 5
#teamviewer passwd <the-password>
#teamviewer license accept
#readonly teamviewer_id="$(teamviewer info | grep 'TeamViewer ID' | awk '{ print $5 }')"
#readonly teamviewer_id="-1"

# prepare_json_message <anydesk-id> <random-id>
# - <anydesk-id>: the ID generated by AnyDesk
# - <random-id>: a random-generated ID
# Prepare the json message for the newcomers registration
function prepare_json_message {
    local -r program="${1}"
    log "Preparing json message for the device..."
    # set +euo pipefail
    local -r anydesk_id="${2}" # $(generate_anydesk_id)"
    local -r random_id="${3}"  # $(generate_random_id_for \"${program}\")"
    read -r -d '' json_message << EOF
    {
        "anydesk": "${anydesk_id}",
        "parkname": "${random_id}",
        "teamviewer": "${program}"
    }
EOF
    # set -euo pipefail
    log "Waiting 5 second for security reasons..."
    sleep 5
    echo "${json_message}"
}

# register_in_newcomers <program-name>
# - <program-name>: must be "pilotage" or "ipsum"
# Register the device in newcomers
function register_in_newcomers {
    local -r anydesk_id="$(generate_anydesk_id)"
    while true;
    do
        local random_id="$(generate_random_id_for ${1})"
        if [[ "${random_id}" == "IP_INVALID" ]];
        then
            sleep 1;
            continue;
        fi
        local json_message=$(prepare_json_message "${1}" "${anydesk_id}" "${random_id}")
        #   4.1 - send IDs to the API and wait for a response
        log "Sending REST request with json data..."
        local response=$(curl -X POST -H "Content-Type: application/json" -d "${json_message}" \
            NEWCOMERAPI -w "%{http_code}" || true)
        #   4.2 - if the code is 200, the IDs have been registered, so we can disable the service;
        #         else goto 4.1 and try again
        log "Received response code ${response}"
        if [[ "${response}" == "200" ]];
        then
            # 4.3 - generates the lockfile
            printf "AnyDesk:\t${anydesk_id}\n"    > "${lockfile}"
            printf "TempParkname:\t${random_id}" >> "${lockfile}"
            log   "ID saved in ${lockfile}"
            systemctl disable first_boot
            log "Disabled first_boot service"
            return 0
        fi
        log "Error! Resending."
    done
}

# start_service_if_needed_for <program-name>
# - <program-name>: must be "pilotage" or "ipsum"
# Start the program, if required. Currently only ipsum needs to auto-start after being plugged
function start_service_if_needed_for {
    local -r running_as="${1}"
    case ${running_as} in
        "ipsum")
            log "Enabling and restarting ipsum.service"
            sudo systemctl enable ipsum.service
            sudo systemctl restart ipsum.service
            ;;
        *)
            log "No need to enable, nor restart, the ${running_as} service"
            ;;
    esac
}

function main {
    assert_do_not_run_on_matrix_station
    assert_do_not_run_on_a_configured_station
    local -r device_type="$(identify_program)"
    update
    register_in_newcomers "${device_type}"
    start_service_if_needed_for "${device_type}"
}

main
