#!/bin/bash
set -euo pipefail
if [[ $EUID -ne 0 ]];
then
    echo "Run as root"
    exit 1
fi

readonly password="<__UNDEFINED>"
if [[ "${password}" == "<__UNDEFINED>" ]];
then
    echo "Please edit the script and insert a password for anydesk access"
    exit 1
fi

systemctl stop anydesk
rm -r /etc/anydesk/service.conf
systemctl start anydesk
sleep 5
echo "${password}" | anydesk --set-password
anydesk --get-id > /home/pi/Desktop/anydesk_id.txt
chown pi:pi /home/pi/Desktop/anydesk_id.txt
echo "ID generated in ~pi/Desktop/anydesk_id.txt"
